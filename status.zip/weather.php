<?php
// GMRSlive  Mods for Supermon (c)2023 
// Dont use on anythin else
// v1.1
// v1.2  Multi weather chart system using old code from google carts. Based on my old weather station code.
//       For now this old code still works. If it stops I will have to learn the new API to upgrade it.
//       This places all the charts in one file. For now each chart has a seperate page. 
//       Any missing data is NULLed because google cant display empty data.
// v1.3  More error checking added
// v1.5  error checking for date
// v1.6  bug fix for blank fields
 
$verGMRS="v1.6";$releaseGMRS="2/4/2025";   $pageTitle="Weather Logs";
$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
$path         = "/etc/asterisk/local/mm-software";

$gpl=false;$betatest=false;$iframe=false;

include_once("$rootDir/status/config.php"); // includes the main settings

if (file_exists($fileAllMon)){$config = parse_ini_file($fileAllMon, true);}
else {print	"Couldn't load AllMon ";}




include_once("$rootDir/status/input.php"); 

$date = date('m-d-Y'); $yesterday = date('m-d-Y', strtotime('-1 day'));$yesterday1 = date('m-d-Y', strtotime('-2 day'));
$setChart="";$setColor="";$setColor="";$setname=""; $A_dataT=""; $setPageName="";
$log=""; $info="";$startDate="";$today_in= 0;$out_day=$date;$today="";
for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'log')  {  $log  = $fieldValues[$i]; }
if ($fieldNames[$i] == 'today'){  $today  = $fieldValues[$i]; }
}

//$datum,$the_temp,$heatIndex,$WindChill,$feelsLike,$dewpoint,$outhumi,$avgwind,$rainofdaily,$barometricPressure,$rainofyearly,$uv,$solarradiation,$gustspeed,$uv,$solarradiation,$gustspeed,$rainofmonthly,$maxdailygust,$barometricPressureABS

// Isolate the input from the function routines
if ($log=="temp"){      $info="temp";}
if ($log=="hum"){       $info="hum";}
if ($log=="wind"){      $info="wind";}
if ($log=="dir"){       $info="dir";}
if ($log=="rain"){      $info="rain";}
if ($log=="press"){     $info="press";}
if ($log=="uvi"){       $info="uvi";}
if ($log=="solar"){     $info="solar";}
if ($today=="1"){       $today_in=1;}
if ($today=="2"){       $today_in=2;$out_day=$yesterday;}
if ($today=="3"){       $today_in=3;}
if ($today=="4"){       $today_in=4;$out_day=$yesterday1;}
if(!$info){die;}

$mmlogfile = "$path/logs/weather.csv"; 
$G_dataT="";$st="";
if (is_readable($mmlogfile)) {
$fileIN = file($mmlogfile);

//$the_temp =$u[1]; $heatIndex=$u[2];$WindChill=$u[3];$feelsLike=$u[4];$dewpoint= $u[5];$outhumi  =$u[6];$avgwind  =$u[7];
//$rainofdaily=$u[8];$barometricPressure=$u[9];$rainofyearly =$u[10];$uv =$u[11];$solarradiation=$u[12];
//$gustspeed=$u[13];$rainofmonthly =$u[14];$maxdailygust;dir  
$lastDate="";  $lastMax="";
$i=0;
foreach($fileIN as $line){ 
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$line = str_replace('"', "", $line); // 01-06-2024-19:13:45,26.8, 
      
 $u = explode(",",$line);// 0 date 1=value

if(!$u[0]){continue;}// skip headers and blank footers
if (!isset($u[1])) {continue;}
if($u[1]=="the_temp"){continue;}// skip headers and blank footers Notice: Undefined offset: 1 in /srv/http/status/weather.php on line 71

 $adate = substr($u[0], 0,10);  
 $atime = substr($u[0], 11,8);
 $ltime = explode(":",$atime) ;
 $A = $ltime[0]; $T = round($A,0) ;
 $pm="am";

 if ($T >12 ){$T =($T -12);$pm="pm";}
 if ($T ==0 ){$T = 12;$pm="am";}
 if (strlen($T)< 2){$T = "0$T";}
if (isset($ltime[1])) {
    $timePMG = "$T:$ltime[1]$pm";
    if (isset($ltime[2])) {
        $timePM = "$T:$ltime[1]:$ltime[2] $pm";
    } else {
        // Handle the case where $ltime[2] is not set
        // For example, assign a default value or continue
        // $timePM = "$T:$ltime[1]:00 $pm"; // Assigning default seconds as '00'
        continue; // Skip this iteration if within a loop
    }
} else {
    // Handle the case where $ltime[1] is not set
    // For example, assign a default value or continue
    // $timePMG = "$T:00$pm"; // Assigning default minutes as '00'
    continue; // Skip this iteration if within a loop
}


if($today_in==1){if($adate <> $date){continue;}}
if($today_in==2){if($adate <> $yesterday){continue;}}
if($today_in==4){if($adate <> $yesterday1){continue;}}
if($today_in==3){if($adate != $date && $adate != $yesterday){continue;}}

  if(!isset($u[13])){$u[13]=0;}// gust
  if(!isset($u[14])){$u[14]=0;}// rainM
  if(!isset($u[15])){$u[15]=0;}//$maxdailygust       
  if(!isset($u[16])){$u[16]="";}//$barometricPressureABS     
  if(!isset($u[17])){$u[17]="";}//$winDir  
    
 if($info=="temp"){
 if($u[2]==""){$u[2]=$u[1];}
 if($u[3]==""){$u[3]=$u[1];}
 if($u[5]==""){$u[5]=$u[1];}
 $st ="$u[5],$u[2],$u[3],$u[1]";
  }
  
if($info=="rain"){ 
 if($u[10]==""){$u[10]=0;}//RainY
 if($u[14]==""){$u[14]=0;}//RainM
 if($u[8]==""){ $u[8] =0;}//RainD
 
 //if($u[14] => 90 or $u[10]=>2 00){continue;}
 
 $st ="$u[8],$u[14]";
  }
   
 if($info=="heat"){ if($u[2]==""){continue;}
 $st =$u[2];}

 if($info=="cool"){ if($u[3]==""){continue;}
 $st =$u[3];}

 if($info=="hum"){  if($u[6]==""){continue;}
 $st =$u[6];}
 
 if($info=="wind"){ 
 if($u[13]==""){$u[13]=0;} // gust
 if($u[7]==""){$u[7]=0;}
 if($u[15]==""){$u[15]=0;} //max
 
 //if($u[13] => 200 or $u[15] => 200){continue;}
 
 $st ="$u[7],$u[13],$u[15]";}
  
 
 
 // $barometricPressure=9  $barometricPressureABS=16  
 if($info=="press"){
 if($u[9]=="" and $u[16]==""){continue; }
 if($u[16]==""){$u[16]=$u[9];}
 if($u[9] ==""){ $u[9]=$u[16];}
 $st ="$u[9],$u[16]";}
 
 if($info=="uvi"){ if($u[11]==""){continue;} 
 $st =$u[11];}
 
 if($info=="solar"){ if($u[12]==""){continue;}  
 $st =$u[12];} 
   
 if($info=="dir"){ if($u[17]==""){continue;}  
 $st =$u[17]; if($st>360 or $st <=0){continue;}  
 $i++;
 if($A_dataT){ $A_dataT="$A_dataT,[$i,$st]\n";}
 else{$A_dataT="[$i,$st]\n";} 
 } 
   
 
 if($G_dataT){ $G_dataT="$G_dataT,['$adate $timePMG',$st]\n";}
 else{$G_dataT="['$adate $timePMG',$st]\n";}
 if(!$startDate){$startDate=$adate;}
 
$lastDate = $G_dataT;
 }


 if($info=="temp"){
 $setPageName="Temp Chart"; $help=1;
 $setChart="
 data.addColumn('string', 'X');  
 data.addColumn('number', 'Dewpoint'); 
 data.addColumn('number', 'Heat Index'); 
 data.addColumn('number', 'Wind Chill'); 
 data.addColumn('number', 'Temp');

";
 $setColor="
        series: { 0: { color: 'red' }},
        series: { 1: { color: 'red' }} ,
        series: { 2: { color: 'blue' }} ,
        series: { 3: { color: 'green' }}
        ";
$setname="temp F";
  }

if($info=="hum"){
 $setPageName="Humidity Chart"; $help=2;
 $setChart="
 data.addColumn('string', 'X');
 data.addColumn('number', 'Humidity');
";
$setColor="series: { 0: { color: 'green' }}";
$setname="%";
  }
  
if($info=="wind"){
 $setPageName="Wind Chart"; $help=3;
 $setChart="
 data.addColumn('string', 'X');
 data.addColumn('number', 'Avg Wind');
 data.addColumn('number', 'Gust');
 data.addColumn('number', 'Max Daily Gust');
";
$setColor="
series: { 0: { color: 'blue' }},
series: { 1: { color: 'red' }},
series: { 2: { color: 'green' }}
";
$setname="MPH";
  }
  
if($info=="rain"){
 $setPageName="Rain Chart";$help=4;
 $setChart="
 data.addColumn('string', 'X');
 data.addColumn('number', 'Rain Daily');
 data.addColumn('number', 'Rain Monthly');
";
$setColor="
series: { 0: { color: 'blue' }},
series: { 1: { color: 'green' }},
";
$setname="Inches";
  }

if($info=="uvi"){
 $setPageName="Ultraviolet Index"; $help=5;
 $setChart="
 data.addColumn('string', 'X');
 data.addColumn('number', 'UVI');
";
$setColor="series: { 0: { color: 'blue' }}";
$setname="Ultraviolet Index";
  }
  
 if($info=="solar"){
 $setPageName="Solar Radation"; $help=6;
 $setChart="
 data.addColumn('string', 'X');
 data.addColumn('number', 'Solar');
";
$setColor="series: { 0: { color: 'red' }}";
$setname="Solar Radiation";
  } 

 if($info=="press"){
 $setPageName="Air Pressure"; $help=7;  // Atmospheric pressure 
 $setChart="
 data.addColumn('string', 'X');
 data.addColumn('number', 'REL Pressure');
 data.addColumn('number', 'ABS Pressure'); 
";
$setColor="series: { 0: { color: 'blue' }}";
$setColor="series: { 0: { color: 'blue' }}";
$setname="Air Pressure";
  } 


  
$Gchart="
<script type=\"text/javascript\" src=\"https://www.google.com/jsapi\"></script>

<script type='text/javascript'>
google.load('visualization', '1', {packages: ['corechart', 'line']});
google.setOnLoadCallback(drawBackgroundColor);
function drawBackgroundColor() {
    var data = new google.visualization.DataTable();
$setChart
    data.addRows([ $G_dataT ]);
    var options = { 
    title: '$setPageName From $startDate to $out_day',
    hAxis: {title: 'Date'},
    vAxis: {title: '$setname'},
    backgroundColor: '#f1f8e9',
    $setColor
    };
    var formatter = new google.visualization.NumberFormat({
    fractionDigits: 2,
    });
    var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
    chart.draw(data, options);
    }
</script>";


if($info=="dir"){
$setChart="";
$setColor="";
$setColor="";
$setname="Wind Direction";

$setPageName="Wind Direction"; $help=33;
$Gchart="
<script type=\"text/javascript\" src=\"https://www.google.com/jsapi\"></script>
<script type=\"text/javascript\">
      google.load(\"visualization\", \"1\", {packages:[\"corechart\"]});
      google.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
         ['Date & Time ', 'Direction'],
$A_dataT

        ]);

        var options = {
          title: '$setPageName From $startDate to $out_day',
          hAxis: {title: 'Time', minValue: 0},
          vAxis: {title: 'Direction', minValue: 0, maxValue: 360},
          backgroundColor: '#f1f8e9',
          legend: 'none',
          colors: ['green'],

          pointSize: 3,
          series: {
                0: { pointShape: 'circle' }
            }


        };
        var chart = new google.visualization.ScatterChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
    </script>";





}




}
include_once("$rootDir/status/header.php"); 
print"<!-- This page was served to [$ipaddress] -->\n";
print "<!-- $c64 -->\n\n";
include_once("$rootDir/status/menu.php");

print"
<div align=\"center\">
<font color=\"GREEN\" size=\"6\">$setPageName</font><br>
";




print"</div>
<!-- Note. Uses old google charts code. Good as long as google supports the code -->


<div id=\"chart_div\"></div>";

print"<center>
<p>Weather log created by the node. [<a href='weather.php?log=$log&today=0'>All</a>] [<a href='weather.php?log=$log&today=4'>$yesterday1</a>] [<a href='weather.php?log=$log&today=2'>$yesterday</a>] [<a href='weather.php?log=$log&today=3'>Yesterday & Today</a>] [<a href='weather.php?log=$log&today=1'>$date only</a>]</p>";
//$width=500;$height=200;$in=$help;Show_help($in);


include ("$rootDir/status/inline-weather.php");
include_once("$rootDir/status/footer.php");

function Show_help($in){
global $width,$height,$in;
print "<a href=\"#\" onclick=\"window.open('/gmrs/help.php?help=$in', 'Help', 'width=$width,height=$height');\"><img src=\"/gmrs/images/help.gif\"></a>";
}

?>
