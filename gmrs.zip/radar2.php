<?php
// GMRSlive  Mods for Supermon (c)2023 
// Dont use on anythin else
// v1.1 

$verGMRS="v1.1";$releaseGMRS="1/11/2024";  
$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
$path         = "/etc/asterisk/local/mm-software";
include_once("$rootDir/gmrs/global.php");
include_once("$rootDir/gmrs/common.php"); 
$fileAllMon = "$rootDir/gmrs/admin/allmon.ini";       
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);// load the now secure file
include_once("$rootDir/gmrs/header.php"); 
include_once("$rootDir/gmrs/menu.php"); 
include_once ("$path/supermon_load_setup.php");  // get the lat long

print"
<iframe width=1200 height=520 src=\"/gmrs/radar-iframe.php\"></iframe>





";




include ("$path/supermon_weather.php");
include_once("$rootDir/gmrs/footer.php");
?>  











