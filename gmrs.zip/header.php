<?php
//
//  AllStarLink/ASL-Supermon is licensed under the GNU General Public License v3.0
//
// https://raw.githubusercontent.com/AllStarLink/ASL-Supermon/develop/LICENSE
// https://github.com/AllStarLink/ASL-Supermon/blob/develop/var/www/html/supermon/link.php
// https://www.gnu.org/licenses/gpl-3.0.en.html
//
//
// Totaly reformated as a modern php file. (NEW HEADER)
//
// $BACKGROUND_COLOR  $BACKGROUND_HEIGHT $CALL $TITLE_NOT_LOGGED $LOCATION $TITLE2  $REFRESH_DELAY $SMSERVERNAME

if(!isset($pageTitle)){$pageTitle="";}

$page3="";$ipaddress = "";$requestURL="";$d="";$uri="";$servername="";$Rdelay=1000;// preset varables 1000seconds=16min

$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
$path         = "/etc/asterisk/local/mm-software";


if(isset($_SERVER['HTTP_CLIENT_IP'])){           $ipaddress = $_SERVER['HTTP_CLIENT_IP'];}
if(isset($_SERVER['REMOTE_ADDR'])){              $ipaddress = $_SERVER['REMOTE_ADDR'];}
if(isset($_SERVER['REQUEST_URI'])){              $requestURL= $_SERVER['REQUEST_URI'];}
if(isset($_SERVER['SERVER_NAME'])){              $servername= $_SERVER['SERVER_NAME'];}


if ($requestURL){$d = explode('/', $requestURL);$d = array_pop($d);$uri = urldecode($d);}

if (preg_match("/link\.php\?nodes=(.+)$/", $uri, $matches)) { $page3= $matches[1];}

if (!empty($REFRESH_DELAY)) { if ($REFRESH_DELAY>=300){$Rdelay=$REFRESH_DELAY;}   }
$home = '/'; if (! empty($var1[1])) {$home="/" . $var1[1];}  // this holds /gmrs  but we are not using it??? 

print "
<!DOCTYPE html>
<html>
<head>
<title>GMRS Node Manager $pageTitle $servername $page3</title>\n";

print "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n";
print "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n";
print "<meta http-equiv='REFRESH' content='$Rdelay'; url='.$uri'>\n";
print "<meta name=\"home\" content=\"$home\">\n";// testing 
print "<meta name=\"description\" content=\"GMRS Node Manager\">\n";
print "<meta name=\"keywords\" content=\"gmrslive,gmrs,node manager,louisiana\">\n";
print "<meta name=\"robots\" content=\"noindex, nofollow\">\n";   
print "<meta name=\"generator\" content=\"GMRS Node Manager (c)2024 lagmrs.com\">\n";
print "<meta name=\"license1\" content=\"Contains code from ASL-Supermon Licensed under GNU General Public License v3.0\">\n";
print "<meta name=\"license2\" content=\"All new code for GMRS is Copyrighted 2023/2024 all rights reserved\">\n";
if($ipaddress){print "<meta name=\"client\" content=\"$ipaddress\">\n";}
print "<link rel=\"shortcut icon\" href=\"/gmrs/favicon.ico\" type=\"image/x-icon\">\n";
print "<link rel=\"icon\" href=\"/gmrs/favicon.ico\" type=\"image/x-icon\">\n";
print "<link type=\"text/css\" rel=\"stylesheet\" href=\"/gmrs/supermon.css\">\n";
print "<link type=\"text/css\" rel=\"stylesheet\" href=\"/gmrs/jquery-ui.css\">\n";
print "<script src=\"/gmrs/jquery-3.1.1.min.js\"></script>\n";
print "<script src=\"/gmrs/jquery-ui.min.js\"></script>\n";

if (isset($Gchart)){print $Gchart;}
else{include("/srv/http/gmrs/header-java.php");} // moved to ext file for easier editing.}

print"</head>\n";

include_once ("$path/supermon_load_setup.php");

//<div id="header" style="background-image: url(background.jpg); background-color: blue; height: 124px ">
//<div id="header" style="background-image: url(background.jpg); background-color: blue; height: 124px ">
//<div id="header" style="background-image: url('/srv/http/gmrs/images/background.jpg') background-color: blue height: 124px">

if (empty($BACKGROUND_COLOR))  { $BACKGROUND_COLOR ="blue";}
if (empty($BACKGROUND_HEIGHT)) { $BACKGROUND_HEIGHT="124px";}
//     background-repeat: no-repeat;/
print"<body>
<div id=\"header\" style=\"background-image: url('/gmrs/images/$banner.jpg'); background-color: $BACKGROUND_COLOR; height: $BACKGROUND_HEIGHT;\">\n
<div id=\"headerTitle\"><i>GMRS Supermon - $pageTitle</i></div>\n
<div id=\"headerTag\"><small><i>$CALL<br>$LOCATION<br>$node.node.gmrslive.com</small> <$TITLE2></i></div>\n";



// The image to the right
print"<div id=\"headerImg\">
<a href=\"http://www.gmrslive.com/\" target=\"_blank\">
<img src=\"/gmrs/images/gmrslive.gif\" style=\"border: 0px;\" alt=\"GMRS Live\"></a>";
//print"<img src=\"/gmrs/images/ast.gif\" style=\"border: 0px;\">";
print"</div>\n";
print"</div><div id=\"test_area\"></div>\n"; 

print"<!-- Header is licensed under https://www.gnu.org/licenses/gpl-3.0.en.html-->\n";
print"<!-- End Header -->\n";
?>
