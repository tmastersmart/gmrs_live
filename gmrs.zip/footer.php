<?php

$path       = "/etc/asterisk/local/mm-software";
include_once ("$path/supermon_footer.php");

print "</body></html>";
?>
