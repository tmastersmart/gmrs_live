<?php
print "<!-- start footer -->";

print "<br><br><small>This is the <a href=http://www.gmrslive.com>GmrsLive.com</a> network. GMRS Supermon node manager</small><img src=/gmrs/images/php.gif>";

print "</body></html>";
?>
