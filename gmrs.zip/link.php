<?php 
//
//  AllStarLink/ASL-Supermon is licensed under the GNU General Public License v3.0
//
// https://raw.githubusercontent.com/AllStarLink/ASL-Supermon/develop/LICENSE
// https://github.com/AllStarLink/ASL-Supermon/blob/develop/var/www/html/supermon/link.php
// https://www.gnu.org/licenses/gpl-3.0.en.html

// Modified in acordance with GPL
// 
// 
// Main status page short and sweet reformated in PHP code
// 
// v2.6 New paths to work with custom servers
// v2.7 slight cleanup
// v3 1/26 cleanup link status box
$versionL="v3.0";$releaseGMRS="1/26/2024"; $verGMRS=$versionL; $betatest=false;  $pageTitle="Status Page";
$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
$path         = "/etc/asterisk/local/mm-software";  
include_once("$rootDir/gmrs/global.php"); // includes the local settings
include_once("$rootDir/gmrs/common.php"); // includes the main settings
$fileAllMon = "$rootDir/gmrs/admin/allmon.ini";
if (file_exists($fileAllMon)){$config = parse_ini_file($fileAllMon, true);}
else {print	"Couldn't load AllMon Login to admin and run Nodemanager Setup";}
include_once("$rootDir/gmrs/header.php"); 
include_once("$rootDir/gmrs/menu.php"); 
include_once ("$path/supermon_input.php");
$nodes="";
for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'nodes')   {  $nodes = $fieldValues[$i]; }
}
$passedNodes = explode(',', @trim($nodes));// for PHP code
$parms = @trim(strip_tags($nodes)); // for java code
if (count($passedNodes) == 0) {die ("Error no node number provided");}
$Displayed_Nodes="999"; $Display_Count=0; $Show_All="1";
// Remove nodes not in our allmon.ini file.
$nodes=array();
foreach ($passedNodes as $i => $node) {
 if (isset($config[$node])) {$nodes[] = $node;} 
 else {print "Warning: Node $node not found in our allmon ini file.";}
}
include("$rootDir/gmrs/link-java.php"); // moved to ext file for easier editing.
include("$path/supermon_display_cache.php");
print"<!-- $ipaddress -->\n";

print"<table border=0 cellspacing=2 id=AutoNumber1 align=left >
<tr><td colspan=3 align=center>";

print "<!-- Load weather ----->\n";include ("$path/supermon_weather.php");
//print "<!-- Nodes table -->\n";  
foreach($nodes as $node) {
if (isset($astdb[$node])){ $info = $astdb[$node][1] . ' ' . $astdb[$node][2] . ' ' . $astdb[$node][3]; }
        else{ 
          $info = "Pending";
          if (file_exists($OurNodeCache)){unlink($OurNodeCache);}// Bad reset it.
          }

$nodeURL = "link.php?nodes=$node";$title = "&nbsp; Node:<a href=\"$nodeURL\" target=\"_blank\">$node</a> Info:$info &nbsp;";

if (isset($config[$node]['listenlive'])) {
  $ListenLiveLink = $config[$node]['listenlive'];
  $title .= "<a href=\"$ListenLiveLink\" target=\"_blank\" id=\"lsnodeschart\">Listen Live</a> &nbsp;";
}

//    rColor=darkblue cColor=red bColor=palegreen gColor=lightgray tColor=lemonchiffon lColor=powderblue  <tr class="gColor">    

// Dont edit table Java looks for this code (colors are set in java code)
print "\n<!-- Start Nodes table $node-->\n";
print"<table border=0 class=gridtable id=table_$node>
<colgroup><col span=1> <col span=1><col span=1><col span=1><col span=1><col span=1><col span=1></colgroup>
<thead>
<tr class=\"lColor\"><td colspan=7 align=center>$title</td></tr>
</thead>
<tbody>
<tr><td colspan=\"7\"> &nbsp; Waiting for Client side refreash...</td></tr>
</tbody>
</table>
<br/>";
print "\n<!-- END Nodes table $node-->\n";
}

include ("/etc/asterisk/local/mm-software/supermon_lnodes.php");
$verGMRS=$versionL;  
include("$rootDir/gmrs/footer.php");

function Show_help($in){
global $width,$height,$in;
print "<a href=\"#\" onclick=\"window.open('/gmrs/help.php?help=$in', 'Help', 'width=$width,height=$height');\"><img src=\"/gmrs/images/help.gif\"></a>";
}
?>
