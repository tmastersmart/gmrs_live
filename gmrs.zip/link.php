<?php 
//
//  AllStarLink/ASL-Supermon is licensed under the GNU General Public License v3.0
//
// https://raw.githubusercontent.com/AllStarLink/ASL-Supermon/develop/LICENSE
// https://github.com/AllStarLink/ASL-Supermon/blob/develop/var/www/html/supermon/link.php

// https://www.gnu.org/licenses/gpl-3.0.en.html

// Modified in acordance with GPL
// 
// Customized user status page. Admin removed for security

// include("/srv/http/gmrs/session.inc");
include("/srv/http/gmrs/global.php");
include("/srv/http/gmrs/common.php"); // BUG fix global and common were being loaded twice on each load slowing down supermon

// SECURITY FIX by WRXB288 
// Major security problem to have this in webserver root directory.
// With the password exposed.....
// BUG fix this was being loaded twice on each load slowing down supermon
// Load before header.inc so menu.inc will have it.  
$fileAllMon = "/srv/http/gmrs/admin/allmon.ini";       
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);// load the now secure file

include("/srv/http/gmrs/header.php"); 
//include("/srv/http/supermon/menu.inc"); 
include("/srv/http/gmrs/menu.php"); 
//error_reporting(E_ALL);
// upgraded to a more modern anti hacker input
$path         = "/etc/asterisk/local/mm-software";
include_once ("$path/supermon_input.php");
//include_once ("input-scan.php");
$nodes="";
for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'nodes')   {  $nodes = $fieldValues[$i]; }
}


$passedNodes = explode(',', @trim($nodes));// for PHP code
$parms = @trim(strip_tags($nodes)); // for java code


if (count($passedNodes) == 0) {die ("Error no node number provided");}

$SUBMITTER = "submit2";


// Added WA3DSP

if (isset($_COOKIE['display-data'])) {
    foreach ($_COOKIE['display-data'] as $name => $value) {
        $name = htmlspecialchars($name);
        switch ($name) {
            case "number-displayed";
               $Displayed_Nodes = htmlspecialchars($value);
               break;
            case "show-number";
               $Display_Count = htmlspecialchars($value);
               break;
            case "show-all";
               $Show_All = htmlspecialchars($value);
               break;
        }
       // echo "$name : $value <br />\n";
    }
}

// Cookie block
if (! isset($Displayed_Nodes)) {$Displayed_Nodes="999";} // If not defined in cookie display all nodes
if ($Displayed_Nodes === "0") { $Displayed_Nodes="999";}
if (! isset($Display_Count)) { $Display_Count=0;} // If not define in cookie display all
if ( ! isset($Show_All)) { $Show_All="1";} // If not defined in cookie show all else omit "Never" Keyed 
// END WA3DSP


// Get GMRSLIVE database file
$db = $ASTDB_TXT;			// Defined in global.inc
$astdb = array();
if (file_exists($db)) {
    $fh = fopen($db, "r");
    if (flock($fh, LOCK_SH)){
        while(($line = fgets($fh)) !== FALSE) {
            $arr = preg_split("/\|/", trim($line));
            $astdb[$arr[0]] = $arr;
        }
    }
    flock($fh, LOCK_UN);
    fclose($fh);
    #print "<pre>"; print_r($astdb); print "</pre>";
}



#print "<pre>"; print_r($config); print "</pre>";
#print "<pre>"; print_r($config[$node]); print "</pre>";

// Remove nodes not in our allmon.ini file.
$nodes=array();
foreach ($passedNodes as $i => $node) {
	if (isset($config[$node])) {
		$nodes[] = $node;
	} else {
		print "Warning: Node $node not found in our allmon ini file.";
	}
}
// when DOM is ready

?>
<script type="text/javascript">

$(document).ready(function() {
  if(typeof(EventSource)!=="undefined") {
		
    // Start SSE 
    var source=new EventSource("/gmrs/server.php?nodes=<?php echo $parms; ?>");
        
    // Fires when node data come in. Updates the whole table
    source.addEventListener('nodes', function(event) {
    //console.log('nodes: ' + event.data);	        
    // server.php returns a json formated string

    var tabledata = JSON.parse(event.data);
    for (var localNode in tabledata) {
        var tablehtml = '';

        // Added WA3DSP
        var total_nodes = 0;
        var shown_nodes = 0;
        var ndisp = <?php echo (int) $Displayed_Nodes ?>;
	ndisp++;
        var sdisp = <?php echo $Display_Count ?>;
        var sall = <?php echo $Show_All ?>;
        // END

	// KB4FXC -- refactored telemetry state logic 10/21/2018

	var cos_keyed = 0;
	var tx_keyed = 0;

        for (row in tabledata[localNode].remote_nodes) {

               if (tabledata[localNode].remote_nodes[row].cos_keyed == 1)
			cos_keyed = 1;

		if (tabledata[localNode].remote_nodes[row].tx_keyed == 1)
			tx_keyed = 1;

	}
//    rColor=darkblue cColor=red bColor=palegreen gColor=lightgray tColor=lemonchiffon lColor=powderblue  <tr class="gColor">
//    p = pink new 
        if (cos_keyed == 0) { 
                if (tx_keyed == 0)
                        tablehtml += '<tr class="gColor"><td colspan="1" align="center">' + localNode + '</td><td colspan="5" align="center" >Idle Waiting for Net or Receiver</td><td align="center" ><div id=\"spinny\"></div></td></tr>';
                else
                        tablehtml += '<tr class="cColor"><td colspan="1" align="center">' + localNode + '</td><td colspan="5" align="center" >PTT-Keyed Transmitting</td><td align="center"><div id=\"spinny\"></div></td></tr>';
        }
        else {
                if (tx_keyed == 0)
                        tablehtml += '<tr class="lColor"><td colspan="1" align="center">' + localNode + '</td><td colspan="6" align="center">COS-Detected</td></tr>';
                else
                        tablehtml += '<tr class="cColor"><td colspan="1" align="center">' + localNode + '</td><td colspan="6" align="center">COS-Detected and PTT-Keyed (Full-Duplex)</td></tr>';
        }

	for (row in tabledata[localNode].remote_nodes) {

            if (tabledata[localNode].remote_nodes[row].info === "NO CONNECTION") {

               tablehtml += '<tr><td colspan="7"> &nbsp; &nbsp; No Connections.</td></tr>';

            } else {

	       nodeNum=tabledata[localNode].remote_nodes[row].node;	
	       if (nodeNum != 1) {

               // ADDED WA3DSP 
               // Increment total and display only requested
               total_nodes++;
               if (row<ndisp) {
                  if (sall == "1" || tabledata[localNode].remote_nodes[row].last_keyed != "Never" || total_nodes < 2) {
                     shown_nodes++;
               // END WA3DSP
        		
//    rColor=darkblue cColor=red bColor=palegreen gColor=lightgray tColor=lemonchiffon lColor=powderblue w=white  <tr class="gColor">
	             if (tabledata[localNode].remote_nodes[row].keyed == 'yes') {
		        tablehtml += '<tr class="rColor">';
	             } else if (tabledata[localNode].remote_nodes[row].mode == 'C') {
		        tablehtml += '<tr class="cColor">';
	             } else {
		        tablehtml += '<tr>';
	             }

	             var id = 't' + localNode + 'c0' + 'r' + row;
	             //console.log(id);
	             tablehtml += '<td id="' + id + '" align="center" class="nodeNum">' + tabledata[localNode].remote_nodes[row].node + '</td>';
            		
	             // Show info or IP if no info
	             if (tabledata[localNode].remote_nodes[row].info != "") {
		     	tablehtml += '<td>' + tabledata[localNode].remote_nodes[row].info + '</td>';
	             } else {
		    	tablehtml += '<td>' + tabledata[localNode].remote_nodes[row].ip + '</td>';
	             }
            	     tablehtml += '<td align="center" id="lkey' + row + '">' + tabledata[localNode].remote_nodes[row].last_keyed + '</td>';
 		     tablehtml += '<td align="center">' + tabledata[localNode].remote_nodes[row].link + '</td>';
	             tablehtml += '<td align="center">' + tabledata[localNode].remote_nodes[row].direction + '</td>';
	             tablehtml += '<td align="right" id="elap' + row +'">' + tabledata[localNode].remote_nodes[row].elapsed + '</td>';
            		
	             // Show mode in plain english
	             if (tabledata[localNode].remote_nodes[row].mode == 'R') {
		      	tablehtml += '<td align="center">Receive Only</td>';
	             } else if (tabledata[localNode].remote_nodes[row].mode == 'T') {
		     	tablehtml += '<td align="center">Transceive</td>';
		     } else if (tabledata[localNode].remote_nodes[row].mode == 'C') {
		    	tablehtml += '<td align="center">Connecting</td>';
	             } else {
		     	tablehtml += '<td align="center">' + tabledata[localNode].remote_nodes[row].mode + '</td>';
	             }
       		     tablehtml += '</tr>';
	          }
        	  //console.log('tablehtml: ' + tablehtml);

                 }  
               }
            }
         }    

      // ADDED WA3DSP
      // START Display node count at the botom 
      // WERXB288 fixed bug no <tr>
         if (sdisp === 1 && total_nodes >= shown_nodes && total_nodes > 0) {
            if (shown_nodes == total_nodes) {
               tablehtml += '<tr class="gColor"><td colspan="7"> &nbsp; &nbsp;' + total_nodes + ' node(s) connected.</td></tr>';
            } else {
               tablehtml += '<tr class="gColor"><td colspan="7"> &nbsp; &nbsp;' + shown_nodes + ' shown of ' + total_nodes + ' nodes connected.</td></tr>';
            }
         }

      // END 

      $('#table_' + localNode + ' tbody:first').html(tablehtml);
    }
});

        
        // Fires when new time data comes in. Updates only time columns
        source.addEventListener('nodetimes', function(event) {
			//console.log('nodetimes: ' + event.data);	        
			var tabledata = JSON.parse(event.data);
			for (localNode in tabledata) {
				tableID = 'table_' + localNode;
				for (row in tabledata[localNode].remote_nodes) {
					//console.log(tableID, row, tabledata[localNode].remote_nodes[row].elapsed, tabledata[localNode].remote_nodes[row].last_keyed);

					rowID='lkey' + row;
					$( '#' + tableID + ' #' + rowID).text( tabledata[localNode].remote_nodes[row].last_keyed );
					rowID='elap' + row;
		 			$( '#' + tableID + ' #' + rowID).text( tabledata[localNode].remote_nodes[row].elapsed );

				}
			}


	                if (spinny == "*") {
                                spinny = "|";
                        } else if (spinny == "|") {
                                spinny = "/";
                        } else if (spinny == "/") {
                                spinny = "-";
                        } else if (spinny == "-") {
                                spinny = "\\";
                        } else if (spinny == "\\") {
                                spinny = "|";
                        } else {
                                spinny = "*";
                        }
                        $('#spinny').html(spinny);
        });
        
        // Fires when connection message comes in.
        source.addEventListener('connection', function(event) {
			//console.log(statusdata.status);
			var statusdata = JSON.parse(event.data);
			tableID = 'table_' + statusdata.node;
			$('#' + tableID + ' tbody:first').html('<tr><td colspan="7">' + statusdata.status + '</td></tr>');
		});
		       
    } else {
        $("#list_link").html("Sorry, your browser does not support server-sent events...");
    }
});
</script>


<?php

$count=count($nodes);


print "<p style=\"margin-bottom:5px;margin-top:10px;\">";


if ((`cat /etc/asterisk/rpt.conf |egrep -c ^"outstreamcmd"` > 0) && (`cat /etc/asterisk/rpt.conf |egrep -c ^"archivedir"` > 0) && ($STREAMING_NODE == $ARCHIVING_NODE)) {
   print " [ Streaming & Archiving node(s): $STREAMING_NODE ]";
} else {
   if (`cat /etc/asterisk/rpt.conf |egrep -c ^"outstreamcmd"` > 0) {
      if (isset($STREAMING_NODE)) {
         print " [ Streaming node(s): $STREAMING_NODE ]";
      }
   }
   if (`cat /etc/asterisk/rpt.conf |egrep -c ^"archivedir"` > 0) {
      if (isset($ARCHIVING_NODE)) {
         print " [ Archiving node(s): $ARCHIVING_NODE ]";
      }
   }
}
// END KN2R
print "</p>\n";


// This installs my weather lines
print "<!-- start weather ----->\n";
include ("/etc/asterisk/local/mm-software/supermon_weather.php");
print "<!-- stop weather  ----->\n";
print "</p>";


print "<!-- Nodes table -->";
foreach($nodes as $node) {
if (isset($astdb[$node])){ $info = $astdb[$node][1] . ' ' . $astdb[$node][2] . ' ' . $astdb[$node][3]; }
else{ $info = "Node not in database";}

$nodeURL = "";$title = "&nbsp; Node:<a href=\"$nodeURL\" target=\"_blank\">$node</a> Info:$info &nbsp;";

if (isset($config[$node]['listenlive'])) {
  $ListenLiveLink = $config[$node]['listenlive'];
  $title .= "<a href=\"$ListenLiveLink\" target=\"_blank\" id=\"lsnodeschart\">Listen Live</a> &nbsp;";
}

//    rColor=darkblue cColor=red bColor=palegreen gColor=lightgray tColor=lemonchiffon lColor=powderblue  <tr class="gColor">    
    
print"<table border=0 class=gridtable id=table_$node>
	<colgroup><col span=1> <col span=1><col span=1><col span=1><col span=1><col span=1><col span=1></colgroup>
	
    <thead>
    <tr class=\"lColor\"><td colspan=7 align=center>$title</td></tr>
	<tr class=\"tColor\"><td>Node</td><td align=center>Node Information</td><td>Received</td><td align=center>Link</td><td>Direction</td><td>Connected</td><td>Mode</td></tr>
	</thead>
	<tbody>
	<tr><td colspan=\"7\"> &nbsp; Waiting for Client side refreash...</td></tr>
	</tbody>
	</table><br/>";
}

print "<!-- start lsnodes ----->\n";
include ("/etc/asterisk/local/mm-software/supermon_lnodes.php");
print "<!-- stop lsnodes  ----->\n";


include ("footer.php");
 


