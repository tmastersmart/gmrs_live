<?php 
//
//  AllStarLink/ASL-Supermon is licensed under the GNU General Public License v3.0
//
// https://raw.githubusercontent.com/AllStarLink/ASL-Supermon/develop/LICENSE
// https://github.com/AllStarLink/ASL-Supermon/blob/develop/var/www/html/supermon/link.php
// https://www.gnu.org/licenses/gpl-3.0.en.html

// Modified in acordance with GPL
// 
// Customized user status page. Admin removed for security
// v2.6 New paths to work with custom servers


$versionL="v2.6";$releaseGMRS="1/7/2024"; $verGMRS=$versionL; $betatest=false;


$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
$path         = "/etc/asterisk/local/mm-software";  

include_once("$rootDir/gmrs/global.php"); // includes the local settings
include_once("$rootDir/gmrs/common.php"); // includes the main settings

$fileAllMon = "$rootDir/gmrs/admin/allmon.ini";
if (file_exists($fileAllMon)){$config = parse_ini_file($fileAllMon, true);}
else {print	"Couldn't load AllMon Login to admin and run Nodemanager Setup";}

include_once("$rootDir/gmrs/header.php"); 
include_once("$rootDir/gmrs/menu.php"); 
include_once ("$path/supermon_input.php");
//include_once ("input-scan.php");
$nodes="";
for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'nodes')   {  $nodes = $fieldValues[$i]; }
}


$passedNodes = explode(',', @trim($nodes));// for PHP code
$parms = @trim(strip_tags($nodes)); // for java code


if (count($passedNodes) == 0) {die ("Error no node number provided");}

$SUBMITTER = "submit2";
$Displayed_Nodes="999"; $Display_Count=0; $Show_All="1";

// Remove nodes not in our allmon.ini file.
$nodes=array();
foreach ($passedNodes as $i => $node) {
 if (isset($config[$node])) {$nodes[] = $node;} 
 else {print "Warning: Node $node not found in our allmon ini file.";}
}

include("$rootDir/gmrs/link-java.php"); // moved to ext file for easier editing.
include("$path/supermon_display_cache.php");

// ADMIN was here moved to ADMIN sub directory



// This installs my weather lines
print "<!-- start weather ----->\n";
include ("$path/supermon_weather.php");
print "<!-- stop weather  ----->\n";
print "</p>";


print "<!-- Nodes table -->";
foreach($nodes as $node) {
if (isset($astdb[$node])){ $info = $astdb[$node][1] . ' ' . $astdb[$node][2] . ' ' . $astdb[$node][3]; }
        else{ 
          $info = "Pending";
          if (file_exists($OurNodeCache)){unlink($OurNodeCache);}// Bad reset it.
          }

$nodeURL = "";$title = "&nbsp; Node:<a href=\"$nodeURL\" target=\"_blank\">$node</a> Info:$info &nbsp;";

if (isset($config[$node]['listenlive'])) {
  $ListenLiveLink = $config[$node]['listenlive'];
  $title .= "<a href=\"$ListenLiveLink\" target=\"_blank\" id=\"lsnodeschart\">Listen Live</a> &nbsp;";
}

//    rColor=darkblue cColor=red bColor=palegreen gColor=lightgray tColor=lemonchiffon lColor=powderblue  <tr class="gColor">    
    
print"<table border=0 class=gridtable id=table_$node>
	<colgroup><col span=1> <col span=1><col span=1><col span=1><col span=1><col span=1><col span=1></colgroup>
	
    <thead>
    <tr class=\"lColor\"><td colspan=7 align=center>$title</td></tr>
	<tr class=\"tColor\"><td>Node</td><td align=center>Node Information</td><td>Received</td><td align=center>Link</td><td>Direction</td><td>Connected</td><td>Mode</td></tr>
	</thead>
	<tbody>
	<tr><td colspan=\"7\"> &nbsp; Waiting for Client side refreash...</td></tr>
	</tbody>
	</table><br/>";
}

print "<!-- start lsnodes ----->\n";
include ("/etc/asterisk/local/mm-software/supermon_lnodes.php");
print "<!-- stop lsnodes  ----->\n";
$verGMRS=$versionL;  
include("$rootDir/gmrs/footer.php");
 


