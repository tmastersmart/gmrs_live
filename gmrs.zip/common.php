<?php
//
//  AllStarLink/ASL-Supermon is licensed under the GNU General Public License v3.0
//
// https://raw.githubusercontent.com/AllStarLink/ASL-Supermon/develop/LICENSE
// https://github.com/AllStarLink/ASL-Supermon/blob/develop/var/www/html/supermon/link.php
// https://www.gnu.org/licenses/gpl-3.0.en.html
// Modified in acordance with GPL


// GMRS modified


$TITLE_LOGGED = "GMRS Supermon Node Manager Mod";// Title in header when not logged in
$TITLE_NOT_LOGGED = "GMRS Supermon Node Manager";// Webserver access log
$WEB_ACCESS_LOG = "/var/log/httpd/access_log";// Webserver error log
$WEB_ERROR_LOG = "/var/log/httpd/error_log";// Asterisk message log
$ASTERISK_LOG = "/var/log/asterisk/messages";// AllStar allmon database
$ASTDB_TXT = "/var/log/asterisk/astdb.txt";// AllStar rpt_extnodes file --- not present in DNS mode.
$EXTNODES = "/tmp/rpt_extnodes";// AllStar Echolink database dump 
$PRIVATENODES = "/etc/asterisk/local/privatenodes.txt";


//$ECHO_DB = "/tmp/echolink.db.gz";// Private AllStar nodelist

//	IRLP related...
//$IRLP_CALLS = "/tmp/irlpdata.txt.gz";
//$IRLP_LOG = "/home/irlp/log/messages";


$version="";  // why do we need version. Just create it incase (once only)
$file= "/tmp/asterisk_version";
if(file_exists($file)){
 $d= file($file); 
  foreach($d as $line){
  $version=$line;
 }
}
else {$version = `export TERM=vt100; sudo asterisk -rx "core show version" |awk '{print $2}' | tee /tmp/asterisk_version`;}

if(!file_exists($file)){$fileOUT=$file; $fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$version");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);}


$version="Asterisk $version";  // 1.4.23-pre.hamvoip-V1.7.1-04
$system_type = "hamvoip";
//
//	Paths to various programs called from php...
$ASTERISK =	"/usr/bin/asterisk";
$AWK =		"/bin/awk";
$CAT =		"/bin/cat";
$CUT =		"/bin/cut";
$DATE =		"/bin/date";
$EGREP =	"/bin/egrep";
$GREP =		"/bin/grep";
$HEAD =		"/bin/head";
$HOSTNAME =	"/bin/hostname";
$IFCONFIG =	"/bin/ifconfig";
$JOURNALCTL =	"/usr/bin/journalctl";
$MBUFFER =	"/usr/local/bin/mbuffer";
$SED =		"/bin/sed";
$SUDO =		"export TERM=vt100 && /usr/bin/sudo";
$TAIL =		"/bin/tail";
$UPTIME =	"/bin/uptime";
$WGET =		"/bin/wget";
$ZCAT =		"/bin/zcat";

//if (file_exists($IRLP_LOG)){$IRLPLOG = true;}
//else{$IRLPLOG = false;}
//if (file_exists($IRLP_CALLS)){$IRLP = true;}
//else{$IRLP = false;}
//if (file_exists($EXTNODES)){$EXTN = true;}
//else{$EXTN = false;}

// Disabled for GMRS Live
$IRLPLOG = false;$IRLP = false;$EXTN = false;

?>
