<?php
//
//  AllStarLink/ASL-Supermon is licensed under the GNU General Public License v3.0
//
// https://raw.githubusercontent.com/AllStarLink/ASL-Supermon/develop/LICENSE
// https://github.com/AllStarLink/ASL-Supermon/blob/develop/var/www/html/supermon/link.php

// https://www.gnu.org/licenses/gpl-3.0.en.html

// Modified in acordance with GPL

// GMRS modified



$TITLE_LOGGED = "GMRS Supermon Node Manager 6.2+ Mod";// Title in header when not logged in
$TITLE_NOT_LOGGED = "GMRS Supermon Node Manager";// Webserver access log
$WEB_ACCESS_LOG = "/var/log/httpd/access_log";// Webserver error log
$WEB_ERROR_LOG = "/var/log/httpd/error_log";// Asterisk message log
$ASTERISK_LOG = "/var/log/asterisk/messages";// AllStar allmon database
$ASTDB_TXT = "/var/log/asterisk/astdb.txt";// AllStar rpt_extnodes file --- not present in DNS mode.
$EXTNODES = "/tmp/rpt_extnodes";// AllStar Echolink database dump
$ECHO_DB = "/tmp/echolink.db.gz";// Private AllStar nodelist
$PRIVATENODES = "/etc/asterisk/local/privatenodes.txt";

//	IRLP related...
//$IRLP_CALLS = "/tmp/irlpdata.txt.gz";
//$IRLP_LOG = "/home/irlp/log/messages";

// Cache version number info.
$file = `find /tmp/asterisk_version /run/asterisk.pid /etc/allstar_version -printf "%T@  %p\n" 2>/dev/null | sort -nr | awk '{if (NR == 1) printf ("%s", $2)}'`;

if ($file == "/tmp/asterisk_version"){$version= `cat /tmp/asterisk_version`;}
else{$version = `export TERM=vt100; sudo asterisk -rx "core show version" |awk '{print $2}' | tee /tmp/asterisk_version`;}

$version="Asterisk $version";

//echo "<p>$file, $version</p>";
//
// Make sure this is hamvoip "Vx.xrc" code
//$pattern="/ [0-9].[0-9]rc[0-9]/";
//if (preg_match($pattern, $version, $match)) {$system_type = "hamvoip";} 

$system_type = "hamvoip";
//
//	Paths to various programs called from php...
$ASTERISK =	"/usr/bin/asterisk";
$AWK =		"/bin/awk";
$CAT =		"/bin/cat";
$CUT =		"/bin/cut";
$DATE =		"/bin/date";
$EGREP =	"/bin/egrep";
$GREP =		"/bin/grep";
$HEAD =		"/bin/head";
$HOSTNAME =	"/bin/hostname";
$IFCONFIG =	"/bin/ifconfig";
$JOURNALCTL =	"/usr/bin/journalctl";
$MBUFFER =	"/usr/local/bin/mbuffer";
$SED =		"/bin/sed";
$SUDO =		"export TERM=vt100 && /usr/bin/sudo";
$TAIL =		"/bin/tail";
$UPTIME =	"/bin/uptime";
$WGET =		"/bin/wget";
$ZCAT =		"/bin/zcat";

//if (file_exists($IRLP_LOG)){$IRLPLOG = true;}
//else{$IRLPLOG = false;}
//if (file_exists($IRLP_CALLS)){$IRLP = true;}
//else{$IRLP = false;}
//if (file_exists($EXTNODES)){$EXTN = true;}
//else{$EXTN = false;}

// Disabled for GMRS Live
$IRLPLOG = false;$IRLP = false;$EXTN = false;

?>
