<?php
// load the program from outside the supermon package
$path       = "/etc/asterisk/local/mm-software";
include_once ("$path/supermon_input.php");
?>
