<?php
// (c)2015/2023 by The Master lagmrs.com
// I license you to use this on your copy of this software only.
//
// Universal help system for node manager. 
// Will provide help pages for all node manager pages
// For non admin pages

$verGMRS="v1.5";$releaseGMRS="2/2/2024";  
$path         = "/etc/asterisk/local/mm-software"; 
$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
include_once("$path/supermon_input.php"); $help="";
$log="";
for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'help') {  $help  = $fieldValues[$i]; }
}

$help = preg_replace('/[^0-9.]+/', '', $help);

if($help <1 or $help >50){$help=100;}

$pageTitle="Help Page $help";
print "
<!DOCTYPE html>
<html>
<head>
<title>$pageTitle GMRS Node Manager</title>\n";
print "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n";
print "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n";
print "<meta name=\"robots\" content=\"noindex, nofollow\">\n";   
print "<meta name=\"generator\" content=\"GMRS Node Manager (c)2024 lagmrs.com\">\n";
print "<meta name=\"license2\" content=\"All new code for GMRS is Copyrighted 2023/2024 all rights reserved\">\n";
print "<link rel=\"shortcut icon\" href=\"/gmrs/favicon.ico\" type=\"image/x-icon\">\n";
print "<link rel=\"icon\" href=\"/gmrs/favicon.ico\" type=\"image/x-icon\">\n";
print "<link type=\"text/css\" rel=\"stylesheet\" href=\"/gmrs/supermon.css\">";

print "<style>
body {
  background-color: #E6E6FA;
}
</style>";

print "</head><body>\n";

print "<table style=\"border-collapse: collapse\" border=0 cellpadding=0 cellspacing=0  width=100%>
<tr><td align=\"center\" bgcolor=\"#000080\"><font color=white>$pageTitle</font></td></tr></table><BR>";

if ($help=="100"){print"ERROR Help code not found<br>";}

$weather="The node keeps a record of all weather reports it collects. This chart shows a 30 day history.";

if ($help=="1"){print"
Temp Chart:<br><BR>
$weather
";}

if ($help=="2"){print"
Humidity Chart:<br><BR>
$weather
";}

if ($help=="3"){print"
Wind Chart:<br><BR>
$weather
";}

if ($help=="33"){print"
Wind Direction:<br><BR>
$weather
";}

if ($help=="4"){print"
Rain Chart:<br><BR>
$weather
";}

if ($help=="5"){print"
Ultraviolet index, or UV Index:<br><BR>
$weather
Basicaly turning your node into a local weather station. Not all stations provide UVIs data.
";}

 if ($help=="6"){print"
Solar Radation:<br><BR>
$weather
Basicaly turning your node into a local weather station. Not all stations provide Solar data.
";}

if ($help=="7"){print"
Preasure Chart:<br><BR>Air pressure or Barometric pressure<br>
$weather
Basicaly turning your node into a local weather station.
";}


if ($help=="8"){print"
Current Weather:<br><BR>Hold your mouse over for more detailed info.
";}

print "<br><BR>";

include ("$rootDir/gmrs/footer.php");

 function Show_help($in){
global $width,$height,$in;
print "<a href=\"#\" onclick=\"window.open('/gmrs/help.php?help=$in', 'Help', 'width=$width,height=$height');\"><img src=\"/gmrs/images/help.gif\"></a>";
}

print"</body></html>";
