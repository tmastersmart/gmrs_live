<?php
//
//  AllStarLink/ASL-Supermon is licensed under the GNU General Public License v3.0
//
// https://raw.githubusercontent.com/AllStarLink/ASL-Supermon/develop/LICENSE
// https://github.com/AllStarLink/ASL-Supermon/blob/develop/var/www/html/supermon/link.php
// https://www.gnu.org/licenses/gpl-3.0.en.html
// Modified in acordance with GPL

// This will all be moved into the setup database

$CALL = "WRXB288";
$NAME = "";
$LOCATION = "Packton La";
$TITLE2 = "RPi2-3 Node";
$TITLE3 = "Allstar GMRSLive System Manager";
$BACKGROUND = "/gmrs/images/background.jpg";
$BACKGROUND_COLOR = "blue";
$BACKGROUND_HEIGHT = "124px";
$REFRESH_DELAY = "3600";
$SHOW_COREDUMPS = "yes";
$LOCALZIP = "71432";


?>
