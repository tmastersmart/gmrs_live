<?php
//
//   v1.1  New node manager expandable menu system
//   v1.2  Modified links to open a new window but stay in that window
//         as you navigate weather pages. and not open more than one.
//   v1.3  uses the names from the nodelist for the status pages
//
//  AllStarLink/ASL-Supermon is licensed under the GNU General Public License v3.0
// https://raw.githubusercontent.com/AllStarLink/ASL-Supermon/develop/LICENSE
// https://www.gnu.org/licenses/gpl-3.0.en.html

// Modified in acordance with GPL


// start of the ani menu  GNU General Public License v3.0 code
$var1 = explode('/', $_SERVER['REQUEST_URI']);$var2 = array_pop($var1);$current_url = urldecode($var2);
if (count($config) <> 0) {
// Builds the nodes menu
$systems = array();
foreach($config as $name => $data) {
if(!isset($data['menu']) || $data['menu'] !== "1") {continue;}  //menu=yes
if(strtolower($name) == 'break') { continue;}
    
$sysName = 'MainNavBar';
if (isset($data['system'])) {  $sysName=$data['system'];}  // system=Nodes
if (isset($data['url'])) {     $systems[$sysName][$name]['url'] = $data['url'];}  // URL: Use 'url', 'rtcmnode', 'nodes', or name
elseif (isset($data['nodes'])){$systems[$sysName][$name]['url'] = "link.php?nodes={$data['nodes']}";}
else { $systems[$sysName][$name]['url'] = "link.php?nodes=$name";}
}
//print '<pre>'; print_r($systems); print '</pre>';
$action="";
foreach ($systems as $sysName => $items) {
    if ($sysName == "Nodes") {
        foreach($items as $itemName => $itemValue) {
            if ($current_url == $itemValue['url']) {
                $action .= " <a class=\"active\" href=\"" . $itemValue['url'] . "\">$itemName</a>";
            } else {
                $action .= " <a href=\"" . $itemValue['url'] . "\">$itemName</a>";
         }
      }
   }
 }
}
// end of the ani menu GNU General Public License v3.0 code

// Start node manager custom auto upgrade menu system

$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
$path         = "/etc/asterisk/local/mm-software";

$nodelistHub = "$path/nodelist/hubs_online.csv";// Cleaned up nodelist
if (file_exists($nodelistHub)) { $fileIN2= file($nodelistHub);} 

// Build the node manager menu
// (c)2024 node manager updatable menu bar
$NewMenu = "$path/web_database.csv";// automaticaly updating menu
$menu1="";$menu2="";$menu3="";$menu4="";$menu5="";
if (file_exists($NewMenu)) {
 $fileIN= file($NewMenu); 
 foreach($fileIN as $line){
 $line = str_replace("\r", "", $line);
 $line = str_replace("\n", "", $line);
  $u = explode("|",$line);

 if($u[0]=="Node Manager"){ $menu1 .= "<a href=\"$u[2]\">$u[1]</a>\n";}
 if($u[0]=="Weather"){      $menu2 .= "<a target=_new href=\"$u[2]\" >$u[1]</a>\n";}
 if($u[0]=="Bookmarks"){    $menu3 .= "<a target=_new href=\"$u[2]\" >$u[1]</a>\n";}
 if($u[0]=="FCC"){          $menu4 .= "<a target=_new href=\"$u[2]\" >$u[1]</a>\n";}
  
// Gets the names from the hub nodelist if found if not uses typed in name  
 if($u[0]=="Status Pages"){
  $alt=$u[1];
   if ($fileIN2){ 
   foreach($fileIN2 as $line2){
   $uu = explode("|",$line2);
   $string=$uu[1];$string = (strlen($string) > 35) ? substr($string,0,35).'..' : $string;   // Stops runaway size
   if($uu[0]==$u[3]){$alt=$string;break;}   
  }
 }
 $menu5 .= "<a target=_new href=\"$u[2]\" alt='$u[3]' > $alt</a>\n";
 } 
}

 
 
} 
 print "<!-- Start node manager menu -->\n"; 
 print "<div id=\"menu\"><ul>\n";
 
 print "<li class=\"dropdown\"><a href=\"#\" class=\"dropbtn\">Nodes</a><div class=\"dropdown-content\">\n"; 
 print $action;
 print "</ul></li>\n";
 
 if($menu1){
 print "<li class=\"dropdown\"><a href=\"#\" class=\"dropbtn\">Node Manager</a><div class=\"dropdown-content\">\n";
 print $menu1;
 print "</div></li>\n";
 }
 if($menu2){ 
 print "<li class=\"dropdown\"><a href=\"#\" class=\"dropbtn\">Weather</a><div class=\"dropdown-content\">\n";
 print $menu2;
 print "</div></li>\n";
 }
 
if($menu3){  
 print "<li class=\"dropdown\"><a href=\"#\" class=\"dropbtn\">Bookmarks</a><div class=\"dropdown-content\">\n";
 print $menu3;
 print "</div></li>\n";
 }
if($menu4){  
 print "<li class=\"dropdown\"><a href=\"#\" class=\"dropbtn\">FCC</a><div class=\"dropdown-content\">\n";
 print $menu4;
 print "</div></li>\n";
 }
 
 print "<!-- Status pages auto updateing names from nodelist -->\n"; 
 if($menu5){  
 print "<li class=\"dropdown\"><a href=\"#\" class=\"dropbtn\">Status Pages</a><div class=\"dropdown-content\">\n";
 print $menu5;
 print "</div></li>\n";
 }
 
 print "</ul></div>\n";  
print "<!-- end node manager menu -->\n";

?>
