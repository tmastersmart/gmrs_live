<?php
//
//   v1.1  New node manager expandable menu system
//
//
//  AllStarLink/ASL-Supermon is licensed under the GNU General Public License v3.0
// https://raw.githubusercontent.com/AllStarLink/ASL-Supermon/develop/LICENSE
// https://www.gnu.org/licenses/gpl-3.0.en.html

// Modified in acordance with GPL


// start of the ani menu  GNU General Public License v3.0 code
$var1 = explode('/', $_SERVER['REQUEST_URI']);$var2 = array_pop($var1);$current_url = urldecode($var2);
if (count($config) <> 0) {
// Builds the nodes menu
$systems = array();
foreach($config as $name => $data) {
if(!isset($data['menu']) || $data['menu'] !== "1") {continue;}  //menu=yes
if(strtolower($name) == 'break') { continue;}
    
$sysName = 'MainNavBar';
if (isset($data['system'])) {  $sysName=$data['system'];}  // system=Nodes
if (isset($data['url'])) {     $systems[$sysName][$name]['url'] = $data['url'];}  // URL: Use 'url', 'rtcmnode', 'nodes', or name
elseif (isset($data['nodes'])){$systems[$sysName][$name]['url'] = "link.php?nodes={$data['nodes']}";}
else { $systems[$sysName][$name]['url'] = "link.php?nodes=$name";}
}
//print '<pre>'; print_r($systems); print '</pre>';
$action="";
foreach ($systems as $sysName => $items) {
    if ($sysName == "Nodes") {
        $action .= "<li class=\"dropdown\">";
        $action .= "<a href=\"#\" class=\"dropbtn\">$sysName</a>";
        $action .= "<div class=\"dropdown-content\">";
        foreach($items as $itemName => $itemValue) {
            if ($current_url == $itemValue['url']) {
                $action .= " <a class=\"active\" href=\"" . $itemValue['url'] . "\">$itemName</a>";
            } else {
                $action .= " <a href=\"" . $itemValue['url'] . "\">$itemName</a>";
         }
      }
      $action .= "</div></li>\n";
   }
 }
}
// end of the ani menu GNU General Public License v3.0 code

// v1.1  Switched from CSV to | database


$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
$path         = "/etc/asterisk/local/mm-software";

// Build the node manager menu
// (c)2024 node manager updatable menu bar
$NewMenu = "$path/web_database.csv";// automaticaly updating menu
$menu1="";$menu2="";$menu3="";
if (file_exists($NewMenu)) {
 $fileIN= file($NewMenu); 
 $menu1 = "<li class=\"dropdown\">";
 $menu1 .= "<a href=\"#\" class=\"dropbtn\">Node Manager</a>";
 $menu1 .= "<div class=\"dropdown-content\">";
 foreach($fileIN as $line){
 $u = explode("|",$line);
 if($u[0]=="Node Manager"){$menu1 .= "<a href=\"$u[2]\">$u[1]</a>";}// internal pages 
 }
 $menu1 .= "</div></li>\n"; 

 $menu2 = "<li class=\"dropdown\"><a href=\"#\" class=\"dropbtn\">Bookmarks</a><div class=\"dropdown-content\">";
 foreach($fileIN as $line){
 $u = explode("|",$line);
 if($u[0]=="Bookmarks"){ $menu2 .= "<a href=\"$u[2]\" target=_blank>$u[1]</a>";} 
 } 
 $menu2 .= "</div></li>\n"; 
 $menu3 = "<li class=\"dropdown\"><a href=\"#\" class=\"dropbtn\">Status Pages</a><div class=\"dropdown-content\">";
 foreach($fileIN as $line){
 $u = explode("|",$line);
 if($u[0]=="Status Pages"){ $menu3 .= "<a href=\"$u[2]\" target=_blank>$u[1]</a>";}
 } 
 $menu3 .= "</div></li>\n"; 
} 
print "<!-- Start node manager menu -->\n";
print "<div id=\"menu\"><ul>\n";
print "$action $menu1 $menu2 $menu3";
print "</ul></div>\n";
print "<!-- end node manager menu -->\n";

?>
