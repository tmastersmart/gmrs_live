<?php
// GMRSlive  Mods for Supermon (c)2023 
// Dont use on anythin else
// v1.1 
$verGMRS="v1.2";$releaseGMRS="1/11/2024";  
$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
$path         = "/etc/asterisk/local/mm-software";
include_once("$rootDir/gmrs/global.php");
include_once("$rootDir/gmrs/common.php"); 
$fileAllMon = "$rootDir/gmrs/admin/allmon.ini";       
if (file_exists($fileAllMon)){$config = parse_ini_file($fileAllMon, true);}
else {print	"Couldn't load AllMon Login to admin and run Nodemanager Setup";}

$mmlogfile = "$path/logs/cpu_temp_log.txt"; 
$G_dataT="";

if (is_readable($mmlogfile)) {
$fileIN = file($mmlogfile);

foreach($fileIN as $line){
 $line = str_replace('"', "", $line); // 01-06-2024-19:13:45,26.8, 
 $u = explode(",",$line);// 0 date 1=value
 $tmp=$u[1];
 $adate = substr($u[0], 0,10);
 $atime = substr($u[0], 11,8);
$ltime = explode(":",$atime) ;
$A = $ltime[0]; $T = round($A,0) ;
$pm="am";

if ($T >12 ){$T =($T -12);$pm="pm";}
if ($T ==0 ){$T = 12;$pm="am";}
if (strlen($T)< 2){$T = "0$T";}
$timePMG ="$T:$ltime[1]$pm";
$timePM  ="$T:$ltime[1]:$ltime[2] $pm";
 
 if($G_dataT){ $G_dataT="$G_dataT,['$adate  $timePMG ',$tmp]\n";}
 else{$G_dataT="['$adate  $timePMG ',$tmp]\n";}
 }
}

$Gchart="
<script type=\"text/javascript\" src=\"https://www.google.com/jsapi\">
</script>
<script type='text/javascript'>
google.load('visualization', '1', {packages: ['corechart', 'line']});
google.setOnLoadCallback(drawBackgroundColor);
function drawBackgroundColor() {
     var data = new google.visualization.DataTable();
     data.addColumn('string', 'X');
     data.addColumn('number', 'CPU Temp');
     data.addRows([ $G_dataT ]);
    var options = { hAxis: {title: 'Time'}, vAxis: {title: 'Temp C'}, backgroundColor: '#f1f8e9',
        series: { 0: { color: 'red' }},
   
    };
    var formatter = new google.visualization.NumberFormat({
      fractionDigits: 2,
    });
    var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
      chart.draw(data, options);
    }
</script>
";

include_once("$rootDir/gmrs/header.php"); 
include_once("$rootDir/gmrs/menu.php"); 

?>
<div align="center">
<font color="GREEN" size="6"><h1>CPU Temp log</h1></font>
<div id="chart_div"></div>
<?php
include_once("$rootDir/gmrs/footer.php");
?>
