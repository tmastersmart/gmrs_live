<?php

$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
$path         = "/etc/asterisk/local/mm-software";

include_once ("$path/supermon_load_setup.php");


header("Location: /gmrs/link.php?nodes=$node");

?>?>
