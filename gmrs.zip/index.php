<?php
// corrected format from html with PHP inserts  to PHP

 include("session.inc"); 
 include("header.inc"); 
$path="/etc/asterisk/local/mm-software";
include ("$path/load.php");

print"<p>Welcome to <b><i>$CALL</i></b> and associated GMRS Live nodes. This Bridge $node runs on the GMRS Live Image
<br>
<br>
This Supermon web site is for monitoring and managing GMRS radio GMRS Live</a> and app_rpt node linking. This is version 6.2+ of Supermon With Node Manager mods
</p>

<p>On the menu bar click on the node numbers to see, and manage if you have a login ID, each local node. These pages dynamically display any remote nodes that
 are connected to it. When a signal is received the remote node will move to the top of the list and will have a dark-blue background. 
The most recently received nodes will always be at the top of the list. 
<ul>
<li>The <b>Direction</b> column shows <b>IN</b> when another node connected to us and <b>OUT</b> if the connection was made from us.</li>
<li>The <b>Mode</b> column will show <b>Transceive</b> when this node will transmit and receive to/from the connected node. It will show <b>Receive Only</b> or <b>Local Monitor</b> if this node only receives from the connected node.</li>
</ul>

<a href='link.php?nodes=$node'>Enter the node here</a>
</p>";

include "footer.inc"; ?>
