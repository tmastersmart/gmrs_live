<?php
// GMRSlive  Mods for Supermon (c)2023 
// Dont use on anythin else
// v1. 
$verGMRS="v1";$releaseGMRS="1/14/2024";  
$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
$path         = "/etc/asterisk/local/mm-software";
$zoomlevel=8;
include_once ("$path/supermon_load_setup.php");  // get the lat long
print"
<html>
<head>
<title>
Full Screen Radar
</title>
<meta name=\"viewport\" content=\"initial-scale=1, maximum-scale=1\">
</head>
<body>
<script type=\"text/javascript\" src=\"https://widgets.media.weather.com/wxwidget.loader.js?cid=286333348\"></script>
<div class=\"radarContainer\" style=\"width:100%; height:100%;\">
<wx-widget type=\"map\" scriptId=\"wxMap\" memberId=\"1167\" mapId=\"0020\" templateId=\"0011\" persistOpacity=\"false\" zoomLevel=\"$zoomlevel\" latitude=\"$lat\" longitude=\"$lon\" opacity=\"0.6\" menuItems=\"0001,1102,0011\" units=\"e\"/>
<!-- 1=radar 2rand sat   1101=earh tracks 0015=?  1102=road --> 
<!-- https://doc.media.weather.com/products/v3.1/configurator.php?auth=public -->
</div>




</body>
</html>";

?>
