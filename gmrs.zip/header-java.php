<?php 
//
//  AllStarLink/ASL-Supermon is licensed under the GNU General Public License v3.0
//
// https://raw.githubusercontent.com/AllStarLink/ASL-Supermon/develop/LICENSE
// https://github.com/AllStarLink/ASL-Supermon/blob/develop/var/www/html/supermon/link.php
// https://www.gnu.org/licenses/gpl-3.0.en.html

// Modified in acordance with GPL
// 
// header java logic
// Unneeded login and #buttions all removed

print"<!-- Start java logic -->\n";  

?> 

<script type="text/javascript">




$(document).ready(function() {
    // Click on a cell to populate the input form
    $('table').on('click', 'td', function( event ) {
          if ( $( this ).attr('class') == 'nodeNum') {
                $('#connect_form #node').val($( this ).text());
                  // split table ID and put node into id="localnode"
                var idarr = $( this ).closest('table').attr('id').split('_');
                $('#connect_form #localnode').val(idarr[1]);
          } 

    });
    

});

</script>

<?php 

print"<!-- End java logic -->\n";   

?>

