<?php
// GMRSlive  Mods for Supermon (c)2023 
// Dont use on anythin else
// Active directory module loader 
  
include_once("/srv/http/gmrs/global.php");
include_once("/srv/http/gmrs/common.php"); 

$fileAllMon = "/srv/http/gmrs/admin/allmon.ini";       
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);

$path = "/etc/asterisk/local/mm-software";
include_once("/srv/http/gmrs/header.php"); 
include_once("/srv/http/gmrs/menu.php"); 
include_once("$path/supermon_directory.php");
include_once("/srv/http/gmrs/footer.php"); 
?>
