<?php
// GMRSlive  Mods for Supermon (c)2023 
// Dont use on anythin else
// v1.1 
include_once("/srv/http/gmrs/global.php");
include_once("/srv/http/gmrs/common.php"); // BUG fix global and common were being loaded twice on each load slowing down supermon

$fileAllMon = "/srv/http/gmrs/admin/allmon.ini";       
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);// load the now secure file

include("/srv/http/gmrs/header.php"); 
include("/srv/http/gmrs/menu.php"); 

$path       = "/etc/asterisk/local/mm-software";
include_once ("$path/supermon_directory.php");

include_once("/srv/http/gmrs/footer.php"); 
?>
