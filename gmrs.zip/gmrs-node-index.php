<?php


//include("/srv/http/gmrs/global.php");
include("/srv/http/gmrs/common.php"); // BUG fix global and common were being loaded twice on each load slowing down supermon

// SECURITY FIX by WRXB288 
// Major security problem to have this in webserver root directory.
// With the password exposed.....
// BUG fix this was being loaded twice on each load slowing down supermon
// Load before header.inc so menu.inc will have it.  
$fileAllMon = "/srv/http/gmrs/admin/allmon.ini";       
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);// load the now secure file


include("/srv/http/gmrs/header.php"); 
include("/srv/http/gmrs/menu.php"); 

$path       = "/etc/asterisk/local/mm-software";
include_once ("$path/supermon_directory.php");
include("/srv/http/gmrs/footer.php");
?>
