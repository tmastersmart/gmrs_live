<?php 
//
//  AllStarLink/ASL-Supermon is licensed under the GNU General Public License v3.0
//
// https://raw.githubusercontent.com/AllStarLink/ASL-Supermon/develop/LICENSE
// https://github.com/AllStarLink/ASL-Supermon/blob/develop/var/www/html/supermon/link.php
// https://www.gnu.org/licenses/gpl-3.0.en.html

// Modified in acordance with GPL
// 
// Server java logic
// when DOM is ready

print"<!-- Start java logic -->\n"; 
//    rColor=darkblue cColor=red bColor=palegreen gColor=lightgray tColor=lemonchiffon lColor=powderblue  p = pink new <tr class="gColor">

$colorIdle="gColor";$colorPPT="cColor";$colorCOS="lColor";$colorCOSPPT="cColor";$colorKeyed="rColor";$colorConnecting="cColor";$colorNormal="wColor";$colorTotal="gColor"; $colorInfo="tColor";
print "<!-- $colorIdle $colorPPT $colorCOS $colorCOSPPT $colorKeyed $colorConnecting $colorNormal $colorTotal -->\n"; 


?>

<script type="text/javascript">

$(document).ready(function() {
  if(typeof(EventSource)!=="undefined") {
    var source=new EventSource("/gmrs/server.php?nodes=<?php echo $parms; ?>");
    source.addEventListener('nodes', function(event) {
    //console.log('nodes: ' + event.data);	        
    var tabledata = JSON.parse(event.data);
    for (var localNode in tabledata) {
        var tablehtml = '<tr class="<?php print $colorInfo; ?>"><td>Node</td><td align=center>Node Information</td><td>Received</td><td align=center>Link</td><td>Direction</td><td>Connected</td><td>Mode</td></tr>';
        // Added WA3DSP
        var total_nodes = 0;
        var shown_nodes = 0;
        var ndisp = <?php echo (int) $Displayed_Nodes ?>;
	ndisp++;
        var sdisp = <?php echo $Display_Count ?>;
        var sall = 1; //<?php echo $Show_All ?>;
	// KB4FXC -- refactored telemetry state logic 10/21/2018
	var cos_keyed = 0;
	var tx_keyed = 0;
        for (row in tabledata[localNode].remote_nodes) {
               if (tabledata[localNode].remote_nodes[row].cos_keyed == 1)
			cos_keyed = 1;
		if (tabledata[localNode].remote_nodes[row].tx_keyed == 1)
			tx_keyed = 1;
	}
    if (cos_keyed == 0) { 
     if (tx_keyed == 0)
     tablehtml += '<tr class="<?php print $colorIdle; ?>"><td colspan="1" align="center">' + localNode + '</td><td colspan="5" align="center" >Idle Waiting for Net or Receiver</td><td align="center" ><div id=\"spinny\"></div></td></tr>';
    else
     tablehtml += '<tr class="<?php print $colorPPT; ?>"><td colspan="1" align="center">' + localNode + '</td><td colspan="5" align="center" >PTT-Keyed Transmitting</td><td align="center"><div id=\"spinny\"></div></td></tr>';
      }
   else {
     if (tx_keyed == 0)
     tablehtml += '<tr class="<?php print $colorCOS; ?>"><td colspan="1" align="center">' + localNode + '</td><td colspan="6" align="center">COS-Detected</td></tr>';
   else
     tablehtml += '<tr class="<?php print $colorCOSPPT; ?>"><td colspan="1" align="center">' + localNode + '</td><td colspan="6" align="center">COS-Detected and PTT-Keyed (Full-Duplex)</td></tr>';
      }
	for (row in tabledata[localNode].remote_nodes) {
      if (tabledata[localNode].remote_nodes[row].info === "NO CONNECTION") {
     tablehtml += '<tr><td colspan="7"> &nbsp; &nbsp; No Connections.</td></tr>';
     } else {
      nodeNum=tabledata[localNode].remote_nodes[row].node;	
      if (nodeNum != 1) {
 // ADDED WA3DSP 
// Increment total and display only requested
               total_nodes++;
               if (row<ndisp) {
                  if (sall == "1" || tabledata[localNode].remote_nodes[row].last_keyed != "Never" || total_nodes < 2) {
                     shown_nodes++;
               // END WA3DSP
		
//    rColor=darkblue cColor=red bColor=palegreen gColor=lightgray tColor=lemonchiffon lColor=powderblue w=white  <tr class="gColor">
	             if (tabledata[localNode].remote_nodes[row].keyed == 'yes') {
		        tablehtml += '<tr class="<?php print $colorKeyed; ?>">'; // keyed
	             } else if (tabledata[localNode].remote_nodes[row].mode == 'C') {
		        tablehtml += '<tr class="<?php print $colorConnecting; ?>">';// connecting
	             } else {
		        tablehtml += '<tr class="<?php print $colorNormal; ?>">'; // normal
	             }

	             var id = 't' + localNode + 'c0' + 'r' + row;
	             //console.log(id);
	             tablehtml += '<td id="' + id + '" align="center" class="nodeNum">' + tabledata[localNode].remote_nodes[row].node + '</td>';
            		
	             // Show info or IP if no info
	             if (tabledata[localNode].remote_nodes[row].info != "") {
		     	tablehtml += '<td>' + tabledata[localNode].remote_nodes[row].info + '</td>';
	             } else {
		    	tablehtml += '<td>' + tabledata[localNode].remote_nodes[row].ip + '</td>';
	             }
            	     tablehtml += '<td align="center" id="lkey' + row + '">' + tabledata[localNode].remote_nodes[row].last_keyed + '</td>';
 		     tablehtml += '<td align="center">' + tabledata[localNode].remote_nodes[row].link + '</td>';
	             tablehtml += '<td align="center">' + tabledata[localNode].remote_nodes[row].direction + '</td>';
	             tablehtml += '<td align="right" id="elap' + row +'">' + tabledata[localNode].remote_nodes[row].elapsed + '</td>';
            		
	             // Show mode in plain english
	             if (tabledata[localNode].remote_nodes[row].mode == 'R') {
		      	tablehtml += '<td align="center">Receive Only</td>';
	             } else if (tabledata[localNode].remote_nodes[row].mode == 'T') {
		     	tablehtml += '<td align="center">Transceive</td>';
		     } else if (tabledata[localNode].remote_nodes[row].mode == 'C') {
		    	tablehtml += '<td align="center">Connecting</td>';
	             } else {
		     	tablehtml += '<td align="center">' + tabledata[localNode].remote_nodes[row].mode + '</td>';
	             }
       		     tablehtml += '</tr>';
	          }
        	  //console.log('tablehtml: ' + tablehtml);

                 }  
               }
            }
         }    

      // ADDED WA3DSP
      // START Display node count at the botom 
      // WERXB288 fixed bug no <tr>
         if (sdisp === 1 && total_nodes >= shown_nodes && total_nodes > 0) {
            if (shown_nodes == total_nodes) {
               tablehtml += '<tr class="<?php print $colorTotal; ?>"><td colspan="7"> &nbsp; &nbsp;' + total_nodes + ' node(s) connected.</td></tr>';
            } else {
               tablehtml += '<tr class="<?php print $colorTotal; ?>"><td colspan="7"> &nbsp; &nbsp;' + shown_nodes + ' shown of ' + total_nodes + ' nodes connected.</td></tr>';
            }
         }

      // END 

      $('#table_' + localNode + ' tbody:first').html(tablehtml);
    }
});
  
        // Fires when new time data comes in. Updates only time columns
        source.addEventListener('nodetimes', function(event) {
			//console.log('nodetimes: ' + event.data);	        
			var tabledata = JSON.parse(event.data);
			for (localNode in tabledata) {
				tableID = 'table_' + localNode;
				for (row in tabledata[localNode].remote_nodes) {
					rowID='lkey' + row;
					$( '#' + tableID + ' #' + rowID).text( tabledata[localNode].remote_nodes[row].last_keyed );
					rowID='elap' + row;
		 			$( '#' + tableID + ' #' + rowID).text( tabledata[localNode].remote_nodes[row].elapsed );

				}
			}
 if (spinny == "*") { spinny = "|";}
 else if (spinny == "|") {spinny = "/";}
 else if (spinny == "/") {spinny = "--";}
 else if (spinny == "--") {spinny = "\\";}
 else if (spinny == "\\") {spinny = "|";}
 else {spinny = "*";}
 $('#spinny').html(spinny);
 });
       
        // Fires when connection message comes in.
        source.addEventListener('connection', function(event) {
			//console.log(statusdata.status);
			var statusdata = JSON.parse(event.data);
			tableID = 'table_' + statusdata.node;
			$('#' + tableID + ' tbody:first').html('<tr><td colspan="7">' + statusdata.status + '</td></tr>');
		});
		       
    } else {
        $("#list_link").html("Sorry, your browser does not support server-sent events...");
    }
});
</script>

<?php 

print"<!-- End java logic -->\n";   

?>


