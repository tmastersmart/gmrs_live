<?php
// GMRSlive  Mods for Supermon (c)2023 
// Dont use on anythin else
// v1.2 8/29/2023 
// v1.3 11/1/23
// v1.4 12/10/23  Work on codes not to use. Chart not yet correct


$verGMRS="v1.5";$releaseGMRS="1/7/2024";$betatest=false; $pageTitle="Freq Chart"; 

$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
$path         = "/etc/asterisk/local/mm-software";

include_once("$rootDir/gmrs/global.php");
include_once("$rootDir/gmrs/common.php"); // BUG fix global and common were being loaded twice on each load slowing down supermon

$fileAllMon = "$rootDir/gmrs/admin/allmon.ini";
if (file_exists($fileAllMon)){$config = parse_ini_file($fileAllMon, true);}
else {print	"allmon is missing";}


include_once("$rootDir/gmrs/header.php"); 
include_once("$rootDir/gmrs/menu.php"); 


?>



<table border="1" cellpadding="3" id="AutoNumber1" cellspacing="3" style="font-family: Verdana, Helvetica; letter-spacing: normal; orphans: 2; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; border-collapse: collapse; background-color: rgb(247, 240, 225)" width="629" height="470">
  <tr>
    <td height="13" align="center" bgcolor="#000080" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">&nbsp;</td>
    <td height="13" align="center" bgcolor="#000080" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     <font color="#FFFFFF">Band 1</font></td>
    <td height="13" align="left" bgcolor="#000080" style="font-family: Verdana, Helvetica; font-size: 11px" width="199">      <font color="#FFFFFF">Band 1 462</font></td>
    <td align="center" height="13" bgcolor="#000080" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">&nbsp;</td>
    <td align="center" height="13" bgcolor="#000080" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">&nbsp;</td>
    <td align="center" height="13" bgcolor="#000080" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">&nbsp;</td>
    <td align="center" height="13" bgcolor="#000080" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     <font color="#FFFFFF"> </font></td>
    <td height="13" align="center" bgcolor="#000080" style="font-family: Verdana, Helvetica; font-size: 11px" width="100">    <font color="#FFFFFF">Band 2</font></td>
    <td height="13" align="center" bgcolor="#000080" style="font-family: Verdana, Helvetica; font-size: 11px" width="241">    <font color="#FFFFFF">Band 2 467</font></td>
    <td align="center" height="13" bgcolor="#000080" style="font-family: Verdana, Helvetica; font-size: 11px" width="135">&nbsp;</td>
    <td align="center" height="13" bgcolor="#000080" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">&nbsp;</td>
    <td align="center" height="13" bgcolor="#000080" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">&nbsp;</td>
    <td align="center" height="13" bgcolor="#000080" style="font-family: Verdana, Helvetica; font-size: 11px" width="40">     <font color="#FFFFFF">moble</font></td>
  </tr>
  <tr>
    <td height="13" align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">&nbsp;</td>
    <td height="13" align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">    Channel</td>
    <td height="13" align="left" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="199">     GMRS Mhz</td>
    <td align="center" height="13" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">&nbsp;</td>
    <td align="center" height="13" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">    
    Data</td>
    <td align="center" height="13" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">    Width</td>
    <td align="center" height="13" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">    Watts</td>
    <td height="13" align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="100">    Channel</td>
    <td height="13" align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="241">    GMRS Mhz</td>
    <td align="center" height="13" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="135">&nbsp;</td>
    <td align="center" height="13" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    Data</td>
    <td align="center" height="13" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     Width</td>
    <td align="center" height="13" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="40">     Watts</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">    R1</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">    15</td>
    <td align="left" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="199">     462.5500</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">    out</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">    
    y</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">    W</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">    50</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="100">    23</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="241">    467.5500</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="135">    in</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    n</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="40">     50</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">&nbsp;</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     1</td>
    <td align="left" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="199">      462.5625</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">&nbsp;</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     5</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="100">    8</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="241">    467.5625</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="135">&nbsp;</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     N</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="40">     .5</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     R2</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     16</td>
    <td align="left" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="199">      462.5750</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     out</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     50</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="100">    24</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="241">    467.5750</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="135">    in</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    n</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="40">     50</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">&nbsp;</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     2</td>
    <td align="left" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="199">      462.5875</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">&nbsp;</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     5</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="100">    9</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="241">    467.5875</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="135">&nbsp;</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     N</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="40">     .5</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     R3</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     17</td>
    <td align="left" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="199">      462.6000</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     out</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     50</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="100">    25</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="241">    467.6000</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="135">    in</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    n</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="40">     50</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">&nbsp;</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     3</td>
    <td align="left" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="199">      462.6125</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">&nbsp;</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     5</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="100">    10</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="241">    467.6125</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="135">&nbsp;</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     N</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="40">     .5</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     R4</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     18</td>
    <td align="left" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="199">      462.6250</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     out</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     50</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="100">    26</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="241">    467.6250</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="135">    in</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    n</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="40">     50</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">&nbsp;</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     4</td>
    <td align="left" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="199">      462.6375</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">&nbsp;</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     5</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="100">    11</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="241">    467.6375</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="135">&nbsp;</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     N</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="40">     .5</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     R5</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     19</td>
    <td align="left" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="199">      462.6500</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     out</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     50</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="100">    27</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="241">    467.6500</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="135">    in</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    n</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="40">     50</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">&nbsp;</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     5</td>
    <td align="left" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="199">      462.6625</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">&nbsp;</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     5</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="100">    12</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="241">    467.6625</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="135">&nbsp;</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     N</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="40">     .5</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     R6</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     20</td>
    <td align="left" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="199">      462.6750</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     out</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     50</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="100">    28</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="241">    467.6750</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="135">    in</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    n</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="40">     50</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">&nbsp;</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     6</td>
    <td align="left" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="199">      462.6875</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">&nbsp;</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     5</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="100">    13</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="241">    467.6875</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="135">&nbsp;</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     N</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="40">     .5</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     R7</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     21</td>
    <td align="left" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="199">      462.7000</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     out</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     50</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="100">    29</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="241">    467.7000</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="135">    in</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    n</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="40">     50</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">&nbsp;</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     7</td>
    <td align="left" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="199">      462.7125</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">&nbsp;</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#C0C0C0" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     5</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="100">    14</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="241">    467.7125</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="135">&nbsp;</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     N</td>
    <td align="center" bgcolor="#FFFFCC" style="font-family: Verdana, Helvetica; font-size: 11px" width="40">     .5</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     R8</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="47">     22</td>
    <td align="left" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="199">
    <span style="color: rgb(0, 0, 0); font-family: Verdana, Helvetica; font-size: 11px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; white-space: normal; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none; background-color: rgb(255, 255, 255)">
    462.7250</span></td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     out</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    y</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     50</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="100">    30</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="241">    <span style="color: rgb(0, 0, 0); font-family: Verdana, Helvetica; font-size: 11px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; white-space: normal; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none; background-color: rgb(255, 255, 255)">
    467.7250</span></td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="135">    in</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     
    n</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="37">     W</td>
    <td align="center" bgcolor="#FFFFFF" style="font-family: Verdana, Helvetica; font-size: 11px" width="40">     50</td>
  </tr>
</table>

<p><small>Remember many unlicensed users exist on GMRS and legaly run 5 watts. Running a low power node may work<BR>
in some areas but not in others. This is not HAM FRS users dont care that you have a license..</small></p>

<p><small>
Use of the frequency bands 457.5125-457.5875 MHz and 467.5125-467.5875 MHz are used by the maritime mobile<br>
in territorial waters. These ships may illegaly use these channels when in a US port.<BR>
<a href="https://www.itu.int/dms_pubrec/itu-r/rec/m/R-REC-M.1174-4-201910-I!!PDF-E.pdf" target=_blank> 
See ITU-R M.1174-4 </a><br>
<BR>
Use of the frequencys 457.525MHz,457.550MHz,457.575MHz,457.600 MHz paired with<br>
467.750MHz,467.775MHz,467.800MHz,467.825MHz are used in the territorial waters <br>
of the United States and the Philippines.<br>
<a href="https://www.itu.int/dms_pubrec/itu-r/rec/m/R-REC-M.1174-4-201910-I!!PDF-E.pdf" target=_blank> 
See ITU-R M.1174-4 </a><br>
</small></p>


<?php

// list of codes not to use. More work on chart is needed
//$file = "/srv/http/gmrs/cts-codes.csv";
//if (is_readable($file)) {
//   $fileIN= file($file); 
//   print "<table>\n\n";
//   foreach($fileIN as $line){
//    $u = explode(",",$line);
//        print "<tr>";
//        foreach ($u as $uu) {
//            print "<td>" . htmlspecialchars($uu) . "</td>";
//        }
//        print "</tr>\n";
//}

//print "\n</table>";
//}
 


include("$rootDir/gmrs/footer.php");
?>
