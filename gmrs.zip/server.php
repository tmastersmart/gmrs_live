<?php
//  AllStarLink/ASL-Supermon is licensed under the GNU General Public License v3.0
// https://raw.githubusercontent.com/AllStarLink/ASL-Supermon/develop/LICENSE
// https://www.gnu.org/licenses/gpl-3.0.en.html

// Modified in acordance with GPL
// GMRS version.
// ECHOLINK and IRPL removed
// Faster loading with smaller code 8/16/2023 by WXRB288
// functions moved into main code. Removed amifunctions.inc nodeinfo.inc 
// Removed echolink and IRLP

#error_reporting(E_ALL);
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('X-Accel-Buffering: no');

$fileAllMon = "/srv/http/gmrs/admin/allmon.ini"; // Major security problem to have this in webserver root directory.      
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);// load the now secure file

include("/gmrs/global.inc");
include("/gmrs/common.inc");

include("/etc/asterisk/local/mm-software/load.php");   


$path          = "/etc/asterisk/local/mm-software";
$nodelist      = "/var/log/asterisk/astdb.txt";
$nodelistBU    = "$path/nodelist/astdb.txt";
$nodelistClean = "$path/nodelist/clean.csv";// nodelist
$fileVersion   = "$path/version.txt";
$db = $ASTDB_TXT;			// Defined in global.inc  

include_once ("$path/supermon_input.php");
$Mynode=$node; // this stores $node which is set in config.
for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'nodes')   {  $nodes = $fieldValues[$i]; }
}

if (!$nodes){$nodes=$Mynode;}   

$passedNodes = explode(',', @trim($nodes));// for PHP code


// Load the clean nodelist
// ---------------Pre cleaned nodelist
$astdb = array();
$fileIN= file($nodelistClean); 
foreach($fileIN as $line){
//$u = explode("|",$line); 
$u = preg_split("/\|/", trim($line));
$astdb[$u[0]] = $u;
}


    


#print "<pre>"; print_r($config); print "</pre>";
#print "<pre>"; print_r($config[$node]); print "</pre>";

// Only cont in at least 1 node is in the config  (bug fix)
// This prevents the loop if no node is valid saving CPU cycles
$ok=false; $nodes = array();
foreach($passedNodes as $i => $node) {
   if (isset($config[$node])) {$nodes[] = $node; $ok=true;}
   else {$data = array('node' => $node, 'status' => "Node $node is not in allmon");
        print "event: nodes\n";
        print 'data: ' . json_encode($data) . "\n\n";
        ob_flush();flush();
        }
   }
if(!$ok){print"END";die;}

// Open a socket to each Asterisk Manager.
$servers = array(); $fp = array();
foreach($nodes as $node) {
    $host = $config[$node]['host'];
    // Connect and login to each manager only once.
    if (!array_key_exists($host, $servers)) {
        // try to connect
        // Show a nice message that we're attempting to connect
        $data = array('host' => $host, 'node' => $node, 'status'=>' &nbsp; Connecting to Asterisk Manager...');
        echo "event: connection\n";
        echo 'data: ' . json_encode($data) . "\n\n";
        ob_flush();
        flush();

        $fp[$host] = AMIconnect($config[$node]['host']);
        if ($fp[$host] === FALSE) {
            $data = array('host' => $host, 'node' => $node, 'status' => ' &nbsp; Could not connect to Asterisk Manager.');
            echo "event: connection\n";
            echo 'data: ' . json_encode($data) . "\n\n";
            ob_flush();
            flush();
        } else {
            // try to login
            if (FALSE !== AMIlogin($fp[$host], $config[$node]['user'], $config[$node]['passwd'])) {
                $servers[$host] = 'y';
            } else {
                $data = array('host' => $host, 'node' => $node, 'status' => ' &nbsp; Could not login to Asterisk Manager.');
                echo "event: connection\n";
                echo 'data: ' . json_encode($data) . "\n\n";
                ob_flush();
                flush();
            }
        }
    }
}
#print_r($servers);

// Main loop - build $data array and write it as a json object
$current=array();
$saved=array();
$nodeTime=array();
$ticToc='';
while(TRUE) {
    foreach ($nodes as $node) {
        
        // Is host of this node logged in?
        if (isset($servers[$config[$node]['host']])) {
            #print "Servers: " . $servers[$config[$node]['host']];
        } else {
            continue;
            #die ("a host is not logged in");
        }
        
        $connectedNodes = getNode($fp[$config[$node]['host']], $node);
        $sortedConnectedNodes = sortNodes($connectedNodes);

        // Build array of time values
        $nodeTime[$node]['node']=$node;
        $nodeTime[$node]['info'] = getAstInfo($fp[$config[$node]['host']], $node);
        
        // Build array 
        $current[$node]['node']=$node;
        $current[$node]['info'] = getAstInfo($fp[$config[$node]['host']], $node);
        
        // Save remote nodes
        $current[$node]['remote_nodes'] = array(); $i=0;
        foreach ($sortedConnectedNodes as $remoteNode => $arr) {
            // Store remote nodes time values
            $nodeTime[$node]['remote_nodes'][$i]['elapsed'] = $arr['elapsed'];
            $nodeTime[$node]['remote_nodes'][$i]['last_keyed'] = $arr['last_keyed'];
            
            // Store remote nodes other than time values (&nbsp;). 
            // Array key of remote_nodes is not node number to prevent javascript (for in) sorting
            $current[$node]['remote_nodes'][$i]['node']=$arr['node'];
            $current[$node]['remote_nodes'][$i]['info']=$arr['info'];
            $current[$node]['remote_nodes'][$i]['link']=$arr['link'];
            $current[$node]['remote_nodes'][$i]['ip']=$arr['ip'];
            $current[$node]['remote_nodes'][$i]['direction']=$arr['direction'];
            $current[$node]['remote_nodes'][$i]['keyed']=$arr['keyed'];
            $current[$node]['remote_nodes'][$i]['mode']=$arr['mode'];
            $current[$node]['remote_nodes'][$i]['elapsed'] = '&nbsp;';


// WA3DSP
// Change to return "Never" so test can be made in link.php

      if ( $arr['last_keyed'] == "Never" ) {
           $current[$node]['remote_nodes'][$i]['last_keyed'] = 'Never';
      } else {   
           $current[$node]['remote_nodes'][$i]['last_keyed'] = '&nbsp';
      }

// WA3DSP 3/2018    
// Change to add local RXKEYED COS display
$current[$node]['remote_nodes'][$i]['cos_keyed']=$arr['cos_keyed'];
$current[$node]['remote_nodes'][$i]['info']=$arr['info'];
$current[$node]['remote_nodes'][$i]['node']=$arr['node'];
// END

// ADDED KN2R 9/2018
// Change to add local TXKEYED PTT display
$current[$node]['remote_nodes'][$i]['tx_keyed']=$arr['tx_keyed'];
// END KN2R

        $i++;
        }
        
    }

    // Send current nodes only when data changes
    if ($current !== $saved) {
        $saved = $current;
        echo "event: nodes\n";
        echo 'data: ' . json_encode($current) . "\n\n";
    }
    
    // Send times every cycle
    echo "event: nodetimes\n";
    echo 'data: ' . json_encode($nodeTime) . "\n\n";
    
    
    #print "===== \$current =====\n";
    #print_r($current);            
    #print_r($nodeTime);            
    #print "===== end =====\n\n";
    ob_flush();
    flush();

    // ADDED KN2R - 05/11/2020 - Supermon loop delay
    if (isset($SMLOOPDELAY) && ($SMLOOPDELAY > 399999 && $SMLOOPDELAY < 5000001)) {
        usleep($SMLOOPDELAY);
    } else {
        usleep(500000); # Wait Default 0.5 seconds
    }
    // END KN2R
}

fwrite($fp, "ACTION: Logoff\r\n\r\n");
exit;

// Get status for this $node
function getNode($fp, $node) {
    $actionRand = mt_rand();    # Asterisk Manger Interface an actionID so we can find our own response
    
    $actionID = 'xstat' . $actionRand;
    if ((fwrite($fp,"ACTION: RptStatus\r\nCOMMAND: XStat\r\nNODE: $node\r\nActionID: $actionID\r\n\r\n")) !== FALSE ) {
        // Get RptStatus
        $rptStatus = AMIget_response($fp, $actionID);
        #print "<pre>\n===== Xstat =====\n";
        #var_dump($rptStatus);            
        #print "===== end =====\n</pre>\n";
    } else {
        $data['status'] = 'XStat() failed!';
        echo 'data: ' .  json_encode($data) . "\n\n";
        ob_flush();
        flush();
    }
    
    // format of Conn lines: Node# isKeyed lastKeySecAgo lastUnkeySecAgo
    $actionID = 'sawstat' . $actionRand;
    if ((fwrite($fp,"ACTION: RptStatus\r\nCOMMAND: SawStat\r\nNODE: $node\r\nActionID: $actionID\r\n\r\n")) !== FALSE ) {
        // Get RptStatus
        $sawStatus = AMIget_response($fp, $actionID);
        #print "<pre>\n===== \$sawStat start =====\n";
        #var_dump($sawStatus);            
        #print "===== end =====\n</pre>\n";
    } else {
        $data['status'] = 'sawStat failed!';
        echo 'data: ' .  json_encode($data) . "\n\n";
        ob_flush();
        flush();
    }
    
    // Parse this $node. Retuns an array of currently connected nodes
    $current = parseNode($fp, $rptStatus, $sawStatus);
    #print "<pre>===== \$current start =====\n";
    #print_r($current);
    #print "===== end =====\n</pre>";

    return($current);
}


function sortNodes($nodes) {
    
    $arr=array();
    $never_heard=array();
    $sortedNodes=array();
    
    // build an array of heard and unheard
    foreach($nodes as $nodeNum => $row) {
        if ($row['last_keyed'] == '-1') {$never_heard[$nodeNum]='Never heard';}
        else {$arr[$nodeNum]=$row['last_keyed'];}
    }
    
    // Sort nodes that have been heard
    if (count($arr) > 0) {asort($arr, SORT_NUMERIC);}
    
    // Add in nodes that have not been heard
    if (count($never_heard) > 0) {
        ksort($never_heard, SORT_NUMERIC);
        foreach($never_heard as $nodeNum => $row) {
            $arr[$nodeNum] = $row;
        }
    }
    
    // Build sorted node array
    foreach($arr as $nodeNum => $row) {
        // Build last_keyed string. Converts seconds to hours, minutes, seconds.
        if ($nodes[$nodeNum]['last_keyed'] > -1) {
            $t = $nodes[$nodeNum]['last_keyed'];
            $h = floor($t / 3600);
            $m = floor(($t / 60) % 60);
            $s = $t % 60;
            $nodes[$nodeNum]['last_keyed'] = sprintf("%03d:%02d:%02d", $h, $m, $s);
        } 
        else { $nodes[$nodeNum]['last_keyed'] = "Never"; }
        $sortedNodes[$nodeNum]=$nodes[$nodeNum];
    }
    
return ($sortedNodes);
}


function parseNode($fp, $rptStatus, $sawStatus) {
    $curNodes = array();
    $links = array();
    $conns = array();
    // Parse 'rptStat Conn:' lines.
    $lines = explode("\n", $rptStatus);
    foreach ($lines as $line) {
     if (preg_match('/Conn: (.*)/', $line, $matches)) {
       $arr = preg_split("/\s+/", trim($matches[1]));
//         if(is_numeric($arr[0]) && $arr[0] > 3000000) { $conns[] = array($arr[0], "", $arr[1], $arr[2], $arr[3], $arr[4]);}  // echolink not used on gmrs
//         else {$conns[] = $arr;}   
        $conns[] = $arr;
        }
 
	if (preg_match('/Var: RPT_RXKEYED=./', $line, $matches)) { $rxKeyed=substr($matches[0], strpos($matches[0], "=") + 1);} // WA3DSP 3/2018
	if (preg_match('/Var: RPT_TXKEYED=./', $line, $matches)) { $txKeyed=substr($matches[0], strpos($matches[0], "=") + 1); }// ADDED KN2R 9/2018
    }
    #print "<pre>Conns: \n"; print_r($conns); print "</pre>";
    // Parse 'sawStat Conn:' lines.
    $keyups = array();
    $lines = explode("\n", $sawStatus);
    foreach ($lines as $line) {
        if (preg_match('/Conn: (.*)/', $line, $matches)) {
            $arr = preg_split("/\s+/", trim($matches[1]));
            $keyups[$arr[0]] = array('node' => $arr[0], 'isKeyed' => $arr[1], 'keyed' => $arr[2], 'unkeyed' => $arr[3]);
        }
    }
    #print "<pre>====== \$keyups start ======\n"; print_r($keyups); print '====== end ======</pre>'; 

    // Parse 'LinkedNodes:' line.
    if (preg_match("/LinkedNodes: (.*)/", $rptStatus, $matches)) {
        $longRangeLinks = preg_split("/, /", trim($matches[1]));
    }
    foreach ($longRangeLinks as $line) {
        $n = substr($line,1);
        $modes[$n]['mode'] = substr($line,0,1);
    }

    // Pull above arrays together into $curNodes
    if (count($conns) > 0 ) {
      // Local connects
        foreach($conns as $node) {
            $n = $node[0];
            $curNodes[$n]['node'] = $node[0];
            $curNodes[$n]['info'] = getAstInfo($fp, $node[0]);
            $curNodes[$n]['ip'] = $node[1];
            $curNodes[$n]['direction'] = $node[3];
            $curNodes[$n]['elapsed'] = $node[4];
            $curNodes[$n]['link'] = @$node[5];
            $curNodes[$n]['keyed'] = 'n/a';
            $curNodes[$n]['last_keyed'] = 'n/a';
            if (isset($modes[$n])) {$curNodes[$n]['mode'] = $modes[$n]['mode'];}
            else {$curNodes[$n]['mode'] = 'Local Monitor';}
            $n++;
        }
        // Pullin keyed
        foreach($keyups as $node => $arr) {
            if ($arr['isKeyed'] == 1) {$curNodes[$node]['keyed'] = 'yes'; }
            else {$curNodes[$node]['keyed'] = 'no';}
            $curNodes[$node]['last_keyed'] = $arr['keyed'];
        }
	$curNodes[1]['node'] = 1;  // WA3DSP 3/2018
   } 
   else {$curNodes[1]['info'] = "NO CONNECTION";}
         
if ($rxKeyed === "1") { $curNodes[1]['cos_keyed'] = 1;}
else {$curNodes[1]['cos_keyed'] = 0;} // END WA3DSP

if ($txKeyed === "1") { $curNodes[1]['tx_keyed'] = 1;} // ADDED KN2R 9/2018 - PTT indicator
else {$curNodes[1]['tx_keyed'] = 0;} // END KN2R

return $curNodes;
}


// GMRS functions added.  

// Reads output lines from Asterisk Manager
function AMIget_response($fp, $actionID) {
    while (TRUE) {
		$str = fgets($fp);
		# Looking for our actionID
		if ("ActionID: $actionID" == trim($str)) {
			$response = $str;
			while (TRUE) {
				$str = fgets($fp);
		        #if (strlen(trim($str)) != 0 ) {
                if ($str != "\r\n") {$response .= $str;}
                else {return($response);}
			}
		}
    }
}

function AMIconnect($host) {
    // Set default port if not provided
    $arr = explode(":", $host);
    $ip = $arr[0];
    if (isset($arr[1])) {$port = $arr[1];}
    else { $port = 5038;}
    // Open a manager socket.
    $fp = @fsockopen($ip, $port, $errno, $errstr, 5);
    #print "parms: $ip $port $errno $errstr";
    return ($fp);
}

function AMIlogin($fp, $user, $password) {
    // Login
	$actionID = $user . $password;
    fwrite($fp,"ACTION: LOGIN\r\nUSERNAME: $user\r\nSECRET: $password\r\nEVENTS: 0\r\nActionID: $actionID\r\n\r\n");
    $login = AMIget_response($fp, $actionID);
	if (preg_match("/Authentication accepted/", $login) == 1) { return(TRUE);}
    else {return(FALSE);}
}


// Send a command to the AMI and return the response.
function AMIcommand($fp, $cmdString) {
	// AMI needs an ActionID so we can find our own response
	$actionRand = mt_rand();
	$actionID = 'cpAction_' . $actionRand;
	if ((@fwrite($fp,"ACTION: COMMAND\r\nCOMMAND: $cmdString\r\nActionID: $actionID\r\n\r\n")) > 0 ) {
    	$rptStatus = AMIget_response($fp, $actionID);
		$resultlist = explode ("\r\n", $rptStatus);
    	return ($resultlist[1]);
	} 
    else {return ("Get node $cmdString failed!");}
}

//    elseif ($nodeNum > 3000000) {$info = "echolink";}// not used on GMRS
//    elseif ($nodeNum > 80000)   {$info = "irlp";}// Not used on GMRS 
//elseif (`echo $nodeNum |egrep -c "\-P"` > 0) { $info = 'AllStar Phone Portal user';}
// this does not work elseif (!empty($node['ip'])) {if (strlen(trim($node['ip'])) > 3) {$info = 'Web Txcvr or Phone Portal (' . $node['ip'] . ')';}} 


// Compacted and converted to GMRS
function getAstInfo($fp, $nodeNum) {
global $astdb,$node; 
$ip="";
if (isset($node[1])) {
   $u= explode(".",$node[1]);
    if (isset($u[4])){$ip=" $u[4]";} 
   }
$info = "DV switch - IAX connection"; 
if (is_numeric($nodeNum)) { $info = "Node not in database$ip";}

if (isset($astdb[$nodeNum])) {$dbNode = $astdb[$nodeNum]; $info = "$dbNode[1] $dbNode[2] $dbNode[3]";} // its in the nodelist
return $info;
}

?>
