#!/bin/bash
# Timezone Configuration Script 
# Updated: 12/20/2024
# This program configures the system timezone and updates timezone files using Arch Linux repositories.
# It also includes logging for debugging and error handling.
#MENUFT%030%Time Zone Change

MM_SOFTWARE_FILE="/etc/asterisk/local/mm-software/version.txt"
if [ -f "$MM_SOFTWARE_FILE" ]; then
    MM_SOFTWARE_VERSION=$(head -1 "$MM_SOFTWARE_FILE" | awk -F ',' '{print "Version: "$1"\nRelease Date: "$2}')
else
    MM_SOFTWARE_VERSION="MM Software Version File Not Found"
fi

IP_ADDRESS=$(ip addr show eth0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
if [ -z "$IP_ADDRESS" ]; then
    IP_ADDRESS=$(ip addr show wlan0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
fi
IP_ADDRESS=${IP_ADDRESS:-"IP info unavailable"}

CUR_TZ=$(/usr/bin/timedatectl | /usr/bin/grep "Time zone" | /usr/bin/awk '{print $3}')

TZDB_LAST_UPDATE=$(stat -c %y /usr/share/zoneinfo | awk '{print $1, $2}' | awk -F'[-: ]' '{printf "%02d-%02d-%04d %02d:%02d:%02d\n", $2, $3, $1, $4, $5, $6}')

LOG_FILE="/tmp/timezone_update.log"


set_utc_offset_from_menu() {
    # Define the complete list of time zones with UTC offsets, including U.S. zones at the top
    TIMEZONES=(
        "1" "UTC-5 (Eastern Standard Time, USA)"
        "2" "UTC-6 (Central Standard Time, USA)"
        "3" "UTC-7 (Mountain Standard Time, USA)"
        "4" "UTC-8 (Pacific Standard Time, USA)"
        "5" "UTC-9 (Alaska Standard Time, USA)"
        "6" "UTC-10 (Hawaii-Aleutian Standard Time, USA)"
        "7" "UTC-4 (Atlantic Standard Time, USA)"
        # Full UTC offsets
        "8" "UTC-12 (Baker Island Time)"
        "9" "UTC-11 (Samoa Standard Time)"
        "10" "UTC-10 (Hawaii-Aleutian Standard Time)"
        "11" "UTC-9 (Alaska Standard Time)"
        "12" "UTC-8 (Pacific Standard Time)"
        "13" "UTC-7 (Mountain Standard Time)"
        "14" "UTC-6 (Central Standard Time)"
        "15" "UTC-5 (Eastern Standard Time)"
        "16" "UTC-4 (Atlantic Standard Time)"
        "17" "UTC-3 (Argentina, Brazil Time)"
        "18" "UTC-2 (South Georgia Time)"
        "19" "UTC-1 (Azores Time)"
        "20" "UTC+0 (Greenwich Mean Time)"
        "21" "UTC+1 (Central European Time)"
        "22" "UTC+2 (Eastern European Time)"
        "23" "UTC+3 (Moscow Standard Time)"
        "24" "UTC+4 (Azerbaijan Time)"
        "25" "UTC+5 (Pakistan Standard Time)"
        "26" "UTC+6 (Bangladesh Standard Time)"
        "27" "UTC+7 (Indochina Time)"
        "28" "UTC+8 (China Standard Time)"
        "29" "UTC+9 (Japan Standard Time)"
        "30" "UTC+10 (Chamorro Standard Time)"
        "31" "UTC+11 (Srednekolymsk Time)"
        "32" "UTC+12 (Wake Island Time)"
        "33" "UTC+13 (Phoenix Islands Time)"
        "34" "UTC+14 (Line Islands Time)"
    )

    # Use dialog to show the time zone selection menu
    SELECTION=$(dialog --menu "This disables daylight savings time\nSelect a Time Zone" 20 70 34 "${TIMEZONES[@]}" 2>&1 > /dev/tty)

    # Log the selection for debugging
    echo "User selected option: $SELECTION" | tee -a "$LOG_FILE"

    # Map the user's selection to the corresponding UTC offset
    case "$SELECTION" in
        1) TIMEZONE="Etc/GMT+5" ;;  # UTC-5
        2) TIMEZONE="Etc/GMT+6" ;;  # UTC-6
        3) TIMEZONE="Etc/GMT+7" ;;  # UTC-7
        4) TIMEZONE="Etc/GMT+8" ;;  # UTC-8
        5) TIMEZONE="Etc/GMT+9" ;;  # UTC-9
        6) TIMEZONE="Etc/GMT+10" ;; # UTC-10
        7) TIMEZONE="Etc/GMT+4" ;;  # UTC-4
        8) TIMEZONE="Etc/GMT+12" ;; # UTC-12
        9) TIMEZONE="Etc/GMT+11" ;; # UTC-11
        10) TIMEZONE="Etc/GMT+10" ;; # UTC-10
        11) TIMEZONE="Etc/GMT+9" ;;  # UTC-9
        12) TIMEZONE="Etc/GMT+8" ;;  # UTC-8
        13) TIMEZONE="Etc/GMT+7" ;;  # UTC-7
        14) TIMEZONE="Etc/GMT+6" ;;  # UTC-6
        15) TIMEZONE="Etc/GMT+5" ;;  # UTC-5
        16) TIMEZONE="Etc/GMT+4" ;;  # UTC-4
        17) TIMEZONE="Etc/GMT+3" ;;  # UTC-3
        18) TIMEZONE="Etc/GMT+2" ;;  # UTC-2
        19) TIMEZONE="Etc/GMT+1" ;;  # UTC-1
        20) TIMEZONE="Etc/GMT" ;;    # UTC+0
        21) TIMEZONE="Etc/GMT-1" ;;  # UTC+1
        22) TIMEZONE="Etc/GMT-2" ;;  # UTC+2
        23) TIMEZONE="Etc/GMT-3" ;;  # UTC+3
        24) TIMEZONE="Etc/GMT-4" ;;  # UTC+4
        25) TIMEZONE="Etc/GMT-5" ;;  # UTC+5
        26) TIMEZONE="Etc/GMT-6" ;;  # UTC+6
        27) TIMEZONE="Etc/GMT-7" ;;  # UTC+7
        28) TIMEZONE="Etc/GMT-8" ;;  # UTC+8
        29) TIMEZONE="Etc/GMT-9" ;;  # UTC+9
        30) TIMEZONE="Etc/GMT-10" ;; # UTC+10
        31) TIMEZONE="Etc/GMT-11" ;; # UTC+11
        32) TIMEZONE="Etc/GMT-12" ;; # UTC+12
        33) TIMEZONE="Etc/GMT-13" ;; # UTC+13
        34) TIMEZONE="Etc/GMT-14" ;; # UTC+14
        *)
            dialog --msgbox "Invalid selection. Please select a valid time zone." 10 60
            echo "Invalid selection. User did not choose a valid option." | tee -a "$LOG_FILE"
            return 1
            ;;
    esac

    echo "Setting timezone to $TIMEZONE (No DST)..." | tee -a "$LOG_FILE"

    # Set the system timezone to the selected UTC offset without DST
    sudo timedatectl set-timezone "$TIMEZONE" 2>&1 | tee -a "$LOG_FILE"

    # Check the result and log success or failure
    if [ $? -eq 0 ]; then
        echo "Timezone successfully set to $TIMEZONE (no DST)." | tee -a "$LOG_FILE"
        dialog --msgbox "Timezone successfully set to $TIMEZONE (no DST)." 10 60
    else
        echo "Failed to set timezone to $TIMEZONE. Check the logs for more details." | tee -a "$LOG_FILE"
        dialog --msgbox "Failed to set timezone. Please try again." 10 60
    fi
}


set_timezone() {
   $SOFF
        $D --title "GMRS USA Time Zone Configuration" \
           --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION $IP_ADDRESS" \
           --nocancel --yesno "\
Time Zone Configuration\n\n\
The current system time zone is set to: ${CUR_TZ}\n\n\
GMRS is a USA only system so only USA timezones are supported.\n
Would you like to update the system's time zone now?" 18 78
        RET=$?
        if [ $RET -ne 0 ]; then
            continue  # Return to the main menu
        fi
        dialog --title "Please Wait" --infobox "Processing... Please wait." 5 50
        # Get the list of timezones for America only
        FILE_TZ=/tmp/settz.$$.1
        /usr/bin/timedatectl --no-pager list-timezones | grep -E "^America/" > $FILE_TZ
        LENGTH=$(/usr/bin/wc -l $FILE_TZ | /usr/bin/awk '{print $1}')

        # Prepare the timezone list
        idx=1
        ARY=()
        TZLIST=()

        # Loop through the timezones and build the list
        for zone in $(cat $FILE_TZ); do
            offset=$(env TZ=":$zone" date +"(%Z, %z)")
            printf -v ttemp "%-30s %s" "$zone" "$offset"
            TZLIST[$idx]="$zone"
            ARY+=($idx "$ttemp")
            let idx+=1
        done

        /usr/bin/rm -f /tmp/settz.$$.*

        ###
        ### Display the timezone selection menu using dialog
        ###

        # Create the menu options string for dialog
        MENU_OPTIONS=()
        for i in "${!TZLIST[@]}"; do
            MENU_OPTIONS+=("$i" "${TZLIST[$i]}")  # Each option: index, timezone
        done

        # Display the timezone selection menu
        SELECTION=$($D --menu "Select a Timezone" 15 60 6 "${MENU_OPTIONS[@]}" 2>&1 > /dev/tty)

        # If no selection was made, return to the menu or exit
        if [ -z "$SELECTION" ]; then
            $D --title "Selection Cancelled" --msgbox "No timezone selected. Exiting..." 8 78
            exit 0
        fi

        # Set the selected timezone
        /usr/bin/timedatectl set-timezone "${TZLIST[$SELECTION]}"
        CUR_TZ=$(/usr/bin/timedatectl | /usr/bin/grep "Time zone" | /usr/bin/awk '{print $3}')
        echo "Timezone successfully set to $CUR_TZ" | tee -a "$LOG_FILE"
        # Display confirmation that the timezone was set successfully
        $D --title "Timezone Set" \
           --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION $IP_ADDRESS" \
           --msgbox "The system's timezone has been updated to: $CUR_TZ" 10 30

        $SON

}




MENU=( 
    1 "Set Timezone by name" 
    2 "Set Timezone to UTC offset - No savings Time"
    3 "Exit"
)

while true; do
    selection=$($D --title "Time Zone Configuration" \
       --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION $IP_ADDRESS" \
       --menu "Timezone: [${CUR_TZ}]\nThis menu allows you to change timezone. " 12 80 4 "${MENU[@]}" 3>&1- 1>&2- 2>&3-)

    RET=$?
    if [ $RET -ne 0 ]; then
        $SOFF
        $SON
        exit 0
    fi

case "$selection" in
    1)
        set_timezone
        continue
        ;;
    2)
        set_utc_offset_from_menu
        continue
        ;;

    3)
        $SOFF
        $SON
        exit 0
        ;;    
        
    *)
        $SOFF
        $SON
        exit 0
        ;;
esac
done

