#!/bin/bash
# MENU%10%Memory Card Utility

if ! command -v dialog &>/dev/null; then
  echo "The 'dialog' command is required but not installed. Please install it and try again."
  exit 1
fi

DIALOG_WIDTH=50
BAR_LENGTH=$((DIALOG_WIDTH - 10))

MM_SOFTWARE_FILE="/etc/asterisk/local/mm-software/version.txt"
if [ -f "$MM_SOFTWARE_FILE" ]; then
    MM_SOFTWARE_VERSION=$(head -1 "$MM_SOFTWARE_FILE" | awk -F ',' '{print "Version: "$1"\nRelease Date: "$2}')
else
    MM_SOFTWARE_VERSION="MM Software Version File Not Found"
fi

# Get IP Address (using ip addr instead of hostname -I)
IP_ADDRESS=$(ip addr show eth0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
if [ -z "$IP_ADDRESS" ]; then
    IP_ADDRESS=$(ip addr show wlan0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
fi
# If IP address is still blank, set fallback message
IP_ADDRESS=${IP_ADDRESS:-"IP info unavailable"}





# Get disk and partition sizes
disk_size=$(lsblk -b -o SIZE -n -d /dev/mmcblk0)
partition_size=$(lsblk -b -o SIZE -n /dev/mmcblk0p2)

disk_size_human=$(lsblk -o SIZE -n -d /dev/mmcblk0)
partition_size_human=$(lsblk -o SIZE -n /dev/mmcblk0p2)

# Calculate percentage usage
partition_percentage=$((partition_size * 100 / disk_size))

# Generate a dynamic text-based bar
generate_text_bar() {
  local percentage=$1
  local filled=$((percentage * BAR_LENGTH / 100))
  local empty=$((BAR_LENGTH - filled))
  local bar=""
  for ((i = 0; i < filled; i++)); do bar+="#"; done
  for ((i = 0; i < empty; i++)); do bar+="-"; done
  echo "[$bar] $percentage%"
}

bar=$(generate_text_bar $partition_percentage)

# Check if the partition already fills the card
is_filled=false
if [ "$disk_size" -eq "$partition_size" ]; then
  is_filled=true
fi

# Create the menu
while true; do
  # Build menu options dynamically
  menu_options=(1 "Help")
  if [ "$is_filled" = false ]; then
    menu_options+=(2 "Expand partition to fill the card")
  fi
  menu_options+=(
    3 "Scan partition for errors"
    4 "View disk and partition info"
    5 "View filesystem usage"
    6 "Exit"
  )

  choice=$(dialog --stdout --title "Memory Card Utility" \
    --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION $IP_ADDRESS" \
    --nocancel \
    --menu "$disk_size_human Card usage:$partition_size_human\n$bar" \
    17 $DIALOG_WIDTH 8 "${menu_options[@]}")

  case $choice in
       1)
dialog --msgbox "The original Hamvoip Asterisk/GMRSLIVE image does NOT automatically expand to fill the entire disk, and it is fixed at 3.6GB.\n\nThis can result in running out of space and not utilizing the full capacity of your SD card.\n\n While this was fine years ago, modern SD cards like the commonly used 32GB cards have become the standard. Modern Raspberry Pi OS images automatically expand to use the entire disk on first boot.\n\nI've opted to make the expansion a manual process, giving you the opportunity to back up your card at its smaller size before expanding it.\n\nYou can now expand the system to use the full capacity of your SD card.\n\nCurrent SD Card Size: $disk_size_human\nCard Usage: $partition_size_human\n$bar\n\nLouisiana GMRS Image (It's just better)" 30 70


      ;;   
    2)
      dialog --infobox "Expanding the partition..." 5 40
      parted /dev/mmcblk0 resizepart 2 100% || {
        dialog --msgbox "Failed to resize the partition." 10 40
        exit 1
      }
      resize2fs /dev/mmcblk0p2 || {
        dialog --msgbox "Failed to resize the filesystem." 10 40
        exit 1
      }
      dialog --msgbox "Partition successfully expanded!\nNew partition size: $(lsblk -o SIZE -n /dev/mmcblk0p2)\n\nA reboot is required to apply the changes." 15 50
      partition_size=$(lsblk -b -o SIZE -n /dev/mmcblk0p2)
      partition_percentage=$((partition_size * 100 / disk_size))
      bar=$(generate_text_bar $partition_percentage)
      is_filled=true
      ;;
    3)
      dialog --infobox "Scanning partition for errors..." 5 40
      fsck -n /dev/mmcblk0p2 > /tmp/fsck_output 2>&1
      dialog --textbox /tmp/fsck_output 20 60
      ;;
    4)
      dialog --infobox "Gathering disk and partition info..." 5 40
      lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINT > /tmp/disk_info
      dialog --textbox /tmp/disk_info 20 60
      ;;
    5)
      dialog --infobox "Gathering filesystem usage info..." 5 40
      df -hT /dev/mmcblk0p2 > /tmp/fs_usage
      dialog --textbox /tmp/fs_usage 20 60
      ;;
    6)

      exit 0
      ;;
    *)
      break
      ;;
  esac
done
