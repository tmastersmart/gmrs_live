#!/bin/bash
# ---------------
# Copyright (C) 2024 By mike wrxb288
# Custom image Version 
# MENU%13%Asterisk Controller & Services
MM_SOFTWARE_FILE="/etc/asterisk/local/mm-software/version.txt"
if [ -f "$MM_SOFTWARE_FILE" ]; then
    MM_SOFTWARE_VERSION=$(head -1 "$MM_SOFTWARE_FILE" | awk -F ',' '{print "Version: "$1"\nRelease Date: "$2}')
else
    MM_SOFTWARE_VERSION="MM Software Version File Not Found"
fi

# Get IP Address (using ip addr instead of hostname -I)
IP_ADDRESS=$(ip addr show eth0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
if [ -z "$IP_ADDRESS" ]; then
    IP_ADDRESS=$(ip addr show wlan0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
fi
# If IP address is still blank, set fallback message
IP_ADDRESS=${IP_ADDRESS:-"IP info unavailable"}

# Function to fetch and display Asterisk version
display_version() {
    ASTERISK_VERSION=$(/sbin/asterisk -rx 'core show version' 2>/dev/null | head -n 1)
    ASTERISK_VERSION=${ASTERISK_VERSION:-"Unable to fetch version. Asterisk may not be running."}
}

# Function to start Asterisk
start_asterisk() {
    if [ -e /var/run/asterisk.ctl ]; then
        dialog --msgbox "Asterisk is already running!" 6 40
    else
        dialog --infobox "Starting Asterisk..." 6 40
        /usr/sbin/safe_asterisk &>/dev/null
        if [ $? -eq 0 ]; then
            dialog --msgbox "Asterisk has been started successfully." 6 40
        else
            dialog --msgbox "Failed to start Asterisk." 6 40
        fi
    fi
}

# Function to stop Asterisk
stop_asterisk() {
    if [ -e /var/run/asterisk.ctl ]; then
        dialog --infobox "Stopping Asterisk..." 6 40
        /sbin/asterisk -rx 'stop now' &>/dev/null
        if [ $? -eq 0 ]; then
            dialog --msgbox "Asterisk has been stopped successfully." 6 40
        else
            dialog --msgbox "Failed to stop Asterisk using CLI." 6 40
        fi
    else
        dialog --infobox "Asterisk is not running. Cleaning up resources..." 6 40
        (
            /sbin/killall safe_asterisk
            /bin/sleep 1
            /sbin/killall asterisk
            /bin/rm -f /var/run/asterisk.ctl /var/run/asterisk.pid
        ) &>/dev/null
        dialog --msgbox "Asterisk was not running. Clean-up completed." 6 40
    fi
}

# Function to restart Asterisk
restart_asterisk() {
    if [ -e /var/run/asterisk.ctl ]; then
        dialog --infobox "Restarting Asterisk..." 6 40
        /sbin/asterisk -rx 'stop now' &>/dev/null
    else
        dialog --infobox "Asterisk is not running! Starting Asterisk..." 6 40
    fi
    (
        /sbin/killall safe_asterisk
        /bin/sleep 1
        /sbin/killall asterisk
        /bin/rm -f /var/run/asterisk.ctl /var/run/asterisk.pid
        /usr/sbin/safe_asterisk
    ) &>/dev/null
    dialog --msgbox "Asterisk has been restarted successfully." 6 40
}


restart_dns() {
    if systemctl is-active --quiet dns_update.service; then
        dialog --infobox "Restarting DNS service..." 6 40
        systemctl restart dns_update &>/dev/null   

    else
        dialog --infobox "DNS service is not running! Starting DNS service..." 6 40
        systemctl start dns_update &>/dev/null
    fi

    if systemctl is-active --quiet dns_update; then
        dialog --msgbox "DNS service has been restarted successfully." 6 40
    else
        dialog --msgbox "Failed to restart DNS service. Please check the service status." 6 40
    fi
}
# Function to reload Asterisk configuration
reload_asterisk_config() {
    if [ -e /var/run/asterisk.ctl ]; then
        dialog --infobox "Reloading Asterisk configuration files..." 6 40
        /sbin/asterisk -rx 'reload' &>/dev/null
        if [ $? -eq 0 ]; then
            dialog --msgbox "Asterisk configuration files reloaded successfully. \nYes its true you dont have to restart when you make changes.\n\n Louisiana image  (its just better)" 10 50
        else
            dialog --msgbox "Failed to reload Asterisk configuration files." 6 40
        fi
    else
        dialog --msgbox "Asterisk is not running! Unable to reload configuration files." 6 40
    fi
}

# Function to open Asterisk CLI
open_asterisk_cli() {
    dialog --clear
    reset
   
    echo "   _____________________________________ "
    echo "  |    Starting Asterisk client. CLI    |" 
    echo "  | type: exit to return to admin menu  |"
    echo "  |                                     |"
    echo "  |Louisiana Image   (its just better)  |"
    echo "  |_____________________________________|"
    echo "  Ready:"
    echo ""
    /sbin/asterisk -vvvvrgc
}

# Main menu with actions for Asterisk
main_menu() {
    display_version
    selection=$(dialog --title "Main services menu" \
        --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION $IP_ADDRESS" \
        --nocancel \
        --menu "Asterisk is the main node program. DNS updates the IP addresses. Status updates the status page database.\n\nPlease select an action:" \
        20 75 9 \
        1 "Start Asterisk" \
        2 "Stop Asterisk" \
        3 "Restart Asterisk" \
        4 "Reload Asterisk Conf (new)" \
        5 "Open Asterisk CLI" \
        6 "Restart GMRS DNS Service (new)"\
        7 "Exit" \
        3>&1 1>&2 2>&3)

    case $selection in
        1)
            start_asterisk
            main_menu
            ;;
        2)
            stop_asterisk
            main_menu
            ;;
        3)
            restart_asterisk
            main_menu
            ;;
        4)
            reload_asterisk_config
            main_menu
            ;;
        5)
            open_asterisk_cli
            main_menu
            ;;
           
        6)
            restart_dns
            main_menu
            ;;            
 
        7)
            exit 0
            ;;
        *)
            dialog --msgbox "Invalid option." 6 40
            main_menu
            ;;
    esac
}

# Start the main menu
main_menu

