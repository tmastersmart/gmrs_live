#!/bin/bash
# Modified 2017/01/20 by David, KB4FXC
# ---------------
# Copyright (C) 2014-2017 David, KB4FXC 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see http://www.gnu.org/licenses/.
# ---------------
#
# 
#MENU%14%Run simpleusb-tune-menu Application

$SON
reset
echo ""
echo ""
echo ""
echo "          Starting simpleusb-tune-menu. Please type: 0<ENTER>"
echo "           when done and you will return to the admin menu."
echo ""
echo ""
echo ""
echo ""
/sbin/simpleusb-tune-menu



exit 0

