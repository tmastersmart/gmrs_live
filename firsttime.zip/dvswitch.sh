#/!bin/bash
#MENUFT%055%DV SWITCH Setup
 
$SON
reset

php /etc/asterisk/local/mm-software/dvswitch_setup.php

exit 0
