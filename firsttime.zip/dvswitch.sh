#/!bin/bash
#MENUFT%055%DV SWITCH Setup Program Version:12-24-2024
 
$SON
reset

php /etc/asterisk/local/mm-software/dvswitch_setup.php

exit 0
