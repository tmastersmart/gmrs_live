#/!bin/bash
#MENUFT%090%Say time and Weather 

$SON
reset

php /etc/asterisk/local/mm-software/weather_pws.php

exit 0
