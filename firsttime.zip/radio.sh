#!/bin/bash
# ---------------
# Copyright (C) 2024 By mike wrxb288
# Custom Louisiana image Version 
#MENU%17%USB FRS Radio Freq Conf

MM_SOFTWARE_FILE="/etc/asterisk/local/mm-software/version.txt"
if [ -f "$MM_SOFTWARE_FILE" ]; then
    MM_SOFTWARE_VERSION=$(head -1 "$MM_SOFTWARE_FILE" | awk -F ',' '{print "Version: "$1"\nRelease Date: "$2}')
else
    MM_SOFTWARE_VERSION="MM Software Version File Not Found"
fi


path="/home/user/srfrs.py"

# Function to get the version of the radio card
get_version() {
    version_output=$(python $path version 2>&1)
    status=$?
    if [[ $status -eq 0 ]]; then
        version_output="Radio Version: $version_output"
    else
        version_output="Error: No radio?"
    fi
}

# Get the version before the main menu
get_version



# Function to execute a command and display output
execute_command() {
    output=$(eval "$1" 2>&1)
    status=$?
    if [[ $status -eq 0 ]]; then
        dialog --msgbox "Command executed successfully:\n\n[$command]\n\n$output" 15 70
    else
        dialog --msgbox "An error occurred:\n\n[$command]\n\n$output" 15 70
    fi
}

# Function to setup the radio
setup_radio() {
    frequency=$(dialog --menu "Select GMRS Channel" 20 50 24 \
        15 "Channel 15 - 462.5500 MHz" \
         1 "Channel 1  - 462.5625 MHz" \
        16 "Channel 16 - 462.5750 MHz" \
         2 "Channel 2  - 462.5875 MHz" \
        17 "Channel 17 - 462.6000 MHz" \
         3 "Channel 3  - 462.6125 MHz" \
        18 "Channel 18 - 462.6250 MHz" \
         4 "Channel 4  - 462.6375 MHz" \
        19 "Channel 19 - 462.6500 MHz" \
         5 "Channel 5  - 462.6625 MHz" \
        20 "Channel 20 - 462.6750 MHz" \
         6 "Channel 6  - 462.6875 MHz" \
        21 "Channel 21 - 462.7000 MHz" \
         7 "Channel 7  - 462.7125 MHz" \
        22 "Channel 22 - 462.7250 MHz" \
        23 "Channel 23 - 467.5500 MHz r1" \
         8 "Channel 8  - 467.5625 MHz" \
        24 "Channel 24 - 467.5750 MHz r2" \
         9 "Channel 9  - 467.5875 MHz" \
        25 "Channel 25 - 467.6000 MHz r3" \
        10 "Channel 10 - 467.6125 MHz" \
        26 "Channel 26 - 467.6250 MHz r4" \
        11 "Channel 11 - 467.6375 MHz" \
        27 "Channel 27 - 467.6500 MHz r5" \
        12 "Channel 12 - 467.6625 MHz" \
        28 "Channel 28 - 467.6750 MHz r6" \
        13 "Channel 13 - 467.6875 MHz" \
        29 "Channel 29 - 467.7000 MHz r7" \
        14 "Channel 14 - 467.7125 MHz" \
        30 "Channel 30 - 467.7250 MHz r8" \
        2>&1 >/dev/tty)

    case $frequency in
       15) frequency="462.5500" ;;
        1) frequency="462.5625" ;;
       16) frequency="462.5750" ;;
        2) frequency="462.5875" ;;
       17) frequency="462.6000" ;;
        3) frequency="462.6125" ;;
       18) frequency="462.6250" ;;
        4) frequency="462.6375" ;;
       19) frequency="462.6500" ;;
        5) frequency="462.6625" ;;
       20) frequency="462.6750" ;;
        6) frequency="462.6875" ;;
       21) frequency="462.7000" ;;
        7) frequency="462.7125" ;;
       22) frequency="462.7250" ;;
       23) frequency="467.5500" ;;
        8) frequency="467.5625" ;;
       24) frequency="467.5750" ;;
        9) frequency="467.5875" ;;
       25) frequency="467.6000" ;;
       10) frequency="467.6125" ;;
       26) frequency="467.6250" ;;
       11) frequency="467.6375" ;;
       27) frequency="467.6500" ;;
       12) frequency="467.6625" ;;
       28) frequency="467.6750" ;;
       13) frequency="467.6875" ;;
       29) frequency="467.7000" ;;
       14) frequency="467.7125" ;;
       30) frequency="467.7250" ;;
      
       
       
        
        
        
       
        *)
            dialog --msgbox "Invalid choice." 6 40
            return
            ;;
    esac

    offset=$(dialog --inputbox "Enter offset: (0.0 default Simplex Node)\n\nFrequency: $frequencyif\nif using 462 Mhz = 5\nif using 467 Mhz = -5\nIncorrect setting will violate fcc rules. Use default if you dont understand :" 15 50 0.0 2>&1 >/dev/tty)
    squelch=$(dialog --inputbox "Enter squelch value (1-9, default: 1):" 11 50 4 2>&1 >/dev/tty)
    
    tone_choice=$(dialog --menu "Select Tone Type:" 15 50 4 \
        1 "CTCSS" \
        2 "DCS (not for AURSINC SR-FRS)" \
        3 "None (don't use without a tone please!)" \
        2>&1 >/dev/tty)

    case $tone_choice in
        1)
            ctcss=$(dialog --menu "Select CTCSS (PL Tone):" 20 50 15 \
                67.0 "67.0 Hz" \
                71.9 "71.9 Hz" \
                74.4 "74.4 Hz" \
                77.0 "77.0 Hz" \
                79.7 "79.7 Hz" \
                82.5 "82.5 Hz" \
                85.4 "85.4 Hz" \
                88.5 "88.5 Hz" \
                91.5 "91.5 Hz" \
                94.8 "94.8 Hz" \
                97.4 "97.4 Hz" \
                100.0 "100.0 Hz" \
                103.5 "103.5 Hz" \
                107.2 "107.2 Hz" \
                110.9 "110.9 Hz" \
                114.8 "114.8 Hz" \
                118.8 "118.8 Hz" \
                123.0 "123.0 Hz" \
                127.3 "127.3 Hz" \
                131.8 "131.8 Hz" \
                136.5 "136.5 Hz" \
                141.3 "141.3 Hz" \
                146.2 "146.2 Hz" \
                151.4 "151.4 Hz" \
                156.7 "156.7 Hz" \
                162.2 "162.2 Hz" \
                167.9 "167.9 Hz" \
                173.8 "173.8 Hz" \
                179.9 "179.9 Hz" \
                186.2 "186.2 Hz" \
                192.8 "192.8 Hz" \
                203.5 "203.5 Hz" \
                210.7 "210.7 Hz" \
                218.1 "218.1 Hz" \
                225.7 "225.7 Hz" \
                233.6 "233.6 Hz" \
                241.8 "241.8 Hz" \
                250.3 "250.3 Hz" \
                2>&1 >/dev/tty)
            command="python $path radio --frequency $frequency --offset $offset --squelch $squelch --ctcss $ctcss"
            ;;
        2)
            dialog --msgbox "Warning: FRS radios do not support DCS at this time." 15 50
            # Select DCS code
            dcs=$(dialog --menu "Select DCS Code:" 20 50 50 \
                023 "023" \
                025 "025" \
                026 "026" \
                031 "031" \
                032 "032" \
                036 "036" \
                043 "043" \
                047 "047" \
                051 "051" \
                053 "053" \
                054 "054" \
                065 "065" \
                071 "071" \
                072 "072" \
                073 "073" \
                074 "074" \
                114 "114" \
                115 "115" \
                116 "116" \
                122 "122" \
                125 "125" \
                131 "131" \
                132 "132" \
                134 "134" \
                143 "143" \
                145 "145" \
                152 "152" \
                155 "155" \
                156 "156" \
                162 "162" \
                165 "165" \
                172 "172" \
                174 "174" \
                205 "205" \
                212 "212" \
                223 "223" \
                225 "225" \
                226 "226" \
                243 "243" \
                244 "244" \
                245 "245" \
                246 "246" \
                251 "251" \
                252 "252" \
                255 "255" \
                261 "261" \
                263 "263" \
                265 "265" \
                266 "266" \
                271 "271" \
                274 "274" \
                306 "306" \
                311 "311" \
                315 "315" \
                325 "325" \
                331 "331" \
                332 "332" \
                343 "343" \
                346 "346" \
                351 "351" \
                356 "356" \
                364 "364" \
                365 "365" \
                371 "371" \
                411 "411" \
                412 "412" \
                413 "413" \
                423 "423" \
                431 "431" \
                432 "432" \
                445 "445" \
                446 "446" \
                452 "452" \
                454 "454" \
                455 "455" \
                462 "462" \
                464 "464" \
                465 "465" \
                466 "466" \
                503 "503" \
                506 "506" \
                516 "516" \
                523 "523" \
                526 "526" \
                532 "532" \
                546 "546" \
                565 "565" \
                606 "606" \
                612 "612" \
                624 "624" \
                627 "627" \
                631 "631" \
                632 "632" \
                654 "654" \
                662 "662" \
                664 "664" \
                703 "703" \
                712 "712" \
                723 "723" \
                731 "731" \
                732 "732" \
                734 "734" \
                743 "743" \
                754 "754" \
                2>&1 >/dev/tty)
            
            # Select Normal or Inverse tone
            tone_type=$(dialog --menu "Select DCS Tone Type:" 15 50 2 \
                1 "Normal" \
                2 "Inverse" \
                2>&1 >/dev/tty)
            
            # Append 'D' for Normal and 'I' for Inverse to the DCS code
            case $tone_type in
                1) dcs_code="${dcs}D" ;;  # Normal
                2) dcs_code="${dcs}I" ;;  # Inverse
                *)
                    dialog --msgbox "Invalid choice for DCS tone." 6 40
                    return
                    ;;
            esac

            command="python $path radio --frequency $frequency --offset $offset --squelch $squelch --dcs $dcs_code"
            ;;

        3)
            command="python $path radio --frequency $frequency --offset $offset --squelch $squelch"
            ;;
        *)
            dialog --msgbox "Invalid choice." 6 40
            return
            ;;
    esac

    execute_command "$command"
}

# Function to set the volume
set_volume() {
    volume=$(dialog --inputbox "Enter volume level (1-8, default: 8):" 10 50 4 2>&1 >/dev/tty)
    command="python $path volume --level $volume"
    execute_command "$command"
}

# Main menu loop
while true; do
    choice=$(dialog \
        --title "Radio Configuration Menu" \
        --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION $IP_ADDRESS" \
        --menu "$version_output\n\nRemember usb plug must be turned over first\n\nUSB Radio Configuration Menu" 15 50 6 \
        1 "Setup Radio" \
        2 "Set Volume" \
        3 "Exit" \
        2>&1 >/dev/tty)
    # Capture the exit status of the dialog command
    status=$?

    if [ $status -eq 1 ]; then
        # User pressed Cancel
        clear
        exit 0
    elif [ $status -ne 0 ]; then
        # Handle other unexpected errors
        dialog --msgbox "An unexpected error occurred. Exiting." 6 40
        clear
        exit 1
    fi
    case $choice in
        1) setup_radio ;;
        2) set_volume  ;;
        3)
            clear
            exit 0
            ;;
        *)
            dialog --msgbox "Invalid choice. Please try again." 6 40
            ;;
    esac
done
