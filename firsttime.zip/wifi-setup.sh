#!/bin/bash
#
# Modified for Louisiana Image
# 
#
#
#
# 
# 
# Raspberry Pi 2/3 and Wireless setup using systemd networking. This is not
# compatible with netctld. You must have your system configured using DHCP and not static IP addressing.
# MENU: Wireless Configuration and Control
#
# Modified 2017/01/23 by David, KB4FXC
# Bug fixes 2017/04/28 by David, KB4FXC
# Copyright (C) 2017 David, KB4FXC
# Copyright (C) 2016 Christopher Kovacs, W0ANM
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see http://www.gnu.org/licenses/.


export DD="/usr/bin/dialog"
MM_SOFTWARE_FILE="/etc/asterisk/local/mm-software/version.txt"
if [ -f "$MM_SOFTWARE_FILE" ]; then
    MM_SOFTWARE_VERSION=$(head -1 "$MM_SOFTWARE_FILE" | awk -F ',' '{print "Version: "$1"\nRelease Date: "$2}')
else
    MM_SOFTWARE_VERSION="MM Software Version File Not Found"
fi

IP_ADDRESS=$(ip addr show eth0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
if [ -z "$IP_ADDRESS" ]; then
    IP_ADDRESS=$(ip addr show wlan0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
fi
IP_ADDRESS=${IP_ADDRESS:-"IP info unavailable"}
# tmp scan file
WL_SCAN_FILE=/tmp/wireless_scan.info
WL_DEV=wlan0

# wpa supplicant file for wlan0
WPA_SUPP_CONF=/etc/wpa_supplicant/wpa_supplicant_custom-wlan0.conf
#WPA_SUPP_CONF=/root/test.conf

# functions
ssid_view () {
    echo > $WL_SCAN_FILE
    iwlist wlan0 scan >> $WL_SCAN_FILE

    grep 'No scan results' $WL_SCAN_FILE 2>/dev/null 1>&2
    RES=$?
    CNT=$(wc $WL_SCAN_FILE | awk '{print $1}')

    if [ $CNT -lt 4 -o $RES -eq 0 ] ; then
        $SOFF
        $D --msgbox " No scan results found! " 10 30
        return
    fi

    entries=$(cat $WL_SCAN_FILE)
    SAVEIFS=$IFS
    IFS=$(echo -en "\n\b")
    count=1
    SIGNAL=()
    QUALITY=()
    ESSID=()
    ENTRY=()
    for line in $entries ; do
        essid=$(echo $line | grep ESSID: | sed 's/^[ \t]*//;s/[ \t]*$//')
        essid=${essid#ESSID:}

        # strip off any quotes
        essid=$(echo ${essid} | sed -e 's/^"//' -e 's/"$//')

        if [ -n "$essid" ] ; then
            ESSID[$count]="$essid"
            continue
        fi

        quality=$(echo $line | grep Quality | awk '{print $1}' | awk -F= '{ print $2 }')
        signal=$(echo $line | grep "Signal level" | awk -F= '{ print $3 }')
        if [ -n "$quality" ] ; then
            QUALITY[$count]="$quality"
            SIGNAL[$count]="$signal"
        fi

        if [ -n "${SIGNAL[$count]}" -a -n "${QUALITY[$count]}" -a -n "${ESSID[$count]}" ] ; then
            let count=count+1
        fi
    done

    IFS=$SAVEIFS
    ITEMS=()
    ptr=1
    while [ $ptr -lt $count ] ; do
        if (grep "${ESSID[$ptr]}" /etc/wpa_supplicant/wpa_supplicant_custom-wlan0.conf> /dev/null) ; then
            ENTRY[$ptr]="****"
        else
            ENTRY[$ptr]="    "
        fi
        ITEMS+=($ptr "$ptr ${ESSID[$ptr]} | ${QUALITY[$ptr]} | ${SIGNAL[$ptr]} ${ENTRY[$ptr]}")
        let ptr=ptr+1
    done

    if [ $count -le 1 ] ; then
        $SOFF
        $D --msgbox " No scan results found! " 10 30
        return
    fi

    SSID_SEL=$($D --no-tags --title "Select SSID" --ok-label "Select SSID" --cancel-label "CANCEL" --menu "Below shows SSID Signal Quality and if entry present:" 20 70 10 "${ITEMS[@]}" 3>&1- 1>&2- 2>&3-)
    RET=$?
    if [ "$RET" = 1 ] ; then
        return
    fi

    ESSID_SEL=${ESSID[${SSID_SEL}]}
}

# main menu
while true; do
    $SOFF
OPTION=$($D --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION $IP_ADDRESS" \
--nocancel --title "WIFI Setup & Control" --menu \
"Please follow the steps to configure your wireless settings. Remember you must not connect wired and WIFI at the same time.\n
And only one wifi setup can be enterted at a time.\n\n
Louisiana GMRS Image (its just better)\n\n
Select an option below:" 20 70 8 \
1 "Setup Wireless SSID and passphrase" \
2 "Enable Wireless Device (wlan0)" \
3 "Disable Wireless Device (wlan0)" \
4 "View Wireless Setup" \
5 "View Network Info" \
6 "Exit" 3>&1 1>&2 2>&3)
    exitstatus=$?
    if [ $exitstatus = 0 ]; then

        if [ "$OPTION" = "1" ] ; then
            $SOFF
            $D --yesno "This program sets the SSID and Password for the wireless network. Do you wish to continue?" 10 60
            if [ "$?" = 1 ] ; then
                continue
            fi

            if [ ! -f "$WPA_SUPP_CONF" ] ; then
                touch "$WPA_SUPP_CONF"
                REBOOTNEEDED=yes
            else
                $SOFF
                $D --defaultno --yesno "Do you want to clear the wpa_supplicant file? Doing so will delete all prior SSID and passphrase entries!!!" 10 60
                if [ "$?" = 0 ] ; then
                    rm -f $WPA_SUPP_CONF
                    $SOFF
                    $D --msgbox "wpa_supplicant file cleared" 10 60
                    touch "$WPA_SUPP_CONF"
                    REBOOTNEEDED=yes
                else
                    $SOFF
                    $D --msgbox "wpa_supplicant file not cleared" 10 60
                fi
            fi

            ip link set wlan0 up

            $SOFF
            $D --defaultno --yesno "Do you want to manually enter the SSID?" 10 60
            if [ "$?" = 1 ] ; then
                $SOFF
                $DD --infobox "Scanning WiFi SSID's, please wait.." 8 70

                ssid_view
            else
                $SOFF
                ESSID_SEL=$($D --title "SSID" \
                --clear \
                --insecure \
                --inputbox "Enter your wireless network SSID." 10 60 3>&1 1>&2 2>&3)

                if [ "$?" = 1 ] ; then
                    continue
                fi
            fi

            CONFIG_SSID=$(grep "ssid=" $WPA_SUPP_CONF | grep -v grep)

            if (echo $CONFIG_SSID | grep "ssid=\"${ESSID_SEL}\"") ; then
                $SOFF
                $D --yes-button "Add" --no-button "Quit" --yesno  "${ESSID_SEL} SSID entry is already present in $WPA_SUPP_CONF file. Do you want to remove and re-add this entry or Quit?" 10 60 
                if [ "$?" = 0 ] ; then
                    foo="$(cat "$WPA_SUPP_CONF" | awk '/'$ESSID_SEL'/ { flag=1 }; flag==0 { print $0 }; /network={/ { flag=0 }' )"
                    if echo -e "$foo" | tail -1 | grep -q 'network={'; then
                        foo=$(echo -e "$foo" | head -n -1)
                    fi
                    echo -e "$foo" > "$WPA_SUPP_CONF"
                else
                    continue
                fi
            fi

            SSID=${ESSID_SEL}

            PASSOK=false
            while [ "$PASSOK" = false ] ; do
                $SON
                WIREPASS=$($D --title "SSID Password" \
                --clear \
                --insecure \
                --inputbox "Enter your wireless network password for SSID - \"$SSID\" (8-32 characters), enter blank for open network and press Ok to continue." 10 60 3>&1 1>&2 2>&3)

                if [ "$?" = 1 ] ; then
                    continue
                fi

                if [ "${#WIREPASS}" -eq "0" ] ; then
                    $SOFF
                    $D --msgbox "No password entered assuming open site." 10 60
                    PASSOK=true
                    site="open"
                else
                    if [ ${#WIREPASS} -lt 8 ] || [ ${#WIREPASS} -gt 32 ] ; then
                        $SOFF
                        $D --msgbox "Password length must be between 8 and 32 characters." 10 60
                        PASSOK=false
                    else
                        PASSOK=true
                    fi
                fi
            done

            if [ "$site" == "open" ] ; then
                $SOFF
                $D --yesno "Adding \"open\" no passphrase site with SSID = \"$SSID\"\n\nOK to Add?" 10 80
                if [ "$?" != "0" ] ; then
                    continue
                fi
                echo >> $WPA_SUPP_CONF
                echo "network={" >> $WPA_SUPP_CONF 
                echo -e "\tssid=\"$SSID\"" >> $WPA_SUPP_CONF
                echo -e "\tkey_mgmt=NONE" >> $WPA_SUPP_CONF
                echo "}" >> $WPA_SUPP_CONF
            else
                $SOFF
                $D --yesno "Adding SSID = \"$SSID\" with passphrase = \"$WIREPASS\"\n\nOK to Add?" 10 80
                if [ "$?" != "0" ] ; then
                    continue
                fi
                wpa_passphrase "$SSID" "$WIREPASS"  >> $WPA_SUPP_CONF
            fi

            systemctl restart wpa_supplicant@wlan0.service

            if [ "$REBOOTNEEDED" = "yes" ] ; then
                $SOFF
                if ($D --yesno "Reboot now?" 22 70) then
                    exit 10
                else
                    $SOFF
                    $D --msgbox "Reboot at a later time if necessary." 10 60
                fi
            fi
        fi


                if [ "$OPTION" = "2" ] ; then
                    systemctl enable  wpa_supplicant@wlan0.service
                    systemctl start wpa_supplicant@wlan0.service
                    OPTION=3
                fi

                if [ "$OPTION" = "3" ] ; then
                    systemctl stop  wpa_supplicant@wlan0.service
                    systemctl disable wpa_supplicant@wlan0.service
                    OPTION=3
                fi

                if [ "$OPTION" = "4" ] ; then
                    REPORT=$(iwconfig wlan0) 
                    REPORT2=$(ip a s wlan0)
                    REPORT3=$(cat "$WPA_SUPP_CONF")
                    $SOFF
                    $D --title "Wireless Setup file" --msgbox "$REPORT \n\n$REPORT2\n\n$REPORT3" 24 78

                fi
                if [ "$OPTION" = "5" ] ; then
                    eth0_info=$(dhcpcd -U eth0)
                    wlan0_info=$(dhcpcd -U wlan0)
                    # Display the gathered information in a readable format
            dialog --title "Network Information" \
           --msgbox "$(printf "Ethernet (eth0) Network Information:\n\n%s\n\nWi-Fi (wlan0) Network Information:\n\n%s" "$eth0_info" "$wlan0_info")" 20 70


                fi
  
             
                if [ "$OPTION" = "6" ] ; then
                   break
                fi
                
    fi
done
