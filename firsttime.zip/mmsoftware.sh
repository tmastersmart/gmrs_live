#/!bin/bash
#MENUFT%08%Node Manager Setup Program Version:6-28-2024
 
$SON
reset

php /etc/asterisk/local/mm-software/setup.php

exit 0
