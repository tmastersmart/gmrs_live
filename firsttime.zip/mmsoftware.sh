#/!bin/bash
#MENUFT%08%Node Manager Setup
 
$SON
reset

php /etc/asterisk/local/mm-software/setup.php

exit 0
