#!/bin/bash
# ---------------
# Copyright (C) 2024 By mike wrxb288
#MENU%16%Webmin web-based admin setup 


MM_SOFTWARE_FILE="/etc/asterisk/local/mm-software/version.txt"
if [ -f "$MM_SOFTWARE_FILE" ]; then
    MM_SOFTWARE_VERSION=$(head -1 "$MM_SOFTWARE_FILE" | awk -F ',' '{print "Version: "$1"\nRelease Date: "$2}')
else
    MM_SOFTWARE_VERSION="MM Software Version File Not Found"
fi

# Get IP Address (using ip addr instead of hostname -I)
IP_ADDRESS=$(ip addr show eth0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
if [ -z "$IP_ADDRESS" ]; then
    IP_ADDRESS=$(ip addr show wlan0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
fi
# If IP address is still blank, set fallback message
IP_ADDRESS=${IP_ADDRESS:-"IP info unavailable"}

# Function to start Webmin
start_webmin() {
    systemctl start webmin
    if [ $? -eq 0 ]; then
        dialog --msgbox "Webmin has been started successfully." 6 40
    else
        dialog --msgbox "Failed to start Webmin." 6 40
    fi
}

# Function to stop Webmin
stop_webmin() {
    systemctl stop webmin
    if [ $? -eq 0 ]; then
        dialog --msgbox "Webmin has been stopped successfully." 6 40
    else
        dialog --msgbox "Failed to stop Webmin." 6 40
    fi
}

# Function to enable Webmin at boot
enable_webmin() {
    systemctl enable webmin
    if [ $? -eq 0 ]; then
        dialog --msgbox "Webmin has been enabled to start at boot." 6 40
    else
        dialog --msgbox "Failed to enable Webmin at boot." 6 40
    fi
}

# Function to disable Webmin from starting at boot
disable_webmin() {
    systemctl disable webmin
    if [ $? -eq 0 ]; then
        dialog --msgbox "Webmin has been disabled from starting at boot." 6 40
    else
        dialog --msgbox "Failed to disable Webmin from starting at boot." 6 40
    fi
}

# Main menu with all actions
main_menu() {


    # Main menu
    selection=$(dialog --title "Webmin Control" \
        --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION $IP_ADDRESS" \
        --nocancel \
        --menu "Webmin is a powerful web-based interface for managing Unix-like systems. It provides a convenient and user-friendly way to manage system services, user accounts, network configurations, disk partitions, and more. With Webmin, system administrators can easily perform common tasks without needing to access the command line.\n\n Access Webmin at: http://$IP_ADDRESS:10000\n\nPlease select an action:" \
        20 75 6 \
        1 "Start Webmin" \
        2 "Stop Webmin" \
        3 "Enable Webmin at Boot" \
        4 "Disable Webmin at Boot" \
        5 "Exit" \
        3>&1 1>&2 2>&3)

    case $selection in
        1)
            start_webmin
            main_menu
            ;;
        2)
            stop_webmin
            main_menu
            ;;
        3)
            enable_webmin
            main_menu
            ;;
        4)
            disable_webmin
            main_menu
            ;;
        5)
            exit 0
            ;;
        *)
            dialog --msgbox "Invalid option." 6 40
            main_menu
            ;;
    esac
}

# Start the main menu
main_menu


