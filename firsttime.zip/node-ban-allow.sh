#!/bin/bash
# ---------------
# Copyright (C) 2024 By mike wrxb288
# Custom image Version 
# MENU%19%Ban/Block Nodes Connecting

function Info {
    dialog --title "Block/Ban Nodes" \
     --backtitle "Louisiana GMRS Image  " \
    --msgbox "
This script can be used to temporarily or permanently block or allow remote nodes to connect to your node.

Blacklist: Blocks specific nodes from connecting.
Whitelist: Allows only specific nodes to connect.

You must configure 'extensions.conf' and 'iax.conf' files for this to work.

For more information, visit:
http://wiki.allstarlink.org/wiki/Blacklist_or_whitelist
    " 20 70
}

function doDbase {
    /usr/sbin/asterisk -rx "database $Cmd"
}

function listbans {
    local output
    output="Current Nodes in the Ban List:\n----------------------------\n"
    Cmd="show blacklist"
    output+=$(/usr/sbin/asterisk -rx "$Cmd")
    output+="\n\nCurrent Nodes in the Allow List:\n-------------------------------\n"
    Cmd="show whitelist"
    output+=$(/usr/sbin/asterisk -rx "$Cmd")
    dialog --title "Node List" --msgbox "$output" 20 70
}

function testban {
    if grep -qr "\bcontext=blacklist\b" /etc/asterisk/iax.conf; then
        Ban="using the blacklist"
    elif grep -qr "^\bcontext=whitelist\b" /etc/asterisk/iax.conf; then
        Ban="using the whitelist"
    else
        Ban="using no blacklist or whitelist"
    fi
    dialog --title "Current Status" --msgbox "Currently $Ban in iax.conf" 10 50
}

function addban {
    node=$(dialog --title "Add Node" --inputbox "Enter Node number to add to the ban list:" 10 50 3>&1 1>&2 2>&3)
    comment=$(dialog --title "Add Comment" --inputbox "Enter a comment (or leave blank):" 10 50 3>&1 1>&2 2>&3)
    if [ -z "$comment" ]; then
        if [ "$Dbname" = "blacklist" ]; then
            comment="node-$node banned"
        else
            comment="node-$node allowed"
        fi
    fi
    Cmd="put $Dbname $node \"$comment\""
    doDbase
    dialog --title "Success" --msgbox "Added node $node to the $Dbname list." 10 50
}

function delban {
    node=$(dialog --title "Delete Node" --inputbox "Enter Node number to delete from the ban list:" 10 50 3>&1 1>&2 2>&3)
    Cmd="del $Dbname $node"
    doDbase
    dialog --title "Success" --msgbox "Deleted node $node from the $Dbname list." 10 50
}

# Main Menu
Info
listbans
testban

while true; do
    Dbname=$(dialog --title "Select List" --menu "Choose a list to modify:" 15 50 4 \
        "whitelist" "Modify whitelist" \
        "blacklist" "Modify blacklist" \
        "quit" "Exit script" 3>&1 1>&2 2>&3)

    if [ "$Dbname" == "quit" ]; then
        break
    fi

    while true; do
        action=$(dialog --title "Modify $Dbname" --menu "Choose an action:" 15 50 4 \
            "add" "Add a node" \
            "delete" "Delete a node" \
            "show" "Show current list" \
            "back" "Return to previous menu" 3>&1 1>&2 2>&3)

        case $action in
            "add") addban ;;
            "delete") delban ;;
            "show") listbans ;;
            "back") break ;;
            *) break ;;
        esac
    done
done
