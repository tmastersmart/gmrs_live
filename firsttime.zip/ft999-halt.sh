#!/bin/bash
# Modified 2016/04/07 by Chris, W0ANM 
# Modified 2016/09/27 by David, KB4FXC
# ---------------
# Copyright (C) 2014-2021 David, KB4FXC 
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see http://www.gnu.org/licenses/.
# ---------------
#
#	Display final config data to user and prepare for reboot!
# 
#MENU%20%Halt the Node (safe powerdown)

function getIPList {
        ADDRESS="Unable to determine."
        COMMA="" 
        LIST=""
        while [ -n "$1" ] ; do
                LIST="$LIST$COMMA$1"
                COMMA=", "
                shift
        done
        if [ -n "$LIST" ] ; then
                ADDRESS=$LIST 
        fi
}

IP=$(hostname --ip-address)

getIPList $IP

MESSAGE=$(cat << _EOF
System Power-OFF

Remember to log back in using the new password and using the
new IP address if you changed it.

Use these values for your next login after reboot: 
   IP Address -  $ADDRESS 
   ssh Port   -  $(grep "Port " /etc/ssh/sshd_config | awk '{print $2}') 

Press <Shutdown> to start the Power-off process

_EOF
)

$SOFF
if ($D --title "Shutdown Info" --yes-label "Shutdown" --defaultno --no-label "Cancel" --yesno "$MESSAGE" 20 70) then
        #yes
        RETURN=11
else
        ##no
        RETURN=0
fi

$SON

###Exit value 11 causes poweroff!

exit $RETURN
