#!/bin/bash
#---------------
#Copyright (C) 2024 By mike wrxb288
#MENUFT%010%Password Setup Menu

MM_SOFTWARE_FILE="/etc/asterisk/local/mm-software/version.txt"
if [ -f "$MM_SOFTWARE_FILE" ]; then
    MM_SOFTWARE_VERSION=$(head -1 "$MM_SOFTWARE_FILE" | awk -F ',' '{print "Version: "$1"\nRelease Date: "$2}')
else
    MM_SOFTWARE_VERSION="MM Software Version File Not Found"
fi

#Get IP Address (using ip addr instead of hostname -I)
IP_ADDRESS=$(ip addr show eth0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
if [ -z "$IP_ADDRESS" ]; then
    IP_ADDRESS=$(ip addr show wlan0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
fi
# If IP address is still blank, set fallback message
IP_ADDRESS=${IP_ADDRESS:-"IP info unavailable"}
    

change_root_password() {
    local PASS="invalid"
    while true; do
        $SON
        data1=$($D --insecure --passwordbox "Enter a new root password" 8 78 3>&1- 1>&2- 2>&3-)
        ret=$?
        if [ $ret -ne 0 ]; then
            break
        fi
        OUT=$(pwqcheck -1 min=7,7,7,7,7 2>&1 <<< "$data1")
        if [ $? -ne 0 ]; then
            $SOFF
            $D --title "Error" --msgbox "Error: $OUT\n\nPlease try again!" 10 70
            continue
        fi
        $SON
        data2=$($D --insecure --passwordbox "Re-enter root password for verification" 8 78 3>&1- 1>&2- 2>&3-)
        ret=$?
        if [ $ret -ne 0 ]; then
            break
        fi
        if [ "$data1" != "$data2" ]; then
            $SOFF
            $D --title "Error" --msgbox "Error! Passwords do not match!\n\nPlease try again!" 10 70
        else
            PASS="root:$data1"
            chpasswd <<< "$PASS"
            $SOFF
            $D --msgbox "Root password successfully changed!" 8 70
            break
        fi
    done
}

change_user_password() {
    local PASS="invalid"
    $SON
    USERNAME=$($D --inputbox "Enter the username to change password for:" 8 78 3>&1- 1>&2- 2>&3-)
    if [ $? -ne 0 ] || [ -z "$USERNAME" ]; then
        $SOFF
        $D --msgbox "Operation canceled or invalid username!" 8 70
        return
    fi
    while true; do
        $SON
        data1=$($D --insecure --passwordbox "Enter a new password for $USERNAME" 8 78 3>&1- 1>&2- 2>&3-)
        ret=$?
        if [ $ret -ne 0 ]; then
            break
        fi
        OUT=$(pwqcheck -1 min=7,7,7,7,7 2>&1 <<< "$data1")
        if [ $? -ne 0 ]; then
            $SOFF
            $D --title "Error" --msgbox "Error: $OUT\n\nPlease try again!" 10 70
            continue
        fi
        $SON
        data2=$($D --insecure --passwordbox "Re-enter password for verification" 8 78 3>&1- 1>&2- 2>&3-)
        ret=$?
        if [ $ret -ne 0 ]; then
            break
        fi
        if [ "$data1" != "$data2" ]; then
            $SOFF
            $D --title "Error" --msgbox "Error! Passwords do not match!\n\nPlease try again!" 10 70
        else
            PASS="$USERNAME:$data1"
            chpasswd <<< "$PASS"
            $SOFF
            $D --msgbox "Password for $USERNAME successfully changed!" 8 70
            break
        fi
    done
}

change_admin_password() {
    $SON       
    local description="Setting the Status page admin password\n\nPlease enter the username for the admin password below:"
    ADMIN_USER=$($D --inputbox "$description" 12 78 3>&1- 1>&2- 2>&3-)
    
    ret=$?
    if [ $ret -ne 0 ] || [ -z "$ADMIN_USER" ]; then
        $SOFF
        $D --msgbox "Operation canceled or invalid username!" 8 70
        return
    fi

    data1=$($D --insecure --passwordbox "Enter a new password for $ADMIN_USER" 8 78 3>&1- 1>&2- 2>&3-)
    ret=$?
    if [ $ret -ne 0 ]; then
        $SOFF
        $D --msgbox "Operation canceled!" 8 70
        return
    fi
    $SON
    data2=$($D --insecure --passwordbox "Re-enter password for verification" 8 78 3>&1- 1>&2- 2>&3-)
    ret=$?
    if [ $ret -ne 0 ]; then
        $SOFF
        $D --msgbox "Operation canceled!" 8 70
        return
    fi
    if [ "$data1" != "$data2" ]; then
        $SOFF
        $D --title "Error" --msgbox "Error! Passwords do not match!\n\nPlease try again!" 10 70
    else
        
# Variables
ADMIN_DIR="/srv/http/admin"
HTPASSWD_FILE="$ADMIN_DIR/.htpasswd"
HTACCESS_FILE="$ADMIN_DIR/.htaccess"

echo "Creating .htaccess file..."
cat > "$HTACCESS_FILE" <<EOF
AuthType Basic
AuthName "Restricted Area"
AuthUserFile $HTPASSWD_FILE
Require valid-user
EOF

# Set permissions for .htaccess
chmod 644 "$HTACCESS_FILE"

htpasswd -cb /srv/http/admin/.htpasswd "$ADMIN_USER" "$data1"

systemctl restart httpd

 
        
        
        
        
        
        
        
        $SOFF
        $D --msgbox "Password for $ADMIN_USER in /srv/http/admin successfully changed!" 8 70
    fi
}

update_allstar_files() {
    # Generate a random 10-character password with at least one number
    local random_password
    random_password=$(head /dev/urandom | tr -dc 'A-Za-z0-9' | head -c 10)

    # Ensure the password contains at least one number
    while ! [[ $random_password =~ [0-9] ]]; do
        random_password=$(head /dev/urandom | tr -dc 'A-Za-z0-9' | head -c 10)
    done

    # First file: /etc/asterisk/manager.conf
    local file1="/etc/asterisk/manager.conf"
    if grep -q "^\[admin\]" "$file1"; then
        sed -i "/^\[admin\]/,/^$/s/^secret =.*/secret = $random_password/" "$file1"
        echo "Updated $file1 with a new random password."
    else
        echo "Error: [admin] section not found in $file1."
    fi

    # Second file: /home/gmrs/poll_status.ini
    local file2="/home/gmrs/poll_status.ini"
    if grep -q "^passwd=" "$file2"; then
        sed -i "s/^passwd=.*/passwd=$random_password/" "$file2"
        echo "Updated $file2 with a new random password."
    else
        echo "Error: passwd= line not found in $file2."
    fi

    # Notify the user
    $D --msgbox "Updated Manager and status page with the new password\n\nCreated random password: [$random_password]\n\nDo not give this password to anyone its used for the STATUS page to connect to AST on the manager port.\n\nThis password might be needed by a node remote control program later and can be viewed with the view menu." 20 60
}


view_passwords() {
 dialog --title "Please Wait" --infobox "Processing... Please wait." 5 50
#    local ROOT_PASS=$(grep -o "^root:.*" /etc/shadow | awk -F: '{print $2}')
#    local USER_PASS=$(grep -o "^user:.*" /etc/shadow | awk -F: '{print $2}')
    local ADMIN_PASS_FILE="/srv/http/admin/.htpasswd"
    local manager_file="/etc/asterisk/manager.conf"
    local DVSWITCH_FILE="/etc/asterisk/iax.conf"
    local STATUS_PAGE=$(grep -E '^(secret|passwd) =' "$manager_file" | head -1 | sed -E 's/^(secret|passwd) = //')
    local DVSWITCH_PASS=$(awk '/^\[dvswitch\]/ {in_stanza=1; next} in_stanza && /^secret=/ {print $0; exit}' "$DVSWITCH_FILE" | sed 's/secret=//')

    # Read contents of the admin password file
    local ADMIN_PASS
    if [ -f "$ADMIN_PASS_FILE" ]; then
        ADMIN_PASS=$(cat "$ADMIN_PASS_FILE")
    else
        ADMIN_PASS="Admin password file not found."
    fi


    # Construct the password display message
    local passwords="
Root Password  (hashed): xxxxxxxx
User Password  (hashed): xxxxxxxx
Admin Password (hashed): $ADMIN_PASS

AST Manager Password: [$STATUS_PAGE]
DVSwitch Password    : [${DVSWITCH_PASS:-Not Found}]

Note: Not all passwords will display. Be sure to change all passwords after first time install!
There are 2 users on this new image. The user account was needed install webmin as it could not be installed by root. The user home directory will be used for other things so dont remove the user account.

Louisiana Image (its just better)
"

    $D --title "Current Passwords" --msgbox "$passwords" 25 70
}

edit_dvswitch_password() {
    local DVSWITCH_FILE="/etc/asterisk/iax.conf"
    local STANZA="[dvswitch]"
    local PASSWORD_PATTERN="^secret="
    local ALLOWED_CHARS="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789" # Avoid i, I, l, 0, o, O

    if [ ! -f "$DVSWITCH_FILE" ]; then
        $SOFF
        $D --msgbox "Error: File $DVSWITCH_FILE not found!" 8 70
        return
    fi

    # Generate a random 6-character password
    local new_password=$(cat /dev/urandom | tr -dc "$ALLOWED_CHARS" | head -c 6)

    # Update the password in the [dvswitch] stanza only if the user selected "Yes"
    awk -v stanza="$STANZA" -v new_password="$new_password" '
        BEGIN { in_stanza = 0 }
        $0 ~ stanza { in_stanza = 1 }
        in_stanza && $0 ~ /^secret=/ { $0 = "secret=" new_password; in_stanza = 0 }
        { print }
    ' "$DVSWITCH_FILE" > "${DVSWITCH_FILE}.tmp" && mv "${DVSWITCH_FILE}.tmp" "$DVSWITCH_FILE"

    # Provide feedback to the user
    if [ $? -eq 0 ]; then
        $SOFF
        $D --msgbox "DVSwitch password successfully Changed to:[$new_password]\n\nEnter this password into the DVSWITCH app\nPlease run the Dvswitch setup program for major changes to the settings." 10 70
    else
        $SOFF
        $D --msgbox "Error: Failed to update DVSwitch password!" 8 70
    fi
}


main_menu() {
    while true; do
        $SON
        CHOICE=$($D --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION $IP_ADDRESS" \
            --nocancel \
            --title "Password Setup Menu" \
            --menu "All passwords must be changed from defaults!\n\
Do not remove the user account, as it and its home directory are required. You must enter your node number first, or changes may be overridden! Please select an option:" 20 60 8 \
            1 "Change Root Password" \
            2 "Change User Password" \
            3 "Change Status page Admin Password" \
            4 "Change AST Manager Password" \
            5 "Change DVSWITCH password" \
            6 "View Current Passwords" \
            7 "Exit" \
            3>&1 1>&2 2>&3)
        RET=$?

        if [ $RET -ne 0 ]; then
            break
        fi

        case $CHOICE in
            1) change_root_password ;;
            2) change_user_password ;;
            3) change_admin_password ;;
            4) update_allstar_files ;;
            5) edit_dvswitch_password ;;
            6) view_passwords ;;  
            7) break ;;
            *) $SOFF; $D --msgbox "Invalid selection, please try again!" 8 70 ;;
        esac
    done
    $SON
}

main_menu
exit 0

