#!/bin/bash
# Copyright (C) 2024 By mike wrxb288
# Custom Louisiana image Version
# Network loader menu
#MENU%040%Network Setup Menu 
export DD="/usr/bin/dialog"
MM_SOFTWARE_FILE="/etc/asterisk/local/mm-software/version.txt"

# Fetch MM Software Version
if [ -f "$MM_SOFTWARE_FILE" ]; then
    MM_SOFTWARE_VERSION=$(head -1 "$MM_SOFTWARE_FILE" | awk -F ',' '{print "Version: "$1"\nRelease Date: "$2}')
else
    MM_SOFTWARE_VERSION="MM Software Version File Not Found"
fi

# Fetch IP Address
IP_ADDRESS=$(ip addr show eth0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
if [ -z "$IP_ADDRESS" ]; then
    IP_ADDRESS=$(ip addr show wlan0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
fi
IP_ADDRESS=${IP_ADDRESS:-"IP info unavailable"}




# Function to display network information for both LAN and Wi-Fi interfaces
function display_network_info {
    # Get DHCP lease information for eth0 (LAN)
    eth0_info=$(dhcpcd -U eth0)

    # Get DHCP lease information for wlan0 (Wi-Fi)
    wlan0_info=$(dhcpcd -U wlan0)

    # Display the gathered information in a readable format
    dialog --title "Network Information" \
           --msgbox "$(printf "Ethernet (eth0) Network Information:\n\n%s\n\nWi-Fi (wlan0) Network Information:\n\n%s" "$eth0_info" "$wlan0_info")" 20 70
}
# Function to display the Network Setup submenu
function network_setup_menu {
    $DD --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION $IP_ADDRESS" \
    --title "Network Setup" \
    --menu "This is the network sub menu.\n
Louisiana GMRS Image (its just better)\n\n
Select an option below:" 19 50 6 \
    1 "Configure the Wired Ethernet Jack" \
    2 "Configure WIFI" \
    3 "Open Router Port" \
    4 "View Current Network Setup" \
    5 "Return to Main Menu" 2>/tmp/network_choice

    network_choice=$(< /tmp/network_choice)

    case $network_choice in
        1) bash /usr/local/sbin/firsttime/ft4-netsetup.sh ;; 
        2) bash /usr/local/sbin/firsttime/wifi-setup.sh ;; 
        3) bash /usr/local/sbin/firsttime/router_port.sh ;;
        4) display_network_info ;;  # Call the view current setup function
        5) return ;;  # Return to the main menu
        *) return ;;
    esac
}

# Call the network setup menu
network_setup_menu
