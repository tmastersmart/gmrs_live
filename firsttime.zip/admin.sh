#!/bin/bash
# Modified for Louisiana Image (error checking added)
# 2017/02/22 by David, KB4FXC
# ---------------
NODE1=$(awk -F= '/^export NODE1=/ {print $2}' /usr/local/etc/allstar.env)
DATE=$(date +"%A, %B %d, %Y")
node_number=$(asterisk -rx "iax2 show registry" | awk '/^\s*[0-9]+\./ {print $3}')
UPTIME=$(awk '{print int($1 / 3600)" hours, "int(($1 % 3600) / 60)" minutes"}' /proc/uptime)

if [ -f /proc/device-tree/model ]; then
    MODEL=$(tr -d '\0' < /proc/device-tree/model)
else
    MODEL="Unknown Model"
fi
# Custom MM Software Version
MM_SOFTWARE_FILE="/etc/asterisk/local/mm-software/version.txt"
if [ -f "$MM_SOFTWARE_FILE" ]; then
    MM_SOFTWARE_VERSION=$(head -1 "$MM_SOFTWARE_FILE" | awk -F ',' '{print "Version: "$1"\nRelease Date: "$2}')
else
    MM_SOFTWARE_VERSION="MM Software Version File Not Found"
fi

if [ "$ADMINSH" = "RUNNING" ] ; then
    echo -e "\nAdmin Menu already Running. Type 'exit' to re-enter\n" >&2
    exit 1
fi
export ADMINSH="RUNNING"

# Test for valid terminal type!
TINFO=$(/usr/bin/infocmp "$TERM" 2>&1 | /bin/grep "infocmp: couldn't open terminfo file")
if [ -n "$TINFO" ] ; then
    echo -e "\n\nERROR: admin.sh can't determine your terminal type!"
    echo -e "EXITING to shell prompt.\n\n\n"
    /bin/bash
    exit
fi

export SON="/usr/bin/setterm --term linux --background blue --foreground white --clear all --cursor on"
export SOFF="/usr/bin/setterm --term linux --background blue --foreground white --clear all --cursor off"
export D="/usr/bin/dialog --clear "

source /usr/local/etc/allstar.env

PROGPATH=/usr/local/sbin/firsttime
NEEDBOOT=NO

while true; do
    idx=1
    MENU=()
    SCRIPT_LIST=()

    NORM=$IFS
    IFS=$'\n'

    # Filter for valid MENU lines, ensuring they are not empty
    for i in $(grep MENU $PROGPATH/*.sh | sort -t '%' -k 2); do
        # Ensure the line is not empty and contains a valid menu item
        if [[ -n "$i" && "$i" == *%* ]]; then
            script=$(awk -F: '{print $1}' <<< "$i")
            menuitem=$(awk -F% '{print $3}' <<< "$i")
            if [[ -n "$script" && -n "$menuitem" ]]; then
                MENU+=($idx "$idx $menuitem")
                SCRIPT_LIST[$idx]="$script"
                let idx+=1
            fi
        fi
    done
    IFS=$NORM
    myip=$(/sbin/ifconfig | awk -F "[: ]+" '/inet / { if ($3 != "127.0.0.1") printf ("%s, ", $3) }')
    if [ -n "$myip" ]; then
        myip=${myip::-2}
    else
        myip="none"
    fi

    ### Display a radiolist of menu items and have the user select items to change.
    while true; do
        $SOFF
        terminal_height=$(tput lines)

        max_menu_height=31  # Set this to a reasonable max number of items for your menu

        num_items=${#MENU[@]}
        menu_height=$((num_items + 4))  # Adjust padding as necessary

        menu_height=$((menu_height > terminal_height ? terminal_height : menu_height))
        menu_height=$((menu_height > max_menu_height ? max_menu_height : menu_height))

        selection=$($D --no-tags --colors \
        --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION $myip" \
        --title "\Z1Louisiana Image Admin Menu" \
        --ok-label "Run" \
        --cancel-label "Logout" \
        --menu "$MODEL\nNode:[$NODE1] IP:$myip $DATE\nUptime:$UPTIME\nPlease select option:" $menu_height 79 25 "${MENU[@]}" 3>&1- 1>&2- 2>&3-)

        RET=$?
        if [ $RET -ne 0 ]; then
            NEEDBOOT=LOGOUT
            break
        fi
        script=${SCRIPT_LIST[$selection]}
        if [ -f "$script" ]; then
            $script
            VAL=$?
            if [ $VAL -eq 10 ]; then
                NEEDBOOT=REBOOT
                break
            fi
            if [ $VAL -eq 11 ]; then
                NEEDBOOT=HALT
                break
            fi
            if [ $VAL -eq 14 ]; then
                NEEDBOOT=RELOAD
                break
            fi
        fi
    done

    if [ "$NEEDBOOT" != "RELOAD" ]; then
        break
    fi
    NEEDBOOT=NO
done

setterm --reset
sync

if [ "$NEEDBOOT" = "REBOOT" ]; then
    /usr/bin/killall watchdog &>/dev/null
    /bin/sleep 1
    echo "1" > /dev/watchdog
    /usr/local/sbin/reboot.sh
fi
if [ "$NEEDBOOT" = "HALT" ]; then
    /usr/local/sbin/halt.sh
fi

exit 0

