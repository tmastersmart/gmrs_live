#!/bin/bash
# ---------------
# Copyright (C) 2024 By mike wrxb288
# MENU%09%Virtual memory Utility

if ! command -v dialog &>/dev/null; then
  echo "The 'dialog' command is required but not installed. Please install it and try again."
  exit 1
fi

DIALOG_WIDTH=80  # Width of the dialog window
BAR_WIDTH=$((DIALOG_WIDTH - 20))  # Bar length, adjusted for padding


MM_SOFTWARE_FILE="/etc/asterisk/local/mm-software/version.txt"
if [ -f "$MM_SOFTWARE_FILE" ]; then
    MM_SOFTWARE_VERSION=$(head -1 "$MM_SOFTWARE_FILE" | awk -F ',' '{print "Version: "$1"\nRelease Date: "$2}')
else
    MM_SOFTWARE_VERSION="MM Software Version File Not Found"
fi

# Get IP Address (using ip addr instead of hostname -I)
IP_ADDRESS=$(ip addr show eth0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
if [ -z "$IP_ADDRESS" ]; then
    IP_ADDRESS=$(ip addr show wlan0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
fi
# If IP address is still blank, set fallback message
IP_ADDRESS=${IP_ADDRESS:-"IP info unavailable"}

# Function to generate a bar graph
generate_bar() {
  local percent=$1
  local width=$BAR_WIDTH
  local filled=$((percent * width / 100))
  local empty=$((width - filled))
  printf "[%s%s]" "$(printf '%0.s#' $(seq 1 $filled))" "$(printf '%0.s-' $(seq 1 $empty))"
}

# Function to get memory and swap usage percentages
get_memory_swap_percentages() {
  memory_total=$(free -m | awk '/Mem:/ {print $2}')
  memory_used=$(free -m | awk '/Mem:/ {print $3}')
  memory_percent=$((memory_used * 100 / memory_total))

  swap_total=$(free -m | awk '/Swap:/ {print $2}')
  swap_used=$(free -m | awk '/Swap:/ {print $3}')
  if [ "$swap_total" -eq 0 ]; then
    swap_percent=0
  else
    swap_percent=$((swap_used * 100 / swap_total))
  fi

  echo "$memory_percent $swap_percent"
}

# Function to get detailed memory and swap info
get_memory_swap_info() {
  memory_info=$(free -h | awk '/Mem:/ {printf "Total: %s  Used: %s  Free: %s  Shared: %s  Buff/Cache: %s  Available: %s\n", $2, $3, $4, $5, $6, $7}')
  swap_info=$(free -h | awk '/Swap:/ {printf "Total: %s  Used: %s  Free: %s\n", $2, $3, $4}')
  echo -e "$memory_info\n$swap_info"
}

# Function to get swap status
get_swap_status() {
  if swapon --show | grep -q '/swapfile'; then
    echo "enabled"
  else
    echo "disabled"
  fi
}

enable_swap() {
  if ! [ -f /swapfile ]; then
    dd if=/dev/zero of=/swapfile bs=1M count=1024 status=progress
    chmod 600 /swapfile
    mkswap /swapfile
  fi
  swapon /swapfile
  sysctl vm.swappiness=10

  # Dialog to make swap persistent
  dialog --yesno "Make swap persistent across reboots?" 7 50
  choice=$?

  if [ $choice -eq 0 ]; then
    if ! grep -q "/swapfile" /etc/fstab; then
      echo "/swapfile none swap sw 0 0" >> /etc/fstab
    fi
    dialog --msgbox "Swap enabled and set to persist across reboots." 7 50
  else
    dialog --msgbox "Swap enabled but will not persist after reboot." 7 50
  fi
}

# Function to disable swap with dialog for removing persistence
disable_swap() {
  swapoff /swapfile

  # Dialog to remove persistence
  dialog --yesno "Remove swap persistence from /etc/fstab?" 7 50
  choice=$?

  if [ $choice -eq 0 ]; then
    sed -i '/\/swapfile/d' /etc/fstab
    dialog --msgbox "Swap persistence removed." 7 50
  else
    dialog --msgbox "Swap disabled but persistence not removed." 7 50
  fi

  dialog --msgbox "Swap disabled." 7 50
}

# Function to resize swap
resize_swap() {
  local new_size=$1
  swapoff /swapfile  # Turn off swap before resizing
  dd if=/dev/zero of=/swapfile bs=1M count="$new_size" status=progress
  chmod 600 /swapfile
  mkswap /swapfile
  swapon /swapfile  # Turn swap back on after resizing
}

# Main menu loop
while true; do
  read memory_percent swap_percent <<<$(get_memory_swap_percentages)
  memory_info=$(get_memory_swap_info)
  swap_status=$(get_swap_status)

  # Get the current swap size
  current_swap_size=$(free -m | awk '/Swap:/ {print $2}')

  # Create bar graphs dynamically
  memory_bar=$(generate_bar "$memory_percent")
  swap_bar=$(generate_bar "$swap_percent")

  # Menu options with Help option added
  menu_options=( 
    1 "Help"
    2 "Toggle Swap ($swap_status)" 
    3 "Resize Swap Memory (Current: $current_swap_size MB)" 
    4 "Delete Swap File" 
    5 "Exit" 
  )

  # Show the dialog with memory info, progress bars, and the menu options
  choice=$(dialog --stdout --title "Virtual Memory Utility" \
     --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION $IP_ADDRESS" \
    --nocancel \
    --menu "System Memory and Swap:\n$memory_info\n$swap_info\n\nMemory Usage: ${memory_percent}% $memory_bar\nSwap Usage: ${swap_percent}% $swap_bar\n\n" \
    20 $DIALOG_WIDTH 8 "${menu_options[@]}")

  case $choice in
    1)
      # Show the Help dialog box with the info about Hamvoip and swap
dialog --msgbox "Hamvoip Asterisk/GMRSLIVE does not use a swap file by default. This is an unusual and non-standard setup for a Raspberry Pi.\n\nIt is recommended to enable a swap file on Raspberry Pi systems.\n\nEnabling swap can help prevent:\n- Memory-related issues\n- System crashes\n- Potential audio jitter\n\nSwap acts as virtual memory, using storage space to assist when physical RAM is under pressure.\n\n**Swap Size Recommendations:**\n- Starting with a 500MB swap file is typically sufficient for most users.\n- Users with larger memory configurations may benefit from a larger swap file (e.g., 1024MB).\n\nYou can adjust the swap size depending on your Raspberry Pi's RAM and SD card capacity.\n\nLouisiana GMRS Image (It's just better)" 30 70

      ;;  
    2)
      if [ "$swap_status" = "enabled" ]; then
        disable_swap
        
      else
        enable_swap
        
      fi
      ;;
    3)
      new_size=$(dialog --stdout --inputbox "Enter new size for Swap memory in MB (Current: $current_swap_size MB):" 10 50 "$current_swap_size")
      if [[ "$new_size" =~ ^[0-9]+$ ]]; then
        resize_swap "$new_size"
      else
        dialog --msgbox "Invalid input. Please enter a valid number." 10 40
      fi
      ;;
    4)
      if [ -f /swapfile ]; then
        swapoff /swapfile
        rm -f /swapfile
        dialog --msgbox "Swap file deleted." 10 40
      else
        dialog --msgbox "No swap file found to delete." 10 40
      fi
      ;;
    5)
      exit 0
      ;;
  esac
done

