#!/bin/bash
# ---------------
# Copyright (C) 2024 By mike wrxb288
# MENU%16%Fan Control Service Setup

# MM Software Version Information
MM_SOFTWARE_FILE="/etc/asterisk/local/mm-software/version.txt"
if [ -f "$MM_SOFTWARE_FILE" ]; then
    MM_SOFTWARE_VERSION=$(head -1 "$MM_SOFTWARE_FILE" | awk -F ',' '{print "Version: "$1"\nRelease Date: "$2}')
else
    MM_SOFTWARE_VERSION="MM Software Version File Not Found"
fi

# Get IP Address (using ip addr instead of hostname -I)
IP_ADDRESS=$(ip addr show eth0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
if [ -z "$IP_ADDRESS" ]; then
    IP_ADDRESS=$(ip addr show wlan0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
fi
# If IP address is still blank, set fallback message
IP_ADDRESS=${IP_ADDRESS:-"IP info unavailable"}
# Get CPU Temperature
if command -v vcgencmd >/dev/null; then
    CPU_TEMP=$(vcgencmd measure_temp | cut -d '=' -f2)
else
    CPU_TEMP="Temperature info unavailable"
fi
# Function to start the fan control service
start_fan_service() {
    systemctl start fan_control
    if [ $? -eq 0 ]; then
        dialog --msgbox "Fan control service has been started successfully." 6 50
    else
        dialog --msgbox "Failed to start the fan control service." 6 50
    fi
}

# Function to stop the fan control service
stop_fan_service() {
    systemctl stop fan_control
    if [ $? -eq 0 ]; then
        dialog --msgbox "Fan control service has been stopped successfully." 6 50
    else
        dialog --msgbox "Failed to stop the fan control service." 6 50
    fi
}

# Function to enable the fan control service at boot
enable_fan_service() {
    systemctl enable fan_control
    if [ $? -eq 0 ]; then
        dialog --msgbox "Fan control service has been enabled to start at boot." 6 50
    else
        dialog --msgbox "Failed to enable the fan control service at boot." 6 50
    fi
}

# Function to disable the fan control service from starting at boot
disable_fan_service() {
    systemctl disable fan_control
    if [ $? -eq 0 ]; then
        dialog --msgbox "Fan control service has been disabled from starting at boot." 6 50
    else
        dialog --msgbox "Failed to disable the fan control service at boot." 6 50
    fi
}

help_screen() {
    dialog --title "Fan Control Help" --msgbox "\
There are 3 options for fan control. GPIO 23 (BCM) is Physical Pin 16. :\n\n\
1. Relay Option\n\
   Use a relay module compatible with 3.3V GPIO logic. Connect GPIO 23 to the relay's signal pin. Wire the fan's power line through the relay. This is the best option to control a case fan and cpu fan together.\n\n\
2. Transistor Option\n\
   Use an NPN transistor (e.g., 2N2222 or BC547) or a MOSFET. Connect the GPIO pin to the transistor's base (via a 1kΩ resistor for NPN). Connect the fan's ground wire to the collector/emitter/source, depending on the transistor type. Important: Make sure the transistor can handle the fan's current and voltage.\n\n\
3. PWM Fan Control Option\n\
   Get a 3 wire PWM FAN compatable with the PI. Amazon sells fans Pi PWM direct plugins that don't need a transistor. B092YXQMX5 Just be sure its for the PI\n" 30 70
}

# Main menu
main_menu() {
    # Main menu
    selection=$(dialog --title "Fan Control Service" \
        --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION $IP_ADDRESS" \
        --nocancel \
        --menu "Controls fan by cpu temp.\nGPIO 23 (BCM) is Physical Pin 16. \nCPU:$CPU_TEMP\n\nPlease select an action:" \
        20 60 6 \
        1 "Start Fan Service" \
        2 "Stop Fan Service" \
        3 "Enable Fan Service at Boot" \
        4 "Disable Fan Service at Boot" \
        5 "Help" \
        6 "Exit" \
        3>&1 1>&2 2>&3)

    case $selection in
        1)
            start_fan_service
            main_menu
            ;;
        2)
            stop_fan_service
            main_menu
            ;;
        3)
            enable_fan_service
            main_menu
            ;;
        4)
            disable_fan_service
            main_menu
            ;;
        5)
            help_screen
            main_menu
            ;;
        6)
            exit 0
            ;;
        *)
            dialog --msgbox "Invalid option." 6 40
            main_menu
            ;;
    esac
}

# Start the main menu
main_menu
