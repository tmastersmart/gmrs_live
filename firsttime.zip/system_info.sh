#!/bin/bash
# ---------------
# Copyright (C) 2024 By mike wrxb288
# ---------------
#
# MENU%13%System Information

# Gather version details
R1=$(head -1 /etc/allstar_version)
R2=$(/sbin/asterisk -V)
R3=$(cat /proc/version | awk -F '[(][g]' '{print $1}')
R4=$(cat /proc/version | awk -F '[(][g]' '{print "g"$2}')
APACHE_VERSION=$(httpd -v | grep "Server version" | awk -F ': ' '{print $2}' || echo "Apache not found")
PHP_VERSION=$(php -v | head -n 1 || echo "PHP not found")
SSH_VERSION=$(ssh -V 2>&1 || echo "SSH not found")
usb_version=$(lsusb | awk 'BEGIN {RS="Bus "} {if (NR > 1) print "Bus" $0}')
usb_version=$(echo "$usb_version" | sed ':a;N;$!ba;s/\n/\\n/g') # Make it single-line for dialog

# Query the registration status
registration_status=$(asterisk -rx "iax2 show registry" | awk '/Registered/ {print $NF}')
registration_details=$(asterisk -rx "iax2 show registry" | awk '/Registered/ {print $1, $3, $NF}')
node_number=$(asterisk -rx "iax2 show registry" | awk '/^\s*[0-9]+\./ {print $3}')
#connection_status=$(asterisk -rx "rpt nodes $node_number" | grep -E "^\s*[0-9]+" | awk '{print $1}')


# Custom MM Software Version
MM_SOFTWARE_FILE="/etc/asterisk/local/mm-software/version.txt"
if [ -f "$MM_SOFTWARE_FILE" ]; then
    MM_SOFTWARE_VERSION=$(head -1 "$MM_SOFTWARE_FILE" | awk -F ',' '{print "Version: "$1"\nRelease Date: "$2}')
else
    MM_SOFTWARE_VERSION="MM Software Version File Not Found"
fi

# Get IP Address (using ip addr instead of hostname -I)
IP_ADDRESS=$(ip addr show eth0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
if [ -z "$IP_ADDRESS" ]; then
    IP_ADDRESS=$(ip addr show wlan0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
fi
# If IP address is still blank, set fallback message
IP_ADDRESS=${IP_ADDRESS:-"IP info unavailable"}

# Fetch Revision Code from /proc/cpuinfo
Revision=$(awk '/Revision/ {print $3}' /proc/cpuinfo)

# Use Device Tree for Model Name (Modern Raspbian Kernel)
if [ -f /proc/device-tree/model ]; then
    MODEL=$(tr -d '\0' < /proc/device-tree/model)
else
    MODEL="Unknown Model"
fi

# Extract CPU Hardware Details
CPU_ARCH=$(uname -m)
KERNEL_VERSION=$(uname -r)
CPU_MODEL=$(awk -F ': ' '/model name/ {print $2; exit}' /proc/cpuinfo)

# Get Total Memory (RAM) in MB
if [ -f /proc/meminfo ]; then
    TOTAL_MEM=$(awk '/MemTotal/ {printf "%.0f MB", $2 / 1024}' /proc/meminfo)
else
    TOTAL_MEM="Memory info unavailable"
fi

# Get Serial Number
SERIAL=$(awk '/Serial/ {print $3}' /proc/cpuinfo)

# Get System Uptime
UPTIME=$(awk '{print int($1 / 3600)" hours, "int(($1 % 3600) / 60)" minutes"}' /proc/uptime)

# Get Firmware Version (Extract date and version only)
FIRMWARE_VERSION=$(vcgencmd version 2>/dev/null | awk 'NR==1 {print $1, $2, $3}' || echo "Firmware info unavailable")

# Get CPU Temperature
if command -v vcgencmd >/dev/null; then
    CPU_TEMP=$(vcgencmd measure_temp | cut -d '=' -f2)
else
    CPU_TEMP="Temperature info unavailable"
fi

# Get Disk Space
DISK_INFO=$(df -h / | awk 'NR==2 {printf "%s used / %s total", $3, $2}')

# Get MAC Address of Primary Interface
PRIMARY_IFACE=$(ip route show default | awk '/default/ {print $5; exit}')
MAC_ADDRESS=$(cat /sys/class/net/$PRIMARY_IFACE/address 2>/dev/null || echo "MAC unavailable")


# Get Current Date, Time, and Timezone
CURRENT_DATE=$(date "+%Y-%m-%d %H:%M:%S")
# Try to get timezone using timedatectl, fallback to /etc/localtime
TIMEZONE=$(timedatectl show --property=Timezone --value 2>/dev/null || \
    readlink /etc/localtime | sed -e 's/.*\/zoneinfo\/\(.*\)$/\1/' || echo "Timezone info unavailable")

# Display the information using Dialog
#$SOFF
#$D --title 'System Information' --msgbox "\n---HamVoIP Firmware Version---\n$R1\n\n---HamVoIP AllStar Version---\n$R2\n\n---Linux Kernel Version---\n$R3\n$R4\n\n---Apache Version---\n$APACHE_VERSION\n\n---PHP Version---\n$PHP_VERSION\n\n---SSH Version---\n$SSH_VERSION\n\n---MM Software Details---\n$MM_SOFTWARE_VERSION\n\n---Raspberry Pi Information---\nModel: $MODEL\nRevision: $Revision\nMemory: $TOTAL_MEM\nCPU Architecture: $CPU_ARCH\nCPU Model: $CPU_MODEL\nKernel: $KERNEL_VERSION\nFirmware Version: $FIRMWARE_VERSION\nCPU Temperature: $CPU_TEMP\nSerial Number: $SERIAL\nMAC Address: $MAC_ADDRESS\nIP Address: $IP_ADDRESS\nDisk Usage: $DISK_INFO\nUptime: $UPTIME" 30 100


# Get Swap Space Information
if [ -f /proc/swaps ]; then
    SWAP_TOTAL=$(free -m | awk '/Swap:/ {print $2}')
    SWAP_USED=$(free -m | awk '/Swap:/ {print $3}')
    
      
    SWAP_INFO="$SWAP_USED used / $SWAP_TOTAL total"
else
    SWAP_INFO="Swap info unavailable"
fi

# Update Info Message
INFO_MESSAGE="\n\
Node Image       : $MM_SOFTWARE_VERSION\n\\n\

Apache Version   : $APACHE_VERSION\n\
PHP Version      : $PHP_VERSION\n\
SSH Version      : $SSH_VERSION\n\
HamVoIP Firmware : $R1\n\
HamVoIP AllStar  : $R2\n\
Linux Kernel     : $R3\n$R4\n\\n\
Registration     : $registration_details\n\
Node reported    : $node_number\n\

Model            : $MODEL\n\
Revision         : $Revision\n\
Memory           : $TOTAL_MEM\n\
Swap Space       : $SWAP_INFO\n\
CPU Architecture : $CPU_ARCH\n\
CPU Model        : $CPU_MODEL\n\
Kernel Version   : $KERNEL_VERSION\n\
Firmware Version : $FIRMWARE_VERSION\n\
CPU Temperature  : $CPU_TEMP\n\
Serial Number    : $SERIAL\n\
MAC Address      : $MAC_ADDRESS\n\
IP Address       : $IP_ADDRESS\n\
Disk Usage       : $DISK_INFO\n\
System Uptime    : $UPTIME\n\
Time Date        : $CURRENT_DATE $TIMEZONE\n\
$usb_version"

# Display Updated Information
$D --title 'System Information' --msgbox "$INFO_MESSAGE" 55 100


exit 0

