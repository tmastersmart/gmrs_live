#!/bin/bash

# This script provides a graphical menu to manage cron jobs for opening router port 80.
# It allows the user to enable or disable the port forwarding and manage cron jobs.

# Copyright (C) 2024 By mike wrxb288
# Custom Louisiana image Version 


MM_SOFTWARE_FILE="/etc/asterisk/local/mm-software/version.txt"
if [ -f "$MM_SOFTWARE_FILE" ]; then
    MM_SOFTWARE_VERSION=$(head -1 "$MM_SOFTWARE_FILE" | awk -F ',' '{print "Version: "$1"\nRelease Date: "$2}')
else
    MM_SOFTWARE_VERSION="MM Software Version File Not Found"
fi

# Get IP Address (using ip addr instead of hostname -I)
IP_ADDRESS=$(ip addr show eth0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
if [ -z "$IP_ADDRESS" ]; then
    IP_ADDRESS=$(ip addr show wlan0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
fi
# If IP address is still blank, set fallback message
IP_ADDRESS=${IP_ADDRESS:-"IP info unavailable"}
EXTERNAL_IP=$(curl -s http://ifconfig.me)

NODE_NUMBER=$(grep -i 'NODE1' /usr/local/etc/allstar_node_info.conf | sed -n 's/.*NODE1="\([0-9]*\)".*/\1/p')



# Function to display the help page
function help_page {
    dialog --title "Help: Port Forwarding" \
    --msgbox "Port Forwarding Process by UPnP:\n\
The script will first attempt to open ports in this order: 80, 8080, 8088. Some routers may reject port 80. Check the following URLs to access the status page:\n\n\
http://$IP_ADDRESS:8080\n\
http://$IP_ADDRESS\n\
http://$EXTERNAL_IP:8080\n\
http://$EXTERNAL_IP\n\
http://$NODE_NUMBER.gmrshubnode.com:8080\n\
http://$NODE_NUMBER.gmrshubnode.com\n\n\
Try ports 8080 or 8088 if port 80 is not available. If your router doesn't support UPnP you will have to manually open the ports in your router's settings.\n\n\
Router must support UPnp = Universal Plug and Play and have it enabled.  If UPnP doesn not work disable this script! Remember you need to reboot after enabling.\n\n\
Louisiana Image (Its just better!)\n" 25 70
}





function is_in_cron {
    crontab -l 2>/dev/null | grep -q '/home/user/open_router.sh'
}

# Function to add the script to cron at reboot and daily
function add_to_cron {
    # Check if the script is already in cron
    if is_in_cron; then
        dialog --msgbox "The script is already scheduled in cron." 10 60
    else
        # Add the script to cron (reboot and daily)
# Add the script to cron (reboot and daily)
(crontab -l 2>/dev/null; echo "@reboot /home/user/open_router.sh >> /tmp/open_router.log 2>&1") | crontab -
(crontab -l 2>/dev/null; echo "0 2 * * * /home/user/open_router.sh >> /tmp/open_router.log 2>&1") | crontab -
        
        
        
        dialog --msgbox "The script has been added to cron. You need to reboot for first time run." 10 60
    fi
}

# Function to remove the script from cron
function remove_from_cron {
    # Remove the script from cron (reboot and daily)
    crontab -l | grep -v '/home/user/open_router.sh' | crontab -
    dialog --msgbox "The script has been removed from cron." 10 60
}





# Function to display the main menu
function main_menu {
    dialog --title "Router UPnp Port Management" \
    --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION $IP_ADDRESS" \
    --menu "Use UPnp to open a port on your router\n\n Choose an option:" 15 50 5 \
    1 "Activate" \
    2 "Deactivate" \
    3 "Help" \
    4 "Exit" 2>/tmp/menu_choice

    # Check if user pressed cancel
    if [ $? -ne 0 ]; then
        exit 0
    fi

    menu_choice=$(cat /tmp/menu_choice)

    case $menu_choice in
        1) add_to_cron ;;
        2) remove_from_cron ;;
        3) help_page ;;
        4) exit 0 ;;
    esac
}

# Ensure dialog is installed
if ! command -v dialog &> /dev/null
then
    echo "dialog is required but not installed. Installing..."
    sudo apt-get install dialog -y
    echo "dialog installed successfully."
fi

# Display the menu until the user exits
while true; do
    main_menu
done
