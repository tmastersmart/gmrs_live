#!/bin/bash

# Variables
export DD="/usr/bin/dialog"
MM_SOFTWARE_FILE="/etc/asterisk/local/mm-software/version.txt"
WL_SCAN_FILE=/tmp/wireless_scan.info
WL_DEV=wlan0
WPA_SUPP_CONF=/etc/wpa_supplicant/wpa_supplicant_custom-wlan0.conf

# Functions
get_software_version() {
    if [ -f "$MM_SOFTWARE_FILE" ]; then
        MM_SOFTWARE_VERSION=$(head -1 "$MM_SOFTWARE_FILE" | awk -F ',' '{print "Version: "$1"\nRelease Date: "$2}')
    else
        MM_SOFTWARE_VERSION="MM Software Version File Not Found"
    fi
}

get_ip_address() {
    IP_ADDRESS=$(ip addr show eth0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
    if [ -z "$IP_ADDRESS" ]; then
        IP_ADDRESS=$(ip addr show wlan0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
    fi
    IP_ADDRESS=${IP_ADDRESS:-"IP info unavailable"}
}

ssid_view() {
    echo > $WL_SCAN_FILE
    iwlist wlan0 scan >> $WL_SCAN_FILE
    grep 'No scan results' $WL_SCAN_FILE 2>/dev/null 1>&2
    RES=$?
    CNT=$(wc $WL_SCAN_FILE | awk '{print $1}')
    if [ $CNT -lt 4 -o $RES -eq 0 ] ; then
        $SOFF
        $D --msgbox " No scan results found! " 10 30
        return
    fi

    entries=$(cat $WL_SCAN_FILE)
    SAVEIFS=$IFS
    IFS=$(echo -en "\n\b")
    count=1
    SIGNAL=()
    QUALITY=()
    ESSID=()
    ENTRY=()
    for line in $entries ; do
        essid=$(echo $line | grep ESSID: | sed 's/^[ \t]*//;s/[ \t]*$//')
        essid=${essid#ESSID:}
        essid=$(echo ${essid} | sed -e 's/^"//' -e 's/"$//')
        if [ -n "$essid" ] ; then
            ESSID[$count]="$essid"
            continue
        fi

        quality=$(echo $line | grep Quality | awk '{print $1}' | awk -F= '{ print $2 }')
        signal=$(echo $line | grep "Signal level" | awk -F= '{ print $3 }')
        if [ -n "$quality" ] ; then
            QUALITY[$count]="$quality"
            SIGNAL[$count]="$signal"
        fi

        if [ -n "${SIGNAL[$count]}" -a -n "${QUALITY[$count]}" -a -n "${ESSID[$count]}" ] ; then
            let count=count+1
        fi
    done

    IFS=$SAVEIFS
    ITEMS=()
    ptr=1
    while [ $ptr -lt $count ] ; do
        if (grep "${ESSID[$ptr]}" /etc/wpa_supplicant/wpa_supplicant_custom-wlan0.conf> /dev/null) ; then
            ENTRY[$ptr]="****"
        else
            ENTRY[$ptr]="    "
        fi
        ITEMS+=($ptr "$ptr ${ESSID[$ptr]} | ${QUALITY[$ptr]} | ${SIGNAL[$ptr]} ${ENTRY[$ptr]}")
        let ptr=ptr+1
    done

    if [ $count -le 1 ] ; then
        $SOFF
        $D --msgbox " No scan results found! " 10 30
        return
    fi

    SSID_SEL=$($D --no-tags --title "Select SSID" --ok-label "Select SSID" --cancel-label "CANCEL" --menu "Below shows SSID Signal Quality and if entry present:" 20 70 10 "${ITEMS[@]}" 3>&1- 1>&2- 2>&3-)
    RET=$?
    if [ "$RET" = 1 ] ; then
        return
    fi

    ESSID_SEL=${ESSID[${SSID_SEL}]}
}

display_network_info() {
    eth0_info=$(dhcpcd -U eth0)
    wlan0_info=$(dhcpcd -U wlan0)

    # Display the gathered information in a readable format
    dialog --title "Network Information" \
           --msgbox "$(printf "Ethernet (eth0) Network Information:\n\n%s\n\nWi-Fi (wlan0) Network Information:\n\n%s" "$eth0_info" "$wlan0_info")" 20 70
}

main_menu() {
    while true; do
        get_software_version
        get_ip_address

        OPTION=$($D --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION $IP_ADDRESS" \
        --nocancel --title "WIFI Setup & Control" --menu \
        "Please follow the steps to configure your wireless settings. Remember you must not connect wired and WIFI at the same time.\n
        And only one wifi setup can be entered at a time.\n\n
        Louisiana GMRS Image (it's just better)\n\n
        Select an option below:" 20 70 8 \
        1 "Setup Wireless SSID and passphrase" \
        2 "Enable Wireless Device (wlan0)" \
        3 "Disable Wireless Device (wlan0)" \
        4 "View Wireless Setup" \
        5 "View Network Info" \
        6 "Exit" 3>&1 1>&2 2>&3)
        
        case $OPTION in
            1) setup_wireless ;;
            2) enable_wireless ;;
            3) disable_wireless ;;
            4) view_wireless_setup ;;
            5) display_network_info ;;
            6) exit 0 ;;
            *) ;;
        esac
    done
}

setup_wireless() {
    # Your setup wireless code here
    echo "Setting up wireless..."
}

enable_wireless() {
    # Your enable wireless code here
    echo "Enabling wireless..."
}

disable_wireless() {
    # Your disable wireless code here
    echo "Disabling wireless..."
}

view_wireless_setup() {
    # Your view wireless setup code here
    echo "Viewing wireless setup..."
}

# Start the main menu
main_menu
