#!/bin/bash
# Bash interface with info 
# MENU%08%Drop to a Bash shell

# Get IP Address (using ip addr instead of hostname -I)
IP_ADDRESS=$(ip addr show eth0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
if [ -z "$IP_ADDRESS" ]; then
    IP_ADDRESS=$(ip addr show wlan0 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
fi
# If IP address is still blank, set fallback message
IP_ADDRESS=${IP_ADDRESS:-"IP info unavailable"}

# Use Device Tree for Model Name (Modern Raspbian Kernel)
if [ -f /proc/device-tree/model ]; then
    MODEL=$(tr -d '\0' < /proc/device-tree/model)
else
    MODEL="Unknown Model"
fi

# Get CPU Info
CPU_INFO=$(cat /proc/cpuinfo | grep "model name" | head -n 1 | cut -d: -f2)

# Get Memory Usage
MEMORY=$(free -h | awk '/Mem:/ {print $3 "/" $2}')

# Get Swap Usage
SWAP=$(free -h | awk '/Swap:/ {print $3 "/" $2}')

# Get Disk Space Usage
DISK_SPACE=$(df -h / | awk 'NR==2 {print $3 "/" $2}')

# Get Date and Time
DATE_TIME=$(date "+%Y-%m-%d %H:%M:%S")

TIMEZONE=$(timedatectl show --property=Timezone --value 2>/dev/null || \
    readlink /etc/localtime | sed -e 's/.*\/zoneinfo\/\(.*\)$/\1/' || echo "Timezone info unavailable")
# Get CPU Temperature
if command -v vcgencmd >/dev/null; then
    CPU_TEMP=$(vcgencmd measure_temp | cut -d '=' -f2)
else
    CPU_TEMP="Temperature info unavailable"
fi
# Custom MM Software Version
MM_SOFTWARE_FILE="/etc/asterisk/local/mm-software/version.txt"
if [ -f "$MM_SOFTWARE_FILE" ]; then
    MM_SOFTWARE_VERSION=$(head -1 "$MM_SOFTWARE_FILE" | awk -F ',' '{print "Version: "$1"\n Release Date: "$2}')
else
    MM_SOFTWARE_VERSION="MM Software Version File Not Found"
fi
# Get System Uptime
UPTIME=$(awk '{print int($1 / 3600)" hours, "int(($1 % 3600) / 60)" minutes"}' /proc/uptime)

# Setup the terminal for other logins
CUSTOM_MESSAGE="
 ============================================================
 (c)2024 Louisiana Node Image $MM_SOFTWARE_VERSION      
 ============================================================
 Model         : $MODEL
 CPU Info      : $CPU_INFO
 Date and Time : \d \t $TIMEZONE
 Arch          : \r 
 ============================================================
 for Config type 'cd /etc/asterisk/' for logs 'cd /var/log/asterisk/' 
"
echo "$CUSTOM_MESSAGE" > /etc/issue



# Clear the screen and set the terminal appearance
$SON
reset
echo ""
echo " ============================================================"
echo " (c)2024 Louisiana Node Image $MM_SOFTWARE_VERSION"      
echo " ============================================================"
echo " Model         : $MODEL"

echo " CPU Info      : $CPU_INFO"
echo " CPU Temp      : $CPU_TEMP"
echo " Memory Usage  : $MEMORY"
echo " Swap Usage    : $SWAP"  # Added line for swap usage
echo " Disk Space    : $DISK_SPACE"
echo " Date and Time : $DATE_TIME $TIMEZONE"
echo " Uptime        : $UPTIME" 
echo " IP Address    : $IP_ADDRESS"
echo " ============================================================"
echo ""
echo "Shell prompt. Type: exit<ENTER> or <CTRL+D> to return to menu"
echo ""
echo "for Config type 'cd /etc/asterisk/' for logs 'cd /var/log/asterisk/' "
echo ""
echo ""
/bin/bash


