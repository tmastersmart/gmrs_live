#!/bin/bash
# total rewrite for GMRS  2024
#
#MENUFT%020%Change your NODE number and enter setup
$SOFF
$D --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION $IP_ADDRESS" --title "Change Node Number" --yesno "Be sure you have your assigned node number and password ready. You get this from GMRShub.com. if you dont have it exit now and get it\n\n Do you want to change the node number?" 10 70
RES=$?

if [ $RES -eq 0 ]; then
    while true; do
        $SON
        NODE1=$($D --title "GMRShub Node Number Input" --nocancel --inputbox "Enter your node number (>= 10000):" 8 78 3>&1 1>&2 2>&3)
        if [ "$(expr $NODE1)" -lt 10000 ]; then
            $SOFF
            $D --title "Node Number Error (Whats that?)" --msgbox "Error: GMRShub node numbers must be greater than or equal to 10000." 8 60
        else
            break
        fi
    done

    # Update the allstar file
    sed -i "s/^export NODE1=.*/export NODE1=${NODE1}/" /usr/local/etc/allstar.env
    sed -i "s/^export PRIVATE_NODE=.*/export PRIVATE_NODE=0/" /usr/local/etc/allstar.env
    #Update the status page 
    sed -i "s/^export $mynode=.*/export $mynode=${node1};/" /srv/http/status/config.php
    sed -i "s/^export $mynode=.*/export $mynode=${node1};/" /srv/http/admin/config.php    


    # Update the node section in poll_status.ini
    sed -i "s/^\[.*\]/[${node1}]/" /home/gmrs/poll_status.ini
    # Update the export nodes line
    sed -i "s/^export nodes=.*/export nodes=${node1}/" /home/gmrs/poll_status.ini

FILE="/home/gmrs/poll_status.ini"
password=$(grep -oP '(?<=^passwd=).*' "$FILE")

cat <<EOF > "$FILE"
[${node1}]
host=127.0.0.1:5038
user=admin
passwd=$password

[All Nodes]
system=Nodes
export nodes=${node1}
menu=yes
EOF

#reset the node manager. Forces a re-install 
rm -f /etc/asterisk/local/mm-software/mm-node.txt
rm -f /etc/asterisk/local/mm-software/setup.txt
rm -f /etc/asterisk/local/mm-software/dvswitch-nodeinfo.txt
#reset the log make sure its clean
rm -f /var/log/asterisk/messages
    
# Define directories to clean
logs_dir="/etc/asterisk/local/mm-software/logs"
repo_dir="/etc/asterisk/local/mm-software/repo"
chart_dir="/etc/asterisk/local/mm-software/chart"
backup_dir="/etc/asterisk/local/mm-software/backup"
nodelist_dir="/etc/asterisk/local/mm-software/nodelist"
# Function to clean a directory
clean_directory() {
    local dir=$1
    if [ -d "$dir" ]; then
        rm -f "$dir"/*
        echo "Files erased from $dir."
    else
        echo "Directory $dir does not exist."
    fi
}

# Clean all specified directories
clean_directory "$logs_dir"
clean_directory "$repo_dir"
clean_directory "$chart_dir"
clean_directory "$backup_dir"
clean_directory "$nodelist_dir"

         
    $SOFF
    $D --title "Node Number Update" --msgbox "Your node number has been updated to ${NODE1}. We now need to reboot and configure ast for the new node number " 8 60
else
    $SOFF
    $D --title "Nothing changed" --msgbox "We didnt do anything." 8 60
    exit 0
fi

# Setup for the node-config script
$SOFF

# Automatically set up the node configuration
touch /node-config

$D --title "Node Configuration" --msgbox "Node configuration will be run after reboot." 10 70

$SON
exit 0

