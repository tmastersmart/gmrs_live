#!/bin/bash
# total rewrite for GMRS  2024
#
#MENUFT%020%Change Node number (Restart Setup)
$SOFF
$D --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION $IP_ADDRESS" \
--title "Change Node Number" \
--yesno "Be sure you have your node number and password ready.\n\
You get this from GMRShub.com.\n\
If you dont have it exit now and get it\n\n\
DANGER This resets everything!!!\n\n\
Do you want to restart with a new node number? For private nodes you may enter a 3 or 4 digit node number but not 9xx which are 911 numbers." 15 60
RES=$?

if [ $RES -eq 0 ]; then
while true; do
    $SON
    NODE1=$($D --title "GMRShub Node Number Input"\
    --nocancel \
    --inputbox "Enter your node number (3 to 6 digits, but not 3-digit numbers starting with 9 911):" 8 78 3>&1 1>&2 2>&3)

    # Check if the input is a valid number between 3 and 6 digits
    if [[ ! "$NODE1" =~ ^[0-9]{3,6}$ ]]; then
        $SOFF
        $D --title "Node Number Error (Invalid Format)" --msgbox "Error: Node numbers must be between 3 and 6 digits." 8 60
    # Disallow 3-digit numbers starting with 9
    elif [[ "$NODE1" =~ ^9[0-9]{2}$ ]]; then
        $SOFF
        $D --title "Node Number Error (Restricted)" --msgbox "Error:911 3-digit node numbers starting with 9 are not allowed." 8 60
    else
        break
    fi
done


    # Update the allstar file
    sed -i "s/^export NODE1=.*/export NODE1=${NODE1}/" /usr/local/etc/allstar.env
    sed -i "s/^export PRIVATE_NODE=.*/export PRIVATE_NODE=0/" /usr/local/etc/allstar.env
    #Update the status page 
    sed -i "s/^export $mynode=.*/export $mynode=${node1};/" /srv/http/status/config.php
    sed -i "s/^export $mynode=.*/export $mynode=${node1};/" /srv/http/admin/config.php    


    # Update the node section in poll_status.ini
    sed -i "s/^\[.*\]/[${node1}]/" /home/gmrs/poll_status.ini
    # Update the export nodes line
    sed -i "s/^export nodes=.*/export nodes=${node1}/" /home/gmrs/poll_status.ini

FILE="/home/gmrs/poll_status.ini"
password=$(grep -oP '(?<=^passwd=).*' "$FILE")

cat <<EOF > "$FILE"
[${node1}]
host=127.0.0.1:5038
user=admin
passwd=$password

[All Nodes]
system=Nodes
export nodes=${node1}
menu=yes
EOF

#reset the node manager. Forces a re-install
rm -f /etc/asterisk/local/mm-software/mm-node.txt
rm -f /etc/asterisk/local/mm-software/setup.txt
rm -f /etc/asterisk/local/mm-software/dvswitch-nodeinfo.txt
#reset the log make sure its clean
rm -f /var/log/asterisk/messages
    
# Define directories to clean
logs_dir="/etc/asterisk/local/mm-software/logs"
repo_dir="/etc/asterisk/local/mm-software/repo"
chart_dir="/etc/asterisk/local/mm-software/chart"
backup_dir="/etc/asterisk/local/mm-software/backup"
nodelist_dir="/etc/asterisk/local/mm-software/nodelist"
# Function to clean a directory
clean_directory() {
    local dir=$1
    if [ -d "$dir" ]; then
        rm -f "$dir"/*
        echo "Files erased from $dir."
    else
        echo "Directory $dir does not exist."
    fi
}

# Clean all specified directories
clean_directory "$logs_dir"
clean_directory "$repo_dir"
clean_directory "$chart_dir"
clean_directory "$backup_dir"
clean_directory "$nodelist_dir"

         
    $SOFF
    $D --title "Node Number Update" --msgbox "Your node number has been updated to ${NODE1}. We now need to reboot and configure ast for the new node number. " 8 60
else
    $SOFF
    $D --title "Nothing changed" --msgbox "Aborted! Nothing was changed. We didnt do anything. Come back later to change node#." 8 60
    exit 0
fi

# Setup for the node-config script
$SOFF

# Automatically set up the node configuration
touch /node-config

$D --title "Node Configuration" --msgbox "Node configuration will be run after reboot." 10 70

$SON
exit 0

