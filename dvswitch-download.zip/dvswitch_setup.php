<?php
// ***************************************************
// (c)2023/2024 by The Master lagmrs.com WRXB288 
//  all rights reserved
//
// 

$ver="v1"; $release="6-1-2024";  
$line =	exec('timedatectl | grep "Time zone"'); //       Time zone: America/Chicago (CDT, -0500)
$line = str_replace(" ", "", $line);
$pos1 = strpos($line, ':');$pos2 = strpos($line, '(');
if ($pos1){  $zone   = substr($line, $pos1+1, $pos2-$pos1-1); }
else {$zone="America/Chicago";}
define('TIMEZONE', $zone);
date_default_timezone_set(TIMEZONE);
$phpzone = date_default_timezone_get(); 
$basename=basename($_SERVER['PHP_SELF']);
$phpVersion= phpversion();   

$iax          = "/etc/asterisk/iax.conf";
$rpi          = "/etc/asterisk/rpt.conf";
$manager      = "/etc/asterisk/manager.conf";
$tmpFile      = "/tmp/temp.dat";
$logger       = "/etc/asterisk/logger.conf";
$path  = "/etc/asterisk/local/mm-software";

$file=""; $in="check"; $changeall=false;

$file= "$path/mm-node.txt";if(!file_exists($file)){create_node ($file);}  
if(file_exists($file)){
$line = file_get_contents($file);
$u= explode(",",$line);
$node=$u[0];$call=$u[1];
}

$port = find_port ("port");
$file="";



print "

______ _   _               _ _       _       _____      _                
|  _  \ | | |             (_) |     | |     /  ___|    | |               
| | | | | | | _____      ___| |_ ___| |__   \ `--.  ___| |_ _   _ _ __   
| | | | | | |/ __\ \ /\ / / | __/ __| '_ \   `--. \/ _ \ __| | | | '_ \  
| |/ /\ \_/ /\__| \ V  V /| | || (__| | | | /\__/ /  __/ |_| |_| | |_) | 
|___/  \___/ |___/ \_/\_/ |_|\__\___|_| |_| \____/ \___|\__|\__,_| .__/  
                                                                 | |     
                                                                 |_|    

============================================================ 
DV Switch setup tool $ver  Welcome $call  
(c)2023/2024 by WRXB288 LAGMRS.com all rights reserved 
PHP:$phpVersion Timezone: $phpzone  Release date:$release
Made in Louisiana by Michael May
============================================================";

dvswitch_menu($in);
start($in);

function dvswitch_menu($in){
global $node,$call,$password,$port;
print "

(1) Install DV Switch/Reinstall Change password
(2) Recall your settings
(r) Repair/reinstall admin menu
(h) Help
(e) Exit
";
}


function dvswitchInstall($in){
global $node,$call,$password,$port;
$password = getRandomString(8);
edit_iax_DV($in);
edit_extensions($in);
dvswitchRecall($in) ;

}

function dvswitchRecall($in){
global $node,$call,$password,$port;
$password=""; $search="?";
search_iax_DV($password);
$localIP = getHostByName(getHostName());
   $myip = exec("/bin/wget -t 1 -T 3 -q -O- http://checkip.dyndns.org:8245 |/bin/cut -d':' -f2 |/bin/cut -d' ' -f2 |/bin/cut -d'<' -f1");
$port = find_port ("port");

if ($password){
print " 

DV-Switch is installed.
 
Be sure you enter your real call because it will be visiable in the link.
lsnodes will show all dvswitch users from any node.

Your IP is [$myip]   
Setup the DV SWitch APP as listed here.
=================================================================
Protocol IAX2
Hostname '$node.node.gmrslive.com'   or on a LAN '$localIP'
Port     '$port'
Username 'dvswitch'
Password '$password'
CallerID '$call'
Caller #    
Node     '$node'

[checked]Phone mode IAX2 Connection 
[ ] Use public autentication
[ ] Autoload node

Codec Types [ulaw]
==================================================================

";}
else {print"
DV switch ERROR 
<<<Not setup please reinstall!>>>
";}
}



function start($in){
global $node,$call,$password,$port;

$stdin = fopen('php://stdin', 'r');
$yes   = false;

while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Main Enter 1-2 E:_";
	$input = trim(fgets($stdin));
    if ($input == '1'){dvswitchInstall("install");}
    if ($input == '2'){dvswitchRecall("recall");}
    if ($input == 'r'){admin_sh_menu("reinstall");}
    if ($input == 'h'){help();}
    if ($input == 'x'){uninstall("x");}
	if ($input == 'e'){exit1();}
    dvswitch_menu($in) ;
}
}


function exit1(){
print "
--- Remember AST must be restarted after install/reinstall ---

--- DV Switch will not be able to login if not  ---

";
sleep(6);
die;
}


function help(){
global $node,$call,$password,$port;
print"
==================================================================
This software is designed to be a 1 click setup of DV switch so
that anyone can install it. At any skill level. Look for more soon.


DV switch will work on a local lan as is but requires port forwarding
on your router to work over the internet.

1) You must set your PI to a static IP in your router. 
   Sometimes called reserved.
2) Port forward port:$port to the IP of your router.
3) Port forward in port:80 for supermon.
4) Once setup the domain name for your pi will be 
   '$node.node.gmrslive.com'

[DANGER] never port forward in ssh ports 22 or 222 because the SSH
the PI is running is not secure and known hacks exist that allow 
hackers access to your entire network. Once in they will have access
to your other computers. So be warned dont do it.

Look for other tools soon. 

Please check website for updates and other tools. 
http://www.lagmrs.com 

==================================================================

";
}





function edit_extensions($in){ 
global $search,$path,$fileEdit,$ok,$node,$changeall,$password;

$ok=false;$line=""; $search= "[dvswitch-iaxrpt]";
$fileEdit= "/etc/asterisk/extensions.conf";
if (file_exists($fileEdit)){
$fileBu = "$fileEdit-.bak"; if (!file_exists($fileBu)){copy($fileEdit,$fileBu);} // This creates a orginal backup
$tmpFile="$fileEdit-new.txt"; 

$fileIN= file($fileEdit);
$fileOUT = fopen($tmpFile, "w") or die ("Error $tmpFile Write falure");
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", $search); 
if ($pos>=1){
$formated="[dvswitch-iaxrpt]  
exten => $node,1,Answer
exten => $node,n,Playback,rpt/node
exten => $node,n,Saydigits(#{EXTEN:1})
exten => $node,n,Set(CALLERID(num)=0)
exten => $node,n,Rpt,2955|P|#{CALLERID(name)} 
"; $formated = str_replace('#', '$', $formated);

$ok=true;fwrite ($fileOUT, "$formated\n"); break;
}  
fwrite ($fileOUT, "$line\n");
}

if (!$ok){ $formated="[dvswitch-iaxrpt] 
exten => $node,1,Answer
exten => $node,n,Playback,rpt/node
exten => $node,n,Saydigits(#{EXTEN:1})
exten => $node,n,Set(CALLERID(num)=0)
exten => $node,n,Rpt,2955|P|#{CALLERID(name)}
"; 
fwrite ($fileOUT, "$formated\n");
}

fclose ($fileOUT);
if (file_exists($tmpFile)){ unlink($fileEdit);} 
rename ($tmpFile, $fileEdit); 
$fileEdit="";$search="";print"\n";
}
}


// Safe search for DV switch password
function search_iax_DV($in){ 
global $node,$call,$password,$port,$iax;
global $search,$path,$ok,$hide;

$ok=false;$line=""; 
$fileEdit= $iax;

if (file_exists($fileEdit)){$fileIN= file($fileEdit);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", "[DVSWITCH]"); if ($pos){$ok=true; } 
$pos = strpos("-$line", "secret="); 
  if ($pos and $ok){ 
  $u = explode("=", $line);
  $search=$u[0];$password=$u[1];
  break;
   }
  }
 }
//if ($password=="xxxxxxx"){$password="";} 
}

// THE Main IAX editor for DVSWITCH 
function edit_iax_DV($password){ 
global $node,$call,$password,$port,$iax;
global $search,$path,$ok,$hide;

$ok=false;$line=""; 
$fileEdit= $iax;

if (file_exists($fileEdit)){
$fileBu = "$fileEdit-.bak"; if (!file_exists($fileBu)){copy($fileEdit,$fileBu);} // This creates a orginal backup
$tmpFile= "$fileEdit-new.txt"; 
$fileIN= file($fileEdit);
$fileOUT = fopen($tmpFile, "w") or die ("Error $tmpFile Write falure");

foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", "[DVSWITCH]"); if ($pos){$ok=true; break;}// if found stop...  
fwrite ($fileOUT, "$line\n");
}


$line="[DVSWITCH]
type=friend
context=dvswitch-iaxrpt
host=dynamic
auth=md5
secret=$password
disallow=all
allow=ulaw
transfer=no
calltokenoptional=0.0.0.0/0.0.0.0
requirecalltoken=no

";
fwrite ($fileOUT, "$line\n");
}
fclose ($fileOUT);

// now if we added we swap it in if it already existed we just stop.
// This needs to be changed so it can overwrite but not for now,.

if (file_exists($tmpFile)){ unlink($fileEdit);} 
rename ($tmpFile, $fileEdit); 

$fileEdit="";$search="";print"\n";
}




// build a password
function getRandomString($n){
    $characters = '0123456789abcdefghijklmnpqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ';
    $randomString = '';

    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }

    return $randomString;
}


function uninstall(){
global $path;
$file="$path/mm-node.txt";if (file_exists($file)){unlink($file);}
$file1="/usr/local/sbin/firsttime/dvswitch.sh";if (file_exists($file1)){unlink($file1);}
$file2="/etc/asterisk/local/mm-software/dvswitch_setup.php";if (file_exists($file2)){unlink($file2);}
print "Software uninstalled. To reinstall go to LAGMRS.com\n";
sleep(20);
die;
}

function admin_sh_menu(){
global $release;
print "$datum Installing into admin menu ";
$file ="/usr/local/sbin/firsttime/adm01-shell.sh";
$file2="/usr/local/sbin/firsttime/dvswitch.sh";
               
copy($file, $file2); print "-";

$formated="#/!bin/bash
#MENUFT%055%DV SWITCH Setup Program Version:$release
";

$out='
$SON
reset

php /etc/asterisk/local/mm-software/dvswitch_setup.php

exit 0
';
$out = "$formated $out";
$fileOUT = fopen($file2, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, $out);flock( $fileOUT, LOCK_UN );fclose ($fileOUT); print "-";
exec("sudo chmod +x $file2",$output,$return_var);
if (file_exists($file2)){print"<ok>\n";}
else{print"<Error>\n";}
}

//
// we check which port is in use
//
function find_port ($in){
global $port,$debug,$datum,$iax ;
$port="";
$fileIN= file($iax);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", "bindport="); 
if ($pos == 1){
if($debug){print"$datum DEBUG $line\n";}
$u= explode("=",$line);
$port = $u[1]; $port= trim($port," ");
return $port;
  }
 }
} 

function create_node ($file){
global $file,$path,$node,$call;
// keep this file up to date
$autotts="";
//if(!$call){$call="hub";}
$file ="/usr/local/etc/allstar_node_info.conf";// only on hamvoip 
if (file_exists($file)){
$autotts=""; 
$fileIN= file($file);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$line = str_replace('"', "", $line);
$pos = strpos("-$line", 'NODE1=');
if ($pos){$u= explode("=",$line);
$node=$u[1];}
$pos2 = strpos("-$line", 'STNCALL='); 
if ($pos2){$u= explode("=",$line);
$call=$u[1];}
}
}
$file= "$path/mm-node.txt";$fileOUT = fopen($file, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$node,$call, , , ,");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
}
?>
