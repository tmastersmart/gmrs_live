<?php
// ***************************************************
// (c)2023/2024 by The Master lagmrs.com WRXB288 
//  all rights reserved
//
// v1  Beta release 6/1/24
// v1.1 Uninstall option added to menu
// v1.2 6-9-24 Changes to detect custom immages and allow manual node number and call setup
// v1.5 bug fixes ind improvements
// v1.6 Auto backup and restore of conf files
// v1.7 changes to comments added in config. Extra delay added after saving
// v1.8 Changes to the menu beta is working so moved up in menu. Rebot changed to R

$ver="v1.8"; $release="7-3-2024";  

$line =	exec('timedatectl | grep "Time zone"'); //       Time zone: America/Chicago (CDT, -0500)
$line = str_replace(" ", "", $line);
$pos1 = strpos($line, ':');$pos2 = strpos($line, '(');
if ($pos1){  $zone   = substr($line, $pos1+1, $pos2-$pos1-1); }
else {$zone="America/Chicago";}
define('TIMEZONE', $zone);
date_default_timezone_set(TIMEZONE);
$phpzone = date_default_timezone_get(); 
$basename=basename($_SERVER['PHP_SELF']);
$phpVersion= phpversion();   
$piSystem=false;if (is_readable("/proc/device-tree/model")) {$piVersion = file_get_contents ("/proc/device-tree/model");$piSystem=true;}
else {$piVersion =	exec('uname -m -p');}
$path  = "/etc/asterisk/local/mm-software";

$iax          = "/etc/asterisk/iax.conf";
$rpt          = "/etc/asterisk/rpt.conf";
$manager      = "/etc/asterisk/manager.conf";
$logger       = "/etc/asterisk/logger.conf";
$extensions   = "/etc/asterisk/extensions.conf";
$tmpFile      = "/tmp/temp.dat";
$fileHamVoip  = "/usr/local/etc/allstar_node_info.conf";

$setupFile    = "$path/dvswitch-nodeinfo.txt";



$file=""; $in="check"; $node="";$call=""; $changeall=false; $password="";

if(!file_exists($setupFile)){create_node($in);}  
if(file_exists($setupFile)){
$line = file_get_contents($setupFile);
$u= explode(",",$line);
$node=$u[0];$call=$u[1];$password=$u[2]; 
}

if (strlen($password) < 5) { $password="";save_node($in); }

$port = find_port ("port");
$file="";

$stripe="=================================================================";

print "

______ _   _               _ _       _       _____      _                
|  _  \ | | |             (_) |     | |     /  ___|    | |               
| | | | | | | _____      ___| |_ ___| |__   \ `--.  ___| |_ _   _ _ __   
| | | | | | |/ __\ \ /\ / / | __/ __| '_ \   `--. \/ _ \ __| | | | '_ \  
| |/ /\ \_/ /\__| \ V  V /| | || (__| | | | /\__/ /  __/ |_| |_| | |_) | 
|___/  \___/ |___/ \_/\_/ |_|\__\___|_| |_| \____/ \___|\__|\__,_| .__/  
                                                                 | |     
                                                                 |_|    

$stripe 
DV Switch setup tool $ver  password:$password
CPU:$piVersion 
(c)2023/2024 by WRXB288 LAGMRS.com all rights reserved 
PHP:$phpVersion Timezone: $phpzone  Release date:$release
Made in Louisiana by Michael May
$stripe";

if (!$node or !$call){ node_menu($in); node_start($in); }
if (!$node or !$call){ exit1(); } // You entered nothing so exit

check_backup($in);
dvswitch_menu($in);
start($in);

function dvswitch_menu($in){
global $node,$call,$password,$port,$stripe;
global $fileHamVoip,$path,$setupFile,$bu1,$bu2,$bu3;

if ($bu1 or $bu2 or $bu3 ){
$d="(5) Repair/Restore from Backups ";
if($bu1){$d="$d [extension]";}
if($bu2){$d="$d [iax]";}
//if($bu3){$d="$d [rpt]";}
}
else{$d="";}
print "
$stripe
(1) Install DV Switch/Reinstall (old)
(2) Install DV Switch/Reinstall (new) Sends node number with your call 
(3) Recall your settings

(4) Repair/Rinstall admin menu
$d
(r) Do a system reboot to install changes
(c) Change the Node:[$node] or Call:[$call]
(d) Download updates.

(h) Help
(u) Uninstall This software
(e) Exit
";
}




function node_menu($in){
global $node,$call,$password,$port,$stripe,$piVersion;
global $fileHamVoip,$path,$setupFile;
$out="";if (!$node or !$call){
$out="$piVersion
Node number and CALL must be entered to continue
";}
print "
$stripe
$out
    Node:[$node]  Call:[$call]
(n) Node Setup 
(c) Call Setup 

(m) Main menu
(h) Help
(u) Uninstall This software
(e) Exit
";
}

function dvswitchInstall($in){
global $node,$call,$password,$port,$stripe;
global $fileHamVoip,$path,$setupFile;
// $password = getRandomString(8);  anoying do it only once
//if($in=="beta")
if (strlen($password) < 5) { $password="";save_node($in); }
edit_iax_DV($in);
edit_extensions($in);
dvswitchRecall($in) ;
burst($call);
}

function dvswitchRecall($in){
global $node,$call,$password,$port,$stripe;
global $fileHamVoip,$path,$setupFile;
$password=""; $search="?";
search_iax_DV($password);
$localIP = getHostByName(getHostName());
   $myip = exec("/bin/wget -t 1 -T 3 -q -O- http://checkip.dyndns.org:8245 |/bin/cut -d':' -f2 |/bin/cut -d' ' -f2 |/bin/cut -d'<' -f1");
$port = find_port ("port");

if ($password){
print " 
$stripe
DV-Switch is installed.

Open up DVSWITCH and create a setup with this information in it.
Enter your full real GMRS call. DO not use a HAM call! 
Do not use just numbers!  Do not use just your last 3 numbers!!!! Do not use your node#!!!
The admins accross the net can see these calls and they need to be real to identify where they come from.. 

Volume control is in the app. not simple usb!

Your IP is [$myip]   
Setup the DV SWitch APP as listed here.
$stripe
Protocol IAX2
Hostname '$node.node.gmrslive.com'   or on a LAN '$localIP'
Port     '$port'
Username 'dvswitch'  
Password '$password'
CallerID '$call'
Caller #    
Node     '$node'

[checked]Phone mode IAX2 Connection 
[ ] Use public autentication
[ ] Autoload node

Codec Types [ulaw]
$stripe

";}
else {print"
ERROR 6  Not setup please install!
";}
}

function node_start($in){
global $node,$call,$password,$port,$stripe;
global $fileHamVoip,$path,$setupFile,$password;

$stdin = fopen('php://stdin', 'r');
$yes   = false;

while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Node edit :_";
	$input = trim(fgets($stdin));
    if ($input == 'n'){node_change($in);save_node($in);}
    if ($input == 'c'){call_change($in);save_node($in);}

    if ($input == 'r'){admin_sh_menu("reinstall");}
    

    if ($input == 'h'){help();}
    if ($input == 'u'){uninstall("x");}
	if ($input == 'm'){return;}    
	if ($input == 'e'){exit1();}
    node_menu($in) ;
}
}
function node_change($in){
global $node,$call,$password,$port,$stripe;
global $fileHamVoip,$path,$setupFile,$password;
$line = readline("Enter Your Node number[$node]: ");
if($line){$node=$line;}
print "\n";
}
function call_change($in){
global $node,$call,$password,$port,$stripe;
global $fileHamVoip,$path,$setupFile;
$line = readline("Enter Your Call [$call]: ");
if($line){$call=$line;}
print "\n";
}



function start($in){
global $node,$call,$password,$port,$stripe;
global $fileHamVoip,$path,$setupFile,$password;

$stdin = fopen('php://stdin', 'r');
$yes   = false;

while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Main Enter 1-2 E:_";
	$input = trim(fgets($stdin));
    if ($input == '1'){dvswitchInstall("install");}
    if ($input == '2'){dvswitchInstall("beta");} // test install with node
    if ($input == '3'){dvswitchRecall("recall");}
    if ($input == '4'){admin_sh_menu("reinstall");}
    if ($input == '5'){restore_from_backup($in);}
    if ($input == 'r'){lets_restart($in);}
    if ($input == 'c'){node_menu($in);node_start($in);}
    if ($input == 'd'){update_core($in);}
    
    if ($input == 'h'){help();}
    if ($input == 'u'){uninstall("x");}
	if ($input == 'e'){exit1();}
    dvswitch_menu($in) ;
}
}




function exit1(){
print "
Remember PI needs to be rebooted after changes. Please use internal safe reboot. 

In case of any problems. Come back here for auto repair.
Contact me if you see any bugs so they can be fixed.
Thanks for using this software.

";
sleep(4);
die;
}


function help(){
global $node,$call,$password,$port,$stripe;
global $fileHamVoip,$path,$setupFile,$call,$password;
print"
$stripe
This software is designed to be a 1 click setup of DV switch so
that anyone can install it. At any skill level. Look for more soon.

It will autodetect your node and call if using the GMRS LIVE image.
The allstar image will require you to enter your node and call.


DV switch will work on a local lan as is but requires port forwarding
on your router to work over the internet.

1) Never place your PI in what routers call a DMZ zone.
2) Port forward port:$port to the IP of your PI.
3) Port forward in port:8088 to port 80 on your pi, if you want supermon access.
   Once setup the domain name for your pi will be
   '$node.node.gmrslive.com' or '$node.node.gmrslive.com:8088'


Please note that opening port 80 will allow bots to find your supermon
do this only if you need remote access. Port 80 gets scanned by bots regulary 
and when they find it open they will start trying to hack it with automated systems.
A better solution is to open a diffrent port like 8088 and forward that to 
port 80 on your pi, you would then access your supermon with a port number 
after the domain name like this  '$node.node.gmrslive.com:8088' 
Opening port 80 is not recomended. Bots could overload you pi. 
  
[DANGER] never port forward in ssh ports 22 or 222 because the SSH
the PI is running is not secure and known hacks exist that allow 
hackers access to your entire network on such old software.
Once in they will have access to your other computers.
Google 'ssh flaw'
So be warned dont do it.
If you do port forward SSH for help remove it right after use.

New format:
The new format fixes security problems by sending the orginating node number
with the users CALL. It is suggested on hubs. It will help identify that you
are who you say you are. Please report any problems.

UPDATE:
Rebooting during a update can nuke conf files. A new safe reboot process has been
added with a auto repair routine. Please dont turn off the power.
  
Volume:
DV switch connects direct to ast and there are no level settings in the node.
DO NOT change simple USB settings they dont control DVSWITCH. Set your levels in the app.
  
If you like this software tell your friends. WRXB288 Mike
Have many nice days !!!
$stripe
";
$line = readline("Press any key: ");
print"




































";
}
function burst($call){
global $node,$piSystem,$call;

if ($piSystem){exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$node'",$output,$return_var);}
}



function lets_restart($in){
global $node,$piSystem,$call;

$reboot=true; // for testing
print"PLEASE WAIT \n";
burst($call); sleep(3);
if ($piSystem){
// /sbin/asterisk -rx 
// /sbin/killall safe_asterisk
// /sbin/killall asterisk
// /bin/rm -f /var/run/asterisk.ctl /var/run/asterisk.pid
// /usr/sbin/safe_asterisk
$action="";
$sound="/var/lib/asterisk/sounds/restarting.gsm"; if (file_exists($sound)){$action="$action $sound";}
$sound="/var/lib/asterisk/sounds/wait-moment.gsm";if (file_exists($sound)){$action="$action $sound";}
$sound="/var/lib/asterisk/sounds/yeah.gsm";       if (file_exists($sound)){$action="$action $sound";}
$sound="/var/lib/asterisk/sounds/groovy.gsm";     if (file_exists($sound)){$action="$action $sound";}

print"talking \n";
$file ="/tmp/jingle.ul";  if (file_exists($file)){unlink($file);} 
  sleep(1);
  exec("sox $action $file",$output,$return_var);  
  exec("sudo asterisk -rx 'rpt localplay $node /tmp/jingle'",$output,$return_var);
  sleep(7);

if($reboot){
print"Rebooting system
Your terminal connection will now disconnect.....
\n";

exec("/usr/local/sbin/reboot.sh $node",$output,$return_var);die; 

   }
}
else { print "ERROR 10 this is not running on a PI\n";}

}


  
function check_backup($in){
global $iax,$rpt,$datum,$extensions,$bu1,$bu2,$bu3,$damaged1,$damaged2,$damaged3;
$bu1=false;$bu2=false; $bu3=false;
$damaged1=false;$damaged2=false;$damaged3=false;

if (filesize($extensions) === 0) { $damaged1=true;
$fileBu  = "$extensions-.bak";
if (file_exists($fileBu)){ copy($fileBu,$extensions);print"$extensions was null Restored from backup\n";}
}
if (filesize($iax) === 0) { $damaged2=true;
$fileBu  = "$iax-.bak";
if (file_exists($fileBu)){ copy($fileBu,$iax);print"$iax was null Restored from backup\n";}
}
if (filesize($rpt) === 0) { $damaged3=true;
$fileBu  = "$rpt-.bak";
if (file_exists($fileBu)){ copy($fileBu,$rpt);print"$rpt was null Restored from backup\n";}
}



$fileBu  = "$extensions-.bak";
if (file_exists($fileBu)){ $bu1=true;}
else{copy($extensions,$fileBu);print"$extensions backed up\n";} 

$fileBu  = "$iax-.bak";       
if (file_exists($fileBu)){ $bu2=true;}
else{copy($iax,$fileBu);print"$iax backed up \n";} 

$fileBu  = "$rpt-.bak";       
if (file_exists($fileBu)){ $bu3=true;}
else{copy($rpt,$fileBu);print"$rpt backed up \n";} 
}





function restore_from_backup($in){
$datum = date('m-d-Y-H:i:s');
global $iax,$datum,$extensions,$password,$rpt;
$fileEdit= "/etc/asterisk/extensions.conf";
$fileBu = "$fileEdit-.bak"; 
$fileBu2 = "$fileEdit-2.bak";
if (file_exists($fileBu)){
print "$datum Restoring $fileEdit from backup ";
copy($fileEdit,$fileBu2);unlink($fileEdit);print"-";
copy($fileBu,$fileEdit);
print"ok\n";
} 
else{print"
There is no backup for extentsions.conf
you may restore a backup from  /usr/local/etc/asterisk_tpl/extensions.conf_tpl
I can not do it because it will need to be edited. With nodenumber port and password. 
";sleep(2);}


$fileEdit= $iax; 
$fileBu = "$fileEdit-.bak";
if (file_exists($fileBu)){
print "$datum Restoring $iax from backup ";
copy($fileEdit,$fileBu2);unlink($fileEdit);print"-";
copy($fileBu,$fileEdit);
print"ok\n";
} 
else{print"
There is no backup for iax.conf
You may restore a backup from /usr/local/etc/asterisk_tpl/iax.conf_tpl
 ";sleep(2);}


// This has been commented out because we dont make any changes to rpt
// It will still do auto repair on a blank file we just wont restore
 
//$fileEdit= $rpt; 
//$fileBu = "$fileEdit-.bak";
//if (file_exists($fileBu)){
//print "$datum Restoring $rpt from backup ";
//copy($fileEdit,$fileBu2);unlink($fileEdit);print"-";
//copy($fileBu,$fileEdit);
//print"ok\n";
//} 
//else{print"
//There is no backup for rpt.conf
//You may restore a backup from /usr/local/etc/asterisk_tpl/rpt.conf_tpl
//but it will need to be edited
// ";sleep(2);} 
 
}


function edit_extensions($in){ 
global $search,$path,$fileEdit,$ok,$node,$changeall,$password;
global $fileHamVoip,$path,$setupFile,$datum;


if($in=="beta"){$thenewID="exten => $node,n,Rpt,$node|P|'$node-#{CALLERID(name)}'";}
else{$thenewID="exten => $node,n,Rpt,$node|P|#{CALLERID(name)}";}

$formated="
[dvswitch-iaxrpt] 
; Added by DVSWITCH_SETUP APP.
; DVSWITCH_setup made a back of the orginal file on $datum 
exten => $node,1,Answer
exten => $node,n,Playback,rpt/node
exten => $node,n,Saydigits(#{EXTEN:1})
exten => $node,n,Set(CALLERID(num)=0)
$thenewID
; dont make changes below this line they will be clipped. add above this block
"; $formated = str_replace('#', '$', $formated);


$datum = date('m-d-Y-H:i:s');
$ok=false;$line=""; $search= "[dvswitch-iaxrpt]";$valid=false;$validPort=false;
$fileEdit= "/etc/asterisk/extensions.conf";
if (file_exists($fileEdit)){
$fileBu = "$fileEdit-.bak"; if (!file_exists($fileBu)){copy($fileEdit,$fileBu);print"$fileEdit backed up to $fileBu";} // This creates a orginal backup
$tmpFile="$fileEdit-new.txt"; 

$fileIN= file($fileEdit);
$fileOUT = fopen($tmpFile, "w") or die ("Error $tmpFile Write falure");
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos3 = strpos("-$line", "allstarlink.org");if($pos3){$line=";$line ";}// Remove any allstar urls 
$pos = strpos("-$line", $search);if ($pos>=1){$ok=true;fwrite ($fileOUT, "$formated\n"); break;}  
fwrite ($fileOUT, "$line\n");
}

if (!$ok){ fwrite ($fileOUT, "$formated\n");}
fclose ($fileOUT);


if (file_exists($tmpFile)){unlink($fileEdit);rename ($tmpFile, $fileEdit);print"$fileEdit modified";}
else{print "ERROR 1 could not rename $tmpFile to $fileEdit  (please report)";}
 
$fileEdit="";$search="";print"\n";
}
sleep(3);
}


// Safe search for DV switch password  Uper or lowercase
function search_iax_DV($in){ 
global $node,$call,$password,$port,$iax;
global $search,$ok,$hide,$validGMRS;
global $fileHamVoip,$path,$setupFile;

$ok=false;$line=""; $validGMRS=false;
$fileEdit= $iax;

if (file_exists($fileEdit)){$fileIN= file($fileEdit);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$test = strtolower($line);
$pos2 = strpos("-$line", "register.gmrslive.com");if($pos2){$validGMRS=true;} 

$pos = strpos("-$test", "[dvswitch]"); if ($pos){$ok=true; } 
$pos = strpos("-$line", "secret="); 
  if ($pos and $ok){ 
  $u = explode("=", $line);
  $search=$u[0];$password=$u[1];
  break;
   }
  }
 }

}

// THE Main IAX editor for DVSWITCH 
function edit_iax_DV($password){ 
global $node,$call,$password,$port,$iax;
global $search,$ok,$hide,$datum;
global $fileHamVoip,$path,$setupFile;

$ok=false;$line="";  $validGMRS=false;
$fileEdit= $iax;

if (file_exists($fileEdit)){
$fileBu = "$fileEdit-.bak"; if (!file_exists($fileBu)){copy($fileEdit,$fileBu);print"$fileEdit backed up to $fileBu";} // This creates a orginal backup
$tmpFile= "$fileEdit-new.txt"; 
$fileIN= file($fileEdit);
$fileOUT = fopen($tmpFile, "w") or die ("Error $tmpFile Write falure");

// we read through looking for our tag.
// This tag should not be in a default config
// basicaly we are copying everything into a new file
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos2 = strpos("-$line", "register.gmrslive.com");if($pos2){$validGMRS=true;} 
$test = strtolower($line);
$pos = strpos("-$test", "[dvswitch]"); if ($pos){$ok=true; break;}// if found stop...  
fwrite ($fileOUT, "$line\n");
}


$line=" 
[dvswitch]
; Added by DVSWITCH_SETUP APP.
; DVSWITCH_setup made a back of the orginal file on $datum 
type=friend
context=dvswitch-iaxrpt
host=dynamic
auth=md5
secret=$password
disallow=all
allow=ulaw
transfer=no
calltokenoptional=0.0.0.0/0.0.0.0
requirecalltoken=no
; DO not add anything under this block it will be clipped. Add above this block. 
";
fwrite ($fileOUT, "$line\n");
}
fclose ($fileOUT);

if ($validGMRS){
  if (file_exists($tmpFile)){unlink($fileEdit);rename($tmpFile, $fileEdit);print"$fileEdit modified";}
  else{print "ERROR 2 could not rename $tmpFile to $fileEdit   (please report)";} 
}
else {print"ERROR 3 $filedit is not a valid gmrs file (please check setup or report)";}
$fileEdit="";$search="";
print"\n";
sleep(3);
}




// build a password (we dont use l,o,O to avoid confusion )
function getRandomString($n){
    $characters = '0123456789abcdefghijkmnpqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ';
    $randomString = '';

    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }

    return $randomString;
}


function uninstall(){
global $fileHamVoip,$path,$setupFile,$iax;
$in="";
$pathR = "$path/repo";  if(!is_dir($pathR)){ mkdir($pathR, 0755);}
clean_repo($pathR);
restore_from_backup($in);
$file="$path/dvswitch-nodeinfo.txt";if (file_exists($file)){unlink($file);}
$file1="/usr/local/sbin/firsttime/dvswitch.sh";if (file_exists($file1)){unlink($file1);}
$file2="/etc/asterisk/local/mm-software/dvswitch_setup.php";if (file_exists($file2)){unlink($file2);}
print "Software uninstalled. To reinstall go to LAGMRS.com\n";
sleep(20);
die;
}

function admin_sh_menu(){
global $fileHamVoip,$path,$setupFile;
global $release;
print "Installing into admin menu ";
$file ="/usr/local/sbin/firsttime/adm01-shell.sh";
$file2="/usr/local/sbin/firsttime/dvswitch.sh";
               
copy($file, $file2); print "-";

$formated="#/!bin/bash
#MENUFT%055%DV SWITCH Setup Program Version:$release
";

$out='
$SON
reset

php /etc/asterisk/local/mm-software/dvswitch_setup.php

exit 0
';
$out = "$formated $out";
$fileOUT = fopen($file2, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, $out);flock( $fileOUT, LOCK_UN );fclose ($fileOUT); print "-";
exec("sudo chmod +x $file2",$output,$return_var);
if (file_exists($file2)){print"<ok>\n";}
else{print"<Error>\n";}
}

//
// we check which port is in use
//
function find_port ($in){
global $port,$debug,$datum,$iax ;
global $fileHamVoip,$path,$setupFile,$password;

$port="";
$fileIN= file($iax);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", "bindport="); 
if ($pos == 1){
if($debug){print"$datum DEBUG $line\n";}
$u= explode("=",$line);
$port = $u[1]; $port= trim($port," ");
return $port;
  }
 }
} 

function create_node($in){
global $node,$call;
global $fileHamVoip,$path,$setupFile,$password;



$autotts="";
if (file_exists($fileHamVoip)){
$autotts=""; 
$fileIN= file($fileHamVoip);
foreach($fileIN as $line){
 $line = str_replace("\r", "", $line);
 $line = str_replace("\n", "", $line);
 $line = str_replace('"', "", $line);
 $pos = strpos("-$line", 'NODE1=');
 if ($pos){$u= explode("=",$line);$node=$u[1];}
 $pos2 = strpos("-$line", 'STNCALL='); 
 if ($pos2){$u= explode("=",$line);$call=$u[1];}
}
save_node($in);
}
}

function save_node($in){
global $node,$call,$password;
global $fileHamVoip,$path,$setupFile; 
if (!$password){$password = getRandomString(6);}
$fileOUT = fopen($setupFile, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$node,$call,$password, , , ,");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
}







// update module 





function update_core($in){
global $datum,$file,$path,$in,$out,$ok,$changeall,$docRouteP; 
global $file1,$call,$node,$path,$soundDbGsm;

$changeall=false;


$path  = "/etc/asterisk/local/mm-software";
print "
---------------------------------------------------------------
Module: Updater 
(c) 2023/2024 by WRXB288 lagmrs.com all rights reserved 

This will Update the package to the latest version.
IF there is no new version it will repair the install.
";

print " U) Update/install  any other key to abort!\n";
$a = readline('Enter your command: ');
if ($a <> "u"){return;}

print "--------------------------------------------------------\n";

$path  = "/etc/asterisk/local/mm-software";        
$repoURL= "https://raw.githubusercontent.com/tmastersmart/gmrs_live/main";

$pathR = "$path/repo";  if(!is_dir($pathR)){ mkdir($pathR, 0755);}
$pathB = "$path/backup";if(!is_dir($pathB)){ mkdir($pathB, 0755);}

print"Cleaning any existing repos......\n";
chdir($pathR);

clean_repo($pathR);

// no longer neeeded clean repo does it.          
$file = "$pathR/dvswitch-download.zip"; if (file_exists($file)){unlink ($file);}
$file = "$pathR/file_id.diz"; if (file_exists($file)){unlink ($file);}


 chdir($pathR);
 print "Downloading new repos ...........\n";
  exec("sudo wget $repoURL/dvswitch-download.zip",$output,$return_var);


 print "Downloading finished...........\n";
 chdir($pathR);
 if (!file_exists("$pathR/core-download.zip")){print"ERROR: no file\n";return;} 
 exec("unzip $pathR/core-download.zip",$output,$return_var);
  
     
   foreach (glob("*.php") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing php file:$path/$file "; 
    if (file_exists("$path/$file")){unlink("$path/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){
    rename ("$pathR/$file", "$path/$file");
     exec("sudo chmod +x $path/$file",$output,$return_var); 
    } 
    print"ok\n";
    }
  }
  
   foreach (glob("*.csv") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing csv file:$path/$file "; 
    if (file_exists("$path/$file")){unlink("$path/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$path/$file"); } 
    print"ok\n";
    }
  }  
 
   foreach (glob("*.txt") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing txt file:$path/$file "; 
    if (file_exists("$path/$file")){unlink("$path/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$path/$file"); } 
    print"ok\n";
    }
  }  
 
 
// reinstall the admin menus. Updates the dates
admin_sh_menu("check");



print "----\n";


}




function clean_repo($in){
chdir($in);
$files = glob($in.'/*'); 
foreach($files as $filed) {
   if($filed == '.' || $filed == '..') continue;
   if (is_file($filed)) { unlink($filed);print"del $filed\n";  }
 }
}

?>
