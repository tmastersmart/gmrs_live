<?php
// ***************************************************
// (c)2023/2024 by The Master lagmrs.com WRXB288 
//  all rights reserved
//
// v1  Beta release 6/1/24
// v1.1 Uninstall option added to menu
// v1.2 6-9-24 Changes to detect custom immages and allow manual node number and call setup

$ver="v1.5"; $release="6-26-2024";  

$line =	exec('timedatectl | grep "Time zone"'); //       Time zone: America/Chicago (CDT, -0500)
$line = str_replace(" ", "", $line);
$pos1 = strpos($line, ':');$pos2 = strpos($line, '(');
if ($pos1){  $zone   = substr($line, $pos1+1, $pos2-$pos1-1); }
else {$zone="America/Chicago";}
define('TIMEZONE', $zone);
date_default_timezone_set(TIMEZONE);
$phpzone = date_default_timezone_get(); 
$basename=basename($_SERVER['PHP_SELF']);
$phpVersion= phpversion();   
$piSystem=false;if (is_readable("/proc/device-tree/model")) {$piVersion = file_get_contents ("/proc/device-tree/model");$piSystem=true;}
else {$piVersion =	exec('uname -m -p');}
$path  = "/etc/asterisk/local/mm-software";

$iax          = "/etc/asterisk/iax.conf";
$rpi          = "/etc/asterisk/rpt.conf";
$manager      = "/etc/asterisk/manager.conf";
$logger       = "/etc/asterisk/logger.conf";
$extensions   = "/etc/asterisk/extensions.conf";
$tmpFile      = "/tmp/temp.dat";
$fileHamVoip  = "/usr/local/etc/allstar_node_info.conf";

$setupFile    = "$path/dvswitch-nodeinfo.txt";



$file=""; $in="check"; $node="";$call=""; $changeall=false; $password="";

if(!file_exists($setupFile)){create_node($in);}  
if(file_exists($setupFile)){
$line = file_get_contents($setupFile);
$u= explode(",",$line);
$node=$u[0];$call=$u[1];$password=$u[2]; 
}

if (strlen($password) < 5) { $password="";save_node($in); }

$port = find_port ("port");
$file="";

$stripe="=================================================================";

print "

______ _   _               _ _       _       _____      _                
|  _  \ | | |             (_) |     | |     /  ___|    | |               
| | | | | | | _____      ___| |_ ___| |__   \ `--.  ___| |_ _   _ _ __   
| | | | | | |/ __\ \ /\ / / | __/ __| '_ \   `--. \/ _ \ __| | | | '_ \  
| |/ /\ \_/ /\__| \ V  V /| | || (__| | | | /\__/ /  __/ |_| |_| | |_) | 
|___/  \___/ |___/ \_/\_/ |_|\__\___|_| |_| \____/ \___|\__|\__,_| .__/  
                                                                 | |     
                                                                 |_|    

$stripe 
DV Switch setup tool $ver  password:$password
CPU:$piVersion 
(c)2023/2024 by WRXB288 LAGMRS.com all rights reserved 
PHP:$phpVersion Timezone: $phpzone  Release date:$release
Made in Louisiana by Michael May
$stripe";

if (!$node or !$call){ node_menu($in); node_start($in); }
if (!$node or !$call){ exit1(); } // You entered nothing so exit

check_backup($in);
dvswitch_menu($in);
start($in);

function dvswitch_menu($in){
global $node,$call,$password,$port,$stripe;
global $fileHamVoip,$path,$setupFile,$bu1,$bu2;

if ($bu1 and $bu2){$d="(4) Install Backups reversing all changes [Backups exist]";}
else{$d="";}
print "
$stripe
(1) Install DV Switch/Reinstall 
(2) Recall your settings
(3) Repair/reinstall admin menu
$d
(5) Do a full system reboot to install changes

(b) Install using new call format (Beta test). Sends node number with your call
    for better system security. (Read help)
(c) Change the Node:[$node] or Call:[$call]

(h) Help
(u) Uninstall This software
(e) Exit
";
}




function node_menu($in){
global $node,$call,$password,$port,$stripe,$piVersion;
global $fileHamVoip,$path,$setupFile;
$out="";if (!$node or !$call){
$out="$piVersion
Node number and CALL must be entered to continue
";}
print "
$stripe
$out
    Node:[$node]  Call:[$call]
(n) Node Setup 
(c) Call Setup 

(m) Main menu
(h) Help
(u) Uninstall This software
(e) Exit
";
}

function dvswitchInstall($in){
global $node,$call,$password,$port,$stripe;
global $fileHamVoip,$path,$setupFile;
// $password = getRandomString(8);  anoying do it only once
//if($in=="beta")
edit_iax_DV($in);
edit_extensions($in);
dvswitchRecall($in) ;
burst($call);
}

function dvswitchRecall($in){
global $node,$call,$password,$port,$stripe;
global $fileHamVoip,$path,$setupFile;
$password=""; $search="?";
search_iax_DV($password);
$localIP = getHostByName(getHostName());
   $myip = exec("/bin/wget -t 1 -T 3 -q -O- http://checkip.dyndns.org:8245 |/bin/cut -d':' -f2 |/bin/cut -d' ' -f2 |/bin/cut -d'<' -f1");
$port = find_port ("port");

if ($password){
print " 
$stripe
DV-Switch is installed.
 
Be sure you enter your real FULL CALL SIGN because it will be visiable in the link.
lsnodes will show all dvswitch users from any node.
DO NOT use a HAM call and do not use just your numbers. 

Your IP is [$myip]   
Setup the DV SWitch APP as listed here.
$stripe
Protocol IAX2
Hostname '$node.node.gmrslive.com'   or on a LAN '$localIP'
Port     '$port'
Username 'DVSWITCH'  (ALL CAPS)
Password '$password'
CallerID '$call'
Caller #    
Node     '$node'

[checked]Phone mode IAX2 Connection 
[ ] Use public autentication
[ ] Autoload node

Codec Types [ulaw]
$stripe

";}
else {print"
ERROR 6  Not setup please install!
";}
}

function node_start($in){
global $node,$call,$password,$port,$stripe;
global $fileHamVoip,$path,$setupFile,$password;

$stdin = fopen('php://stdin', 'r');
$yes   = false;

while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Node edit :_";
	$input = trim(fgets($stdin));
    if ($input == 'n'){node_change($in);save_node($in);}
    if ($input == 'c'){call_change($in);save_node($in);}

    if ($input == 'r'){admin_sh_menu("reinstall");}
    if ($input == 'h'){help();}
    if ($input == 'u'){uninstall("x");}
	if ($input == 'm'){return;}    
	if ($input == 'e'){exit1();}
    node_menu($in) ;
}
}
function node_change($in){
global $node,$call,$password,$port,$stripe;
global $fileHamVoip,$path,$setupFile,$password;
$line = readline("Enter Your Node number[$node]: ");
if($line){$node=$line;}
print "\n";
}
function call_change($in){
global $node,$call,$password,$port,$stripe;
global $fileHamVoip,$path,$setupFile;
$line = readline("Enter Your Call [$call]: ");
if($line){$call=$line;}
print "\n";
}



function start($in){
global $node,$call,$password,$port,$stripe;
global $fileHamVoip,$path,$setupFile,$password;

$stdin = fopen('php://stdin', 'r');
$yes   = false;

while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Main Enter 1-2 E:_";
	$input = trim(fgets($stdin));
    if ($input == '1'){dvswitchInstall("install");}
    if ($input == 'b'){dvswitchInstall("beta");} // test install with node
    if ($input == '2'){dvswitchRecall("recall");}
    if ($input == '3'){admin_sh_menu("reinstall");}
    if ($input == '4'){restore_from_backup($in);}
    if ($input == '5'){lets_restart($in);}
    
    if ($input == 'c'){node_menu($in);node_start($in);}
    if ($input == 'r'){admin_sh_menu("reinstall");}
    if ($input == 'h'){help();}
    if ($input == 'u'){uninstall("x");}
	if ($input == 'e'){exit1();}
    dvswitch_menu($in) ;
}
}




function exit1(){
print "
Remember AST must be restarted after making changes 

DV Switch will not be able to login if you dont restart 

IN case of any problems you may restore from backup

";
sleep(4);
die;
}


function help(){
global $node,$call,$password,$port,$stripe;
global $fileHamVoip,$path,$setupFile,$call,$password;
print"
$stripe
This software is designed to be a 1 click setup of DV switch so
that anyone can install it. At any skill level. Look for more soon.

It will autodetect your node and call if usingthe GMRS LIve image
If using a allstar image you will need to manualy enter your information.


DV switch will work on a local lan as is but requires port forwarding
on your router to work over the internet.

1) Never place your PI in what routers call a DMZ zone.
2) Port forward port:$port to the IP of your PI.
3) Port forward in port:8088 to port 80 on your pi, if you want supermon access.
   Once setup the domain name for your pi will be
   '$node.node.gmrslive.com' or '$node.node.gmrslive.com:8088'


Please note that opening port 80 will allow bots to find your supermon
do this only if you need remote access. Port 80 gets scanned by bots regulary 
and when they find it open they will start trying to hack it with automated systems.
A better solution is to open a diffrent port like 8088 and forward that to 
port 80 on your pi, you would then access your supermon with a port number 
after the domain name like this  '$node.node.gmrslive.com:8088' 
Opening port 80 is not recomended. Bots could overload you pi. 
  
[DANGER] never port forward in ssh ports 22 or 222 because the SSH
the PI is running is not secure and known hacks exist that allow 
hackers access to your entire network on such old software.
Once in they will have access to your other computers.
Google 'ssh flaw'
So be warned dont do it.
If you do port forward SSH for help remove it right after use.

(beta security test)
The beta test id fixes many security problems by sending the orginating node number
With the users CALL. Will help identify that you are who you say you are.
If you would like to help test this please report any problems. 
  

If you like this software tell your friends. WRXB288 Mike
Have many nice days !!!
$stripe
";
$line = readline("Press any key: ");
print"




































";
}
function burst($call){
global $node,$piSystem,$call;

if ($piSystem){exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$node'",$output,$return_var);}
}



function lets_restart($in){
global $node,$piSystem,$call;

$reboot=true; // for testing
print"PLEASE WAIT \n";
burst($call); sleep(3);
if ($piSystem){
// /sbin/asterisk -rx 
// /sbin/killall safe_asterisk
// /sbin/killall asterisk
// /bin/rm -f /var/run/asterisk.ctl /var/run/asterisk.pid
// /usr/sbin/safe_asterisk
$action="";
$sound="/var/lib/asterisk/sounds/restarting.gsm"; if (file_exists($sound)){$action="$action $sound";}
$sound="/var/lib/asterisk/sounds/wait-moment.gsm";if (file_exists($sound)){$action="$action $sound";}
$sound="/var/lib/asterisk/sounds/yeah.gsm";       if (file_exists($sound)){$action="$action $sound";}
$sound="/var/lib/asterisk/sounds/groovy.gsm";     if (file_exists($sound)){$action="$action $sound";}

print"talking \n";
$file ="/tmp/jingle.ul";  if (file_exists($file)){unlink($file);} 
  sleep(1);
  exec("sox $action $file",$output,$return_var);  
  exec("sudo asterisk -rx 'rpt localplay $node /tmp/jingle'",$output,$return_var);
  sleep(7);

if($reboot){
print"Rebooting system
Your terminal connection will now disconnect.....
\n";

exec("/usr/local/sbin/reboot.sh",$output,$return_var);die; 

   }
}
else { print "ERROR 10 this is not running on a PI\n";}

}



function check_backup($in){
global $iax,$datum,$extensions,$bu1,$bu2;
$bu1=false;$bu2=false;
$fileBu  = "$extensions-.bak";if (file_exists($fileBu)){ $bu1=true;}
$fileBu  = "$iax-.bak";       if (file_exists($fileBu)){ $bu2=true;}
}




function restore_from_backup($in){
$datum = date('m-d-Y-H:i:s');
global $iax,$datum,$extensions,$password;
$fileEdit= "/etc/asterisk/extensions.conf";
$fileBu = "$fileEdit-.bak"; 
$fileBu2 = "$fileEdit-2.bak";
if (file_exists($fileBu)){
print "$datum Restoring $fileEdit from backup ";
copy($fileEdit,$fileBu2);unlink($fileEdit);print"-";
copy($fileBu,$fileEdit);
print"ok\n";
} 
else{print"
There is no backup for extentsions.conf
you may restore a backup from  /usr/local/etc/asterisk_tpl/extensions.conf_tpl
I can not do it because it will need to be edited. With nodenumber port and password. 
";sleep(2);}


$fileEdit= $iax; 
$fileBu = "$fileEdit-.bak";
if (file_exists($fileBu)){
print "$datum Restoring $iax from backup ";
copy($fileEdit,$fileBu2);unlink($fileEdit);print"-";
copy($fileBu,$fileEdit);
print"ok\n";
} 
else{print"
There is no backup for iax.conf
You may restore a backup from /usr/local/etc/asterisk_tpl/iax.conf_tpl
 ";sleep(2);}

}


function edit_extensions($in){ 
global $search,$path,$fileEdit,$ok,$node,$changeall,$password;
global $fileHamVoip,$path,$setupFile,$datum;

if($in=="beta"){$thenewID="exten => $node,n,Rpt,$node|P|$node,#{CALLERID(name)}";}
else{$thenewID="exten => $node,n,Rpt,$node|P|#{CALLERID(name)}";}

$formated="
; Added by DVSWITCH_SETUP APP if you need to make changes make them above this line.
; DVSWITCH_setup made a back of the orginal file on $datum 
[dvswitch-iaxrpt]  
exten => $node,1,Answer
exten => $node,n,Playback,rpt/node
exten => $node,n,Saydigits(#{EXTEN:1})
exten => $node,n,Set(CALLERID(num)=0)
$thenewID
; dont make changes below this line they will be clipped
"; $formated = str_replace('#', '$', $formated);


$datum = date('m-d-Y-H:i:s');
$ok=false;$line=""; $search= "[dvswitch-iaxrpt]";$valid=false;$validPort=false;
$fileEdit= "/etc/asterisk/extensions.conf";
if (file_exists($fileEdit)){
$fileBu = "$fileEdit-.bak"; if (!file_exists($fileBu)){copy($fileEdit,$fileBu);print"$fileEdit backed up to $fileBu";} // This creates a orginal backup
$tmpFile="$fileEdit-new.txt"; 

$fileIN= file($fileEdit);
$fileOUT = fopen($tmpFile, "w") or die ("Error $tmpFile Write falure");
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos3 = strpos("-$line", "allstarlink.org");if($pos3){$line=";$line ";}// Remove any allstar urls 
$pos = strpos("-$line", $search);if ($pos>=1){$ok=true;fwrite ($fileOUT, "$formated\n"); break;}  
fwrite ($fileOUT, "$line\n");
}

if (!$ok){ fwrite ($fileOUT, "$formated\n");}
fclose ($fileOUT);


if (file_exists($tmpFile)){unlink($fileEdit);rename ($tmpFile, $fileEdit);print"$fileEdit modified";}
else{print "ERROR 1 could not rename $tmpFile to $fileEdit  (please report)";}
 
$fileEdit="";$search="";print"\n";
}
}


// Safe search for DV switch password
function search_iax_DV($in){ 
global $node,$call,$password,$port,$iax;
global $search,$ok,$hide,$validGMRS;
global $fileHamVoip,$path,$setupFile;

$ok=false;$line=""; $validGMRS=false;
$fileEdit= $iax;

if (file_exists($fileEdit)){$fileIN= file($fileEdit);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos2 = strpos("-$line", "register.gmrslive.com");if($pos2){$validGMRS=true;} 

$pos = strpos("-$line", "[DVSWITCH]"); if ($pos){$ok=true; } 
$pos = strpos("-$line", "secret="); 
  if ($pos and $ok){ 
  $u = explode("=", $line);
  $search=$u[0];$password=$u[1];
  break;
   }
  }
 }

}

// THE Main IAX editor for DVSWITCH 
function edit_iax_DV($password){ 
global $node,$call,$password,$port,$iax;
global $search,$ok,$hide,$datum;
global $fileHamVoip,$path,$setupFile;

$ok=false;$line="";  $validGMRS=false;
$fileEdit= $iax;

if (file_exists($fileEdit)){
$fileBu = "$fileEdit-.bak"; if (!file_exists($fileBu)){copy($fileEdit,$fileBu);print"$fileEdit backed up to $fileBu";} // This creates a orginal backup
$tmpFile= "$fileEdit-new.txt"; 
$fileIN= file($fileEdit);
$fileOUT = fopen($tmpFile, "w") or die ("Error $tmpFile Write falure");

// we read through looking for our tag.
// This tag should not be in a default config
// basicaly we are copying everything into a new file
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos2 = strpos("-$line", "register.gmrslive.com");if($pos2){$validGMRS=true;} 
$pos = strpos("-$line", "[DVSWITCH]"); if ($pos){$ok=true; break;}// if found stop...  
fwrite ($fileOUT, "$line\n");
}


$line="
; Added by DVSWITCH_SETUP APP if you need to make changes make them above this line.
; DVSWITCH_setup made a back of the orginal file on $datum 
[DVSWITCH]
type=friend
context=dvswitch-iaxrpt
host=dynamic
auth=md5
secret=$password
disallow=all
allow=ulaw
transfer=no
calltokenoptional=0.0.0.0/0.0.0.0
requirecalltoken=no
; DO not add anything under this line it will be clipped 
";
fwrite ($fileOUT, "$line\n");
}
fclose ($fileOUT);

if ($validGMRS){
  if (file_exists($tmpFile)){unlink($fileEdit);rename($tmpFile, $fileEdit);print"$fileEdit modified";}
  else{print "ERROR 2 could not rename $tmpFile to $fileEdit   (please report)";} 
}
else {print"ERROR 3 $filedit is not a valid gmrs file (please check setup or report)";}
$fileEdit="";$search="";
print"\n";
}




// build a password
function getRandomString($n){
    $characters = '0123456789abcdefghijklmnpqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ';
    $randomString = '';

    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }

    return $randomString;
}


function uninstall(){
global $fileHamVoip,$path,$setupFile,$iax;

restore_from_backup($in);
$file="$path/mm-node.txt";if (file_exists($file)){unlink($file);}
$file1="/usr/local/sbin/firsttime/dvswitch.sh";if (file_exists($file1)){unlink($file1);}
$file2="/etc/asterisk/local/mm-software/dvswitch_setup.php";if (file_exists($file2)){unlink($file2);}
print "Software uninstalled. To reinstall go to LAGMRS.com\n";
sleep(20);
die;
}

function admin_sh_menu(){
global $fileHamVoip,$path,$setupFile;
global $release;
print "Installing into admin menu ";
$file ="/usr/local/sbin/firsttime/adm01-shell.sh";
$file2="/usr/local/sbin/firsttime/dvswitch.sh";
               
copy($file, $file2); print "-";

$formated="#/!bin/bash
#MENUFT%055%DV SWITCH Setup Program Version:$release
";

$out='
$SON
reset

php /etc/asterisk/local/mm-software/dvswitch_setup.php

exit 0
';
$out = "$formated $out";
$fileOUT = fopen($file2, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, $out);flock( $fileOUT, LOCK_UN );fclose ($fileOUT); print "-";
exec("sudo chmod +x $file2",$output,$return_var);
if (file_exists($file2)){print"<ok>\n";}
else{print"<Error>\n";}
}

//
// we check which port is in use
//
function find_port ($in){
global $port,$debug,$datum,$iax ;
global $fileHamVoip,$path,$setupFile,$password;

$port="";
$fileIN= file($iax);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", "bindport="); 
if ($pos == 1){
if($debug){print"$datum DEBUG $line\n";}
$u= explode("=",$line);
$port = $u[1]; $port= trim($port," ");
return $port;
  }
 }
} 

function create_node($in){
global $node,$call;
global $fileHamVoip,$path,$setupFile,$password;



$autotts="";
if (file_exists($fileHamVoip)){
$autotts=""; 
$fileIN= file($fileHamVoip);
foreach($fileIN as $line){
 $line = str_replace("\r", "", $line);
 $line = str_replace("\n", "", $line);
 $line = str_replace('"', "", $line);
 $pos = strpos("-$line", 'NODE1=');
 if ($pos){$u= explode("=",$line);$node=$u[1];}
 $pos2 = strpos("-$line", 'STNCALL='); 
 if ($pos2){$u= explode("=",$line);$call=$u[1];}
}
save_node($in);
}
}

function save_node($in){
global $node,$call,$password;
global $fileHamVoip,$path,$setupFile; 
if (!$password){$password = getRandomString(6);}
$fileOUT = fopen($setupFile, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$node,$call,$password, , , ,");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
}


?>
