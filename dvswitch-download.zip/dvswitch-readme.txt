GMRS Dv Switch setup tool
(c) 2024/2025 all rights reserved by lagmrs.com
 

This tool is now included in the full image




download the installer.
Drop to a shell
type
cd /tmp
sudo wget https://raw.githubusercontent.com/tmastersmart/gmrs_live/main/install-dvswitch.php



This software is designed to do 1 click installs of DV switch

Contact lagmrs.com for mor info or help



