#!/usr/bin/php
<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//$ver="v1";  // 08/02/2023

function tagline($tagline){
global $path,$tagline;
//===================================================
//GMRSLive old 1991 tagline reader
//
//Silley Little Mail Reader taglines (c)1991
//===================================================

$file="$path/taglines.txt";
srand (time (0));
if (file_exists($file)){
$fileIN= file($file); $count=0;
foreach($fileIN as $line){$count++;} 
$random = mt_rand(1, $count);
$fileIN= file($file); $i=0;
foreach($fileIN as $line){
$i++; 
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $line = str_replace("�", "'", $line); // dos font artifact convert to new       
if ($i==$random){print "* SLMR v2.1 * $line";}                               
 }
}

else {print"ERROR cant file $file\n";}
}
?>

