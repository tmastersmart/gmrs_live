<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//v1   08/02/2023
//v1.1 10/26/23 
//v1.2 12/31/23  Better stripping for ansi art
//v1.3 1/25/24 Again a new ANSI art striping routine
//
// back in the 90s SLMRv2.1a was a QWK BBS mailreader. 
// https://bbs.mythicalkingdom.com/sbbs/data/dirs/bbsoffli/slmr21a.zip
// Taglines are from QWK mailreaders we used to copy and reuse others taglines.
// My tagline was 'Have many nice days.' 
//
function tagline($tagline){
global $path,$tagline;
//===================================================
//GMRSLive old 1991 tagline reader
//
//Silley Little Mail Reader taglines (c)1991
//===================================================

$file="$path/taglines.txt";
srand (time (0));
if (file_exists($file)){
$fileIN= file($file); $count=0;
foreach($fileIN as $line){$count++;} 
$random = mt_rand(1, $count);
$fileIN= file($file); $i=0; $regex = "/[^a-zA-Z0-9~!@ #$%^&*()_+\/]+/";
foreach($fileIN as $line){
$i++; 
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $line = str_replace("�", "'", $line); // dos font artifact convert to new 
  $line = preg_replace($regex, '', $line);
//$line = preg_replace('/[\x00-\x1F\x7F-\xFF]/', '', $line); // 7 bit
//  $line = preg_replace('/[\x00-\x1F\x7F]/', '', $line);// 8 bit extended ASCII?
//$line = preg_replace('/[\x00-\x1F\x7F]/u', '', $line);// utf8
//$chr=chr(254);
  $chr="*";
  if ($i==$random){print "$chr SLMR v2.1a $chr \"$line\"";}                               
 }
}

else {print"error no file\n";}
$line=""; $file=""; $fileIN=""; // stop leaking
}
?>

