<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
// Blipverts is copyright 1995 by M&M BBS Software
//Was part of my commodore c64 bbs system 
//
// CORE advertisment system. Beta
//
// v1.1 02/11/2024  BlipVerts anounce system.
// v1.2 3/15 
// v1.5 5/24/24  Adjustments to friday net alert

$roadkillNationwide=true;

$ver="v1.5";$release = "05/24/2024";
$path="/etc/asterisk/local/mm-software"; 
include_once ("$path/load.php");
include_once ("$path/sound_db.php");
$phpVersion= phpversion();
$datum = date('m-d-Y-H:i:s');$day =date("l");//$day ="Friday";
$out="";  
if(!isset($roadkillNationwide)){$roadkillNationwide=false;}
if(!isset($roadkillLouisiana)) {$roadkillLouisiana=false;}
if(!isset($emergencyHub))      {$emergencyHub=false;}
print "
===================================================
Blipverts  $coreVersion $ver 
(c) 2024 by WRXB288 LAGMRS.com all rights reserved 
$phpzone PHP $phpVersion    Release date:$release
Today is $day Node $node
===================================================\n";
chdir($path);

$file = "/tmp/jingle.gsm";if(file_exists($file)){unlink($file);}
$flag = "/tmp/blipverts.txt";// if(file_exists($flag)){unlink($flag);}

$note="";
if(file_exists($flag)){   
$ft = time()-filemtime($flag);$minutes = floor($ft / 60); $note="$minutes mins since last play"; 
if ($ft > 20 * 60) {unlink($flag);$note="$minutes mins since last play. Ready to play.";} // 20 min
//if ($ft > 1 * 3600){unlink($flag);} // 1 hrs
}
if($blipVerts and !file_exists ($flag)){ 
  $min  = date('i'); //$min=30;
  print"$datum BlipVerts:TRUE ($min min) ";
  if($min >=20 and $min <=50){
 //    $randomS = mt_rand(1, 9);
     $action=""; 
     $seconds = mt_rand(10, 19);// wait for cap 
     print"Playing BlipVert in $seconds second(s)\n"; sleep($seconds);

  
if ($roadkillNationwide or $roadkillLouisiana ){
  if($day =="Friday" ){
  $randomS = mt_rand(1, 6);
    if ($randomS==1){check_gsm_db("roadnet1");if($file1){$action = "$action $file1";}} 
    if ($randomS==2){check_gsm_db("roadnet2");if($file1){$action = "$action $file1";}}
    if ($randomS==3){check_gsm_db("roadnet3");if($file1){$action = "$action $file1";}} 
    if ($randomS==4){check_gsm_db("roadnet4");if($file1){$action = "$action $file1";}}
    if ($randomS==5){check_gsm_db("roadkill1");if($file1){$action = "$action $file1";}} 
    if ($randomS==6){check_gsm_db("roadkill2");if($file1){$action = "$action $file1";}}
    if ($randomS==7){check_gsm_db("roadkill3");if($file1){$action = "$action $file1";}} 
    if ($randomS==8){check_gsm_db("roadkill4");if($file1){$action = "$action $file1";}}
    if ($randomS==9){check_gsm_db("gmrs_live2");if($file1){$action = "$action $file1";}}
    print"Playing BlipVert NET Roadkill: $randomS $action\n";
}
else{
 $randomS = mt_rand(1, 5);
 if ($randomS==1){check_gsm_db("roadkill1");if($file1){$action = "$action $file1";}} 
 if ($randomS==2){check_gsm_db("roadkill2");if($file1){$action = "$action $file1";}}
 if ($randomS==3){check_gsm_db("roadkill3");if($file1){$action = "$action $file1";}} 
 if ($randomS==4){check_gsm_db("roadkill4");if($file1){$action = "$action $file1";}}
 if ($randomS==5){check_gsm_db("gmrs_live2");if($file1){$action = "$action $file1";}}
print"Playing BlipVert roadkill: $randomS $action\n";
 }
}
  
else{
// if we are not on roadkill
$randomS = mt_rand(1, 4);
if ($randomS==1){check_gsm_db("gmrs_live1");if($file1){$action = "$action $file1";}} 
if ($randomS==2){check_gsm_db("gmrs_live2");if($file1){$action = "$action $file1";}}
if ($randomS==3){check_gsm_db("gmrs_live3");if($file1){$action = "$action $file1";}}
print"Playing BlipVert: $randomS $action\n";
}
     check_gsm_db("silence1"); if($file1){$action = "$action $file1";}// just add padding
  
     exec("sox $action $file",$output,$return_var); if($debug){print "DEBUG:$action";} 
     exec("sudo asterisk -rx 'rpt localplay $node /tmp/jingle'",$output,$return_var);
     $fileOUT = fopen($flag, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,played jingle\n");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
    } //30 min
   else {print" Skipping Wrong time\n";}
}
else {print"$datum  BlipVerts:SKIP - $note\n";}
 
print "===================================================\n";

?>
