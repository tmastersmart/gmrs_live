<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
// Blipverts is copyright 1995 by M&M BBS Software
//Was part of my commodore c64 bbs system 
//
// CORE advertisment system. 
//
// v1.1 02/11/2024  BlipVerts anounce system.
// v1.2 3/15 
// v1.5 5/24/24  Adjustments to friday net alert
// v1.6 6/20/24 Bugs when on standard gmrs live fixed
// v1.7 7/1/24 cron support added to force playing
// v1.8 8/26/24  
// v1.9 2/25 new release for node image
// v2   3/8/25 Moving flags 
// v2.1 3/22/25 bug fix

$ver="v2.1";$release = "03/22/2025"; 
$cron=false;$min  = date('i');
if (!empty($argv[1])) {  if ($argv[1] =="cron"){$cron=true;$min=30;} }// force itto play

$path="/etc/asterisk/local/mm-software"; 
include_once ("$path/load.php");
include_once ("$path/sound_db.php");
$phpVersion= phpversion();
$datum = date('m-d-Y-H:i:s');
$day = strtolower(date('l'));
$out="";  
if(!isset($emergencyHub))      {$emergencyHub=false;}
print "
===================================================
Blipverts  $coreVersion $ver 
(c) 2024/2025 by WRXB288 LAGMRS.com all rights reserved 
$phpzone PHP $phpVersion    Release date:$release
Today is $day Node $node
===================================================\n";
chdir($path);

$file = "/tmp/jingle.gsm";if(file_exists($file)){unlink($file);}

// move flag to support through reboots
$pathFlag="/etc/asterisk/local";
$flag = "$pathFlag/blipverts-flag.txt"; 
//if(file_exists($flag)){unlink($flag);} // uncomment for testing 

$note="";$holdtime=60;
if(file_exists($flag)){   
$ft = time()-filemtime($flag);$minutes = floor($ft / $holdtime); $note="$minutes mins since last play"; 
if ($ft > 120 * $holdtime or $cron) {unlink($flag);$note="$minutes mins since last play. Ready to play.";} 
//if ($ft > 1 * 3600){unlink($flag);} // 1 hrs
}


if($blipVerts and !file_exists ($flag)){ 
 // $min  = date('i'); //$min=30;
  print"$datum BlipVerts:TRUE ($min min)\n";
  if($min >=20 and $min <=50){
   $action="";$seconds = mt_rand(9, 20);  
   print"$datum Playing BlipVert in $seconds second(s)\n"; sleep($seconds);
 
   check_wav_db ("light click");if($file1){$action = "$action $file1";}    
   $hour = date('H');$day  = date('l');$hr =   date('h');$min  = date('i'); 
   $randomS = mt_rand(1, 2);
   
   if ($randomS==1){check_gsm_db("gmrshub1");if($file1){$action = "$action $file1";}} 
   if ($randomS==2){check_gsm_db("gmrshub2");if($file1){$action = "$action $file1";}}  
   
   


  
print"$datum Playing BlipVert: $randomS \n"; 
if($debug){print "$datum DEBUG:$action\n";}
//}
//     check_gsm_db("silence1"); if($file1){$action = "$action $file1";}// just add padding
     exec("sox $action $file",$output,$return_var);  
     exec("sudo asterisk -rx 'rpt localplay $node /tmp/jingle'",$output,$return_var);
     $fileOUT = fopen($flag, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,played jingle,$action\n");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
    } //30 min
}
   else {
     if(file_exists($flag)){print"$datum  on HOLD already played\n";} 
     else{print"$datum  Skipping Wrong time ($min min)\n";}
     
     }


 
print "===================================================\n";

?>

