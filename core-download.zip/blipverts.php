<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
// Blipverts is copyright 1995 by M&M BBS Software
//Was part of my commodore c64 bbs system 
//
// CORE advertisment system. Beta
//
// v1.1 02/11/2024  BlipVerts anounce system.

 
$ver="v1.1";$release = "02/11/2024";
$path="/etc/asterisk/local/mm-software"; 
include_once ("$path/load.php");
include_once ("$path/sound_db.php");
$phpVersion= phpversion();
$datum = date('m-d-Y-H:i:s');
$out="";  
if(!isset($roadkillNationwide)){$roadkillNationwide=false;}
if(!isset($roadkillLouisiana)) {$roadkillLouisiana=false;}
if(!isset($emergencyHub))      {$emergencyHub=false;}
print "
===================================================
Blipverts  $coreVersion $ver 
(c) 2024 by WRXB288 LAGMRS.com all rights reserved 
$phpzone PHP $phpVersion    Release date:$release
===================================================\n";
chdir($path);

$file = "/tmp/jingle.gsm";if(file_exists($file)){unlink($file);}
$flag = "/tmp/blipverts.txt"; //if(file_exists($flag)){unlink($flag);}

if(file_exists($flag)){   $ft = time()-filemtime($flag); if ($ft > 2 * 3600){unlink($flag);}} // 2 hrs
if($blipVerts and !file_exists ($flag)){ 
  $min  = date('i'); 
  print"$datum BlipVerts =TRUE($min min) ";
  if($min >=25 and $min <=40){
     $randomS = mt_rand(1, 3);$action="";  
     $seconds = mt_rand(10, 19);// wait for cap 
     print"Playing BlipVert in $seconds second(s)\n"; sleep($seconds);
if ($roadkillNationwide or $roadkillLouisiana ){
print"Playing BlipVert: Roadkill$randomS \n";
if ($randomS==1){check_gsm_db("roadkill1");if($file1){$action = "$action $file1";}} 
if ($randomS==2){check_gsm_db("roadkill2");if($file1){$action = "$action $file1";}}
if ($randomS==3){check_gsm_db("gmrs_live2");if($file1){$action = "$action $file1";}}
}
else{
print"Playing BlipVert: gmrs_live_jingle$randomS \n";
if ($randomS==1){check_gsm_db("gmrs_live1");if($file1){$action = "$action $file1";}} 
if ($randomS==2){check_gsm_db("gmrs_live2");if($file1){$action = "$action $file1";}}
if ($randomS==3){check_gsm_db("gmrs_live3");if($file1){$action = "$action $file1";}}
}
     
     exec("sox $action $file",$output,$return_var); if($debug){print "DEBUG:$action";} 
     exec("sudo asterisk -rx 'rpt localplay $node /tmp/jingle'",$output,$return_var);
     $fileOUT = fopen($flag, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,played jingle\n");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
    } //30 min
   else {print" Skipping Wrong time\n";}
}
else {print"$datum BlipVerts = FALSE\n";}
 
print "===================================================\n";

?>
