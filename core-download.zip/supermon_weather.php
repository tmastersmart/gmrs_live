<?php
// (c)2023 by WRXB288 and LAgmrs.com  
// Import this into link.php on supermon
// added conditions by WRXB288
// v1.1 8/10/23
// v1.2 9/22/23  version check and error checking into comments lines

$path="/etc/asterisk/local/mm-software";
include_once ("$path/load.php");

$ver ="v1.2 09/22/2023";

$copyrightcall="WRXB288";
$conditions="/tmp/conditions.txt";
$skywarn   ="/tmp/skywarn.txt";
$forcast   ="/tmp/forcast.txt";
$icons     ="/tmp/forcast_icons.txt"; 
$forcastWeekFile="/tmp/forcast_week.txt";
$alertTxtHeadline ="/tmp/skywarn_headline.txt";

print "\n<!-- Start Weather by $copyrightcall $coreVersion $ver----->\n";


if (file_exists($conditions)) {
print "\n<!-- conditions -->\n";
  $d = file_get_contents ($conditions); $size= filesize($conditions);   if ($size >=5){
    print "<p style='margin-top:0px;'> Local Weather conditions: [";
    print "<span style='margin-top:0px; background-color: GAINSBORO;'>&nbsp;<small>$d</small>&nbsp;</span>]";
 }             
}
else{print"<!-- $conditions file missing -->\n";}


if (file_exists($skywarn)) { 
print "\n<!-- Warning in progress -->\n";
  $d = file_get_contents ($skywarn);$size= filesize($skywarn);   if ($size >=5){
  print "<span style=\"color: red;\"><br><b>Alert(s): [$d]</b></span>";
} 

if (file_exists($alertTxtHeadline)) {
 $d = file_get_contents ($alertTxtHeadline);
 print"<br>";
 $u= explode(",",$d);
 foreach($u as $line){
 print "<small>$line</small><br>";
 }
 }
}
else{print"\n<!-- No Warnings -->\n";}


//  $shortForcast,$detailedForecast,$icon

if (file_exists($forcast)) { 
  print "\n<!-- Forcast -->\n";
  $d = file_get_contents ($forcast); $size= filesize($forcast);  if ($size >=9){
  $u = explode("|",$d);
  print "<br><img src='$u[2]' width=20 height=20><small>Forcast:[$u[1]]</small>
  ";
} 
}
else{print"<!-- $forcast file missing -->\n";}


// The icon block 
if (file_exists($icons)) {
print "\n<!-- icon table -->\n";
// Load the descriptions
 if (file_exists($forcastWeekFile)) {
  $f = file_get_contents ($forcastWeekFile);
  $size= filesize($forcastWeekFile);
  $fc= explode("|",$f);//print "<p>$f</p>"; 
 }

$d = file_get_contents ($icons); 
$size= filesize($icons);  
if ($size >=9){
 print "<table border=0 cellpadding=5 cellspacing=5 style='border-collapse: collapse' id=forcast><tr>\n";
  $u= explode("|",$d); $i=0;//$i=count($d);
  foreach($u as $line){
  $dateF = strtotime("+$i day");
  $day = date('D j', $dateF);
  if ($i==0){$day="Today";}
  if ($i==1){$day="Tomorow";}
  print"<td><div title='$fc[$i]'><img src='$line' width=40 height=40 alt='$i'/></div><small>$day</small></td>\n"; // will be over 7
  $i++;
 }
 print "</tr></table>\n"; 
 }
}
else{print"\n<!-- $icons file missing -->\n";}


$verTest="$path/version.txt";
if (is_readable($verTest)) {
 $fileIN= file($verTest);
 foreach($fileIN as $line){
 $u = explode(",",$line);   
  if($coreVersion < $u[0]){print "<p>Please run Update. You are running $coreVersion and version has been released $u[0] on $u[1]<p>";} 
 }
}


print "<!-- END Weather by $copyrightcall $coreVersion $ver----->\n";

?>

