<?php
// (c)2023 by WRXB288 and LAgmrs.com  
// Import this into link.php on supermon
// added conditions by WRXB288
// v1.1 8/10/23
// v1.2 9/22/23  version check and error checking into comments lines
// v1.3 9/27/23 Day names added since NWS file is fluid and is not always 7 days.
// v1.4 11/30/23 Word wrapping for long forcast
// v1.5 12/18/23 Forcast icon block off option
// v1.6 12/28/23 Backup forcast added when API goes down
// v1.7 1/15/24  Actual temp data now used to set colors.
// v1.9 1/17/24 update to html
// v2.0 1/24 Fixed Style problem with weather 
// v2.1 1/25  Swaped load to supermon_load
// v2.3 6/20/24  Weather service broke the URL. This autofixes it  


$path="/etc/asterisk/local/mm-software";
include_once ("$path/supermon_load_setup.php");
$ver ="v2.3" ;

$copyrightcall="WRXB288";
//$conditions="/tmp/conditions.txt";
$currentTxt     ="/tmp/current.txt";
$skywarn   ="/tmp/skywarn.txt";
$forcast   ="/tmp/forcast.txt";
$alertTxtHeadline    ="/tmp/skywarn_headline.txt";
$alertTxtDescription ="/tmp/skywarn_description.txt"; 
$forcastIcons    ="/tmp/forcast_icons.txt";
$forcastWeekFile ="/tmp/forcast_week.txt";
$nameWeekFile    ="/tmp/forcast_name.txt";

print "\n<!-- Start Weather by $copyrightcall $ver----->\n";
print "<table border=0 class=weather id=table_weather>
<tr><td align=center >
";



// Read new raw weather file.
//$datum,$the_temp,$heatIndex,$WindChill,$feelsLike,$dewpoint,$outhumi,$avgwind,$rainofdaily,$barometricPressure,$rainofyearly,$uv,$solarradiation,$cond1,$gustspeed,$rainofmonthly,$maxdailygust
//01-27-2024-12:26:06, 53.4 ,,,           53.4 ,     52 ,     95 ,     1.57 ,   0.15 ,       30.01 ,             9.65 ,        1 ,  61.18 ,        cloudy,4.92 ,     9.65 ,
//<!-- RAW weather: 01-27-2024-23:57:26,48,,,48,45.5,91,0,0.15,30.16,9.65,0,0, mostly cloudy,2.46,9.65,20.13,Packton La Temp:48 Dew:45.5 hum:91% Rain:0.15 Pres:30.16 in,Packton La,,,, -->
if (file_exists($currentTxt)) {
   $fileIN= file($currentTxt);
   foreach($fileIN as $line){
$u = explode(",",$line);
 $line = str_replace("\r", "", $line);
 $line = str_replace("\n", "", $line);
print "\n<!-- RAW weather: $line -->\n";

for ($i = 1; $i <= 20; $i++) {if (!isset($u[$i])) {$u[$i] = "";}}

$update=$u[0];
$the_temp =$u[1]; $heatIndex=$u[2];$WindChill=$u[3];$feelsLike=$u[4];$dewpoint= $u[5];
$outhumi  =$u[6];$barometricPressure=$u[9];
$avgwind  =$u[7];$maxdailygust=$u[16];$gustspeed=$u[14];
$rainofdaily=$u[8];$rainofmonthly =$u[15];$rainofyearly =$u[10];
$uv =$u[11];$solarradiation=$u[12];
$cond1=$u[13];$condWX=$u[17];$Station=$u[18];     
break;}

// set internal auto adjusting css
$bgColor="#90EE90";$bgAlerts="red";$fColor ="white";

$Alertsdec_font  = "DarkRed";  $Alertsdec_bg ="clear";
$AlertsHead_font = "FireBrick";$AlertsHead_bg="clear";
$bgColorForcast="#FFFFE0";

if ($the_temp<=32) {$bgColor="#ADD8E6";$bgAlerts="blue";$fColor ="white";$Alertsdec_font = "blue"; $Alertsdec_bg="clear";$AlertsHead_font = "DarkBlue";$AlertsHead_bg="clear";}
if ($the_temp>=90) {$bgColor="#FF8000";$bgAlerts="red"; $fColor ="white";$Alertsdec_font = "DarkRed"; $Alertsdec_bg="clear";}
if ($the_temp>=100){$bgColor="#E10000";$bgAlerts="red"; $fColor ="white";$Alertsdec_font = "DarkRed"; $Alertsdec_bg="clear";}


//if ($levelDew and $dewpoint) {$status="$status Dew:$dewpoint";}


$status="";
//if ($Station){  $status="$Station -";}
if ($the_temp){ $status="$status Temp:$the_temp";}
//if ($heatIndex){$status="$status Heat Index:$heatIndex";}
//if ($WindChill){$status="$status WindChill:$WindChill";}
if ($dewpoint) {$status="$status Dew:$dewpoint";}
if ($outhumi){  $status="$status Hum:$outhumi";}
if ($avgwind){  $status="$status Wind:$avgwind";}
if ($gustspeed){  $status="$status Gust:$gustspeed";}
if ($maxdailygust){  $status="$status MaxGust:$maxdailygust";}
if ($rainofdaily) {$status="$status Rain:$rainofdaily";}
if ($barometricPressure) {$status="$status Press:$barometricPressure";} 
if ($uv) {$status="$status UVI:$uv";} 
if ($solarradiation) {$status="$status Solar:$solarradiation";} 
//if ($cond1) {$status="$status $cond1";} 

$status2="Last Update:$update"; // Alt text mouse over
//if ($Station){  $status2="$status2 $Station -";}
if ($the_temp){$status2="$status2 Temperature:$the_temp";}
if ($heatIndex){$status2="$status2 Heat Index:$heatIndex";}
if ($WindChill){$status2="$status2 WindChill:$WindChill";}
if ($dewpoint) {$status2="$status2 Dewpoint:$dewpoint";}
if ($outhumi){  $status2="$status2 Humidity:$outhumi";}
if ($avgwind){  $status2="$status2 Avg Wind:$avgwind";}
if ($gustspeed){  $status2="$status2 Curent Gust:$gustspeed";}
if ($maxdailygust){  $status2="$status2 Max Daily Gust:$maxdailygust";}
if ($rainofdaily) {$status2="$status2 Rain Daily:$rainofdaily";}
if ($rainofmonthly) {$status2="$status2 Rain Monthly:$rainofmonthly";}
if ($rainofyearly) {$status2="$status2 Rain Yearly:$rainofyearly";}
if ($barometricPressure) {$status2="$status2 Pressure:$barometricPressure";} 
if ($uv) {$status2="$status2 UVI:$uv";} 
if ($solarradiation) {$status2="$status2 Solar Radiation:$solarradiation";} 
if ($cond1) {$status2="$status2 Conditions:$cond1";} 

if ($status){ 
// [ La Temp:53.4 Dew:52 hum:95% Wind:1.57 Rain:0.15 Preasure:30.01 in UV Index:1 Solar:61.18 cloudy]

$len = strlen($string); //$adate = substr($u[0], 0,10);
print "

<div title='$status2'> $cond1 [<span style='margin-top:0px; background-color: $bgColor;'>$status</span>]</div>


";
 }             
}
else {print "
<p>Weather file missing check html for eror codes</p>

<!-- RAW weather missing 
Notice if PrivateTmp=true is set the server cant see the tmp directory
and looks in a diffrent private tmp directory.

edit /etc/systemd/system/multi-user.target.wants/apache2.service   and comment out  #PrivateTmp=true
Restart systemd: sudo systemctl daemon-reload
Restart apache: sudo systemctl restart apache2 -->

";}




if (file_exists($skywarn)) { 
print "\n<!-- Warning exists -->\n";
$d = file_get_contents ($skywarn);//$size= filesize($skywarn);
print "
</td></tr><tr><td align=center>
<span style=\"color: $fColor; background-color: $bgAlerts;\"><b>Alert(s): [$d]</b></span><br>"; 

if (file_exists($alertTxtHeadline)) {
 $d = file_get_contents ($alertTxtHeadline);
 $u= explode(",",$d);

print"</td></tr><tr><td align=left>";
 $count=0;
 print "<span style=\"color: $AlertsHead_font; background-color: $AlertsHead_bg; justify-content: left;\"><b>";
 foreach($u as $line){
   $line = str_replace('\n', " ", $line);
 $count++;
 print "$count. $line<br>\n";
  }
print "</span><br>\n";
 }
print"\n<!-- start alert -->"; 
if (file_exists($alertTxtDescription)) {
 $d = file_get_contents ($alertTxtDescription);
  $out = preg_replace('!\s+!', ' ', $d); 
  $out = str_replace('\n', " ", $out);
//  $out = wordwrap($out,120,"<br>\n");// wrap long forcast  
 print "<span  style=\"color: $Alertsdec_font; background-color: $Alertsdec_bg; justify-content: left;\"><b>$out</b></span>\n";
 }
print "<BR>";  
}
else{print"\n<!-- No Warnings -->\n";}


//  $shortForcast,$detailedForecast,$icon
$forcastIcon=""; $forcastAlt="";$forcastOut="";
if (file_exists($forcast)) { 
 print "\n<!-- Forcast Exists -->\n"; 
  $d = file_get_contents ($forcast); $size= filesize($forcast);  if ($size >=9){
  $u = explode("|",$d);
  $forcastOut = preg_replace('!\s+!', ' ', $u[1]); // 0 is a icon 1 is text
  $forcastOut = str_replace('\n', "", $forcastOut);
  $forcastIcon = $u[2];
  $forcastAlt  = $u[0];
//  $out = wordwrap($out,120,"<br>\n");// wrap long forcast 

    } 
 }
else{print"<!-- No forcast -->\n";}

print "</td></tr><tr><td align=center>";

// The icon block 
if (file_exists($forcastIcons)and $IconBlock) {
print "\n<!-- icon table -->\n";
// Load the descriptions
 if (file_exists($forcastWeekFile)) { 
  $lastDate = date('m-d-Y H:i', filemtime($forcastWeekFile));
  $f = file_get_contents ($forcastWeekFile);
  $size= filesize($forcastWeekFile);
  $fc= explode("|",$f);//print "<!-- $f -->\n"; 
 }
 // load the names
  if (file_exists($nameWeekFile)) {
  $f = file_get_contents ($nameWeekFile);
  $size= filesize($nameWeekFile);
  $fcName = explode("|",$f);//print "<!-- $f -->\n"; 
 }
 

$d = file_get_contents ($forcastIcons); 
$size= filesize($forcastIcons);  

 print "<table border=0 cellpadding=2 cellspacing=2 style='gridtable' id=forcast ><tr>\n";
 print "<td colspan=7>";
 if ($forcastOut){
 $pos = strpos($forcastIcon, 'api.weather.gov');if(!$pos){$forcastIcon="https://api.weather.gov$forcastIcon";}   // Fix for removal of url.
 print"
 <img src='$forcastIcon' align=left width=48 height=48 title='$forcastAlt'>
 <span align=left style='background-color: $bgColorForcast;' >Forcast: $forcastOut</span>";
 }
else {print"Forcast: Error";}//, Last date updated: $lastDate 


$lastModifiedTime = filemtime($forcastWeekFile);
$difference = time() - $lastModifiedTime; $test =12 * 3600;
if ($difference > $test) { print "Extended forcast is old data";}

print "</td></tr><tr>"; 
// Improved format.  Only shows night once
  $u= explode("|",$d); $i=0;$ii=0;//print "<!-- $u -->\n"; 
  foreach($u as $line){
  if($i==0){$i++;continue;}
   $pos = strpos($fcName[$i], 'Night');
  if($pos){$day="Night";if ($i >=2){$i++;continue;}} 
  else{$day=$fcName[$i];}
  // TWS names need to be smaller for phones. 
  $abbreviations = ['Sunday' => 'Sun','Monday' => 'Mon','Tuesday' => 'Tue','Wednesday' => 'Wed','Thursday' => 'Thu','Friday' => 'Fri','Saturday' => 'Sat','This Afternoon' => 'Now'];   
  if (array_key_exists($day, $abbreviations)) { $day = $abbreviations[$day];}
  $pos = strpos($line, 'api.weather.gov');if(!$pos){$line="https://api.weather.gov$line";}   // Fix for removal of url.
  print"<td><div title='$fcName[$i]: $fc[$i]'><img src='$line' width=48 height=48 alt='$i'/></div><small>$day</small></td>\n";
  $i++;$ii++;
 // if($ii>=7){print"</tr><tr>";$ii=0;}// break stops the secoond line
 }
 print "</tr></table>\n"; 
// }
}

else{
if ($IconBlock){ print"\n<!-- NWS API has failed -->\n";print $weather;}
}

print "<!-- END Weather by $copyrightcall $ver----->
</td></tr></table>

";

