<?php
// (c)2023 by WRXB288 and LAgmrs.com  
// Import this into link.php on supermon
// added conditions by WRXB288
// v1.1 8/10/23
// v1.2 9/22/23  version check and error checking into comments lines
// v1.3 9/27/23 Day names added since NWS file is fluid and is not always 7 days.
// v1.4 11/30/23 Word wrapping for long forcast
// v1.5 12/18/23 Forcast icon block off option
// v1.6 12/28/23 Backup forcast added when API goes down

$path="/etc/asterisk/local/mm-software";
include_once ("$path/load.php");

$ver ="v1.6" ;

$copyrightcall="WRXB288";
$conditions="/tmp/conditions.txt";
$skywarn   ="/tmp/skywarn.txt";
$forcast   ="/tmp/forcast.txt";

$alertTxtHeadline ="/tmp/skywarn_headline.txt";

$forcastIcons    ="/tmp/forcast_icons.txt";
$forcastWeekFile ="/tmp/forcast_week.txt";
$nameWeekFile    ="/tmp/forcast_name.txt";


print "\n<!-- Start Weather by $copyrightcall $coreVersion $ver----->\n";


if (file_exists($conditions)) {
print "\n<!-- conditions -->\n";
  $d = file_get_contents ($conditions); $size= filesize($conditions);   
  if ($size >=5){
    print "<p style='margin-top:0px;'> Local Weather conditions: [";
    print "<span style='margin-top:0px; background-color: GAINSBORO;'>$d</span>]";
 }             
}
else{print"<!-- $conditions file missing -->\n";}


if (file_exists($skywarn)) { 
print "\n<!-- Warning in progress -->\n";
  $d = file_get_contents ($skywarn);$size= filesize($skywarn);   if ($size >=5){
  print "<span style=\"color: red;\"><br><b>Alert(s): [$d]</b></span>";
} 

if (file_exists($alertTxtHeadline)) {
 $d = file_get_contents ($alertTxtHeadline);
 print"<br>";
 $u= explode(",",$d);
 foreach($u as $line){
 print "<small>$line</small><br>";
 }
 }
}
else{print"\n<!-- No Warnings -->\n";}


//  $shortForcast,$detailedForecast,$icon

if (file_exists($forcast)) { 
  print "\n<!-- Forcast -->\n"; 
  print "<table border=0 style='border-collapse: collapse' id=forcast width=760px><tr>\n";
  $d = file_get_contents ($forcast); $size= filesize($forcast);  if ($size >=9){
  $u = explode("|",$d);
  //$u[1] = wordwrap($u[1],90,"<br>\n");// wrap long forcast  (using table to force it)
  print "<td><img src='$u[2]' width=40 height=40 align=left></td>\n";
  print "<td>Forcast: $u[1] </td>\n";
} 
 print "</tr></table>";
}
else{print"<!-- $forcast file missing -->\n";}


// The icon block 
if (file_exists($forcastIcons)and $IconBlock) {
print "\n<!-- icon table -->\n";
// Load the descriptions
 if (file_exists($forcastWeekFile)) {
  $f = file_get_contents ($forcastWeekFile);
  $size= filesize($forcastWeekFile);
  $fc= explode("|",$f);//print "<!-- $f -->\n"; 
 }
 // load the names
  if (file_exists($nameWeekFile)) {
  $f = file_get_contents ($nameWeekFile);
  $size= filesize($nameWeekFile);
  $fcName = explode("|",$f);//print "<!-- $f -->\n"; 
 }
 

$d = file_get_contents ($forcastIcons); 
$size= filesize($forcastIcons);  
//if ($size >=9){
 print "<table border=0 cellpadding=5 cellspacing=5 style='border-collapse: collapse' id=forcast width=760px><tr>\n";
  $u= explode("|",$d); $i=0;//print "<!-- $u -->\n"; 
  foreach($u as $line){
  $pos = strpos($fcName[$i], 'Night');if($pos){$day="Night";} 
  else{$day=$fcName[$i];}
  print"<td><div title='$fcName[$i]: $fc[$i]'><img src='$line' width=40 height=40 alt='$i'/></div><small>$day</small></td>\n";
  $i++;
 }
 print "</tr></table>\n"; 
// }
}
else{

if ($IconBlock){
print"\n<!-- NWS API has failed -->\n";
print"<br>The detailed point forecast weather data is not currently available.<br>
<img src=\"http://www.weatherusa.net/forecasts/?forecast=zone&alt=hwizone7day&daysonly=3&config=png&pands=$zipcode&hwvdisplay=\" width=500 height=200 border=0 title=\"Backup Forecast NWS API is down\">
<br>";
}

else{print"\n<!-- forcast icons off -->\n";}



}


$verTest="$path/version.txt";
if (is_readable($verTest)) {
 $fileIN= file($verTest);
 foreach($fileIN as $line){
 $u = explode(",",$line);   
  if($coreVersion < $u[0]){print "<p>Please run Update. You are running $coreVersion and version has been released $u[0] on $u[1]<p>";} 
 }
}


print "<!-- END Weather by $copyrightcall $coreVersion $ver----->\n";

?>

