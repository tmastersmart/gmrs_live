<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
// Anti bridging system for nodes.  ABS 
// /usr/local/sbin/sm-support/smlogger_background.sh 
// /var/log/asterisk/connectlog
// logging to  /etc/asterisk/local/mm-software/logs/log.txt
// Disconnected, Connected
// =OUT=>,=v=, Likely also <=IN=


$path="/etc/asterisk/local/mm-software";
include ("$path/load.php");
include ("$path/sound_db.php");
$currentTime = "/tmp/bridged.gsm";if(file_exists($currentTime)){unlink($currentTime);}





//08-01-2023 23:42:46,ABS v1.0  Node:xxxx status:Disconnected to:1195 State:=v= Name:The RoadKill,,
//08-01-2023 23:43:34,ABS v1.0  Node:xxxx status:Connected to:1195 State:=OUT=> Name:The RoadKill,,

$ver="v1.4";  // 08/18/2023
$datum   = date('m-d-Y H:i:s');$gmdatum = gmdate('m-d-Y H:i:s');
$ConNode= "";$MyNode= "";$outIn="";$nodeName="";$status="";

if (!empty($argv[1])) {
$ConNode  = $argv[11];
$status  = $argv[9];
$MyNode   = $argv[8];
$outIn    = $argv[12];
$nodeName = "$argv[13] $argv[14]";}

$out="ABS $ver  Node:$MyNode status:$status to:$ConNode State:$outIn Name:$nodeName";
save_task_log ($out);print"$datum $out\n";

if ($node <> $MyNode){save_task_log ("Error I am node $node but reported to me as $MyNode ?IGNORING?");} 

if($bridgeCheck){
bridge_check("check"); $out="ABS $ver $out";save_task_log ($out);print"$datum $out\n";
if ($bridged){
//  emergency  warning  terminating  sorry2  removed repair
// alllinksdisconnected 
check_wav_db ("strong click"); if($file1){$action = "$action $file1";}
check_gsm_db ("emergency");if($file1){$action = "$action $file1";}
check_gsm_db ("warning");if($file1){$action = "$action $file1";}
check_gsm_db ("warning_bridged");if($file1){$action = "$action $file1";} 
//check_gsm_db ("sorry2");if($file1){$action = "$action $file1";}  
check_ulaw_db ("alllinksdisconnected");if($file1){$action = "$action $file1";} 
save_task_log ("Fixing Bridged connections.");
exec("sudo asterisk -rx 'rpt cmd $node ilink 6 '",$output,$return_var);
sleep(5); // wait for asterisk 
exec("sox $action $currentTime",$output,$return_var);//print "DEBUG $action";
exec("sudo asterisk -rx 'rpt localplay $node /tmp/bridged'",$output,$return_var);

 } // end if bridged
} // end if bridge check

unset ($soundDbWav);
unset ($soundDbGsm);
unset ($soundDbUlaw);





function bridge_check($in){
global $out,$bridged,$node,$nodes,$path,$datum,$debug,$call;

$file   = "/tmp/xnodes.txt"; if(file_exists($file)){unlink($file);}
$status= exec("/bin/asterisk -rx 'rpt xnode $node' > $file",$output,$return_var);
$fileIN= file($file);$bridged=false;
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", "RPT_ALINKS"); // RPT_ALINKS=1,1195TU
if ($pos){
$out=$line;
$u = explode("=",$line);// get the value
$u2 = explode(",",$u[1]);// break up the fields
$nodes=$u2[0];//if($debug){print"$datum DEBUG $u[0]=$u[1]\n";} 
$dv = strpos("-$line", $call); if ($dv){$nodes=$nodes-1;} // test for DV SWITCH 
if ($nodes >1){$bridged=true;}
  }
 }
$file = "/tmp/bridged_flag.txt"; if(file_exists($file)){unlink($file);}

if($bridged) {
$out="node $node is Bridged $u[1]"; save_task_log ($out);//print "$datum $out\n";
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$out);flock ($fileOUT, LOCK_UN );fclose ($fileOUT); 
//  /etc/asterisk/local/mm-software/sounds/,bridged,bridged
}
 
 
}
?>
