#!/usr/bin/php
<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved

// Anti bridging system for nodes.  ABS 
 
//  /var/log/asterisk/connectlog

// logging to  /etc/asterisk/local/mm-software/logs/log.txt
// Disconnected, Connected
// =OUT=>,=v=, Likely also <=IN=

$path="/etc/asterisk/local/mm-software";
include ("$path/load.php");
include ("$path/sound_db.php");
$currentTime = "/tmp/bridged.gsm";if(file_exists($currentTime)){unlink($currentTime);}


 // Get php timezone in sync with the PI
$line =	exec('timedatectl | grep "Time zone"'); //       Time zone: America/Chicago (CDT, -0500)
$line = str_replace(" ", "", $line);
$pos1 = strpos($line, ':');$pos2 = strpos($line, '(');
if ($pos1){  $zone   = substr($line, $pos1+1, $pos2-$pos1-1); }
else {$zone="America/Chicago";}
define('TIMEZONE', $zone);
date_default_timezone_set(TIMEZONE);
$phpzone = date_default_timezone_get(); // test it 
if ($phpzone == $zone ){$phpzone=$phpzone;}
else{$phpzone="$phpzone ERROR";}




$ver="v1.0";
$datum   = date('m-d-Y H:i:s');$gmdatum = gmdate('m-d-Y H:i:s');
$ConNode= "";$MyNode= "";$outIn="";$nodeName="";$status="";

if (!empty($argv[1])) {
$ConNode  = $argv[11];
$status  = $argv[9];
$MyNode   = $argv[8];
$outIn    = $argv[12];
$nodeName = "$argv[13] $argv[14]";}
save_task_log ("ABS $ver  Node:$MyNode status:$status to:$ConNode State:$outIn Name:$nodeName");

if ($node <> $MyNode){save_task_log ("Error I am node $node but reported to me as $MyNode ?IGNORING?");} 

if($bridgeCheck){
bridge_check("check");
if ($bridged){
//  emergency  warning  terminating  sorry2  removed repair
// alllinksdisconnected 
check_wav_db ("strong click"); if($file1){$action = "$action $file1";}
check_gsm_db ("emergency");if($file1){$action = "$action $file1";}
check_gsm_db ("warning");if($file1){$action = "$action $file1";}
check_gsm_db ("bridged");if($file1){$action = "$action $file1";} 
//check_gsm_db ("sorry2");if($file1){$action = "$action $file1";}  
check_ulaw_db ("alllinksdisconnected");if($file1){$action = "$action $file1";} 
save_task_log ("Fixing Bridged connections.");

exec("sox $action $currentTime",$output,$return_var);//print "DEBUG $action";
exec("sudo asterisk -rx 'rpt localplay $node /tmp/bridged'",$output,$return_var);
exec("sudo asterisk -rx 'rpt cmd $node ilink 6 '",$output,$return_var);
 } // end if bridged
} // end if bridge check

unset ($soundDbWav);
unset ($soundDbGsm);
unset ($soundDbUlaw);





function bridge_check($in){
global $bridged,$node,$nodes,$path,$datum,$debug;

$file   = "/tmp/bridge_check.txt"; if(file_exists($file)){unlink($file);}
$status= exec("/bin/asterisk -rx 'rpt xnode $node' > $file",$output,$return_var);
$fileIN= file($file);$bridged=false;
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", "RPT_ALINKS"); // RPT_ALINKS=1,1195TU
if ($pos){ 
$u = explode("=",$line);// get the value
$u2 = explode(",",$u[1]);// break up the fields
$nodes=$u2[0];//if($debug){print"$datum DEBUG $u[0]=$u[1]\n";} 
if ($nodes >1){$bridged=true;}
  }
 }
$file = "/tmp/bridged_flag.txt"; if(file_exists($file)){unlink($file);}

if($bridged) {
$out="node $node is Bridged $u[1]"; save_task_log ($out);//print "$datum $out\n";
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$out);flock ($fileOUT, LOCK_UN );fclose ($fileOUT); 
//  /etc/asterisk/local/mm-software/sounds/,bridged,bridged
}
 
 
}
?>
