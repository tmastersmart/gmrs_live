#!/usr/bin/php
<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
// Improved nodelist update with load sharing  (astdb.php  replacement)
// Much improved random load sharing.
// Creates a clean nodelist index for node manager databases
//
// http://register.gmrslive.com/cgi-bin/privatenodes.txt
// /var/log/asterisk/astdb.txt 
// 
//
// For now this includes Kludges to correct errors in the nodelist 
//and to identify hubs and repeators. Ongoing updates will be needed
//if you see a error please notify me.
//
//
// v2.9 10-17-23  Changes to restore from backup if nodelist not found.
// v3.0 10-18-23  Tweaking hub detection
// v3.1 10-26-23
// v3.2 10-30-23  Changes mode corrections and cleaning
// v3.3 11-22-23  Added semore files 
// v3.4 11-28-23  Chart data tmp removed 
// v3.5 12-10-23  FIXES and new Live hub index for connection page
// v3.6 12-16-23  Cleanup some failed hub and node detections
// v3.7 12-17-23  trim out " unsafe
// v3.8 12-27-23  autodetect tweeking 

$cron=false;
if (!empty($argv[1])) { 
 if ($argv[1] =="cron"){$cron=true;}
 }
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_start = $mtime;
$ver = "v3.8"; $release="12-28-2023";

$path       = "/etc/asterisk/local/mm-software";
$nodelistBU = "$path/nodelist/astdb.txt";
$privatefile= "/etc/asterisk/local/privatenodes.txt";
$nodelist   = "/var/log/asterisk/astdb.txt";
$flag2      = "/tmp/nodelist_updated.txt"; 

include_once ("$path/load.php");


$phpVersion= phpversion();
$datum   = date('m-d-Y H:i:s');
$gmdatum = gmdate('m-d-Y H:i:s');
print "
===================================================
GMRSLive Nodelist Update System  $coreVersion  $ver
(c)2023 WRXB288 LAGMRS.com all rights reserved
$phpzone PHP v$phpVersion   Release date:$release
===================================================
$datum Model: $piVersion
$datum Node:$node UTC:$gmdatum 
";

// If we have a backup install it.
if (!file_exists($nodelist)){
 $out="Nodelist is missing";save_task_log ($out);print"$datum $out\n";
 if (file_exists($nodelistBU)){
 rename($nodelistBU,$nodelist);
 copy($nodelist,$nodelistBU);
 }
 $out="Restoring nodelist from backup $nodelistBU";save_task_log ($out);print"$datum $out\n";
}

$update = true;
// only update if db is old  48 hrs min
if (file_exists($nodelist)){
 $ft = time()-filemtime($nodelist);
 if ($ft < 24 * 3600){
 $update=false; $fth=round($ft /3600);
 $out="Nodelist does not need update ($fth hrs) old.";save_task_log ($out);print"$datum $out\n";
 } 
}


$datum  = date('m-d-Y H:i:s');
// debugging
if (!$cron){ $out="Nodelist Manual Update";save_task_log ($out);print"$datum $out\n";$update = true;}

if ($update ){
$seconds = mt_rand(0, 1800); $min= round(($seconds / 60),0);
if($cron){$out="Nodelist. Sleep for $min min(s)";save_task_log ($out);print"$datum $out\n";
sleep($seconds);
}

//http://register.gmrslive.com/cgi-bin/privatenodes.txt
$domain ="register.gmrslive.com"; $url = "/cgi-bin/privatenodes.txt"; 
$datum  = date('m-d-Y H:i:s');
print "$datum Polling $domain >";
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-Encoding: gzip\r\n" 
));
$context = stream_context_create($options);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$html = @file_get_contents("http://$domain/$url",false,$context);
$html = gzinflate( substr($html,10,-8) ); 
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
test_data ($html);  


if ($trust ==0){ // try again gzip off
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "User-Agent: none\r\n" 
));
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$datum  = date('m-d-Y H:i:s');print "$datum Polling 2 $domain >";
$html = @file_get_contents("http://$domain/$url",false,$context);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
test_data ($html);
}

if ($trust ==0){// try again
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$datum  = date('m-d-Y H:i:s');print "$datum Polling 3 $domain >";
$html = @file_get_contents("http://$domain/$url",false,$context);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
test_data ($html);
}

$datum  = date('m-d-Y H:i:s');
if ($trust ==0){line_end("ERROR BAD DATA");}


$contents="";


if (file_exists($privatefile)) {
// test for private nodes and erase the bad header
$fileIN= file($privatefile);$compile="";$i=0;
foreach($fileIN as $line){
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $pos = strpos($line, "Freq. or Description");  
  if (!$pos){
   $pos2 = strpos($line, "|"); 
    if($pos2){ $compile="$compile $line\n";$i++;}
    }
}
if ($i>=1){
$size = strlen($compile);
$out="Importing Private Nodes $size bytes";save_task_log ($out);print"$datum $out\n";
$contents .= $compile;
} 
// get rid of the trash. If this file has nothing but a header get rid of it
// Default image has a node 1000 header that we dont want to import.
// This looks to be a bug that could cause trouble for the real node 1000
else {unlink($privatefile);} 
}

$contents .= $html;
$contents = preg_replace('/[\x00-\x09\x0B-\x0C\x0E-\x1F\x7F-\xFF]/', '', $contents);

if(file_exists($nodelist)){copy($nodelist,$nodelistBU);} // keep backups

$fileOUT = fopen($nodelist,'w');fwrite ($fileOUT,$contents);fclose ($fileOUT);
$sizeN = strlen($contents);                                                           
//$out="Loading nodelist $size bytes";print"$datum $out\n";//save_task_log ($out);
sort_nodes ("nodes"); // Builds the database

$flag2      = "/tmp/nodelist_updated.txt"; if(file_exists($flag2)) {unlink($flag2);}
$fileOUT = fopen($flag2,'a+');fwrite ($fileOUT,"$datum updated Nodelist\n");fclose ($fileOUT);

//built_sounds ("ok"); // internal use to build sound files. tts must be setup

} // end update

include_once ("$path/version_check.php");



$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_end = $mtime;$script_time = ($script_end - $script_start);$script_time = round($script_time,2);
$datum  = date('m-d-Y H:i:s');
$memory = memory_get_usage() ;$memory =formatBytes($memory);

print "$datum ";$tagline="";tagline($tagline);print "\n";

print "$datum  [Line end] Used:$memory $script_time Sec\n";
unset ($soundDbWav);
unset ($soundDbGsm);
unset ($soundDbUlaw);
print"===================================================\n";


function test_data ($html){
global $trust,$poll_time;
$trust = 0;
$pos = strpos($html, "GMRSLive.com");if ($pos){$trust++;}
$pos = strpos($html, "RoadKill");if ($pos){$trust++;} 
$pos = strpos($html, "Texas GMRS Network");if ($pos){$trust++;}
$pos = strpos($html, "Do No Edit");if ($pos){$trust++;}
$pos = strpos($html, "WRXB288");if ($pos){$trust++;}
$pos = strpos($html, "WRXN291");if ($pos){$trust++;}
$pos = strpos($html, "WROY524");if ($pos){$trust++;}
$pos = strpos($html, "WRTL610");if ($pos){$trust++;}
$pos = strpos($html, "WRNS719");if ($pos){$trust++;}


// good trust should be >3 If its not we are not on GMRS Live Or the server gave us bad data   
if ($trust >=5){$out="<ok> Trust level:$trust [$poll_time Sec.]";save_task_log ($out);print"$out\n";}
else {$out="<error> Trust level:$trust [$poll_time Sec.]";save_task_log ($out);print"$out\n";}
}

//NODENAMES=/var/lib/asterisk/sounds/rpt/nodenames


// Custom to build node audio names.
// This code creates the sound files on production system. Not used on nodes
function built_sounds ($in){
global $path;
$datum  = date('m-d-Y H:i:s');
print "$datum Building HUB sound files >\n";

$soundPath="/var/lib/asterisk/sounds/rpt/nodenames"; 
chdir($soundPath);
$pathNode="$path/nodelist";
$nodelist3 =  "$pathNode/hubs.csv";
$fileIN= file($nodelist3);
natsort($fileIN); $i=0;
foreach($fileIN as $line){
 //Remove line feeds
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $line = str_replace("!", "|", $line);
  $line = str_replace("(", "|", $line);
  $line = str_replace("[", "|", $line);
  $line = str_replace("www", "|", $line);
  $line = str_replace("-", "|", $line);
   
$u = explode("|",$line);
$nodeName=$u[0]; $name=$u[1];
// use shorter names for text to speach
//if($nodeName==1195){ $name="The Roadkill network";}
//if($nodeName==50132){$name="The Roadkill network";}

if($nodeName==4521){$name="Thrasher";}
if($nodeName==2329){$name="Oregon GMRS.org Main Hub";}
if($nodeName==1535){$name="GMRS.RADIO HUB";}

if($nodeName==700){$name="Nationwide Chat By GMRS Live";}
if($nodeName==1196){$name="EMERGENCY Operations By Roadkill";}
if($nodeName==900){$name="EMERGENCY Operations By GMRS Live";}
if($nodeName==921){$name="EMERGENCY Operations By BROADNET SYSTEMS";}
if($nodeName==922){$name="EMERGENCY Operations By Texas GMRS Network";}
if($nodeName==923){$name="EMERGENCY Operations By South Dade GMRS";}
print "$datum processing $nodeName $name \n";

//if(file_exists("$soundPath/1195.ul")){unlink("$soundPath/1195.ul");}

if(file_exists("$soundPath/$nodeName.txt")){unlink("$soundPath/$nodeName.txt");}
if(!file_exists("$soundPath/$nodeName.ul") and $name<>"" and $i<=20){
$fileOUT  = fopen("$soundPath/$nodeName.txt",  "w");
fwrite ($fileOUT, "$name\n");
fclose($fileOUT);
print "$datum Building $nodeName $name $soundPath/$nodeName.txt\n";
exec ("tts_audio.sh $soundPath/$nodeName.txt",$output,$return_var);
unlink("$soundPath/$nodeName.txt");$i++;
  }
 }
}



function sort_nodes ($in){
global $beta,$path,$node,$datum,$cron,$sizeN;
//
//  The purpose in this is to format a human readable index
// and keep all location data and calls in a standarized formats
//
// It is also to detect HUBS repeaters So they can be indexed seperatly
// In cases where the autodetect does not work manual kludges
// are needed.
//
// Some fields have problems with the wrong Delimiters and inconsistent
// formating that must be corrected for the directory to work 
//
// Please do not be upset that your data was adjusted it is only
// to format it for my index.
//
// This is a work in progress. And changes will likely be needed
// as many old fixes have been removed in the last months and 
// more added to keep the database clean.
//
// *    *  Have many nice days (c) 2023
$Statedata= file("$path/states.csv");
$lastCall=""; $count=0; $countR=0;$countH=0;$countC=0;
$nodelist  =  "/var/log/asterisk/astdb.txt";
if(file_exists($nodelist)){

$pathNode="$path/nodelist";
if(!is_dir($pathNode)){ mkdir($pathNode, 0755);}
$dns = "/tmp/rpt_extnodes"; $fileINdns="";
if (file_exists($dns)){$fileINdns= file($dns);$dnsScan=true;}
else {$dnsScan=false;}
$nodelist2 = "$pathNode/dirty.csv";
$newfile  =  "$pathNode/clean.csv";
$newfile2 =  "$pathNode/repeaters.csv";
$newfile3 =  "$pathNode/hubs.csv"; if (file_exists($newfile3)){unlink($newfile3);}
$newfile4 =  "$pathNode/hubs_online.csv";if (file_exists($newfile4)){unlink($newfile4);}

if (file_exists($nodelist2)){
$ft = time()-filemtime($nodelist2);
if($cron){if ($ft < 24 * 3600 ){return;}}
}

$datum  = date('m-d-Y H:i:s');
print "$datum Building Nodelist Database ";
copy($nodelist,$nodelist2); // make our own dirty backup

$fileOUT =fopen($newfile,  "w");
$fileOUT2=fopen($newfile2, "w");
$fileOUT3=fopen($newfile3, "w");
$fileOUT4=fopen($newfile4, "w");




$fileIN= file($nodelist2);
natsort($fileIN);
foreach($fileIN as $line){
 //Remove line feeds
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $line = str_replace('"' , "", $line);// get rid of the quotes
  
$u = explode("|",$line);

// Extra error checking
if(!isset($u[0])){$u[0]="";}
if(!isset($u[1])){$u[1]="";}
if(!isset($u[2])){$u[2]="";}
if(!isset($u[3])){$u[3]="";}
if(!isset($u[4])){$u[4]="";}



// (CLEAN up the fields)  
// Location field should not have this
$u[2] = str_replace("-", "", $u[2]);
$u[2] = str_replace("(", "", $u[2]);$u[2] = str_replace(")", "", $u[2]); 
$u[2] = str_replace("[", "", $u[2]);$u[2] = str_replace("]", "", $u[2]); 
// call  
$u[3] = str_replace("(", "", $u[3]);$u[3] = str_replace(")", "", $u[3]); 
$u[3] = str_replace("[", "", $u[3]);$u[3] = str_replace("]", "", $u[3]); 


$test= "-$u[1] $u[2]";  $test= strtolower($test);
$pos = strpos($test, "inactive");if ($pos){$u[0]=0;}
 

if ($u[0]>1){  

if (!$u[3]){$u[4]="H";}  // if no call then its a repeater or a HUB- Guess HUB

// repeator detection
$pos = strpos($test, "repeater") ;if ($pos){$u[4]="R";}
$pos = strpos($test, "550"); if ($pos){$u[4]="R";} // These are repeator freqs (may create mistakes)
$pos = strpos($test, "575"); if ($pos){$u[4]="R";}
$pos = strpos($test, "600"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "625"); if ($pos){$u[4]="R";}
$pos = strpos($test, "650"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "675"); if ($pos){$u[4]="R";}
$pos = strpos($test, "700"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "725"); if ($pos){$u[4]="R";} 

// HUB Detection do r first in case of "repeater hub"
$pos = strpos($test, "dvswitch"); if ($pos){$u[4]="H";}
$pos = strpos($test, "emergency");if ($pos){$u[4]="H";} 
$pos = strpos($test, "statewide");if ($pos){$u[4]="H";}  // Testing
$pos = strpos($test, "hub");      if ($pos){$u[4]="H";}
$pos = strpos($test, "cloud");    if ($pos){$u[4]="H";}
$pos = strpos($test, "iax");      if ($pos){$u[4]="H";}
$pos = strpos($test, "zello");    if ($pos){$u[4]="H";}
$pos = strpos($test, "dvswitch"); if ($pos){$u[4]="H";}






$pos = strpos($test, "moble");    if ($pos){$u[4]="N";}
$pos = strpos($test, "node");     if ($pos){$u[4]="N";}
$pos = strpos($test, "mobile");   if ($pos){$u[4]="N";} 
$pos = strpos($test, "inactive"); if ($pos){$u[4]="N";}  
$pos = strpos($test, "hotspot");  if ($pos){$u[4]="N";}

// Hubs that fail autodect or are forced
if ($u[0] == 1195 or $u[0]==1167 or $u[0]==1196 or $u[0]==50132 or $u[0]==2460) {$u[4]="H";}

// repeaters. that fail autodetect
//if ($u[0] == 1053){$u[4]="R";}  //1053|Pasco Simplex Node 462.550|Deltona,FL|WRBM944|R|


// Nodes that fail audo detect
if ($u[0] == 1120){$u[4]="N";}
if ($u[0] == 1121){$u[4]="N";}
if ($u[0] == 1122){$u[4]="N";}
if ($u[0] == 1123){$u[4]="N";}
if ($u[0] == 1124){$u[4]="N";}

if ($u[0] == 1150){$u[4]="N";}
if ($u[0] == 1151){$u[4]="N";}
if ($u[0] == 1152){$u[4]="N";}
if ($u[0] == 1153){$u[4]="N";}
if ($u[0] == 1154){$u[4]="N";}

//1770*	Ross	The City of Doral,FL	WRNC518
//1772*	Ross	Home/Mobile HotSpot,FL	WRNC518
if ($u[0] == 1770){$u[2]="Doral,FL";} 
if ($u[0] == 1772){$u[1]="$u[1] Home/Mobile HotSpot";$u[2]=",FL";}

if ($u[0] == 1926){$u[4]="N";}
if ($u[0] == 1927){$u[4]="N";}
if ($u[0] == 1928){$u[4]="N";}

if ($u[0] == 2300){$u[4]="N";}
if ($u[0] == 2340){$u[4]="N";}// 	DDB HS625 Hotspot	Sutherlin,OR	WRTX950

if ($u[0] == 3001){$u[4]="N";} // 3001	Tony - Palmetto Fl
if ($u[0] == 3008){$u[4]="N";} // 3008	Kirby - GMRS Live Network Assistant

// Format and correct the lone wolf system 
if ($u[0] == 1691){$u[4]="H";}// lone wolf hub
if ($u[0] == 1690){$u[4]="R";}// 1690	Lone Wolf Apopka, FL
if ($u[0] == 1925){$u[4]="R";}//1925	Lone Wolf St. Cloud	
if ($u[0] == 1053){$u[4]="R";}//1053	Pasco Simplex Node 462.550 -
if ($u[0] == 1602){$u[4]="R";}//1602	Lone Wolf System EPIC UNIV	
if ($u[0] == 1780){$u[4]="R";}//1780	Lone Wolf System Yalaha	  
if ($u[0] == 1781){$u[4]="R";}//1781	Lone Wolf System Minneola
if ($u[0] == 2135){$u[4]="R";}//2135	Lone Wolf Sys GMRS Somos Latinos Gainesville GA

// 2557||Idaho Hub|Pacific NorthWest Network|WRTX950
// field 1 is empty creating a 4th field and coruption 
if($u[0]==2557){
 if ($u[1]==""){$u[1]=$u[2];$u[2]=$u[3];$u[3]=$u[4];$u4="H";}//automatic skip if fixed
}
// Texas GMRS data 2250 - 2267 are corrupted. 
// 1 is blank 2 contains the data that should  be in 1
//2250||Texas GMRS Network - Statewide Link|
//2251||North Texas Hub|
//2252||South Texas Hub|
//2253||East Texas Hub|
//2254||West Texas Hub|
//2255||Memorial Park 550 Repeater|
//2256||Northwest Houston 725 Repeater|
//2257||Channelview 675 Repeater|
//2258||Dallas County REACT 675 Repeater|
//2259||Lufkin 725 Repeater|
//2260||Dickinson 650 Repeater|
//2261||La Marque 700 Repeater|
//2262||Montgomery 600 Repeater|
//2263||Conroe 700 Repeater|
//2264||La Grange 725 Repeater|
//2265||Lubbock 700 Repeater|
//2266||Sugar Land 600 Repeater|
//2267||Chappell Hill 650 Repeater|
//2268||Amarillo 650 Repeater|  
//slide over data to fix corruped entries above

if ($u[0] >=2250 and $u[0]<=2268){ 
 if ($u[1]==""){$u[1]=$u[2];$u[2]="";$u[3]="";}
} // make it automatic so when fixed it will skip

//2269-2279 have only 1 data field others blank
//2270|Texas GMRS Network




// Blank named nodes detection
// 10,12,13,2978 
if ($u[1]==""){$u[1]="inactive";$u[4]= "N";}



//700|Nationwide Chat|Hosted By GMRS Live
//750|Zello Link | ** Go To GMRSLive.com for Info **
//900|EOC Emergency Op's for Storm and Severe Weather|Hosted By GMRS Live|
//921|EOC Emergency Op's for Storm and Severe Weather|Hosted By BROADNET SYSTEMS|
//922|EOC Emergency Op's for Storm and Severe Weather|Hosted By Texas GMRS Network|
//923|EOC Emergency Op's for Storm and Severe Weather|Hosted By South Dade GMRS|
//1535|GMRS.RADIO HUB| - Visit https://gmrs.radio
//2555|Oregon Hub|Pacific NorthWest Network|WRTX950
//2556|Washington Hub|Pacific NorthWest Network|WRTX950
//2557||Idaho Hub|Pacific NorthWest Network|WRTX950
//2558|Northern California Hub|Pacific NorthWest Network|WRTX950
//2559|Alaska Hub|Pacific NorthWest Network|WRTX950
//2225|Pennsylvania GMRS Network|- Northcentral Hub
//2226|Pennsylvania GMRS Network|- Northeast Hub
//2227|Pennsylvania GMRS Network|- Southwest Hub
//2228|Pennsylvania GMRS Network|- Southcentral Hub
//2229|Pennsylvania GMRS Network|- Southeast Hub
//1809|Florida Hub| - South Dade GMRS
//1890|Miami Dade Hub| - South Dade GMRS
//1891|Broward Hub| - South Dade GMRS
//1892|Florida Keys Hub| - South Dade GMRS
//1893|Puerto Rico Hub| - South Dade GMRS
//1894|Spanish Hub| - South Dade GMRS

// reformat Known nodes (hubs) that have descriptions in City,State location field
if($u[0]==700 or $u[0]==750  or $u[0]==900  or $u[0]==921  or $u[0]==922  or
   $u[0]==923 or $u[0]==1535 or $u[0]==2555 or $u[0]==2556 or $u[0]==2557 or $u[0]==2558 or 
   $u[0]==2559or $u[0]==2225 or $u[0]==2226 or $u[0]==2227 or $u[0]==2228 or $u[0]==2229 or
   $u[0]==1809or $u[0]==1890 or $u[0]==1891 or $u[0]==1892 or $u[0]==1893 or $u[0]==1894 
   ) {$u[1]="$u[1] - $u[2]";$u[2]="";$u[4]="H";}

// Other info in the location field
//1001*	Tony	HotSpotRadio Palmetto,FL	WRAW556
//1004	Tony	Home HotSpot Palmetto,FL	WRAW556
// Apoligies to tony but this corrupts my location database.
if ($u[0]==1001 or $u[0]==1004 and $u[2]<>"Palmetto,FL"){$u[1]="$u[1] $u[2]";$u[2]="Palmetto,FL";
}
   
//1120|Darrell - Tampa, FL
//1121|Mr. Potato Head - Radio-Less Node
//1122|Darrell - Mobile Node
//1123|Darrell - Hot Spot Node
//1124|Darrell - Hot Spot Node
// no call    
if ($u[0]==1120 or $u[0]==1121 or $u[0]==1122 or $u[0]==1123 or $u[0]==1124){$u[2]="Tampa,FL";}  // no call fix the location
   
//1430|JOEL WQZR739 BROADNET SYSTEMS|||H|
if ($u[0]==1430){$u[3]="WQZR739";$u[4]="N";}// Node or hub?


// Fix repeater with Call in place of name. 
//1920|WRQU236|- Florence 625 - Florence, SC|
if ($u[0]==1920 and $u[1]=="WRQU236"){$u[1]="Florence 625";$u[2]="Florence,SC";$u[3]="WRQU236";$u[4]="R";}

//1925|Lone Wolf System St. Cloud
//1926|LWS Shaun WRTE516
//1927|LWS Shaun Mobile Node
//1928|Lone Wolf System Altamonte Springs, FL
//1929|LWS Shaun WRTE516
// no location or CALL fields

if ($u[0]==1926 or $u[0]==1927 or $u[0]==1929){ $u[2]="FL";$u[3]="WRTE516";$u[4]="N";} // no location no CALL


//2295|Alex Hotspot, Milwaukee WI
//2296|Milwaukee 675 Repeater, Wisconsin
//2297|WRON446 Family Node, Milwaukee WI
//2298|Alex|- Milwaukee,WI|(WRON446)
//2299|Milwaukee, WI Hub
if ($u[0]==2295){ $u[2]="Milwaukee,WI";$u[3]="WRON446";$u[4]="N";}
if ($u[0]==2297){ $u[1]="Family Node";$u[2]="Milwaukee,WI";$u[3]="WRON446";$u[4]="N";}

 

// All formated with nodata fields as a hub
//2460|Sparta 600 Hub (WROY240)
//2461|James - Cromwell, IN (WROY240)
//2462|James / Radio-less Node (WROY240)
//2463|Sparta 600 Repeater (WROY240)
//2464|James Sparta 600 Zello (WROY240)
if ($u[0]==2461 or $u[0]==2462){ $u[2]="Cromwell,IN";$u[3]="WROY240";$u[4]="N";}


//1105|HOT SPOT|Ottawa Lake,MI||N|
//1106|Bob|Ottawa Lake,MI|WRJT765||
//1107|Bob|Ottawa Lake,MI|WRJT765||
//1108|Bob|Ottawa Lake,MI|WRJT765||
//1109|Bob|Ottawa Lake,MI|WRJT765||
if ($u[0]==1105){$u[3]="WRJT765";$u[4]= "N";}


//1040|Thomas,- Hammond, IN|(WRCW750)
//1041|Thomas,- Hammond, IN|(WRCW750)
//1042|Thomas|- Hammond, IN|(WRCW750)
//1043|Thomas|- Hammond, IN|(WRCW750)
//1044|Thomas|- Hammond, IN|(WRCW750)

// 1040 and 1041 have the wrong field have a , in place of a | 
// TBR if fixed
if ($u[0] ==1040 or $u[0] ==1041){$u[1]="Thomas";$u[2]="Hammond,IN";$u[3]="WRCW750";$u[4]="N";}





//2080|Jeffrey| - Mobile| [WRTY487]
if ($u[0]==2080){$u[1]="$u[1] - $u[2]";$u[2]="Harrisonville,MO";}  // incorrect format




//2300|CAPTAIN DOUG WROY 524
//2301|Doug|- Denham Spring,La|(WROY524)
//2302|Doug|- Denham Spring,La|(WROY524)
//2303|Doug|- Denham Spring,La|(WROY524)
//2304|Doug|- Denham Spring,La|(WROY524)
if($u[0]==2300){$u[2]="Denham Spring,LA";$u[3]="WROY524";$u[4]="R";} // is this a repeator



//4405|Holger / herman the german| - Meridian, ID| (WROM586)
//4406|Holger / herman the german| - Meridian, ID| (WROM586)
//4407|Holger / herman the german| - Meridian, ID| (WROM586)
//4408|SW Idaho GMRS Hub
//4409|Holger \ herman the german -Meridian, Idaho wrom586 
// Coruption detected
// Not sure is this a hub or a node?  I think its a node. 
if ($u[0]==4409){$u[2]="Meridian,ID";$u[3]="WROM586";$u[4]="N";}
 
//4445	Ryan - Lockwood, MT (WRXV321)		WRXV321  (false detected as a hub)
if ($u[0]==4445){$n[2]="Lockwood,MT";$u[4]="N";} // address in wrong field


//4516|Lake Wales, FL
//4517|White River Jct., VT
//4518|Claremont, NH
//4519|Melbourne, FL
if ($u[0]>=4516 and $u[0]<=4519){$u[4]="R";}// i think these are repeaters not hubs



// All formated as a hub with no datafields
//4585|Cowboy Robbie - Buffalo, NY (WRWP511)
if ($u[0]>=4585 and $u[0]<=4589){$u[1]="Cowboy Robbie";$u[2]="Buffalo, NY";$u[3]="WRWP511";$u[4]="N";}


// looks like all nodes but 46
//4845|Eric Portable Node (WRUK935)
//4846|Casper, Wyoming 675 Repeater (WRUK935)
//4847|Eric - Casper, WY (WRUK935)
//4848|Eric - Casper, WY (WRUK935)
//4849|Eric - Casper, WY (WRUK935) 
if ($u[0]==4845 or $u[0] ==4847 or $u[0] ==4848 or $u[0] ==4849 ){
 if (!$u[2]){$u[2]="Casper, WY";$u[3]="WRUK935";$u[4]="N";}
 }


// False detection as hubs ? 
//50245|Mr. Statewide| - Owens Cross Roads, AL| (WRXD909)
//50246|Mr. Statewide| - Owens Cross Roads, AL| (WRXD909)
//50247|Mr. Statewide| - Owens Cross Roads, AL| (WRXD909)
//50248|Mr. Statewide| - Owens Cross Roads, AL| (WRXD909)
//50249|Mr. Statewide| - Owens Cross Roads, AL| (WRXD909)
if ($u[0] >=50245 and $u[0] <=50249 ){$u[4]="N";}

//50790|AREA 51 - St. Cloud, FL
//50791|Patrick| - St. Cloud, Fl| (WRUW660)
//50792|Patrick| - St. Cloud, Fl| (WRUW660)
//50793|Patrick| - St. Cloud, Fl| (WRUW660)
//50794|Patrick| - St. Cloud, Fl| (WRUW660)
if ($u[0] >=50791 and $u[0] <=50794 ){$u[4]="N";}




// pull id from the first field and put in 3 
$posL = strpos($u[1], "[W"); 
if ($posL>=1){
    $test = explode("[",$u[1]);$id= explode("]",$test[1]);
    $size= strlen($id[0]);
    if ($size ==7){
     if(!$u[3]){$u[3]="$id[0]";}
    }
   }
     
// pull id from the first field and put in 3 
$posL = strpos($u[1], "(W"); 
if ($posL>=1){
    $test = explode("(",$u[1]);$id= explode(")",$test[1]);
    $size= strlen($id[0]);
    if ($size ==7){
      if(!$u[3]){$u[3]="$id[0]";}
    }
    }
         
// FIX IDs in the state field
$posL = strpos("-$u[2]", "[W"); 
if ($posL>=1){
    $u[2]=str_replace("[", "", $u[2]);
    $u[2]=str_replace("]", "", $u[2]); 
    $u[2]=trim($u[2]);

    $size= strlen($u[2]);
    if ($size ==7){
      if(!$u[3]){$u[3]="$u[2]";$u[2]="";}
    }
   } 

 

// fix for city state not in location field
$posW = strpos("-$u[1]", "Bloomington IL");if($posW> 1){$u[2]="Bloomington,IL";} 
$posW = strpos("-$u[1]", "Lacombe, LA");   if($posW> 1){$u[2]="Lacombe,LA";}
$posW = strpos("-$u[1]", "Bakersfield Ca");if($posW> 1){$u[2]="Bakersfield,CA";} 
$posW = strpos("-$u[1]", "Lincoln IL");    if($posW> 1){$u[2]="Lincoln,IL";} 
$posW = strpos("-$u[1]", "San Jose, Ca");  if($posW> 1){$u[2]="San Jose,Ca";}
$posW = strpos("-$u[1]", "Baton Rouge,LA");if($posW> 1){$u[2]="Baton Rouge,LA";}
$posW = strpos("-$u[1]", "Buffalo, NY");   if($posW> 1){$u[2]="Buffalo,NY";}
$posW = strpos("-$u[1]", "Lockwood, MT");  if($posW> 1){$u[2]="Lockwood,MT";}
$posW = strpos("-$u[1]", "San Jose, CA");  if($posW> 1){$u[2]="San Jose,CA";}
$posW = strpos("-$u[1]", "Palmetto Fl");   if($posW> 1){$u[2]="Palmetto,Fl";}
 

// Tampa Florida fix
$florida=0;
$posW = strpos("-$u[1]", "Tampa");if($posW){$florida++;} 
$posW = strpos("-$u[1]", "FL");if($posW){$florida++;} 
if($florida>1) {$u[2]="Tampa,FL";}


// fix states
$state = explode(",",$u[2]);
// Extra error checking
if(!isset($state[0])){$state[0]="";}
if(!isset($state[1])){$state[1]="";}
$state[1] = strtoupper($state[1]);
$state[1] = str_replace(" ", "", $state[1]);
// $Statedata
// fix state names. Convert to proper abv
foreach($Statedata as $line){ 
$line = strtoupper($line); $line  = str_replace(" ", "", $line );
$uu = explode(",",$line); 
if ($uu[0]==$state[1]){$state[1]=$uu[1];break;} // Louisiana,LA
if ($uu[1]==$state[1]){ break;} // get some extra cpu cycles
}
$test = str_replace(" ", "", $state[0]);
// kludge for known typos. This is automatic will be skipped when fixed
if ($test=="Michigan"){    $state[1]="MI";$state[0]="";}
if ($test=="SanAntonioTx"){$state[1]="TX";$state[0]="San Antonio";}
if ($test=="BuckeyeAz"){   $state[1]="AZ";$state[0]="Buckeye";}
if ($test=="AshevilleNC"){ $state[1]="NC";$state[0]="Asheville";}
if ($test=="PlanoTX"){     $state[1]="TX";$state[0]="Plano";}
if ($test=="ElkhartIn"){   $state[1]="IN";$state[0]="Elkhart";}
if ($test=="Thornton Tx"){ $state[1]="TX";$state[0]="Thornton";}
if ($test=="HOUSTON"){     $state[1]="TX";$state[0]="Houston";} // Fix upercase typos

$state[0]= ltrim( $state[0]);// Remove the leading spaces from the address
if($state[1]){  $u[2]= "$state[0],$state[1]";  } // cleaned up 
$u[3] = strtoupper($u[3]); // convert all IDS to upercase   
$u[0]=trim($u[0]);
$u[1]=trim($u[1]);
$u[2]=trim($u[2]);
$u[3]=trim($u[3]); 


// (CLEAN up the fields)  2 = location 3 = call
$u[2] = str_replace("-", "", $u[2]);
$u[2] = str_replace("(", "", $u[2]);$u[2] = str_replace(")", "", $u[2]); 
$u[2] = str_replace("[", "", $u[2]);$u[2] = str_replace("]", "", $u[2]); 
$u[3] = str_replace("(", "", $u[3]);$u[3] = str_replace(")", "", $u[3]); 
$u[3] = str_replace("[", "", $u[3]);$u[3] = str_replace("]", "", $u[3]); 




// Pull this running node info out the nodelist and save it. 
if($u[0]==$node){ 
$file= "$path/node-name.txt";
if(!file_exists($file)){
$fileOUT5 = fopen($file, "w") ;flock( $fileOUT5, LOCK_EX );fwrite ($fileOUT5, "$u[0],$u[1],$u[2],$u[3],$u[4],\n");flock( $fileOUT5, LOCK_UN );fclose ($fileOUT5);
print"<$u[1] $u[2]>";// this is our info  (one time update)
 }
}

$count++;
               fwrite ($fileOUT,  "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|\n");
if($u[4]=="R"){fwrite ($fileOUT2, "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|\n");$countR++;}
if($u[4]=="H"){fwrite ($fileOUT3, "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|\n");$countH++;

// Creates a list of live nodes for the connect box. Runs at night so must be 24hr
 if ($dnsScan){
   foreach($fileINdns as $lineDns){
    $lineDns = str_replace(" ", "", $lineDns);
    $uu = explode("=",$lineDns);
     if ($uu[0]==$u[0]){fwrite ($fileOUT4, "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|\n");$countC++;break;}
   }
  }// end dns scan
   
 } // end hub
}  // if >1


}  // end for each loop

fclose($fileOUT);fclose($fileOUT2);fclose($fileOUT3);fclose($fileOUT4);// we are finished close them all

$datum = date('[H:i:s]');$out="Building Nodelist Database Nodes:$count Bytes:$sizeN";save_task_log ($out); 

print "<ok> Bytes:$sizeN Nodes:$count Repeaters:$countR Hubs:$countH/$countC \n";

// chart logging module
//$time= date('H:i');
//$date =  date('m-d-Y');
//$datum   = date('m-d-Y H:i:s');
//$pathChart="$path/charts";
//if(!is_dir($pathChart)){ mkdir($pathChart, 0755);}
//$file = "$pathChart/nodes.dat"; $fileOUT = fopen($file,'a+');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$time $count \r\n"); flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
//$file = "$pathChart/online.dat";$fileOUT = fopen($file,'a+');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$time $countC \r\n"); flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
//print "$datum Chart data saved\n";
}

else{$out="Missing Nodelist $nodelist";save_task_log ($out);print "$datum $out\n";}

}

