#!/usr/bin/php
<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
// Improved nodelist update with load sharing  (astdb.php  replacement)
// Much improved random load sharing.
// Creates a clean nodelist index for node manager databases
//
// http://register.gmrslive.com/cgi-bin/privatenodes.txt
// /var/log/asterisk/astdb.txt 
// 
//
// For now this includes Kludges to correct errors in the nodelist 
//and to identify hubs and repeators. Ongoing updates will be needed
//if you see a error please notify me.
//
//
// v2.9 10-17-23  Changes to restore from backup if nodelist not found.
// v3.0 10-18-23  Tweaking hub detection
// v3.1 10-26-23
// v3.2 10-30-23  Changes mode corrections and cleaning
// v3.3 11-22-23  Added semore files 
// v3.4 11-28-23  Chart data tmp removed 
// v3.5 12-10-23  FIXES and new Live hub index for connection page
// v3.6 12-16-23  Cleanup some failed hub and node detections
// v3.7 12-17-23  trim out " unsafe
// v3.8 12-27-23  autodetect tweeking
// v4.0 1/5/24  Tweeks and slight bug fix 
// v4.1 1/14/24
// v4.3 1/26     Normal tweeks
// v4.3 -------2/23

$cron=false; $antiDupe=""; $copyright="wrxb288";
if (!empty($argv[1])) { 
 if ($argv[1] =="cron"){$cron=true;}
 }
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_start = $mtime;
$ver = "v4.5"; $release="2-12-2024";

$path       = "/etc/asterisk/local/mm-software";
$nodelistBU = "$path/nodelist/astdb.txt";
$privatefile= "/etc/asterisk/local/privatenodes.txt";
$nodelist   = "/var/log/asterisk/astdb.txt";
$flag2      = "/tmp/nodelist_updated.txt"; 
$pathNodelist = "$path/nodelist";if(!is_dir($pathNodelist)){ mkdir($pathNodelist, 0755);}

include_once ("$path/load.php");


$phpVersion= phpversion();
$datum   = date('m-d-Y H:i:s');
$gmdatum = gmdate('m-d-Y H:i:s');
print "
===================================================
GMRSLive Nodelist Update System  $coreVersion  $ver
(c)2023 WRXB288 LAGMRS.com all rights reserved
$phpzone PHP v$phpVersion   Release date:$release
===================================================
$datum Model: $piVersion
$datum Node:$node UTC:$gmdatum 
";

// If we have a backup install it.
if (!file_exists($nodelist)){
 $out="Nodelist is missing";save_task_log ($out);print"$datum $out\n";
 if (file_exists($nodelistBU)){
 rename($nodelistBU,$nodelist);
 copy($nodelist,$nodelistBU);
 }
 $out="Restoring nodelist from backup $nodelistBU";save_task_log ($out);print"$datum $out\n";
}

$update = true;
// only update if db is old  48 hrs min
if (file_exists($nodelist)){
 $ft = time()-filemtime($nodelist);
 if ($ft < 24 * 3600){
 $update=false; $fth=round($ft /3600);
 $out="Nodelist does not need update ($fth hrs) old.";save_task_log ($out);print"$datum $out\n";
 } 
}


$datum  = date('m-d-Y H:i:s');
// debugging
if (!$cron){ $out="Nodelist Manual Update";save_task_log ($out);print"$datum $out\n";$update = true;}

if ($update ){
$seconds = mt_rand(0, 1800); $min= round(($seconds / 60),0);
if($cron){$out="Nodelist. Sleep for $min min(s)";save_task_log ($out);print"$datum $out\n";
sleep($seconds);
}

//http://register.gmrslive.com/cgi-bin/privatenodes.txt
$domain ="register.gmrslive.com"; $url = "/cgi-bin/privatenodes.txt"; 
$datum  = date('m-d-Y H:i:s');
print "$datum Polling $domain >";
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-Encoding: gzip\r\n" 
));
$context = stream_context_create($options);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$html = @file_get_contents("http://$domain/$url",false,$context);
$html = gzinflate( substr($html,10,-8) ); 
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
test_data ($html);  


if ($trust ==0){ // try again gzip off
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "User-Agent: none\r\n" 
));
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$datum  = date('m-d-Y H:i:s');print "$datum Polling 2 $domain >";
$html = @file_get_contents("http://$domain/$url",false,$context);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
test_data ($html);
}

if ($trust ==0){// try again
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$datum  = date('m-d-Y H:i:s');print "$datum Polling 3 $domain >";
$html = @file_get_contents("http://$domain/$url",false,$context);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
test_data ($html);
}

$datum  = date('m-d-Y H:i:s');
if ($trust <=2 or !$trust2){line_end("ERROR BAD DATA (Licensed for GMRSlive.com ONLY)");}

$contents="";
if (file_exists($privatefile)) {
// test for private nodes and erase the bad header
$fileIN= file($privatefile);$compile="";$i=0;
foreach($fileIN as $line){
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $pos = strpos($line, "Freq. or Description");  
  if (!$pos){
   $pos2 = strpos($line, "|"); 
    if($pos2){ $compile="$compile $line\n";$i++;}
    }
}
if ($i>=1){
$size = strlen($compile);
$out="Importing Private Nodes $size bytes";save_task_log ($out);print"$datum $out\n";
$contents .= $compile;
} 
// get rid of the trash. If this file has nothing but a header get rid of it
// Default image has a node 1000 header that we dont want to import.
// This looks to be a bug that could cause trouble for the real node 1000
else {unlink($privatefile);} 
}

$contents .= $html;
$contents = preg_replace('/[\x00-\x09\x0B-\x0C\x0E-\x1F\x7F-\xFF]/', '', $contents);

if(file_exists($nodelist)){
 if(file_exists($nodelistBU)){unlink($nodelistBU);}
 copy($nodelist,$nodelistBU);
} // keep backups

$fileOUT = fopen($nodelist,'w');fwrite ($fileOUT,$contents);fclose ($fileOUT);
$sizeN = strlen($contents);                                                           
//$out="Loading nodelist $size bytes";print"$datum $out\n";//save_task_log ($out);
sort_nodes ("nodes"); // Builds the database

//include_once ("$path/purge_log.php"); // moved to midnight.php

$flag2      = "/tmp/nodelist_updated.txt"; if(file_exists($flag2)) {unlink($flag2);}
$fileOUT = fopen($flag2,'a+');fwrite ($fileOUT,"$datum updated Nodelist\n");fclose ($fileOUT);

//built_sounds ("ok"); // internal use to build sound files. tts must be setup

} // end update

include_once ("$path/version_check.php");



$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_end = $mtime;$script_time = ($script_end - $script_start);$script_time = round($script_time,2);
$datum  = date('m-d-Y H:i:s');
$memory = memory_get_usage() ;$memory =formatBytes($memory);

print "$datum  [Line end] Used:$memory $script_time Sec\n"; 
$tagline="";tagline($tagline);print "\n";
unset ($soundDbWav);
unset ($soundDbGsm);
unset ($soundDbUlaw);
print"===================================================\n";


function test_data ($html){
global $trust,$poll_time,$trust2;
$trust=0;$trust2=false;$test=strtolower($html); 
$pos = strpos($test, "wrxb288");if($pos){$trust++;      print"1";$trust2=true;}
$pos = strpos($test, "gmrslive.com");if ($pos){$trust++;print"2";}
$pos = strpos($test, "roadkill");if ($pos){$trust++;    print"3";} 
$pos = strpos($test, "do no edit");if ($pos){$trust++;  print"4";}
$pos = strpos($test, "thrasher");if ($pos){$trust++;    print"5";}
$pos = strpos($test, "mishigami");if ($pos){$trust++;   print"6";} 
$pos = strpos($test, "slingshot");if ($pos){$trust++;   print"7";}   
$pos = strpos($test, "swla");if ($pos){$trust++;        print"8";}

// is Nodelist from another network?
$pos = strpos($html, "Texas GMRS Network");if ($pos){$trust=-10;} 

// good trust should be >3 If its not we are not on GMRS Live Or the server gave us bad data   
if ($trust >=3){$out="<ok> Trust level:$trust [$poll_time Sec.]";save_task_log ($out);print"$out\n";}
else {$out="<error> Trust level:$trust [$poll_time Sec.]";save_task_log ($out);print"$out\n";}
}

//NODENAMES=/var/lib/asterisk/sounds/rpt/nodenames


// Custom to build node audio names.
// This code creates the sound files on production system. Not used on nodes
function built_sounds ($in){
global $path;
$datum  = date('m-d-Y H:i:s');
print "$datum Building HUB sound files >\n";

$soundPath="/var/lib/asterisk/sounds/rpt/nodenames"; 
chdir($soundPath);
$pathNode="$path/nodelist";
$nodelist3 =  "$pathNode/hubs.csv";
$fileIN= file($nodelist3);
natsort($fileIN); $i=0;
foreach($fileIN as $line){
 //Remove line feeds
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $line = str_replace("!", "|", $line);
  $line = str_replace("(", "|", $line);
  $line = str_replace("[", "|", $line);
  $line = str_replace("www", "|", $line);
  $line = str_replace("-", "|", $line);
   
$u = explode("|",$line);
$nodeName=$u[0]; $name=$u[1];
// use shorter names for text to speach
//if($name=="inactive"){continue;}
if($nodeName==4521){$name="Thrasher";}
if($nodeName==2329){$name="Oregon GMRS.org Main Hub";}
if($nodeName==1535){$name="GMRS.RADIO HUB";}
if($nodeName>=51010 and $nodeName<=51014){$name="South West Lousiana GMRS";} //  51010	SWLA GMRS - Lake Charles. La (WRVU907)	Lake Charles,LA	WRVU907
if($nodeName==700){$name="Nationwide Chat By GMRS Live";}
if($nodeName==900){$name="EMERGENCY Operations By GMRS Live";}
if($nodeName==921){$name="EMERGENCY Operations By BROADNET SYSTEMS";}
if($nodeName==923){$name="EMERGENCY Operations By South Dade GMRS";}
print "$datum processing $nodeName $name \n";

//if(file_exists("$soundPath/1195.ul")){unlink("$soundPath/1195.ul");}

if(file_exists("$soundPath/$nodeName.txt")){unlink("$soundPath/$nodeName.txt");}
if(!file_exists("$soundPath/$nodeName.ul") and $name<>"" and $i<=20){
$fileOUT  = fopen("$soundPath/$nodeName.txt",  "w");
fwrite ($fileOUT, "$name\n");
fclose($fileOUT);
print "$datum Building $nodeName $name $soundPath/$nodeName.txt\n";
exec ("tts_audio.sh $soundPath/$nodeName.txt",$output,$return_var);
unlink("$soundPath/$nodeName.txt");$i++;
  }
 }
}



function sort_nodes ($in){
global $beta,$path,$node,$datum,$cron,$sizeN;
//
//  The purpose in this is to format a human readable index
// and keep all location data and calls in a standarized formats
//
// It is also to detect HUBS repeaters So they can be indexed seperatly
// In cases where the autodetect does not work manual kludges
// are needed.
//
// Some fields have problems with the wrong Delimiters and inconsistent
// formating that must be corrected for the directory to work 
//
// Please do not be upset that your data was adjusted it is only
// to format it for my index.
//
// This is a work in progress. And changes will likely be needed
// as many old fixes have been removed in the last months and 
// more added to keep the database clean.
//
// *    *  Have many nice days (c) 2023

$antiDupe="";$antiDupe2=""; $nodeDupe=""; $spin=0;
$Statedata= file("$path/states.csv");
$lastCall=""; $count=0; $countR=0;$countH=0;$countC=0;
$nodelist  =  "/var/log/asterisk/astdb.txt";
if(file_exists($nodelist)){

$pathNode="$path/nodelist";
if(!is_dir($pathNode)){ mkdir($pathNode, 0755);}
$dns = "/tmp/rpt_extnodes"; $fileINdns="";
if (file_exists($dns)){$fileINdns= file($dns);$dnsScan=true;}
else {$dnsScan=false;}
$nodelist2 = "$pathNode/dirty.csv";
$newfile  =  "$pathNode/clean.csv";
$newfile2 =  "$pathNode/repeaters.csv";
$newfile3 =  "$pathNode/hubs.csv"; if (file_exists($newfile3)){unlink($newfile3);}
$newfile4 =  "$pathNode/hubs_online.csv";if (file_exists($newfile4)){unlink($newfile4);}
$newfile5 =  "$pathNode/map_data.csv";if (file_exists($newfile5)){unlink($newfile5);}
//$newfile6 =  "$pathNode/map_data2.csv";if (file_exists($newfile6)){unlink($newfile6);}

if (file_exists($nodelist2)){
$ft = time()-filemtime($nodelist2);
if($cron){if ($ft < 24 * 3600 ){return;}}
}

$datum  = date('m-d-Y H:i:s');
print "$datum Building Nodelist Database ";
copy($nodelist,$nodelist2); // make our own dirty backup

$fileOUT =fopen($newfile,  "w");
$fileOUT2=fopen($newfile2, "w");
$fileOUT3=fopen($newfile3, "w");
$fileOUT4=fopen($newfile4, "w");
$fileOUT5=fopen($newfile5, "w");
//$fileOUT6=fopen($newfile6, "w");
fwrite ($fileOUT5,  "Node,Name,City,State,Call,Type,\n");
//fwrite ($fileOUT6,  "Node,Name,City,State,Call, ,\n");

$fileIN= file($nodelist2);
natsort($fileIN);
foreach($fileIN as $line){
 //Remove line feeds
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $line = str_replace('"' , "", $line);// get rid of the quotes
  
$u = explode("|",$line);
// Extra error checking
if(!isset($u[0])){$u[0]="";}
if(!isset($u[1])){$u[1]="";}
if(!isset($u[2])){$u[2]="";}
if(!isset($u[3])){$u[3]="";}
if(!isset($u[4])){$u[4]="";}

// this really should be anything over 100
if ($u[0]>1){

$nodeDupe = $u[0];

// (CLEAN up the fields)  
// Location field should not have this
$u[2] = str_replace("-", "", $u[2]);
$u[2] = str_replace("(", "", $u[2]);$u[2] = str_replace(")", "", $u[2]); 
$u[2] = str_replace("[", "", $u[2]);$u[2] = str_replace("]", "", $u[2]); 

// Clean the call field  
$u[3] = str_replace("(", "", $u[3]);$u[3] = str_replace(")", "", $u[3]); 
$u[3] = str_replace("[", "", $u[3]);$u[3] = str_replace("]", "", $u[3]); 



$test= "-$u[1] $u[2]";  $test= strtolower($test);
//$pos = strpos($test, "inactive");if ($pos){$u[0]=0;}

if (!$u[3]){$u[4]="R";} // Now guesing repeator not hub
if (!$u[1]){$u[1]="NA";$u[4]= "N";}
 
$pos = strpos($test, "repeater") ;if ($pos){$u[4]="R";}
// These are repeator freqs (may create mistakes)
$pos = strpos($test, "550"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "575"); if ($pos){$u[4]="R";}
$pos = strpos($test, "600"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "625"); if ($pos){$u[4]="R";}
$pos = strpos($test, "650"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "675"); if ($pos){$u[4]="R";}
$pos = strpos($test, "700"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "725"); if ($pos){$u[4]="R";} 

// HUB Detection do r first in case of "repeater hub"
$pos = strpos($test, "emergency") ;if ($pos){$u[4]="H";} 
$pos = strpos($test, "statewide") ;if ($pos){$u[4]="H";}
$pos = strpos($test, "nationwide");if ($pos){$u[4]="H";}  
$pos = strpos($test, "hub");       if ($pos){$u[4]="H";}
$pos = strpos($test, "cloud");     if ($pos){$u[4]="H";}


$pos = strpos($test, "iax");      if ($pos){$u[4]="H";}
$pos = strpos($test, "zello");    if ($pos){$u[4]="H";}
$pos = strpos($test, "dvswitch"); if ($pos){$u[4]="H";}  
$pos = strpos($test, "dv switch");if ($pos){$u[4]="H";}  
$pos = strpos($test, "moble");    if ($pos){$u[4]="N";}
$pos = strpos($test, "node");     if ($pos){$u[4]="N";}
$pos = strpos($test, "mobile");   if ($pos){$u[4]="N";} 
$pos = strpos($test, "inactive"); if ($pos){$u[4]="N";}  
$pos = strpos($test, "hotspot");  if ($pos){$u[4]="N";}
$pos = strpos($test, "simplex");  if ($pos){$u[4]="N";}


// Prevent these from being in hub repeater directory. Place them as nodes                                                    
$pos = strpos($test, "private");  if ($pos){$u[4]="N";}// delist private servers(mark as private?)
$pos = strpos($test, "personal"); if ($pos){$u[4]="N";}// delist PERSONAL
$pos = strpos($test, "voip");     if ($pos){$u[4]="N";}// delist any VOIP 
// Hubs that fail autodect or are forced

if ($u[0]==611 or $u[0]==1876  or $u[0] == 1167 or $u[0] == 1195 or $u[0]==1196 or $u[0]==2460 or $u[0]==2505 or 
    $u[0]==2156 or $u[0]==50130 or $u[0]==4520 or $u[0]==1215 or $u[0]==4146 or $u[0]==4147
    ) {$u[4]="H";}
    
    
// Nodes that fail auto detect
if ($u[0]== 750  or $u[0] == 1121 or $u[0] == 1122 or $u[0] == 1123 or $u[0] == 50930 or 
    $u[0] == 2978 or $u[0]== 1124 or $u[0] == 1150 or $u[0] == 1151 or $u[0] == 1152 or 
    $u[0] == 1153 or $u[0]== 1154 or $u[0] == 1926 or $u[0] == 1927 or $u[0] == 1928 or
    $u[0] == 2300 or $u[0]== 2340 or $u[0] == 3001 or $u[0] == 3008 or $u[0] == 31691 or
    $u[0] == 2244 or $u[0]==2616  or $u[0] == 4190 or $u[0] == 4192 or $u[0] == 4800  or
    $u[0] == 51334) {
    $u[4]="N";}
    

// Node numbers in the name mess up my directory
$pos = strpos($test, $u[0]);
if($pos){ 
 $u[1] = str_replace($u[0], "", $u[1]);
 $u[1] = str_replace("-", "", $u[1]);// has a - after the node number
}

// 750	Zello Link	** Go To GMRSLive.com for Info **,	
if ($u[0] == 750 ){ $u[1]="$u[1] $u[2]";$u[2]="";$u[4]="N";} // Clear the city state field & take out of hub list


// Format and correct the lone wolf system 
if ($u[0] == 1691){$u[4]="H";}// lone wolf hub
if ($u[0] == 1690){$u[4]="R";}// 1690	Lone Wolf Apopka, FL
if ($u[0] == 1925){$u[4]="R";}//1925	Lone Wolf St. Cloud	
if ($u[0] == 1053){$u[4]="R";}//1053	Pasco Simplex Node 462.550 -
if ($u[0] == 1602){$u[4]="R";}//1602	Lone Wolf System EPIC UNIV	
if ($u[0] == 1780){$u[4]="R";}//1780	Lone Wolf System Yalaha	  
if ($u[0] == 1781){$u[4]="R";}//1781	Lone Wolf System Minneola
if ($u[0] == 2135){$u[4]="R";}//2135	Lone Wolf Sys GMRS Somos Latinos Gainesville GA



// reformat Known nodes (hubs) that have descriptions in City,State location field
// This will likely require adjustments
if($u[0]==700  or $u[0]==900  or $u[0]==921  or $u[0]==922  or $u[0]==1691 or $u[0]==1020 or 
   $u[0]==923  or $u[0]==924  or $u[0]==925  or $u[0]==1535 or $u[0]==2555 or $u[0]==2556 or
   $u[0]==2557 or $u[0]==2558 or $u[0]==2559 or $u[0]==2225 or $u[0]==2226 or $u[0]==2227 or
   $u[0]==2228 or $u[0]==2229 or $u[0]==1809 or $u[0]==1890 or $u[0]==1891 or $u[0]==1892 or
   $u[0]==1893 or $u[0]==1894 or $u[0]==4621) {$u[1]="$u[1] - $u[2]";$u[2]="";$u[4]="H";}



// Fix location fied
//1001|Tony| - HotSpotRadio - Palmetto, FL|[WRAW556]
//1004|Tony| - Home HotSpot - Palmetto, FL|[WRAW556]
// Apoligies to tony but this corrupts my location mapping database .
if ($u[0]==1001 or $u[0]==1004 and $u[2]<>"Palmetto,FL"){$u[1]="$u[1] $u[2]";$u[2]="Palmetto,FL";}

// Using , instead of |
//1040|Thomas,- Hammond, IN|(WRCW750)
//1041|Thomas,- Hammond, IN|(WRCW750)
if ($u[0] ==1040 or $u[0] ==1041){$u[1]="Thomas";$u[2]="Hammond,IN";$u[3]="WRCW750";$u[4]="N";}


//1060|Andrew|- Mobile Node|(WRAB494)
if ($u[0]==1060){ $u[1]="$u[1] - $u[2]";$u[2]="";}

//1083|Andrew|- Michigan|(WRAB494)
//1084|Andrew - Stevensville, MI (WRAB494  
if ($u[0]==1083 or $u[0]==1084){$u[2]="Stevensville,MI";$u[3]="WRAB494";$u[4]="N";} 

   
//1105|Hot Spot  Mishigami Repeater System Perrysburg,OH
if ($u[0]==1105){$u[2]="Perrysburg,OH";$u[3]="WRJT765";$u[4]= "N";} 


//1120|Darrell - Tampa, FL
//1121|Mr. Potato Head - Radio-Less Node
//1122|Darrell - Mobile Node
//1123|Darrell - Hot Spot Node
//1124|Darrell - Hot Spot Node
if ($u[0]>=1120 and $u[0]<=1124){$u[2]="Tampa,FL";$u[4]="N";}  // no call known
   
//1430|JOEL WQZR739 BROADNET SYSTEMS|||H|
if ($u[0]==1430){$u[3]="WQZR739";$u[4]="N";}// Node or hub?

// Bad location format
//1560|Bob|- Islip NY|(WQWS860)
//1561|Bob|- Islip NY|(WQWS860)
//1562|Bob|- Islip NY|(WQWS860)
//1563|Bob|- Islip NY|(WQWS860)
//1564|Bob|- Islip NY|(WQWS860)
if ($u[0]>=1560 and $u[0]<=1564){$u[2]="Islip,NY";}  

// fix nodes format
//1715|Tampa Bay 600
//1716|John WREM697 Riverview, FL Simplex
//1717|Tampa Bay 725 [WREM697]
//1718|John WREM697 Orlando, FL Simplex
//1719|John|- Riverview,Fl|(WREM697)
if ($u[0]==1716){ $u[2]="Riverview,FL";$u[3]="WREM697";$u[4]="N";} 
if ($u[0]==1718){ $u[2]="Orlando,FL";  $u[3]="WREM697";$u[4]="N";} 

// Backwards call in wrong field
//1779|Washington,IL GMRS Live Linked Repeater|(WRJN397)
if ($u[0]==1779){ $u[2]="Washington,IL";$u[3]="WRJN397";$u[4]="R";}
 
// Fix repeater with Call in place of name. 
//1920|WRQU236|- Florence 625 - Florence,SC
if ($u[0]==1920 and $u[1]=="WRQU236"){$u[1]="Florence 625";$u[2]="Florence,SC";$u[3]="WRQU236";$u[4]="R";}

//1925|Lone Wolf System St. Cloud
//1926|LWS Shaun WRTE516
//1927|LWS Shaun Mobile Node
//1928|Lone Wolf System Altamonte Springs, FL
//1929|LWS Shaun WRTE516
// no location or CALL fields
if ($u[0]==1925){ $u[2]="St. Cloud,FL";        $u[4]="R";} 
if ($u[0]==1926 or $u[0]==1927 or $u[0]==1929){ $u[3]="WRTE516";$u[4]="N";} // no location no CALL
if ($u[0]==1928){ $u[2]="Altamonte Springs,FL";$u[4]="R";}

// Backwards call in wrong field
//2056|Scheller,IL GMRS Live Linked Repeater|(WRQL716)
if ($u[0]==2056){$u[1]="GMRS Live Linked Repeater - Scheller IL";$u[2]="Scheller,IL";$u[3]="WRQL716";$u[4]="R";}  

//2080|Jeffrey| - Mobile| [WRTY487]
//2081|Jeffrey| - Harrisonville, MO| [WRTY487]
if ($u[0]==2080){$u[1]="$u[1] - $u[2]";$u[2]="Harrisonville,MO";$u[4]="N";}  

//2147|DDB Simplex Mobile |- Dodge PU|(WRTX950)
if ($u[0]==2147){ $u[1]="$u[1] - $u[2]";$u[2]="";}  // Dodge PU in location




//Location problem
//2235|Ramey|- Thornton Tx|(WQVC581)
if ($u[0]>=2235 and $u[0]<=2239){ $u[2]="Thornton,Tx";} 


//2295|Alex Hotspot, Milwaukee WI
//2296|Milwaukee 675 Repeater, Wisconsin
//2297|WRON446 Family Node, Milwaukee WI
//2298|Alex|- Milwaukee,WI|(WRON446)
//2299|Milwaukee, WI Hub
if ($u[0]>=2295 and $u[0]<=2299){ $u[2]="Milwaukee,WI";$u[3]="WRON446";$u[4]="N";}
if ($u[0]==2296){ $u[1]="Milwaukee 675 Repeater";$u[4]="R";}
if ($u[0]==2297){ $u[1]="Family Node";}

// Continue cleanup here <-------------------------------------------------------------



//2325|NV725 Repeater - Grants Pass,Oregon (WRCD602)
//2326|IV550 Repeater - Selma,Oregon (WRCD602)
//2327|ELK675 Repeater - Weimer,Oregon (WRCD602)
//2328|PHOENIX-700 Repeater - Phoenix, Oregon [WRCD602]
//2329|OregonGMRS.org Main Hub - Southern,Oregon (WRCD602)
if ($u[0]==2325){ $u[2]="Grants Pass,OR";}
if ($u[0]==2326){ $u[2]="Selma,OR";}
if ($u[0]==2327){ $u[2]="Weimer,OR";}
if ($u[0]==2328){ $u[2]="Phoenix,OR";}



//2405|Brawlie|Romeoville IL|WRNQ331||
//2406|Brawlie|Romeoville IL|WRNQ331||
//2407|Brawlie|Romeoville IL|WRNQ331||
//2408|Brawlie|Romeoville IL|WRNQ331||
//2409|Brawlie|Romeoville IL|WRNQ331||
if ($u[0]>=2405 and $u[0]<=2409){ $u[2]="Romeoville,IL";} 


// All formated with nodata fields as a hub
//2460|Sparta 600 Hub (WROY240)
//2461|James - Cromwell, IN (WROY240)
//2462|James / Radio-less Node (WROY240)
//2463|Sparta 600 Repeater (WROY240)
//2464|James Sparta 600 Zello (WROY240)
if ($u[0]==2461 or $u[0]==2462){ $u[2]="Cromwell,IN";$u[3]="WROY240";$u[4]="N";}







//2300|CAPTAIN DOUG WROY 524
//2301|Doug|- Denham Spring,La|(WROY524)
//2302|Doug|- Denham Spring,La|(WROY524)
//2303|Doug|- Denham Spring,La|(WROY524)
//2304|Doug|- Denham Spring,La|(WROY524)
if($u[0]==2300){$u[2]="Denham Spring,LA";$u[3]="WROY524";$u[4]="R";} // is this a repeator


//2505|Slingshot Repeater System, San Jose, Ca| [WRKH273]
//2506|Slingshot Repeater System HUB, San Jose, Ca| [WRKH273]
//2507|Slingshot Mobile - San Jose, CA" [WRKH273]
//2508|Slingshot| - San Jose, Ca| [WRKH273]
//2509|Slingshot| - San Jose, Ca| [WRKH273]
if ($u[0]==2505) {$u[2]="San Jose,CA"; $u[3]="WRKH273";$u[4]="H";} 
if ($u[0]==2506) {$u[2]="San Jose,CA"; $u[3]="WRKH273";$u[4]="H";} 
if ($u[0]==2507) {$u[2]="San Jose,CA"; $u[3]="WRKH273";$u[4]="N";} 




//2555|Oregon Hub|Pacific NorthWest Network|WRTX950
//2556|Washington Hub|Pacific NorthWest Network|WRTX950
//2557||Idaho Hub|Pacific NorthWest Network|WRTX950
//2558|Northern California Hub|Pacific NorthWest Network|WRTX950
//2559|Alaska Hub|Pacific NorthWest Network|WRTX950
if ($u[0]==2555 or $u[0]==2556 or $u[0]==2558 or $u[0]==2559){$u[1]="$u[1] $u[2]"; $u[2]="";$u[3]="WRTX950";$u[4]="H";} 

// 2557||Idaho Hub|Pacific NorthWest Network|WRTX950
// field 1 is empty creating a 4th field and coruption 
if($u[0]==2557 and $u[1]<>"Idaho Hub"){$u[1]="$u[2] $u[3]";$u[2]="";$u[3]="WRTX950";$u4="H";}//automatic skip if fixed
 
if ($u[0]==31691){$u[1]="$u[1] $u[2]";$u[2]="";$u[3]=""; $u[4]="N";}  // 31691|VOIP Live Connection|Hosted By GMRS Live

if ($u[0]==4251){$u[3]="WRUI413";$u[2]="";$u[4]="N";}
if ($u[0]==4254){$u[3]="WRUI413";$u[2]="";$u[4]="H";}



//4405|Holger / herman the german| - Meridian, ID| (WROM586)
//4406|Holger / herman the german| - Meridian, ID| (WROM586)
//4407|Holger / herman the german| - Meridian, ID| (WROM586)
//4408|SW Idaho GMRS Hub
//4409|Holger \ herman the german -Meridian, Idaho wrom586 
// Coruption detected
// Not sure is this a hub or a node?  I think its a node. 
if ($u[0]==4409){$u[2]="Meridian,ID";$u[3]="WROM586";$u[4]="N";}
 
//4445	Ryan - Lockwood, MT (WRXV321)		WRXV321  (false detected as a hub)
if ($u[0]==4445){$n[2]="Lockwood,MT";$u[4]="N";} // address in wrong field


//4516|Lake Wales, FL
//4517|White River Jct., VT
//4518|Claremont, NH
//4519|Melbourne, FL
if ($u[0]>=4516 and $u[0]<=4519){$u[4]="R";}// i think these are repeaters not hubs

// 4659 duplicate nodelist bug   (what to do about this)
//4569	Brooksville. FL	WRZF316			
//4569	Brooksville. FL	WRZF316			
//4569	Brooksville. FL	WRZF316			
//4569	Brooksville. FL	WRZF316			
//4569	Brooksville. FL	WRZF316			
//4569	Goody	Lafayette	IN	WRQZ654	


// All formated as a hub with no datafields
//4585|Cowboy Robbie - Buffalo, NY (WRWP511)
if ($u[0]>=4585 and $u[0]<=4589){$u[1]="Cowboy Robbie";$u[2]="Buffalo, NY";$u[3]="WRWP511";$u[4]="N";}


// looks like all nodes but 46
//4845|Eric Portable Node (WRUK935)
//4846|Casper, Wyoming 675 Repeater (WRUK935)
//4847|Eric - Casper, WY (WRUK935)
//4848|Eric - Casper, WY (WRUK935)
//4849|Eric - Casper, WY (WRUK935) 
if ($u[0]==4845 or $u[0] ==4847 or $u[0] ==4848 or $u[0] ==4849 ){
 if (!$u[2]){$u[2]="Casper, WY";$u[3]="WRUK935";$u[4]="N";}
 }

//50210|GK - Slidell, LA (WRYM479)
//50211|GK - Slidell, LA (WRYM479)
if ($u[0] ==50210 or $u[0] ==50211 ){$u[4]="N";}

// False detection as hubs ? 
//50245|Mr. Statewide| - Owens Cross Roads, AL| (WRXD909)
//50246|Mr. Statewide| - Owens Cross Roads, AL| (WRXD909)
//50247|Mr. Statewide| - Owens Cross Roads, AL| (WRXD909)
//50248|Mr. Statewide| - Owens Cross Roads, AL| (WRXD909)
//50249|Mr. Statewide| - Owens Cross Roads, AL| (WRXD909)
if ($u[0] >=50245 and $u[0] <=50249 ){$u[4]="N";}

//50790|AREA 51 - St. Cloud, FL
//50791|Patrick| - St. Cloud, Fl| (WRUW660)
//50792|Patrick| - St. Cloud, Fl| (WRUW660)
//50793|Patrick| - St. Cloud, Fl| (WRUW660)
//50794|Patrick| - St. Cloud, Fl| (WRUW660)
if ($u[0] >=50791 and $u[0] <=50794 ){$u[4]="N";}


if ($u[0] == 50834){$u[4]="N";$u[2]="Mirage,AZ";}// 50834	Scott-El Mirage, AZ (WRZQ882)
//50930|Ezra - Belle Chasse, LA (WRYW618)
if ($u[0] ==50930){$u[4]="N";}

//51000|Albert - NEW BRAUNFELS,TX (WRYI790) < r?
//51001|WRYI790
//51002|WRYI790
//51003|WRYI790
//51004|WRYI790
if ($u[0] == 51000){$u[2]="New Braunfels,TX";$u[3]="WRYI790";$u[4]="R";}	
if ($u[0] >= 51001 and $u[0] <= 51004){$u[2]="New Braunfels,TX";$u[3]="WRYI790";$u[4]="N";}


// pull id from the first field and put in 3 
$posL = strpos($u[1], "[W"); 
if ($posL>=1){
    $test = explode("[",$u[1]);$id= explode("]",$test[1]);
    $size= strlen($id[0]);
    if ($size ==7){
     if(!$u[3]){$u[3]="$id[0]";}
    }
   }
     
// pull id from the first field and put in 3 
$posL = strpos($u[1], "(W"); 
if ($posL>=1){
    $test = explode("(",$u[1]);$id= explode(")",$test[1]);
    $size= strlen($id[0]);
    if ($size ==7){
      if(!$u[3]){$u[3]="$id[0]";}
    }
    }
         
// FIX IDs in the state field
$posL = strpos("-$u[2]", "[W"); 
if ($posL>=1){
    $u[2]=str_replace("[", "", $u[2]);
    $u[2]=str_replace("]", "", $u[2]); 
    $u[2]=trim($u[2]);

    $size= strlen($u[2]);
    if ($size ==7){
      if(!$u[3]){$u[3]="$u[2]";$u[2]="";}
    }
   } 

 
if(!$u[2]){
// fix for city state not in location field
// Not automated manual fix
$stateTest = strtoupper($u[1]); $stateTest=str_replace("-", " ", $stateTest);  $stateTest2=str_replace(".", "x", $stateTest); $stateTest=str_replace(".", "", $stateTest);   //LFT.LA
$posW = strpos("-$u[1]", "Claremont, NH")   ;if($posW){$u[2]="Claremont,NH";}  // Claremont, NH
$posW = strpos("-$stateTest2", "CLAREMOUNTx NH")   ;if($posW){$u[2]="Claremont,NH";}  // Claremont, NH
//$posW = strpos("-$stateTest2", "WHITE RIVER JCTxx VT");if($posW){$u[2]="White River Jct,VT";}
$posW = strpos("-$u[1]", "Gainesville GA");if($posW){$u[2]="Gainesville,GA";}

if($u[0]==4846){$u[2]="Casper,WY";}



$posW = strpos("-$stateTest", "GREENVILLE OHIO");if($posW){$u[2]="Greenville,OH";}

$posW = strpos($stateTest, " VT");
 if ($posW){
$posW = strpos("-$stateTest", "WHITE RIVER JCT");    if($posW){$u[2]="White River Jct,VT";} 
}

$posW = strpos($stateTest, " NC");
 if ($posW){
$posW = strpos("-$stateTest", "RALEIGH");       if($posW){$u[2]="Raleigh,NC";} 
}

//COOLBAUGH PA

$posW = strpos($stateTest, " PA");
 if ($posW){
$posW = strpos("-$stateTest", "COOLBAUGH");       if($posW){$u[2]="Coolbaugh,PA";} 
$posW = strpos("-$stateTest", "MONTCO");          if($posW){$u[2]="Montco,PA";}  
}
// Richboro
$posW = strpos("-$u[1]", "Richboro");if($posW){$u[2]="Richboro,PA";}

$posW = strpos("-$u[1]", "Buffalo, NY");     if($posW){$u[2]="Buffalo,NY";}
$posW = strpos("-$u[1]", "Lockwood, MT");    if($posW){$u[2]="Lockwood,MT";}  
$posW = strpos("-$u[1]", "Nashville, TN");   if($posW){$u[2]="Nashville,TN";} 
$posW = strpos("-$u[1]", "NYC BRONX");       if($posW){$u[2]="New York,NY";}  
$posW = strpos("-$u[1]", "RHODE ISLAND");    if($posW){$u[2]="Rhode Island,NY";}  

//West Lafayette. IN
$posW = strpos($stateTest, " IL ");
 if ($posW){
$posW = strpos("-$stateTest", "BLOOMINGTON");  if($posW){$u[2]="Bloomington,IL";} 
$posW = strpos("-$stateTest", "LINCOLN");      if($posW){$u[2]="Lincoln,IL";} 
$posW = strpos("-$stateTest", "VILLA RIDGE");  if($posW){$u[2]="Villa Ridge,IL";}  // Villa Ridge. IL
}

$posW = strpos($stateTest, " RI");
 if ($posW){
$posW = strpos("-$stateTest", "RIVERSIDE"); if($posW){$u[2]="Riverside,RI";}  
$posW = strpos("-$stateTest", "WARWICK");   if($posW){$u[2]="Warwick,RI";} 
$posW = strpos("-$stateTest", "PROVIDENCE");if($posW){$u[2]="East Providence,RI";} 
}



$posW = strpos($stateTest, " CA ");
 if ($posW){
$posW = strpos("-$stateTest", "BAKERSFIELD");  if($posW){$u[2]="Bakersfield,CA";} 
$posW = strpos("-$stateTest", "SAN JOSE");     if($posW){$u[2]="San Jose,CA";}
}
$posW = strpos("-$u[1]", "Bakersfield Ca");  if($posW){$u[2]="Bakersfield,Ca";}

$posW = strpos($stateTest, " FL");
 if ($posW){
 // Avon Park. Fl    Viera. FL
$posW = strpos("-$stateTest", "VIERA");       if($posW){$u[2]="Viera,FL";}  
$posW = strpos("-$stateTest", "AVON PARK");   if($posW){$u[2]="Avon Park,FL";}  
$posW = strpos("-$stateTest", "KISSIMMEE");   if($posW){$u[2]="Kissimmee,FL";}  
$posW = strpos("-$stateTest", "BLANTON");     if($posW){$u[2]="Blanton,FL";}  
$posW = strpos("-$stateTest", "BROOKSVILLE"); if($posW){$u[2]="Brooksville,FL";} 
$posW = strpos("-$stateTest", "PALMETTO");    if($posW){$u[2]="Palmetto,FL";}
$posW = strpos("-$stateTest", "SORRENTO")    ;if($posW){$u[2]="Sorrento,FL";}
$posW = strpos("-$stateTest", "APOPKA")      ;if($posW){$u[2]="Apopka,FL";}
$posW = strpos("-$stateTest", "TAMPA")       ;if($posW){$u[2]="Tampa,FL";}
$posW = strpos("-$stateTest", "ST CLOUD")    ;if($posW){$u[2]="St. Cloud,FL";}
$posW = strpos("-$stateTest", "LAKE WALES") ;if($posW){$u[2]="Lake Wales,FL";}
$posW = strpos("-$stateTest", "SEMINOLE")    ;if($posW){$u[2]="Seminole,FL";}
$posW = strpos("-$stateTest", "MELBOURNE")   ;if($posW){$u[2]="Melbourne,FL";}
$posW = strpos("-$stateTest", "SPRING HILL") ;if($posW){$u[2]="Spring Hill,FL";}
}
$posW = strpos("-$stateTest2", "SORRENTOxFL");  if($posW){$u[2]="Sorrento,FL";}
//$posW = strpos("-$u[1]", "South Dade");   if($posW){$u[2]="South Dade,FL";}
if ($u[0]==1604){$u[2]="Sorrento,FL";} 

$posW = strpos("-$stateTest", "YALAHA");    if($posW){$u[2]="Yalaha,FL";}
$posW = strpos("-$stateTest", "MINNEOLA");  if($posW){$u[2]="Minneola,FL";}
 
// MI test  MI
$posW = strpos($stateTest, " MI");
 if ($posW){
  $posW = strpos($stateTest, "ST JOSEPH")   ;if($posW){$u[2]="St. Joseph,MI";}
  $posW = strpos($stateTest, "GRAND RAPIDS");if($posW){$u[2]="Grand Rapids,MI";}
  $posW = strpos($stateTest, "OTTAWA LAKE"); if($posW){$u[2]="Ottawa Lake,MI";}  //Ottawa Lake. MI
  $posW = strpos($stateTest, "LAMBERTVILLE");if($posW){$u[2]="Lambertville,MI";} //Lambertville
  $posW = strpos($stateTest, "HOLLAND");     if($posW){$u[2]="Holland,MI";}
  $posW = strpos($stateTest, "CURTIS");      if($posW){$u[2]="Curtis,MI";}
  $posW = strpos($stateTest, "BATH");        if($posW){$u[2]="Bath,MI";}
  $posW = strpos($stateTest, "GAYLORD");     if($posW){$u[2]="Gaylord,MI";}		
}




// ID test
$posW = strpos($stateTest, " ID");
 if ($posW){   
  $posW = strpos($stateTest, "MOUNTAIN HOME");if($posW){$u[2]="Mountain Home,ID";} 
  $posW = strpos($stateTest, "BOISE")      ;if($posW){$u[2]="Boise,ID";}
  $posW = strpos($stateTest, "MERIDIAN")   ;if($posW){$u[2]="Meridian,ID";}
  $posW = strpos($stateTest, "NAMPA")      ;if($posW){$u[2]="Nampa,ID";}
  $posW = strpos($stateTest, "KUNA")       ;if($posW){$u[2]="Kuna,ID";}
}


// LA test
$posW = strpos($stateTest, " LA");
 if ($posW){
  $posW = strpos($stateTest, "LAKE CHARLES");if($posW){$u[2]="Lake Charles,LA";} 
  $posW = strpos("-$stateTest", "JACKSON") ; if($posW){$u[2]="Jackson,LA";}  // Jackson
  $posW = strpos("-$stateTest", "LACOMBE");  if($posW){$u[2]="Lacombe,LA";}      //Lacombe. LA  Lacombe. LA
  $posW = strpos($stateTest, "BATON ROUGE"); if($posW){$u[2]="Baton Rouge,LA";}  
  $posW = strpos($stateTest, "ROUGE");       if($posW){$u[2]="Baton Rouge,LA";}  
  $posW = strpos($stateTest, "LAFAYETTE");if($posW){$u[2]="Lafayette,LA";}  
  $posW = strpos($stateTest, "ALEXANDRIA");  if($posW){$u[2]="Alexandria,LA";}  
  $posW = strpos($stateTest, "RIDDER");      if($posW){$u[2]="De Ridder,LA";} 
  $posW = strpos($stateTest, "LEESVILLE");   if($posW){$u[2]="Leesville,LA";}   
  $posW = strpos($stateTest, "SLIDELL");     if($posW){$u[2]="Slidell,LA";} 
  $posW = strpos($stateTest, "BELLE CHASSE");if($posW){$u[2]="Belle Chasse,LA";}
}

$posW = strpos("-$stateTest2", "LFTxLA")     ;if($posW){$u[2]="Lafayette,LA";}
$posW = strpos("-$stateTest", "LFT")       ;
if($posW){
$posW = strpos("-$stateTest", "LA")       ;
if($posW){$u[2]="Lafayette,LA";}
}
if ($u[0] == 4507){$u[2]="Lafayette,LA";}
//if ($u[0] == 1167 or $u[0]==1195 or $u=1196 or $u=1197 ){$u[2]="south,LA";}

// IN test
$posW = strpos($stateTest, " IN");
 if ($posW){
$posW = strpos("-$stateTest", "WILLIAMSPORT");if($posW){$u[2]="Williamsport,IN";}
$posW = strpos("-$stateTest", "HAMMOND")     ;if($posW){$u[2]="Hammond,IN";}  //Hammond. IN
$posW = strpos("-$stateTest", "BURLINGTON")  ;if($posW){$u[2]="Burlington,IN";}
$posW = strpos("-$stateTest", "DAYTON")      ;if($posW){$u[2]="Dayton,IN";}
$posW = strpos("-$stateTest", "WEST LAFAYETTE");if($posW){$u[2]="West Lafayette,IN";}  
$posW = strpos("-$stateTest", "FRANKFORT");     if($posW){$u[2]="Frankfort,IN";}
}
//4030|West Lafayette GMRS Hub (WRNE507)
if ($u[0] == 4030 or $u[0] == 4260 or $u[0]==4262 or $u[0]== 4264){$u[2]="West Lafayette,IN";}
$posW = strpos("-$stateTest", "WEST LAFAYETTE");if($posW){$u[2]="West Lafayette,IN";}  // Gets a false detection from LA this fixes it

// TX test
$posW = strpos($stateTest, " TX");
 if ($posW){
//  $u[2]=",TX";  Temple, Tx Port Arthur Tx
  $posW = strpos("-$stateTest", "PORT ARTHUR")  ;if($posW){$u[2]="Port Arthur,Tx";} 
  $posW = strpos("-$stateTest", "TEMPLE")       ;if($posW){$u[2]="Temple,TX";} 
  $posW = strpos("-$stateTest", "WATAUGA")      ;if($posW){$u[2]="Watauga,TX";} 
  $posW = strpos("-$stateTest", "LAMPASAS")     ;if($posW){$u[2]="Lampasas,TX";} 
  $posW = strpos("-$stateTest", "EASTLAND")     ;if($posW){$u[2]="Eastland,TX";} //Eastland
  $posW = strpos($stateTest, "GRANBURY")        ;if($posW){$u[2]="Granbury,TX";} 
  $posW = strpos($stateTest, "WEATHERFORD")     ;if($posW){$u[2]="Weatherford,TX";}
  $posW = strpos($stateTest, "BELL COUNTY")     ;if($posW){$u[2]="Bell County,TX";}
  $posW = strpos($stateTest, "DUBLIN")          ;if($posW){$u[2]="Dublin,TX";}
  $posW = strpos($stateTest, "STEPHENVILLE")    ;if($posW){$u[2]="Stephenville,TX";} 
  $posW = strpos($stateTest, "PLANO");           if($posW){$u[2]="Plano,TX";}      //Plano. TX
  $posW = strpos($stateTest, "HUNTSVILLE");      if($posW){$u[2]="Huntsville,TX";}
  $posW = strpos($stateTest, "FARMERS BRANCH");  if($posW){$u[2]="Farmers Branch,TX";} 
  $posW = strpos($stateTest, "DALLAS");          if($posW){$u[2]="Dallas,TX";}  
  $posW = strpos($stateTest, "MINERAL WELLS");   if($posW){$u[2]="Mineral Wells,TX";}  
}
$posW = strpos("-$stateTest", "RIESEL RANCH");    if($posW){$u[2]="Riesel,TX";}
$posW = strpos("-$stateTest", "LAMPASAS");  if($posW){$u[2]="Lampasas,TX";}
$posW = strpos("-$stateTest", "LAVERNIA");  if($posW){$u[2]="La Vernia,TX";}
//Riesel, TX

//2159	Blind GMRS Haven. Plano. TX
if ($u[0] == 2159){$u[2]="Plano,TX";}


$posW = strpos("-$u[1]", "Malvern AR")      ;if($posW){$u[2]="Malvern,AR";} 
$posW = strpos("-$u[1]", "Malvern,AR")      ;if($posW){$u[2]="Malvern,AR";} 

// 51076	LRN Repeater - Cudahy. WI
if ($u[0] == 51076){$u[2]="Cudahy,WI";}
$posW = strpos("-$u[1]", "Cudahy. WI")      ;if($posW){$u[2]="Cudahy,WI";}
$posW = strpos("-$u[1]", "Rome, WI")        ;if($posW){$u[2]="Rome,WI";}  


}


// fix states
$state = explode(",",$u[2]);
// Extra error checking
if(!isset($state[0])){$state[0]="";}
if(!isset($state[1])){$state[1]="";}
$state[1] = strtoupper($state[1]);
$state[1] = str_replace(" ", "", $state[1]);
// $Statedata
// fix state names. Convert to proper abv
foreach($Statedata as $line){ 
$line = strtoupper($line); $line  = str_replace(" ", "", $line );
$uu = explode(",",$line); 
if ($uu[0]==$state[1]){$state[1]=$uu[1];break;} // Louisiana,LA
if ($uu[1]==$state[1]){ break;} // get some extra cpu cycles
}
$test = str_replace(" ", "", $state[0]);
// kludge for known typos. This is automatic will be skipped when fixed
if ($test=="Michigan"){    $state[1]="MI";}
if ($test=="SanAntonioTx"){$state[1]="TX";$state[0]="San Antonio";}
if ($test=="BuckeyeAz"){   $state[1]="AZ";$state[0]="Buckeye";}
if ($test=="AshevilleNC"){ $state[1]="NC";$state[0]="Asheville";}
if ($test=="PlanoTX"){     $state[1]="TX";$state[0]="Plano";}
if ($test=="ElkhartIn"){   $state[1]="IN";$state[0]="Elkhart";}
if ($test=="Thornton Tx"){ $state[1]="TX";$state[0]="Thornton";}
if ($test=="HOUSTON"){     $state[1]="TX";$state[0]="Houston";} // Fix upercase typos
$state[0]= ltrim( $state[0]);// Remove the leading spaces from the address
$u[2]= "$state[0],$state[1]"; 
$u[3] = strtoupper($u[3]); // convert all IDS to upercase   
$u[0]=trim($u[0]);
$u[1]=trim($u[1]);
$u[2]=trim($u[2]);
$u[3]=trim($u[3]); 
// (CLEAN up the fields)  2 = location 3 = call
$u[2] = str_replace("-", "", $u[2]);
$u[2] = str_replace("(", "", $u[2]);$u[2] = str_replace(")", "", $u[2]); 
$u[2] = str_replace("[", "", $u[2]);$u[2] = str_replace("]", "", $u[2]); 
$u[3] = str_replace("(", "", $u[3]);$u[3] = str_replace(")", "", $u[3]); 
$u[3] = str_replace("[", "", $u[3]);$u[3] = str_replace("]", "", $u[3]); 
// Pull this running node info out the nodelist and save it. 
if($u[0]==$node){ 
$file= "$path/node-name.txt";
if(!file_exists($file)){
$fileOUT00 = fopen($file, "w") ;flock( $fileOUT00, LOCK_EX );fwrite ($fileOUT00, "$u[0],$u[1],$u[2],$u[3],$u[4],\n");flock( $fileOUT00, LOCK_UN );fclose ($fileOUT00);
print"<$u[1] $u[2]>";// this is our info  (one time update)
 }
}
$count++;  if ($count % 1500 > 0 && $count % 1500 <= 10) {print".";}


//} // skips some but gives status

$antiDupe2 = str_replace(" ", "", $u[1]); 
$antiDupe2 = str_replace("-", "", $antiDupe2); 
$antiDupe2 = str_replace(".", "", $antiDupe2);
$antiDupe2 = str_replace("(", "", $antiDupe2); 
$antiDupe2 = str_replace(")", "", $antiDupe2);
$antiDupe2 = str_replace("[", "", $antiDupe2); 
$antiDupe2 = str_replace("]", "", $antiDupe2);

if ($antiDupe != $antiDupe2){
 $u[1]= str_replace(",", ".", $u[1]);
 fwrite ($fileOUT5,  "$u[0],$u[1],$u[2],$u[3],$u[4],\n");  // this creates the mapping geocode database
$antiDupe= $u[1];
$antiDupe = str_replace(" ", "", $antiDupe);
$antiDupe = str_replace("-", "", $antiDupe); 
$antiDupe = str_replace(".", "", $antiDupe);
$antiDupe = str_replace("(", "", $antiDupe); 
$antiDupe = str_replace(")", "", $antiDupe);
$antiDupe = str_replace("[", "", $antiDupe); 
$antiDupe = str_replace("]", "", $antiDupe);
  }  // this creates a list skipping blank loc
  
if ($u[2]==","){$u[2]="";}

               fwrite ($fileOUT,  "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|\n");
if($u[4]=="R"){fwrite ($fileOUT2, "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|\n");$countR++;}
if($u[4]=="H"){fwrite ($fileOUT3, "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|\n");$countH++;}
// Creates a list of live nodes for the connect box. Runs at night so must be 24hr
if($u[4]=="H"){
 if ($dnsScan){
   foreach($fileINdns as $lineDns){
    $lineDns = str_replace(" ", "", $lineDns);
    $uu = explode("=",$lineDns);
     if ($uu[0]==$u[0]){fwrite ($fileOUT4, "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|\n");$countC++;break;}
   }
  }// end dns scan
 }  
}  // if >1

}  // end for each loop
fclose($fileOUT);fclose($fileOUT2);fclose($fileOUT3);fclose($fileOUT4);fclose($fileOUT5);//fclose($fileOUT6);// we are finished close them all
$datum = date('[H:i:s]');$out="Building Nodelist Database Nodes:$count Bytes:$sizeN";save_task_log ($out); 
print "<ok>\n$datum Bytes:$sizeN Nodes:$count Repeaters:$countR Hubs:$countH/$countC \n";
}
else{$out="Missing Nodelist $nodelist";save_task_log ($out);print "$datum $out\n";}
}

