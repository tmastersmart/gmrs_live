#!/usr/bin/php
<?php
// (c)2023/2024 by WRXB288 and LAgmrs.com all rights reserved
//  /usr/bin/php
// Improved nodelist update with load sharing  (astdb.php  replacement)



// v6.0 8/24/24 Major rewrite for tht  nodelist starting over. 

$cron=false; $antiDupe=""; $copyright="wrxb288";
if (!empty($argv[1])) { 
 if ($argv[1] =="cron"){$cron=true;}
 }
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_start = $mtime;
$ver = "v6.0"; $release="8-24-2024";

$path       = "/etc/asterisk/local/mm-software";
$nodelistBU = "$path/nodelist/astdb.txt";
$privatefile= "/etc/asterisk/local/privatenodes.txt";
$nodelist   = "/var/log/asterisk/astdb.txt";
$flag2      = "/tmp/nodelist_updated.txt";
$dnsSnap    = "$path/nodelist/dns-snapshot.txt"; 
$pathNodelist = "$path/nodelist";if(!is_dir($pathNodelist)){ mkdir($pathNodelist, 0755);}

include_once ("$path/load.php");


$phpVersion= phpversion();
$datum   = date('m-d-Y H:i:s');
$gmdatum = gmdate('m-d-Y H:i:s');
print "
===================================================
GMRSLive Nodelist Update System  $coreVersion  $ver
(c)2023 WRXB288 LAGMRS.com all rights reserved
$phpzone PHP v$phpVersion   Release date:$release
===================================================
$datum Model: $piVersion
$datum Node:$node UTC:$gmdatum 
";

// If we have a backup install it.
if (!file_exists($nodelist)){
 $out="Nodelist is missing";save_task_log ($out);print"$datum $out\n";
 if (file_exists($nodelistBU)){
 rename($nodelistBU,$nodelist);
 copy($nodelist,$nodelistBU);
 }
 $out="Restoring nodelist from backup $nodelistBU";save_task_log ($out);print"$datum $out\n";
}

$update = true;
// only update if db is old  48 hrs min
if (file_exists($nodelist)){
 $ft = time()-filemtime($nodelist);
 if ($ft < 10 * 3600){
 $update=false; $fth=round($ft /3600);
 $out="Nodelist does not need update ($fth hrs) old.";save_task_log ($out);print"$datum $out\n";
 } 
}


$datum  = date('m-d-Y H:i:s');
// debugging
if (!$cron){ $out="Nodelist Manual Update";save_task_log ($out);print"$datum $out\n";$update = true;}

if ($update ){
$seconds = mt_rand(0, 1800); $min= round(($seconds / 60),0);
if($cron){$out="Nodelist. Sleep for $min min(s)";save_task_log ($out);print"$datum $out\n";
sleep($seconds);
}

// new looping code
$gzip=true;
for ($i = 0; $i < 3; $i++){

//http://register.gmrslive.com/cgi-bin/privatenodes.txt
$domain ="register.gmrslive.com"; $url = "/cgi-bin/privatenodes.txt"; 
$datum  = date('m-d-Y H:i:s');

print "$datum Polling Nodelist $domain \n";

function HandleHeaderLine( $curl, $header_line ) {
global $datum;
    print "$datum $header_line";
    return strlen($header_line);
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://$domain/$url");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
if ($gzip){curl_setopt($ch, CURLOPT_ENCODING, 'gzip');}
curl_setopt($ch, CURLOPT_TIMEOUT, 20);	 	
curl_setopt($ch, CURLOPT_HEADERFUNCTION, "HandleHeaderLine");
$html=curl_exec($ch);

 
curl_close($ch);


//$context = stream_context_create($options);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
//$html = @file_get_contents("http://$domain/$url",false,$context);
$datum  = date('m-d-Y H:i:s');
$deb = substr($html, 0, 20);print"$datum Received $deb \n";



//    [0] => HTTP/1.0 200 OK
//    [1] => Server: SimpleHTTP/0.6 Python/3.11.2
//    [2] => Date: Fri, 15 Mar 2024 22:17:26 GMT
//    [3] => Content-type: text/plain          
//           Content-Encoding: gzip
//    [4] => Content-Length: 182966
//    [5] => Last-Modified: Fri, 15 Mar 2024 14:01:03 GMT

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
test_data ($html);  
if ($trust >=3){break;}// stop the loop its good
sleep(30); // add a delay before retrying
$gzip=false;
}





$datum  = date('m-d-Y H:i:s');
if ($trust <=2 or !$trust2){line_end("ERROR BAD DATA");}

$contents="";
if (file_exists($privatefile)) {
// test for private nodes and erase the bad header
$fileIN= file($privatefile);$compile="";$i=0;
foreach($fileIN as $line){
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $pos = strpos($line, "Freq. or Description");  
  if (!$pos){
   $pos2 = strpos($line, "|"); 
    if($pos2){ $compile="$compile $line\n";$i++;}
    }
}
if ($i>=1){
$size = strlen($compile);
$out="Importing Private Nodes $size bytes";save_task_log ($out);print"$datum $out\n";
$contents .= $compile;
} 
// get rid of the trash. If this file has nothing but a header get rid of it
// Default image has a node 1000 header that we dont want to import.
// This looks to be a bug that could cause trouble for the real node 1000
else {unlink($privatefile);} 
}

$contents .= $html;
$contents = preg_replace('/[\x00-\x09\x0B-\x0C\x0E-\x1F\x7F-\xFF]/', '', $contents);

if(file_exists($nodelist)){
 if(file_exists($nodelistBU)){unlink($nodelistBU);}
 copy($nodelist,$nodelistBU);
} // keep backups

$fileOUT = fopen($nodelist,'w');fwrite ($fileOUT,$contents);fclose ($fileOUT);
$sizeN = strlen($contents);                                                           
//$out="Loading nodelist $size bytes";print"$datum $out\n";//save_task_log ($out);


// Do our own DNS update
$update2 = true;
//if (file_exists($dnsSnap)){
// $ft = time()-filemtime($dnsSnap);
// if ($ft < $dnsTIME * 3600){ $update2=false; $fth=round($ft /3600); } 
//}

if($update2){
//http://register.gmrslive.com/cgi-bin/nodes.pl
$domain ="register.gmrslive.com"; $url = "/cgi-bin/nodes.pl"; 
$datum  = date('m-d-Y H:i:s');
print "$datum Polling DNS >";
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "User-Agent: none\r\n" 
));
$context = stream_context_create($options);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$html = @file_get_contents("http://$domain/$url",false,$context);
//$html = gzinflate( substr($html,10,-8) ); 
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
//$fileOUT = fopen($dns,'w');fwrite ($fileOUT,$html);fclose ($fileOUT);// creates/updates the systems dns file
$fileOUT = fopen($dnsSnap,'w');fwrite ($fileOUT,$html);fclose ($fileOUT); // takes a snap of the dns
print " ok $dnsSnap\n";
}












// --------------------------------build database ----------------------------------
sort_nodes ("nodes"); // Builds the database

//include_once ("$path/purge_log.php"); // moved to midnight.php

$flag2      = "/tmp/nodelist_updated.txt"; if(file_exists($flag2)) {unlink($flag2);}
$fileOUT = fopen($flag2,'a+');fwrite ($fileOUT,"$datum updated Nodelist\n");fclose ($fileOUT);

//built_sounds ("ok"); // internal use to build sound files. tts must be setup

} // end update

include_once ("$path/version_check.php");

line_end("Line End");




function line_end($in){
global $trust,$poll_time,$trust2,$datum,$mtime,$script_end,$script_start,$soundDbWav,$soundDbGsm,$soundDbUlaw;

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_end = $mtime;$script_time = ($script_end - $script_start);$script_time = round($script_time,2);
$datum  = date('m-d-Y H:i:s');
$memory = memory_get_usage() ;$memory =formatBytes($memory);

print "$datum  [$in] Used:$memory $script_time Sec\n"; 
$tagline="";tagline($tagline);print "\n";
unset ($soundDbWav);
unset ($soundDbGsm);
unset ($soundDbUlaw);
print"===================================================\n";



}

//2955|Mike| - Louisiana
//2956|Mike| - Louisiana
//2957|Mike| - Louisiana
//2958|Mike| - Louisiana
//2959|Mike| - Louisiana
//TESTING .34567]<valid> Trust level:5 [0 Sec.]   [ERROR BAD DATA] Used:834.31KB 0.02 Sec
function test_data ($html){
global $trust,$poll_time,$trust2,$datum;
print"$datum TESTING .";
$trust=0;$trust2=false;$test=strtolower($html); 
$pos = strpos($test, "2955");if($pos){$trust++;      print"1";$trust2=true;}
$pos = strpos($test, "2957");if($pos){$trust++;      print"2";$trust2=true;}
$pos = strpos($test, "roadkill");if ($pos){$trust++;    print"3";} 
$pos = strpos($test, "do no edit");if ($pos){$trust++;  print"4";}
print"]";

  
if ($trust >=3){$out="<valid> Trust level:$trust [$poll_time Sec.]";save_task_log ($out);print"$out\n";}
else {$out="<not valid> Trust level:$trust [$poll_time Sec.]";save_task_log ($out);print"$out\n";}
}

//NODENAMES=/var/lib/asterisk/sounds/rpt/nodenames


// Custom to build node audio names.
// This code creates the sound files on production system. Not used on nodes
function built_sounds ($in){
global $path;
$datum  = date('m-d-Y H:i:s');
print "$datum Building HUB sound files >\n";

$soundPath="/var/lib/asterisk/sounds/rpt/nodenames"; 
chdir($soundPath);
$pathNode="$path/nodelist";
$nodelist3 =  "$pathNode/hubs.csv";
$fileIN= file($nodelist3);
natsort($fileIN); $i=0;
foreach($fileIN as $line){
 //Remove line feeds
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $line = str_replace("!", "|", $line);
  $line = str_replace("(", "|", $line);
  $line = str_replace("[", "|", $line);
  $line = str_replace("www", "|", $line);
  $line = str_replace("-", "|", $line);
   
$u = explode("|",$line);
$nodeName=$u[0]; $name=$u[1];
// use shorter names for text to speach
//if($name=="inactive"){continue;}
if($nodeName==4521){$name="Thrasher";}
if($nodeName==2329){$name="Oregon GMRS.org Main Hub";}
if($nodeName==1535){$name="GMRS.RADIO HUB";}
if($nodeName>=51010 and $nodeName<=51014){$name="South West Lousiana GMRS";} //  51010	SWLA GMRS - Lake Charles. La (WRVU907)	Lake Charles,LA	WRVU907
if($nodeName==700){$name="Nationwide Chat By GMRS Live";}


if($nodeName==900){$name="EMERGENCY Operations By GMRS Live";}
if($nodeName==921){$name="EMERGENCY Operations By BROADNET SYSTEMS";}
if($nodeName==923){$name="EMERGENCY Operations By South Dade GMRS";}
if($nodeName==924){$name="EMERGENCY Operations By The North Carolina Network";}
if($nodeName==925){$name="EMERGENCY Operations By Central Texas GMRS HUB";}
if($nodeName==926){$name="EMERGENCY Operations By The Road Kill Network";}
if($nodeName==927){$name="EMERGENCY Operations By The NC GMRS Network";}
if($nodeName==928){$name="EMERGENCY Operations By Ocean State GMRS";}

print "$datum processing $nodeName $name \n";

//if(file_exists("$soundPath/1195.ul")){unlink("$soundPath/1195.ul");}

if(file_exists("$soundPath/$nodeName.txt")){unlink("$soundPath/$nodeName.txt");}
if(!file_exists("$soundPath/$nodeName.ul") and $name<>"" and $i<=20){
$fileOUT  = fopen("$soundPath/$nodeName.txt",  "w");
fwrite ($fileOUT, "$name\n");
fclose($fileOUT);
print "$datum Building $nodeName $name $soundPath/$nodeName.txt\n";
exec ("tts_audio.sh $soundPath/$nodeName.txt",$output,$return_var);
unlink("$soundPath/$nodeName.txt");$i++;
  }
 }
}




function sort_nodes ($in){
global $beta,$path,$node,$datum,$cron,$sizeN,$dnsSnap;
//  $dnsSnap 
//  The purpose in this is to format a human readable index
// and keep all location data and calls in a standarized formats
//
// It is also to detect HUBS repeaters So they can be indexed seperatly
// In cases where the autodetect does not work manual kludges
// are needed.
//
// Some fields have problems with the wrong Delimiters and inconsistent
// formating that must be corrected for the directory to work 
//
// Please do not be upset that your data was adjusted it is only
// to format it for my index.
//
// This is a work in progress. And changes will likely be needed
// as many old fixes have been removed in the last months and 
// more added to keep the database clean.
//
// *    *  Have many nice days (c) 2023

$antiDupe="";$antiDupe2=""; $nodeDupe=""; $spin=0;
$Statedata= file("$path/states.csv");
$lastCall=""; $count=0; $countR=0;$countH=0;$countC=0;
$nodelist  =  "/var/log/asterisk/astdb.txt";
if(file_exists($nodelist)){

$pathNode="$path/nodelist";
if(!is_dir($pathNode)){ mkdir($pathNode, 0755);}
$fileINdns="";
if (file_exists($dnsSnap)){$fileINdns= file($dnsSnap);$dnsScan=true;}
else {$dnsScan=false;}
$nodelist2 = "$pathNode/dirty.csv";
$newfile  =  "$pathNode/clean.csv";
//newfile2 =  "$pathNode/repeaters.csv";
$newfile3 =  "$pathNode/hubs.csv"; //if (file_exists($newfile3)){unlink($newfile3);}
$newfile4 =  "$pathNode/hubs_online.csv";//if (file_exists($newfile4)){unlink($newfile4);}
$newfile5 =  "$pathNode/map_data.csv";//if (file_exists($newfile5)){unlink($newfile5);}
//$newfile6 =  "$pathNode/map_data2.csv";if (file_exists($newfile6)){unlink($newfile6);}

if (file_exists($nodelist2)){
$ft = time()-filemtime($nodelist2);
if($cron){if ($ft < 24 * 3600 ){return;}}
}

$datum  = date('m-d-Y H:i:s');
print "$datum Building Nodelist Database ";
copy($nodelist,$nodelist2); // make our own dirty backup

$fileOUT =fopen($newfile,  "w");
//$fileOUT2=fopen($newfile2, "w");
$fileOUT3=fopen($newfile3, "w");
$fileOUT4=fopen($newfile4, "w");
$fileOUT5=fopen($newfile5, "w");
//$fileOUT6=fopen($newfile6, "w");
fwrite ($fileOUT5,  "Node,Name,City,State,Call,Type,extra,\n");
//fwrite ($fileOUT6,  "Node,Name,City,State,Call, ,\n");

$fileIN= file($nodelist2);
natsort($fileIN);
foreach($fileIN as $line){
 //Remove line feeds
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $line = str_replace('"' , "", $line);// get rid of the quotes
  
$u = explode("|",$line);
// Extra error checking
if(!isset($u[0])){$u[0]="";}
if(!isset($u[1])){$u[1]="";}
if(!isset($u[2])){$u[2]="";}
if(!isset($u[3])){$u[3]="";}

//if(isset($u[4])){$u[1]="$u[1] - $u[4]";} // error checking for New fields
$u[4]="";$u[5]="";$u[6]="";// just blank these for my use. Change later

if (preg_match('#;.*$#m', $u[0]) || preg_match('#[+\-*/]#', $u[0])) {
    $u[0] = "";
}

if ($u[0]>1){

$nodeDupe = $u[0];

if ($u[1]==""){$u[5]="Null Name";}
if ($u[2]==""){$u[5]="Null State";}
// if all blank but call. call is not valid
//if ($u[1]=="" and $u[2]=="" and $u[3]<>""){$u[1]=$u[3];$u[3]="";$u[5]="< slide left";}


$u[2] = str_replace("-", "", $u[2]);
$u[2] = str_replace(".", "", $u[2]);




         








$test= "-$u[1] $u[2]";  $test= strtolower($test);
//$pos = strpos($test, "inactive");if ($pos){$u[0]=0;}

$u[4]="N"; // all default to a node

$pos = strpos($test, "repeater") ;if ($pos){$u[4]="R";}

// These are repeator freqs (may create mistakes)
$pos = strpos($test, "550"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "575"); if ($pos){$u[4]="R";}
$pos = strpos($test, "600"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "625"); if ($pos){$u[4]="R";}
$pos = strpos($test, "650"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "675"); if ($pos){$u[4]="R";}
$pos = strpos($test, "700"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "725"); if ($pos){$u[4]="R";} 

// HUB Detection do r first in case of "repeater hub"
$pos = strpos($test, "emergency") ;if ($pos){$u[4]="H";} 
$pos = strpos($test, "statewide") ;if ($pos){$u[4]="H";}
$pos = strpos($test, "nationwide");if ($pos){$u[4]="H";}  
$pos = strpos($test, "hub");       if ($pos){$u[4]="H";}
$pos = strpos($test, "cloud");     if ($pos){$u[4]="H";}
$pos = strpos($test, ".com");      if ($pos){$u[4]="H";}
$pos = strpos($test, "iax");      if ($pos){$u[4]="H";}
$pos = strpos($test, "zello");    if ($pos){$u[4]="H";}
$pos = strpos($test, "dvswitch"); if ($pos){$u[4]="H";}  
$pos = strpos($test, "dv switch");if ($pos){$u[4]="H";}  



$pos = strpos($test, "talk around");if ($pos){$u[4]="H";} 
$pos = strpos($test, "public")    ;if ($pos){$u[4]="R";} 


$pos = strpos($test, "moble");    if ($pos){$u[4]="N";}
$pos = strpos($test, "node");     if ($pos){$u[4]="N";}
$pos = strpos($test, "mobile");   if ($pos){$u[4]="N";} 
$pos = strpos($test, "inactive"); if ($pos){$u[4]="N";}  
$pos = strpos($test, "hotspot");  if ($pos){$u[4]="N";}
$pos = strpos($test, "simplex");  if ($pos){$u[4]="N";}


// Prevent these from being in hub repeater directory. Place them as nodes                                                    
$pos = strpos($test, "private");  if ($pos){$u[4]="N";}// delist private servers(mark as private?)
$pos = strpos($test, "personal"); if ($pos){$u[4]="N";}// delist PERSONAL

//$pos = strpos($test, "voip");     if ($pos){$u[4]="N";}// delist any VOIP 
// Hubs that fail autodect or are forced

if ($u[0]==611 or $u[0]==1876  or $u[0] == 1167 or $u[0] == 1195 or $u[0]==1196 or $u[0]==2460 or $u[0]==2505 or 
    $u[0]==2156 or $u[0]==50130 or $u[0]==4520 or $u[0]==1215 or $u[0]==4146 or $u[0]==4147
    ) {$u[4]="H";}
    
    
// updates as of 3/8/24 START     
// Nodes that fail auto detect
if ($u[0]== 750  or $u[0] == 1121 or $u[0] == 1122 or $u[0] == 1123 or $u[0] == 50930 or 
    $u[0] == 2978 or $u[0]== 1124 or $u[0] == 1150 or $u[0] == 1151 or $u[0] == 1152 or 
    $u[0] == 1153 or $u[0]== 1154 or $u[0] == 1926 or $u[0] == 1927 or $u[0] == 1928 or
    $u[0] == 2300 or $u[0]== 2340 or $u[0] == 3001 or $u[0] == 3008 or $u[0] == 31691 or
    $u[0] == 2244 or $u[0]== 2616 or $u[0] == 4190 or $u[0] == 4192 or $u[0] == 4800  or
    $u[0] == 51334or $u[0] == 51380) {
    $u[4]="N";}



// Format and correct the lone wolf system 
if ($u[0] == 1691){$u[4]="H";}// lone wolf hub
if ($u[0] == 1690){$u[4]="R";}// 1690	Lone Wolf Apopka, FL
if ($u[0] == 1925){$u[4]="R";}//1925	Lone Wolf St. Cloud	
if ($u[0] == 1053){$u[4]="R";}//1053	Pasco Simplex Node 462.550 -
if ($u[0] == 1330){$u[4]="R";}
if ($u[0] == 1602){$u[4]="R";}//1602	Lone Wolf System EPIC UNIV	
if ($u[0] == 1780){$u[4]="R";}//1780	Lone Wolf System Yalaha	  
if ($u[0] == 1781){$u[4]="R";}//1781	Lone Wolf System Minneola
if ($u[0] == 2135){$u[4]="R";}//2135	Lone Wolf Sys GMRS Somos Latinos Gainesville GA

if ($u[0] == 50796){$u[4]="R";$u[2]="Hammond,LA";}


if ($u[0] == 2957) {$u[1]="North Central Louisiana HUB";$u[4]="H";}
if ($u[0] == 51567) {$u[1]="Cajun Nation Hub";$u[4]="H";}
if ($u[0] == 51568) {$u[1]="Queens Hub";$u[4]="H";}








$count++;  if ($count % 1500 > 0 && $count % 1500 <= 10) {print".";}


//} // skips some but gives status

$antiDupe2 = preg_replace('/[ \-\.\(\)\[\]]/', '', $u[1]);


if ($antiDupe != $antiDupe2){
 $u[1]= str_replace(",", ".", $u[1]);
 fwrite ($fileOUT5,  "$u[0],$u[1],$u[2],$u[3],$u[4],$u[5],\n");  // this creates the mapping geocode database
 $antiDupe = preg_replace('/[ \-\.\(\)\[\]]/', '', $u[1]);
}  // this creates a list skipping blank loc
  
if ($u[2]==","){$u[2]="";}
$u[2] = trim($u[2]);

               fwrite ($fileOUT,  "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|$u[5]|\n");
// if($u[4]=="R"){fwrite ($fileOUT2, "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|$u[5]|\n");$countR++;}
if($u[4]=="H"){fwrite ($fileOUT3, "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|$u[5]|\n");$countH++;}
// Creates a list of live nodes for the connect box. Runs at night so must be 24hr
if($u[4]=="H"){
 if ($dnsScan){
   foreach($fileINdns as $lineDns){
    $lineDns = str_replace(" ", "", $lineDns);
    $uu = explode("=",$lineDns);
     if ($uu[0]==$u[0]){fwrite ($fileOUT4, "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|$u[5]|\n");$countC++;break;}
   }
  }// end dns scan
 }  
}  // if >1

}  // end for each loop
fclose($fileOUT);fclose($fileOUT3);fclose($fileOUT4);fclose($fileOUT5);//fclose($fileOUT6);// we are finished close them all
$datum = date('[H:i:s]');$out="Building Nodelist Database Nodes:$count Bytes:$sizeN";save_task_log ($out); 
print "<ok>\n$datum Bytes:$sizeN Nodes:$count Repeaters:$countR Hubs:$countH/$countC \n";
}
else{$out="Missing Nodelist $nodelist";save_task_log ($out);print "$datum $out\n";}
}

