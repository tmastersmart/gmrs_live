#!/usr/bin/php
<?php
// (c)2023  lagmrs.com
//
// Improved nodelist update with load sharing 
// Much improved random load sharing.
// Creates a clean index for supermon
// cleans the private nodelist
//
// http://register.gmrslive.com/cgi-bin/privatenodes.txt
// /var/log/asterisk/astdb.txt 
// astdb.php  replacement and upgrade
//
// Filtering hubs from repeaters from nodes is a ongoing process
// This will require updates and the automated process still needs kludges
$cron=false;
if (!empty($argv[1])) { 
 if ($argv[1] =="cron"){$cron=true;}
 }
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_start = $mtime;
$ver = "v2.8"; $release="09-23-2023";

$path       = "/etc/asterisk/local/mm-software";
$nodelistBU = "$path/nodelist/astdb.txt";
$privatefile= "/etc/asterisk/local/privatenodes.txt";
$nodelist   = "/var/log/asterisk/astdb.txt";

include_once ("$path/load.php");


$phpVersion= phpversion();
$datum   = date('m-d-Y H:i:s');
$gmdatum = gmdate('m-d-Y H:i:s');
print "
===================================================
GMRSLive Nodelist Update System  $coreVersion  $ver
(c)2023 WRXB288 LAGMRS.com all rights reserved
$phpzone PHP v$phpVersion   Release date:$release
===================================================
$datum Model: $piVersion
$datum Node:$node UTC:$gmdatum 
";


$update = true;
// only update if db is old  48 hrs min
if (file_exists($nodelist)){
 $ft = time()-filemtime($nodelist);
 if ($ft < 24 * 3600){
 $update=false; $fth=round($ft /3600);
 $out="Nodelist does not need update ($fth hrs) old.";save_task_log ($out);print"$datum $out\n";
 } 
}

$datum  = date('m-d-Y H:i:s');
// debugging
if (!$cron){ $out="Nodelist Manual Update";save_task_log ($out);print"$datum $out\n";$update = true;}

if ($update ){
$seconds = mt_rand(0, 1800); $min= round(($seconds / 60),0);
if($cron){$out="Nodelist. Sleep for $min min(s)";save_task_log ($out);print"$datum $out\n";
sleep($seconds);
}

//http://register.gmrslive.com/cgi-bin/privatenodes.txt
$domain ="register.gmrslive.com"; $url = "/cgi-bin/privatenodes.txt"; 
$datum  = date('m-d-Y H:i:s');
print "$datum Polling $domain >";
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-Encoding: gzip\r\n" 
));
$context = stream_context_create($options);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$html = @file_get_contents("http://$domain/$url",false,$context);
$html = gzinflate( substr($html,10,-8) ); 
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
test_data ($html);  


if ($trust ==0){ // try again gzip off
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "User-Agent: none\r\n" 
));
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$datum  = date('m-d-Y H:i:s');print "$datum Polling 2 $domain >";
$html = @file_get_contents("http://$domain/$url",false,$context);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
test_data ($html);
}

if ($trust ==0){// try again
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$datum  = date('m-d-Y H:i:s');print "$datum Polling 3 $domain >";
$html = @file_get_contents("http://$domain/$url",false,$context);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
test_data ($html);
}

$datum  = date('m-d-Y H:i:s');
if ($trust ==0){line_end("ERROR BAD DATA");}


$contents="";


if (file_exists($privatefile)) {
// test for private nodes and erase the bad header
$fileIN= file($privatefile);$compile="";$i=0;
foreach($fileIN as $line){
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $pos = strpos($line, "Freq. or Description");  
  if (!$pos){
   $pos2 = strpos($line, "|"); 
    if($pos2){ $compile="$compile $line\n";$i++;}
    }
}
if ($i>=1){
$size = strlen($compile);
$out="Importing Private Nodes $size bytes";save_task_log ($out);print"$datum $out\n";
$contents .= $compile;
} 
// get rid of the trash. If this file has nothing but a header get rid of it
// Default image has a node 1000 header that we dont want to import.
// This looks to be a bug that could cause trouble for the real node 1000
else {unlink($privatefile);} 
}

$contents .= $html;
$contents = preg_replace('/[\x00-\x09\x0B-\x0C\x0E-\x1F\x7F-\xFF]/', '', $contents);

if(file_exists($nodelist)){copy($nodelist,$nodelistBU);} // keep backups

$fileOUT = fopen($nodelist,'w');fwrite ($fileOUT,$contents);fclose ($fileOUT);
$size = strlen($contents);
$out="Saving new nodelist $size bytes";save_task_log ($out);print"$datum $out\n";
sort_nodes ("nodes"); 
//built_sounds ("ok"); // internal use to build sound files. tts must be setup

} // end update

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_end = $mtime;$script_time = ($script_end - $script_start);$script_time = round($script_time,2);
$datum  = date('m-d-Y H:i:s');
$memory = memory_get_usage() ;$memory =formatBytes($memory);

print "$datum ";$tagline="";tagline($tagline);print "\n";

print "$datum  [Line end] Used:$memory $script_time Sec\n";
unset ($soundDbWav);
unset ($soundDbGsm);
unset ($soundDbUlaw);
print"===================================================\n";


function test_data ($html){
global $trust,$poll_time;
$trust = 0;
$pos = strpos($html, "GMRSLive.com");if ($pos){$trust++;}
$pos = strpos($html, "RoadKill");if ($pos){$trust++;}
$pos = strpos($html, "Do No Edit");if ($pos){$trust++;}
$pos = strpos($html, "WRXB288");if ($pos){$trust++;}
$pos = strpos($html, "WRXN291");if ($pos){$trust++;}
$pos = strpos($html, "WROY524");if ($pos){$trust++;}
$pos = strpos($html, "WRTL610");if ($pos){$trust++;}
$pos = strpos($html, "WRNS719");if ($pos){$trust++;}
$pos = strpos($html, "WRFT828");if ($pos){$trust++;}
$pos = strpos($html, "Texas GMRS Network");if ($pos){$trust++;}
// good trust should be >9 If its not we are not on GMRS Live Or the server gave us bad data   
if ($trust >=3){$out="<ok> Trust level:$trust [$poll_time Sec.]";save_task_log ($out);print"$out\n";}

else {$out="<error> trust:$trust [$poll_time Sec.]";save_task_log ($out);print"$out\n";}
}

//NODENAMES=/var/lib/asterisk/sounds/rpt/nodenames


// Custom to build node audio names.
function built_sounds ($in){
global $path;
$datum  = date('m-d-Y H:i:s');
print "$datum Building HUB sound files >\n";

$soundPath="/var/lib/asterisk/sounds/rpt/nodenames"; 
chdir($soundPath);
$pathNode="$path/nodelist";
$nodelist3 =  "$pathNode/hubs.csv";
$fileIN= file($nodelist3);
natsort($fileIN); $i=0;
foreach($fileIN as $line){
 //Remove line feeds
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $line = str_replace("!", "|", $line);
  $line = str_replace("(", "|", $line);
  $line = str_replace("[", "|", $line);
  $line = str_replace("www", "|", $line);
  $line = str_replace("-", "|", $line);
   
$u = explode("|",$line);
$nodeName=$u[0]; $name=$u[1];
if($nodeName==1195){$name="The Roadkill network";}
if($nodeName==1167){$name="Roadkill DV Switch";}

if($nodeName==700){$name="Nationwide Chat	By GMRS Live";}
if($nodeName==1196){$name="EMERGENCY Operations By Roadkill";}
if($nodeName==900){$name="EMERGENCY Operations By GMRS Live";}
if($nodeName==921){$name="EMERGENCY Operations By BROADNET SYSTEMS";}
if($nodeName==922){$name="EMERGENCY Operations By Texas GMRS Network";}
if($nodeName==923){$name="EMERGENCY Operations By South Dade GMRS";}
print "$datum processing $nodeName $name \n";


if(file_exists("$soundPath/$nodeName.txt")){unlink("$soundPath/$nodeName.txt");}
if(!file_exists("$soundPath/$nodeName.ul") and $name<>"" and $i<=20){
$fileOUT  = fopen("$soundPath/$nodeName.txt",  "w");
fwrite ($fileOUT, "$name\n");
fclose($fileOUT);
print "$datum Building $nodeName $name $soundPath/$nodeName.txt\n";
exec ("tts_audio.sh $soundPath/$nodeName.txt",$output,$return_var);
unlink("$soundPath/$nodeName.txt");$i++;
}
}

}
function sort_nodes ($in){
global $beta,$path,$node,$datum,$cron;
//
//  The purpose in this is to format a human readable index
// and keep all location data and calls in a standarized formats
//
// It is also to detect HUBS repeaters So they can be indexed seperatly
// In cases where the autodetect does not work manual kludges
// are needed.
//
// Some fields have bugs with the wrong Delimiters and must be
// corrected for the directory to work 
//
// Please do not be upset that your data was adjusted it is only
// to format it for the index.
//
// This is a work in progress. And changes will likely be needed
// as many old fixes have been removed in the last months and 
// more added to keep the database clean.
//
// *    *  Have many nice days (c) 2023
$Statedata= file("$path/states.csv");
$lastCall=""; $count=0; $countR=0;$countH=0;$countC=0;
$nodelist  =  "/var/log/asterisk/astdb.txt";
if(file_exists($nodelist)){

$pathNode="$path/nodelist";
if(!is_dir($pathNode)){ mkdir($pathNode, 0755);}
$dns = "/tmp/rpt_extnodes";
$nodelist2 = "$pathNode/dirty.csv";
$newfile  =  "$pathNode/clean.csv";
$newfile2 =  "$pathNode/repeaters.csv";
$newfile3 =  "$pathNode/hubs.csv";
$newfile4 =  "$pathNode/hubs_online.csv";

if (file_exists($nodelist2)){
$ft = time()-filemtime($nodelist2);
if($cron){if ($ft < 24 * 3600 ){return;}}
}

$datum = date('[H:i:s]');$out="Saving Supermon Index Database";save_task_log ($out); 
print "$datum $out";
copy($nodelist,$nodelist2); // make our own dirty backup

$fileOUT4=fopen($newfile4, "w");$fileOUT3=fopen($newfile3, "w");
$fileOUT2=fopen($newfile2, "w");$fileOUT=fopen($newfile,  "w");

$fileINdns= file($dns);
$fileIN= file($nodelist2);
natsort($fileIN);
foreach($fileIN as $line){
 //Remove line feeds
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  
$u = explode("|",$line);

// Extra error checking
if(!isset($u[0])){$u[0]="";}
if(!isset($u[1])){$u[1]="";}
if(!isset($u[2])){$u[2]="";}
if(!isset($u[3])){$u[3]="";}
if(!isset($u[4])){$u[4]="";}



$u[2] = str_replace("-", "", $u[2]);// remove from address

//  using() instead of []

$u[2] = str_replace("(", "[", $u[2]);$u[2] = str_replace(")", "]", $u[2]); 
$u[3] = str_replace("(", "", $u[3]);$u[3] = str_replace(")", "", $u[3]); 


$test= "-$u[1] $u[2]";  $test= strtolower($test);
$pos = strpos($test, "inactive");if ($pos){$u[0]=0;}
 

if ($u[0]>1){  
// if no call then its a repeater or a HUB- Guess HUB
if (!$u[3]){$u[4]="H";} 

// Auto Create the type field
//1195	The RoadKill !! Repeater System	Baton Rouge,LA		H
$pos = strpos($test, "repeater") ;if ($pos){$u[4]="R";}
$pos = strpos($test, "roadkill") ;if ($pos){$u[4]="R";}
$pos = strpos($test, "road kill");if ($pos){$u[4]="R";}
$pos = strpos($test, "statewide");if ($pos){$u[4]="H";}
$pos = strpos($test, "hub");      if ($pos){$u[4]="H";}
$pos = strpos($test, "cloud");    if ($pos){$u[4]="H";}
$pos = strpos($test, "node");     if ($pos){$u[4]="N";}
$pos = strpos($test, "iax");      if ($pos){$u[4]="H";}
$pos = strpos($test, "zello");    if ($pos){$u[4]="H";}
$pos = strpos($test, "moble");    if ($pos){$u[4]="N";}
$pos = strpos($test, "mobile");   if ($pos){$u[4]="N";} 
//$pos = strpos($test, "dvswitch"); if ($pos){$u[4]="H";}
$pos = strpos($test, "emergency");if ($pos){$u[4]="H";}  
$pos = strpos($test, "inactive"); if ($pos){$u[4]="N";}  

// These are repeator freqs (may create mistakes)
$pos = strpos($test, "550"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "575"); if ($pos){$u[4]="R";}
$pos = strpos($test, "600"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "625"); if ($pos){$u[4]="R";}
$pos = strpos($test, "650"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "675"); if ($pos){$u[4]="R";}
$pos = strpos($test, "700"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "725"); if ($pos){$u[4]="R";} 


// Hubs that fail autodect
if ($u[0] == 1195){$u[4]="H";}
if ($u[0] == 1167){$u[4]="H";}


//Mobile Client Hub Node   not T&K Repeater	Palmetto,FL
if ($u[0] == 1000 ){ $u[1]="Mobile Client Hub Node TX";$u[2]="";$u[3]="";$u[4]="H";}
 
// repeaters. that fail autodetect
if ($u[0] == 1053){$u[4]="R";}


// Nodes that fail audo detect
if ($u[0] == 1120){$u[4]="N";}
if ($u[0] == 1121){$u[4]="N";}
if ($u[0] == 1122){$u[4]="N";}
if ($u[0] == 1123){$u[4]="N";}
if ($u[0] == 1124){$u[4]="N";}

if ($u[0] == 1150){$u[4]="N";}
if ($u[0] == 1151){$u[4]="N";}
if ($u[0] == 1152){$u[4]="N";}
if ($u[0] == 1153){$u[4]="N";}
if ($u[0] == 1154){$u[4]="N";}

if ($u[0] == 1926){$u[4]="N";}
if ($u[0] == 1927){$u[4]="N";}
if ($u[0] == 1928){$u[4]="N";}

if ($u[0] == 2300){$u[4]="N";}
if ($u[0] == 2340){$u[4]="N";}// 	DDB HS625 Hotspot	Sutherlin,OR	WRTX950

if ($u[0] == 3001){$u[4]="N";} // 3001	Tony - Palmetto Fl
if ($u[0] == 3008){$u[4]="N";} // 3008	Kirby - GMRS Live Network Assistant

// Format the lone wolf system to seperate repeaters  
if ($u[0] == 1691){$u[4]="H";}// lone wolf hub
if ($u[0] == 1690){$u[4]="R";}// 1690	Lone Wolf Apopka, FL
if ($u[0] == 1925){$u[4]="R";}//1925	Lone Wolf St. Cloud	
if ($u[0] == 1053){$u[4]="R";}//1053	Pasco Simplex Node 462.550 -
if ($u[0] == 1602){$u[4]="R";}//1602	Lone Wolf System EPIC UNIV	
if ($u[0] == 1780){$u[4]="R";}//1780	Lone Wolf System Yalaha	  
if ($u[0] == 1781){$u[4]="R";}//1781	Lone Wolf System Minneola
if ($u[0] == 2135){$u[4]="R";}//2135	Lone Wolf Sys GMRS Somos Latinos Gainesville GA


// Texas GMRS data 2250 - 2267 are corrupted. 
// 1 is blank 2 contains the data that should  be in 1
//2250||Texas GMRS Network - Statewide Link|
//2251||North Texas Hub|
//2252||South Texas Hub|
//2253||East Texas Hub|
//2254||West Texas Hub|
//2255||Memorial Park 550 Repeater|
//2256||Northwest Houston 725 Repeater|
//2257||Channelview 675 Repeater|
//2258||Dallas County REACT 675 Repeater|
//2259||Lufkin 725 Repeater|
//2260||Dickinson 650 Repeater|
//2261||La Marque 700 Repeater|
//2262||Montgomery 600 Repeater|
//2263||Conroe 700 Repeater|
//2264||La Grange 725 Repeater|
//2265||Lubbock 700 Repeater|
//2266||Sugar Land 600 Repeater|
//2267||Chappell Hill 650 Repeater|
//2268||Amarillo 650 Repeater|  

// 2557||Idaho Hub|Pacific NorthWest Network|WRTX950
// PACIFIC NORTHWEST NETWORK is in the CALL field
if($u[0]==2557){
 if ($u[1]==""){$u[1]=$u[2];$u[2]=$u[3];$u[3]=$u[4]="";$u4="H";}
}
//slide over data to fix corruped entries above


if ($u[0] >=2250 and $u[0]<=2268){ 
 if ($u[1]==""){$u[1]=$u[2];$u[2]="";$u[3]="";}
} // make it automatic so when fixed it will skip

// Whats this 10,12,13,2978 also blank
if ($u[1]==""){$u[1]="inactive";$u[4]= "N";}// No named node?????


// reformat Known nodes that have descriptions in location field
if($u[0]==700 or $u[0]==750  or $u[0]==900  or $u[0]==921  or $u[0]==922  or
   $u[0]==923 or $u[0]==1535 or $u[0]==2555 or $u[0]==2556 or $u[0]==2557 or $u[0]==2558 or 
   $u[0]==2559or $u[0]==2225 or $u[0]==2226 or $u[0]==2227 or $u[0]==2228 or $u[0]==2229 or
   $u[0]==1809or $u[0]==1890 or $u[0]==1891 or $u[0]==1892 or $u[0]==1893 or $u[0]==1894 
   ) {$u[1]="$u[1] - $u[2]";$u[2]="";$u[4]="H";}

//1920|WRQU236|- Florence 625 - Florence, SC|
if ($u[0]==1920){$u[1]="Florence 625 / WRQU236";$u[2]="Florence,SC";$u[3]="";}


//2461|James - Cromwell, IN (WROY240)
//2462|James / Radio-less Node (WROY240)
//2463|Sparta 600 Repeater (WROY240)
//2464|James Sparta 600 Zello (WROY240)

if ($u[0]==2461 or $u[0]==2462 or $u[0]==2463 or $u[0]==2464){$u[2]="Cromwell,IN";$u[3]="(WROY240)";}
if ($u[0] == 2461){$u[4]="N";}


//1105|HOT SPOT|Ottawa Lake,MI||N|
//1106|Bob|Ottawa Lake,MI|WRJT765||
//1107|Bob|Ottawa Lake,MI|WRJT765||
//1108|Bob|Ottawa Lake,MI|WRJT765||
//1109|Bob|Ottawa Lake,MI|WRJT765||
if ($u[0]==1105){$u[3]="WRJT765";$u[4]= "N";}

//1805|Irish *Hotspot*|- Cutler Bay, FL|(WROY605)
//1806|South Dade GMRS Club Hub
//1807|South Dade 650 Repeater|- Cutler Bay, FL
//1808|Irish *IAX*|- Culter Bay,FL|(WROY605)
//1809|Florida Hub| - South Dade GMRS	

//4405|Holger / herman the german| - Meridian, ID| (WROM586)
//4406|Holger / herman the german| - Meridian, ID| (WROM586)
//4407|Holger / herman the german| - Meridian, ID| (WROM586)
//4408|SW Idaho GMRS Hub
//4409|Holger \ herman the german -Meridian, Idaho wrom586 
// Coruption detected
// Not sure is this a hub or a node?  I think its a node. 
if ($u[0]==4409){$u[2]="Meridian,ID";$u[3]="[WROM586]";$u[4]="N";} 

//2080	Jeffrey	Mobile	WRTY487
//2081	Jeffrey	Harrisonville,MO	WRTY487
if ($u[0]==2080){$u[1]="$u[1] - $u[2]";$u[2]="Harrisonville,MO";} 




// Cap doug all messed up. Being detected as a HUB 
//2300|CAPTAIN DOUG WROY 524|||H
//2301|Doug|Denham Spring,LA|WROY524|
if($u[0]==2300){$u[2]="Denham Spring,LA";$u[3]="[WROY524]";$u[4]="N";}

//1040|Thomas,- Hammond, IN|(WRCW750)
//1041|Thomas,- Hammond, IN|(WRCW750)
//1042|Thomas|- Hammond, IN|(WRCW750)
//1043|Thomas|- Hammond, IN|(WRCW750)
//1044|Thomas|- Hammond, IN|(WRCW750)

// 1040 and 1041 have the wrong field have a , in place of a | 
// TBR if fixed
if ($u[0] ==1040 or $u[0] ==1041){$u[1]="Thomas";$u[2]="Hammond,IN";$u[3]="[WRCW750]";$u[4]="N";}




// pull id from the first field and put in 3 
$posL = strpos($u[1], "[W"); 
if ($posL>=1){
    $test = explode("[",$u[1]);$id= explode("]",$test[1]);
    $size= strlen($id[0]);
    if ($size <=8){$u[3]="[$id[0]]";} 
    }
     
// pull id from the first field and put in 3 
$posL = strpos($u[1], "(W"); 
if ($posL>=1){
    $test = explode("(",$u[1]);$id= explode(")",$test[1]);
    $size= strlen($id[0]);
    if ($size <=8){$u[3]="[$id[0]]";} 
    }
         
// FIX IDs in the wrong fields 
$posL = strpos("-$u[2]", "[W"); 
if ($posL>=1){
    $u[2]=str_replace("[", "", $u[2]);
    $u[2]=str_replace("]", "", $u[2]); 
    $u[2]=trim($u[2]);
    $u[3]="[$u[2]]";$u[2]="";
    }
    

 

// fix for city state not in location field
$posW = strpos("-$u[1]", "Bloomington IL");if($posW){$u[2]="Bloomington,IL";} 
$posW = strpos("-$u[1]", "Lacombe, LA");   if($posW){$u[2]="Lacombe,LA";}
$posW = strpos("-$u[1]", "Bakersfield Ca");if($posW){$u[2]="Bakersfield,CA";} 
$posW = strpos("-$u[1]", "Lincoln IL");    if($posW){$u[2]="Lincoln,IL";} 
$posW = strpos("-$u[1]", "Tampa FL");      if($posW){$u[2]="Tampa,FL";} 
$posW = strpos("-$u[1]", "San Jose, Ca");  if($posW){$u[2]="San Jose,Ca";}
$posW = strpos("-$u[1]", "Baton Rouge,LA");if($posW){$u[2]="Baton Rouge,LA";}
 



// fix states
$state = explode(",",$u[2]);
// Extra error checking
if(!isset($state[0])){$state[0]="";}
if(!isset($state[1])){$state[1]="";}
$state[1] = strtoupper($state[1]);
$state[1] = str_replace(" ", "", $state[1]);
// $Statedata
// fix state names. Convert to proper abv
foreach($Statedata as $line){ 
$line = strtoupper($line); $line  = str_replace(" ", "", $line );
$uu = explode(",",$line); 
if ($uu[0]==$state[1]){$state[1]=$uu[1];break;} // Louisiana,LA
if ($uu[1]==$state[1]){ break;} // get some extra cpu cycles
}
$test = str_replace(" ", "", $state[0]);
// kludge for known typos. This is automatic will be skipped when fixed
if ($test=="Michigan"){    $state[1]="MI";$state[0]="";}
if ($test=="SanAntonioTx"){$state[1]="TX";$state[0]="San Antonio";}
if ($test=="BuckeyeAz"){   $state[1]="AZ";$state[0]="Buckeye";}
if ($test=="AshevilleNC"){ $state[1]="NC";$state[0]="Asheville";}
if ($test=="PlanoTX"){     $state[1]="TX";$state[0]="Plano";}
if ($test=="ElkhartIn"){   $state[1]="IN";$state[0]="Elkhart";}
if ($test=="Thornton Tx"){ $state[1]="TX";$state[0]="Thornton";}
$state[0]= ltrim( $state[0]);// Remove the leading spaces from the address
if($state[1]){  $u[2]= "$state[0],$state[1]";  } // cleaned up 
$u[3] = strtoupper($u[3]); // convert all IDS to upercase   
$u[0]=trim($u[0]);
$u[1]=trim($u[1]);
$u[2]=trim($u[2]);
$u[3]=trim($u[3]); 
$u[3] = str_replace("[", "", $u[3]);$u[3] = str_replace("]", "", $u[3]); 

// Pull this nodes info out the nodelist. 
if($u[0]==$node){ 
$file= "$path/node-name.txt";
if(!file_exists($file)){
$fileOUT5 = fopen($file, "w") ;flock( $fileOUT5, LOCK_EX );fwrite ($fileOUT5, "$u[0],$u[1],$u[2],$u[3],$u[4],\n");flock( $fileOUT5, LOCK_UN );fclose ($fileOUT5);
print"<$u[1] $u[2]>";
 }
}

$count++;
               fwrite ($fileOUT,  "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|\n");
if($u[4]=="R"){fwrite ($fileOUT2, "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|\n");$countR++;}
if($u[4]=="H"){fwrite ($fileOUT3, "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|\n");$countH++;
$live=false;
foreach($fileINdns as $lineDns){
 $lineDns = str_replace(" ", "", $lineDns);
 $uu = explode("=",$lineDns);
 if ($uu[0]==$u[0]){$live=true;break;}
}
if($live){fwrite ($fileOUT4, "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|\n");$countC++;}// Builds a active nodelist
  }
 }
}
fclose($fileOUT);fclose($fileOUT2);fclose($fileOUT3);fclose($fileOUT4); 

print "<ok> Nodes:$count Repeaters:$countR Hubs:$countH Hubs Online:$countC\n";

// chart logging module
$time= date('H:i');
$date =  date('m-d-Y');
$datum   = date('m-d-Y H:i:s');
$pathChart="$path/charts";
if(!is_dir($pathChart)){ mkdir($pathChart, 0755);}
$file = "$pathChart/nodes.dat"; $fileOUT = fopen($file,'a+');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$time $count \r\n"); flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
$file = "$pathChart/online.dat";$fileOUT = fopen($file,'a+');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$time $countC \r\n"); flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
print "$datum Chart data saved\n";

$file="$path/version.txt";  // get current version

$update=true;
if (file_exists($file)){
 $ft = time()-filemtime($file);
 if ($ft < 120 * 3600){$update=false; } // about 5 days
}

if ($update ){

$domain ="raw.githubusercontent.com"; $url = "/tmastersmart/gmrs_live/main/version.txt"; 
$datum  = date('m-d-Y H:i:s');
print "$datum Getting Update Info $domain >";
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-Encoding: gzip\r\n" 
));
$context = stream_context_create($options);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$html = @file_get_contents("https://$domain/$url",false,$context);
$html = gzinflate( substr($html,10,-8) ); 
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
print"$html";
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$html\r\n"); flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
}

}

else{$out="Missing Nodelist $nodelist";save_task_log ($out);print "$datum $out\n";}


}

