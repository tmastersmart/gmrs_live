#!/usr/bin/php
<?php
// (c)2023/2024 by WRXB288 and LAgmrs.com all rights reserved
//  /usr/bin/php
// Improved nodelist update with load sharing  (astdb.php  replacement)
// Much improved random load sharing.
// 
// With its own DNS database  
//
// For now this includes Kludges to correct errors in the nodelist 
//and to identify hubs and repeators. Ongoing updates will be needed
//if you see a error please notify me.
//
//
// v2.9 10-17-23  Changes to restore from backup if nodelist not found.
// v3.0 10-18-23  Tweaking hub detection
// v3.1 10-26-23
// v3.2 10-30-23  Changes mode corrections and cleaning
// v3.3 11-22-23  Added semore files 
// v3.4 11-28-23  Chart data tmp removed 
// v3.5 12-10-23  FIXES and new Live hub index for connection page
// v3.6 12-16-23  Cleanup some failed hub and node detections
// v3.7 12-17-23  trim out " unsafe
// v3.8 12-27-23  autodetect tweeking
// v4.0 1/5/24  Tweeks and slight bug fix 
// v4.1 1/14/24
// v4.3 1/26     Normal tweeks
// v4.3 -------2/23
// v4.4        2/25/24    Creates our own DNS database.
// v4.7        3/14/24
// v4.8 3/15  Fix for the server turning off gzip compression. GZIP now detected 
// v4.9 3/20  Total rewrite for curl to fix gzip falures.
// v5.0 4/5   changed timinmg
// v5.1 5/2   Monthly updates Bug fixed where nodelist gets erased before testing if its aged out
// v5.6 6/3   Protection for calls having bad data must fit the fcc format size 8  and last 3 numbers. 
// v5.7 6/9/24  Rewrite Extra checking for all fields 
//              Error detection to move data to correct fields.
// v5.8 6/25  new hubs added

$cron=false; $antiDupe=""; $copyright="wrxb288";
if (!empty($argv[1])) { 
 if ($argv[1] =="cron"){$cron=true;}
 }
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_start = $mtime;
$ver = "v5.8"; $release="6-25-2024";

$path       = "/etc/asterisk/local/mm-software";
$nodelistBU = "$path/nodelist/astdb.txt";
$privatefile= "/etc/asterisk/local/privatenodes.txt";
$nodelist   = "/var/log/asterisk/astdb.txt";
$flag2      = "/tmp/nodelist_updated.txt";
$dnsSnap    = "$path/nodelist/dns-snapshot.txt"; 
$pathNodelist = "$path/nodelist";if(!is_dir($pathNodelist)){ mkdir($pathNodelist, 0755);}

include_once ("$path/load.php");


$phpVersion= phpversion();
$datum   = date('m-d-Y H:i:s');
$gmdatum = gmdate('m-d-Y H:i:s');
print "
===================================================
GMRSLive Nodelist Update System  $coreVersion  $ver
(c)2023 WRXB288 LAGMRS.com all rights reserved
$phpzone PHP v$phpVersion   Release date:$release
===================================================
$datum Model: $piVersion
$datum Node:$node UTC:$gmdatum 
";

// If we have a backup install it.
if (!file_exists($nodelist)){
 $out="Nodelist is missing";save_task_log ($out);print"$datum $out\n";
 if (file_exists($nodelistBU)){
 rename($nodelistBU,$nodelist);
 copy($nodelist,$nodelistBU);
 }
 $out="Restoring nodelist from backup $nodelistBU";save_task_log ($out);print"$datum $out\n";
}

$update = true;
// only update if db is old  48 hrs min
if (file_exists($nodelist)){
 $ft = time()-filemtime($nodelist);
 if ($ft < 10 * 3600){
 $update=false; $fth=round($ft /3600);
 $out="Nodelist does not need update ($fth hrs) old.";save_task_log ($out);print"$datum $out\n";
 } 
}


$datum  = date('m-d-Y H:i:s');
// debugging
if (!$cron){ $out="Nodelist Manual Update";save_task_log ($out);print"$datum $out\n";$update = true;}

if ($update ){
$seconds = mt_rand(0, 1800); $min= round(($seconds / 60),0);
if($cron){$out="Nodelist. Sleep for $min min(s)";save_task_log ($out);print"$datum $out\n";
sleep($seconds);
}

// new looping code
$gzip=true;
for ($i = 0; $i < 3; $i++){

//http://register.gmrslive.com/cgi-bin/privatenodes.txt
$domain ="register.gmrslive.com"; $url = "/cgi-bin/privatenodes.txt"; 
$datum  = date('m-d-Y H:i:s');

print "$datum Polling Nodelist $domain \n";

function HandleHeaderLine( $curl, $header_line ) {
global $datum;
    print "$datum $header_line";
    return strlen($header_line);
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://$domain/$url");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
if ($gzip){curl_setopt($ch, CURLOPT_ENCODING, 'gzip');}
curl_setopt($ch, CURLOPT_TIMEOUT, 20);	 	
curl_setopt($ch, CURLOPT_HEADERFUNCTION, "HandleHeaderLine");
$html=curl_exec($ch);

 
curl_close($ch);


//$context = stream_context_create($options);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
//$html = @file_get_contents("http://$domain/$url",false,$context);
$datum  = date('m-d-Y H:i:s');
$deb = substr($html, 0, 20);print"$datum Received $deb \n";



//    [0] => HTTP/1.0 200 OK
//    [1] => Server: SimpleHTTP/0.6 Python/3.11.2
//    [2] => Date: Fri, 15 Mar 2024 22:17:26 GMT
//    [3] => Content-type: text/plain          
//           Content-Encoding: gzip
//    [4] => Content-Length: 182966
//    [5] => Last-Modified: Fri, 15 Mar 2024 14:01:03 GMT

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
test_data ($html);  
if ($trust >=3){break;}// stop the loop its good
sleep(30); // add a delay before retrying
$gzip=false;
}





$datum  = date('m-d-Y H:i:s');
if ($trust <=2 or !$trust2){line_end("ERROR BAD DATA");}

$contents="";
if (file_exists($privatefile)) {
// test for private nodes and erase the bad header
$fileIN= file($privatefile);$compile="";$i=0;
foreach($fileIN as $line){
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $pos = strpos($line, "Freq. or Description");  
  if (!$pos){
   $pos2 = strpos($line, "|"); 
    if($pos2){ $compile="$compile $line\n";$i++;}
    }
}
if ($i>=1){
$size = strlen($compile);
$out="Importing Private Nodes $size bytes";save_task_log ($out);print"$datum $out\n";
$contents .= $compile;
} 
// get rid of the trash. If this file has nothing but a header get rid of it
// Default image has a node 1000 header that we dont want to import.
// This looks to be a bug that could cause trouble for the real node 1000
else {unlink($privatefile);} 
}

$contents .= $html;
$contents = preg_replace('/[\x00-\x09\x0B-\x0C\x0E-\x1F\x7F-\xFF]/', '', $contents);

if(file_exists($nodelist)){
 if(file_exists($nodelistBU)){unlink($nodelistBU);}
 copy($nodelist,$nodelistBU);
} // keep backups

$fileOUT = fopen($nodelist,'w');fwrite ($fileOUT,$contents);fclose ($fileOUT);
$sizeN = strlen($contents);                                                           
//$out="Loading nodelist $size bytes";print"$datum $out\n";//save_task_log ($out);


// Do our own DNS update
$update2 = true;
//if (file_exists($dnsSnap)){
// $ft = time()-filemtime($dnsSnap);
// if ($ft < $dnsTIME * 3600){ $update2=false; $fth=round($ft /3600); } 
//}

if($update2){
//http://register.gmrslive.com/cgi-bin/nodes.pl
$domain ="register.gmrslive.com"; $url = "/cgi-bin/nodes.pl"; 
$datum  = date('m-d-Y H:i:s');
print "$datum Polling DNS >";
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "User-Agent: none\r\n" 
));
$context = stream_context_create($options);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$html = @file_get_contents("http://$domain/$url",false,$context);
//$html = gzinflate( substr($html,10,-8) ); 
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
//$fileOUT = fopen($dns,'w');fwrite ($fileOUT,$html);fclose ($fileOUT);// creates/updates the systems dns file
$fileOUT = fopen($dnsSnap,'w');fwrite ($fileOUT,$html);fclose ($fileOUT); // takes a snap of the dns
print " ok $dnsSnap\n";
}












// --------------------------------build database ----------------------------------
sort_nodes ("nodes"); // Builds the database

//include_once ("$path/purge_log.php"); // moved to midnight.php

$flag2      = "/tmp/nodelist_updated.txt"; if(file_exists($flag2)) {unlink($flag2);}
$fileOUT = fopen($flag2,'a+');fwrite ($fileOUT,"$datum updated Nodelist\n");fclose ($fileOUT);

//built_sounds ("ok"); // internal use to build sound files. tts must be setup

} // end update

include_once ("$path/version_check.php");

line_end("Line End");




function line_end($in){
global $trust,$poll_time,$trust2,$datum,$mtime,$script_end,$script_start,$soundDbWav,$soundDbGsm,$soundDbUlaw;

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_end = $mtime;$script_time = ($script_end - $script_start);$script_time = round($script_time,2);
$datum  = date('m-d-Y H:i:s');
$memory = memory_get_usage() ;$memory =formatBytes($memory);

print "$datum  [$in] Used:$memory $script_time Sec\n"; 
$tagline="";tagline($tagline);print "\n";
unset ($soundDbWav);
unset ($soundDbGsm);
unset ($soundDbUlaw);
print"===================================================\n";



}



function test_data ($html){
global $trust,$poll_time,$trust2,$datum;
print"$datum TESTING .";
$trust=0;$trust2=false;$test=strtolower($html); 
$pos = strpos($test, "wrxb288");if($pos){$trust++;      print"1";$trust2=true;}
$pos = strpos($test, "gmrslive.com");if ($pos){$trust++;print"2";}
$pos = strpos($test, "roadkill");if ($pos){$trust++;    print"3";} 
$pos = strpos($test, "do no edit");if ($pos){$trust++;  print"4";}
$pos = strpos($test, "thrasher");if ($pos){$trust++;    print"5";}
$pos = strpos($test, "mishigami");if ($pos){$trust++;   print"6";} 
$pos = strpos($test, "slingshot");if ($pos){$trust++;   print"7";}   
$pos = strpos($test, "swla");if ($pos){$trust++;        print"8";}
print"]";
// is Nodelist from another network?
$pos = strpos($html, "Texas GMRS Network");if ($pos){$trust=-10;print"?";} 

// good trust should be >3 If its not we are not on GMRS Live Or the server gave us bad data
   
if ($trust >=3){$out="<valid> Trust level:$trust [$poll_time Sec.]";save_task_log ($out);print"$out\n";}
else {$out="<not valid> Trust level:$trust [$poll_time Sec.]";save_task_log ($out);print"$out\n";}
}

//NODENAMES=/var/lib/asterisk/sounds/rpt/nodenames


// Custom to build node audio names.
// This code creates the sound files on production system. Not used on nodes
function built_sounds ($in){
global $path;
$datum  = date('m-d-Y H:i:s');
print "$datum Building HUB sound files >\n";

$soundPath="/var/lib/asterisk/sounds/rpt/nodenames"; 
chdir($soundPath);
$pathNode="$path/nodelist";
$nodelist3 =  "$pathNode/hubs.csv";
$fileIN= file($nodelist3);
natsort($fileIN); $i=0;
foreach($fileIN as $line){
 //Remove line feeds
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $line = str_replace("!", "|", $line);
  $line = str_replace("(", "|", $line);
  $line = str_replace("[", "|", $line);
  $line = str_replace("www", "|", $line);
  $line = str_replace("-", "|", $line);
   
$u = explode("|",$line);
$nodeName=$u[0]; $name=$u[1];
// use shorter names for text to speach
//if($name=="inactive"){continue;}
if($nodeName==4521){$name="Thrasher";}
if($nodeName==2329){$name="Oregon GMRS.org Main Hub";}
if($nodeName==1535){$name="GMRS.RADIO HUB";}
if($nodeName>=51010 and $nodeName<=51014){$name="South West Lousiana GMRS";} //  51010	SWLA GMRS - Lake Charles. La (WRVU907)	Lake Charles,LA	WRVU907
if($nodeName==700){$name="Nationwide Chat By GMRS Live";}


if($nodeName==900){$name="EMERGENCY Operations By GMRS Live";}
if($nodeName==921){$name="EMERGENCY Operations By BROADNET SYSTEMS";}
if($nodeName==923){$name="EMERGENCY Operations By South Dade GMRS";}
if($nodeName==924){$name="EMERGENCY Operations By The North Carolina Network";}
if($nodeName==925){$name="EMERGENCY Operations By Central Texas GMRS HUB";}
if($nodeName==926){$name="EMERGENCY Operations By The Road Kill Network";}
if($nodeName==927){$name="EMERGENCY Operations By The NC GMRS Network";}
if($nodeName==928){$name="EMERGENCY Operations By Ocean State GMRS";}

print "$datum processing $nodeName $name \n";

//if(file_exists("$soundPath/1195.ul")){unlink("$soundPath/1195.ul");}

if(file_exists("$soundPath/$nodeName.txt")){unlink("$soundPath/$nodeName.txt");}
if(!file_exists("$soundPath/$nodeName.ul") and $name<>"" and $i<=20){
$fileOUT  = fopen("$soundPath/$nodeName.txt",  "w");
fwrite ($fileOUT, "$name\n");
fclose($fileOUT);
print "$datum Building $nodeName $name $soundPath/$nodeName.txt\n";
exec ("tts_audio.sh $soundPath/$nodeName.txt",$output,$return_var);
unlink("$soundPath/$nodeName.txt");$i++;
  }
 }
}




function sort_nodes ($in){
global $beta,$path,$node,$datum,$cron,$sizeN,$dnsSnap;
//  $dnsSnap 
//  The purpose in this is to format a human readable index
// and keep all location data and calls in a standarized formats
//
// It is also to detect HUBS repeaters So they can be indexed seperatly
// In cases where the autodetect does not work manual kludges
// are needed.
//
// Some fields have problems with the wrong Delimiters and inconsistent
// formating that must be corrected for the directory to work 
//
// Please do not be upset that your data was adjusted it is only
// to format it for my index.
//
// This is a work in progress. And changes will likely be needed
// as many old fixes have been removed in the last months and 
// more added to keep the database clean.
//
// *    *  Have many nice days (c) 2023

$antiDupe="";$antiDupe2=""; $nodeDupe=""; $spin=0;
$Statedata= file("$path/states.csv");
$lastCall=""; $count=0; $countR=0;$countH=0;$countC=0;
$nodelist  =  "/var/log/asterisk/astdb.txt";
if(file_exists($nodelist)){

$pathNode="$path/nodelist";
if(!is_dir($pathNode)){ mkdir($pathNode, 0755);}
$fileINdns="";
if (file_exists($dnsSnap)){$fileINdns= file($dnsSnap);$dnsScan=true;}
else {$dnsScan=false;}
$nodelist2 = "$pathNode/dirty.csv";
$newfile  =  "$pathNode/clean.csv";
$newfile2 =  "$pathNode/repeaters.csv";
$newfile3 =  "$pathNode/hubs.csv"; //if (file_exists($newfile3)){unlink($newfile3);}
$newfile4 =  "$pathNode/hubs_online.csv";//if (file_exists($newfile4)){unlink($newfile4);}
$newfile5 =  "$pathNode/map_data.csv";//if (file_exists($newfile5)){unlink($newfile5);}
//$newfile6 =  "$pathNode/map_data2.csv";if (file_exists($newfile6)){unlink($newfile6);}

if (file_exists($nodelist2)){
$ft = time()-filemtime($nodelist2);
if($cron){if ($ft < 24 * 3600 ){return;}}
}

$datum  = date('m-d-Y H:i:s');
print "$datum Building Nodelist Database ";
copy($nodelist,$nodelist2); // make our own dirty backup

$fileOUT =fopen($newfile,  "w");
$fileOUT2=fopen($newfile2, "w");
$fileOUT3=fopen($newfile3, "w");
$fileOUT4=fopen($newfile4, "w");
$fileOUT5=fopen($newfile5, "w");
//$fileOUT6=fopen($newfile6, "w");
fwrite ($fileOUT5,  "Node,Name,City,State,Call,Type,extra,\n");
//fwrite ($fileOUT6,  "Node,Name,City,State,Call, ,\n");

$fileIN= file($nodelist2);
natsort($fileIN);
foreach($fileIN as $line){
 //Remove line feeds
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $line = str_replace('"' , "", $line);// get rid of the quotes
  
$u = explode("|",$line);
// Extra error checking
if(!isset($u[0])){$u[0]="";}
if(!isset($u[1])){$u[1]="";}
if(!isset($u[2])){$u[2]="";}
if(!isset($u[3])){$u[3]="";}

//if(isset($u[4])){$u[1]="$u[1] - $u[4]";} // error checking for New fields
$u[4]="";$u[5]="";$u[6]="";// just blank these for my use. Change later

if (preg_match('#;.*$#m', $u[0]) || preg_match('#[+\-*/]#', $u[0])) {
    $u[0] = "";
}

if ($u[0]>1){

$nodeDupe = $u[0];

if ($u[1]==""){$u[5]="Null Name";}
if ($u[2]==""){$u[5]="Null State";}
// if all blank but call. call is not valid
if ($u[1]=="" and $u[2]=="" and $u[3]<>""){$u[1]=$u[3];$u[3]="";$u[5]="< slide left";}


$u[2] = str_replace("-", "", $u[2]);
$u[2] = str_replace(".", "", $u[2]);




// Find ids in the name and address fields and put them in the ID field
$testString="$u[1] $u[2]";
$posL = strpos($testString, "[W"); 
if ($posL>=1){
    $test = explode("[",$testString);$id= explode("]",$test[1]);
    $size= strlen($id[0]);
    if ($size ==7){
     if(!$u[3]){$u[3]="$id[0]";}
    }
   }
$posL = strpos($testString, "(W"); 
if ($posL>=1){
    $test = explode("(",$testString);$id= explode(")",$test[1]);
    $size= strlen($id[0]);
    if ($size ==7){
      if(!$u[3]){$u[3]=$id[0];}
  }
}
         








$test= "-$u[1] $u[2]";  $test= strtolower($test);
//$pos = strpos($test, "inactive");if ($pos){$u[0]=0;}

if (!$u[3]){$u[4]="R";} 
if (!$u[1]){$u[1]="";$u[4]= "N";}
 
$pos = strpos($test, "repeater") ;if ($pos){$u[4]="R";}

// These are repeator freqs (may create mistakes)
$pos = strpos($test, "550"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "575"); if ($pos){$u[4]="R";}
$pos = strpos($test, "600"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "625"); if ($pos){$u[4]="R";}
$pos = strpos($test, "650"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "675"); if ($pos){$u[4]="R";}
$pos = strpos($test, "700"); if ($pos){$u[4]="R";} 
$pos = strpos($test, "725"); if ($pos){$u[4]="R";} 

// HUB Detection do r first in case of "repeater hub"
$pos = strpos($test, "emergency") ;if ($pos){$u[4]="H";} 
$pos = strpos($test, "statewide") ;if ($pos){$u[4]="H";}
$pos = strpos($test, "nationwide");if ($pos){$u[4]="H";}  
$pos = strpos($test, "hub");       if ($pos){$u[4]="H";}
$pos = strpos($test, "cloud");     if ($pos){$u[4]="H";}
$pos = strpos($test, ".com");      if ($pos){$u[4]="H";}
$pos = strpos($test, "iax");      if ($pos){$u[4]="H";}
$pos = strpos($test, "zello");    if ($pos){$u[4]="H";}
$pos = strpos($test, "dvswitch"); if ($pos){$u[4]="H";}  
$pos = strpos($test, "dv switch");if ($pos){$u[4]="H";}  



$pos = strpos($test, "talk around");if ($pos){$u[4]="H";} 
$pos = strpos($test, "public")    ;if ($pos){$u[4]="R";} 


$pos = strpos($test, "moble");    if ($pos){$u[4]="N";}
$pos = strpos($test, "node");     if ($pos){$u[4]="N";}
$pos = strpos($test, "mobile");   if ($pos){$u[4]="N";} 
$pos = strpos($test, "inactive"); if ($pos){$u[4]="N";}  
$pos = strpos($test, "hotspot");  if ($pos){$u[4]="N";}
$pos = strpos($test, "simplex");  if ($pos){$u[4]="N";}


// Prevent these from being in hub repeater directory. Place them as nodes                                                    
$pos = strpos($test, "private");  if ($pos){$u[4]="N";}// delist private servers(mark as private?)
$pos = strpos($test, "personal"); if ($pos){$u[4]="N";}// delist PERSONAL

//$pos = strpos($test, "voip");     if ($pos){$u[4]="N";}// delist any VOIP 
// Hubs that fail autodect or are forced

if ($u[0]==611 or $u[0]==1876  or $u[0] == 1167 or $u[0] == 1195 or $u[0]==1196 or $u[0]==2460 or $u[0]==2505 or 
    $u[0]==2156 or $u[0]==50130 or $u[0]==4520 or $u[0]==1215 or $u[0]==4146 or $u[0]==4147
    ) {$u[4]="H";}
    
    
// updates as of 3/8/24 START     
// Nodes that fail auto detect
if ($u[0]== 750  or $u[0] == 1121 or $u[0] == 1122 or $u[0] == 1123 or $u[0] == 50930 or 
    $u[0] == 2978 or $u[0]== 1124 or $u[0] == 1150 or $u[0] == 1151 or $u[0] == 1152 or 
    $u[0] == 1153 or $u[0]== 1154 or $u[0] == 1926 or $u[0] == 1927 or $u[0] == 1928 or
    $u[0] == 2300 or $u[0]== 2340 or $u[0] == 3001 or $u[0] == 3008 or $u[0] == 31691 or
    $u[0] == 2244 or $u[0]== 2616 or $u[0] == 4190 or $u[0] == 4192 or $u[0] == 4800  or
    $u[0] == 51334or $u[0] == 51380) {
    $u[4]="N";}





if ($u[0] == 51393){$u[2]="Grand Tower,IL";$u[3]="WRVN707";$u[4]="N";}
//1926	LWS Shaun WRTE516		WRTE516
//1927*	LWS Shaun Mobile Node		WRTE516
//1929*	LWS Shaun WRTE516		WRTE516
if ($u[0] >= 1926 and $u[0] <= 1929){$u[2]="St. Cloud,FL";$u[4]="N";} 

//2147|DDB Simplex Mobile |- Dodge PU|(WRTX950)
if ($u[0]==2147){ $u[1]="$u[1] - $u[2]";$u[2]="Sutherlin,OR";}  // also remove dupe bellow



// Node numbers in the name 
$pos = strpos($test, $u[0]);
if($pos){ 
 $u[1] = str_replace($u[0], "", $u[1]);
 $u[1] = str_replace("-", "", $u[1]);// has a - after the node number
}

// 750	Zello Link	** Go To GMRSLive.com for Info **,	
if ($u[0] == 750 ){ $u[1]="$u[1] $u[2]";$u[2]="";$u[4]="N";} // Clear the city state field & take out of hub list


// Format and correct the lone wolf system 
if ($u[0] == 1691){$u[4]="H";}// lone wolf hub
if ($u[0] == 1690){$u[4]="R";}// 1690	Lone Wolf Apopka, FL
if ($u[0] == 1925){$u[4]="R";}//1925	Lone Wolf St. Cloud	
if ($u[0] == 1053){$u[4]="R";}//1053	Pasco Simplex Node 462.550 -
if ($u[0] == 1330){$u[4]="R";}
if ($u[0] == 1602){$u[4]="R";}//1602	Lone Wolf System EPIC UNIV	
if ($u[0] == 1780){$u[4]="R";}//1780	Lone Wolf System Yalaha	  
if ($u[0] == 1781){$u[4]="R";}//1781	Lone Wolf System Minneola
if ($u[0] == 2135){$u[4]="R";}//2135	Lone Wolf Sys GMRS Somos Latinos Gainesville GA

if ($u[0] == 50796){$u[4]="R";$u[2]="Hammond,LA";}

// reformat Known nodes (hubs) that have descriptions in City,State location field
// This will likely require adjustments
if($u[0]==700  or 
   $u[0]==900  or $u[0]==921  or $u[0]==922  or $u[0]==923  or $u[0]==924  or $u[0]==925  or $u[0]==926  or $u[0]==927  or $u[0]==928  or $u[0]==929  or
   $u[0]==1020 or $u[0]==1535 or $u[0]==1691 or $u[0]==1809 or $u[0]==1890 or $u[0]==1891 or $u[0]==1892 or $u[0]==1893 or $u[0]==1894 or
   $u[0]==2555 or $u[0]==2556 or $u[0]==2557 or $u[0]==2558 or $u[0]==2559 or $u[0]==2225 or $u[0]==2226 or $u[0]==2227 or $u[0]==2228 or $u[0]==2229 or 
   $u[0]==4621 or $u[0]==30700 or $u[0]==301195 or $u[0]==301691) {
   $u[1]="$u[1] - $u[2]";$u[2]="";$u[4]="H";}


// fix the VOPI nodes 
$posW = strpos("-$u[1] ", "VOIP Live");
if($posW){ $u[1]="$u[1] $u[2] $u[3]";$u[2]="";$u[3]="";$u[4]="H";}




//1000|NA||T&K REPEATER|N|
//1001|Tony   HotSpotRadio  Palmetto. FL|Palmetto,FL|WRAW556|N|
//1002|Tony|Palmetto,FL|WRAW556||
//1003|Tony|Palmetto,FL|WRAW556||
//1004|Tony|Palmetto,FL|-  - PALMETTO, FL WRAW556||
//1004|||Tony- Home HotSpot - Palmetto, FL [WRAW556]

// Fix location fied
if ($u[0]==1000){$u[1]="T&K REPEATER";$u[2]="Palmetto,FL";$u[3]="WRAW556";$u[4]="R";}
if ($u[0]==1001){$u[1]="HOME HOTSPOT";$u[2]="Palmetto,FL";$u[3]="WRAW556";$u[4]="N";}
if ($u[0]==1004){$u[1]="Tony- Home HotSpot";$u[2]="Palmetto,FL";$u[3]="WRAW556";$u[4]="N";}


// Using , instead of |
//1040|Thomas,- Hammond, IN|(WRCW750)
//1041|Thomas,- Hammond, IN|(WRCW750)
if ($u[0] ==1040 or $u[0] ==1041){$u[1]="Thomas";$u[2]="Hammond,IN";$u[3]="WRCW750";$u[4]="N";}


//1060|Andrew|- Mobile Node|(WRAB494)
if ($u[0]==1060){ $u[1]="$u[1] - $u[2]";$u[2]="";}

if ($u[0]==1083 or $u[0]==1084){$u[2]="Stevensville,MI";$u[3]="WRAB494";$u[4]="N";} 
if ($u[0]==1064){ if(!$u[2]){   $u[2]="Stevensville,MI"; }}


if ($u[0]>=1120 and $u[0]<=1124){$u[2]="Tampa,FL";$u[4]="N";}  // no call known

if ($u[0]==1301){if(!$u[2]){   $u[2]="East Harlem,NY"; }}

//1330	Holden Louisiana
if ($u[0]==1330){if(!$u[2]){   $u[2]="Holden,LA";$u[4]="R";}}


//1430|JOEL WQZR739 BROADNET SYSTEMS|||H|
if ($u[0]==1430){$u[3]="WQZR739";$u[4]="N";}// Node or hub?

if ($u[0]==1532){if(!$u[2]){   $u[2]="Billings,MT";}}

if ($u[0]>=1560 and $u[0]<=1564){$u[2]="Islip,NY";} 


//1640|Billings.MT 462.600 Repeater (WQEU929)||WQEU929|R|Invalid State (WQEU929), |
if ($u[0]==1640){ $u[2]="Billings,MT";$u[3]="WQEU929";$u[4]="R";}

if ($u[0]==1645){if(!$u[2]){   $u[2]="Newnan,GA";}}

 

// fix nodes format
//1715|Tampa Bay 600
//1716|John WREM697 Riverview, FL Simplex
//1717|Tampa Bay 725 [WREM697]
//1718|John WREM697 Orlando, FL Simplex
//1719|John|- Riverview,Fl|(WREM697)
if ($u[0]==1716){ $u[2]="Riverview,FL";$u[3]="WREM697";$u[4]="N";} 
if ($u[0]==1718){ $u[2]="Orlando,FL";  $u[3]="WREM697";$u[4]="N";} 

// Backwards call in wrong field
//1779|Washington,IL GMRS Live Linked Repeater|(WRJN397)
if ($u[0]==1779){ $u[2]="Washington,IL";$u[3]="WRJN397";$u[4]="R";}
 
// Fix repeater with Call in place of name. 
//1920|WRQU236|- Florence 625 - Florence,SC
if ($u[0]==1920 and $u[1]=="WRQU236"){$u[1]="Florence 625";$u[2]="Florence,SC";$u[3]="WRQU236";$u[4]="R";}

//1925|Lone Wolf System St. Cloud
//1926|LWS Shaun WRTE516
//1927|LWS Shaun Mobile Node
//1928|Lone Wolf System Altamonte Springs, FL
//1929|LWS Shaun WRTE516
// no location or CALL fields
if ($u[0]==1925){ $u[2]="St. Cloud,FL";        $u[4]="R";} 
if ($u[0]==1926 or $u[0]==1927 or $u[0]==1929){ $u[3]="WRTE516";$u[4]="N";} // no location no CALL
if ($u[0]==1928){ $u[2]="Altamonte Springs,FL";$u[4]="R";}


// place the hubs on the map
if ($u[0]==1195 or $u[0]==1196 or  $u[0]==1197 or $u[0]==1167 or $u[0]==50132){ $u[2]="Baton Rouge,LA";}


//2005|Shaun| - St. Cloud, Fl| (WRTE516)
//2006|Shaun| - St. Cloud, Fl| (WRTE516)
//2007|Shaun| - St. Cloud, Fl| (WRTE516)
//2008|Shaun| - St. Cloud, Fl| (WRTE516)
//2009|Shaun| - St. Cloud, Fl| (WRTE516)
if ($u[0]>=2005 and $u[0]<=2009){$u[4]="N";} /// emergency patch to stop repeater detection

//2014|WROG208 Mobile Node 1
if ($u[0]==2014){ $u[3]="WROG208";$u[4]="N";} 
// Backwards call in wrong field
//2056|Scheller,IL GMRS Live Linked Repeater|(WRQL716)
if ($u[0]==2056){$u[1]="GMRS Live Linked Repeater - Scheller IL";$u[2]="Scheller,IL";$u[3]="WRQL716";$u[4]="R";}  

//2080|Jeffrey| - Mobile| [WRTY487]
//2081|Jeffrey| - Harrisonville, MO| [WRTY487]
if ($u[0]==2080){$u[1]="$u[1] - $u[2]";$u[2]="Harrisonville,MO";$u[4]="N";}  






//Location problem
//2235|Ramey|- Thornton Tx|(WQVC581)
if ($u[0]>=2235 and $u[0]<=2239){ $u[2]="Thornton,Tx";} 

if ($u[0]==2240){if(!$u[2]){   $u[2]="North,TX";}}



if ($u[0]>=2295 and $u[0]<=2299){ $u[2]="Milwaukee,WI";$u[3]="WRON446";$u[4]="N";}
if ($u[0]==2296){ $u[1]="Milwaukee 675 Repeater";$u[4]="R";}
if ($u[0]==2297){ $u[1]="Family Node";}


//2340|||DDB HS625 Hotspot- (WRTX950)
//2341|DDB LV675 Repeater |- Lakeview,Or|(WRTX950)
//2342|DDB KF600 Repeater |- Klamath Falls,Or|(WRTX950)
//2343|DDB HP575 Repeater| Herd Peak, CA|(WRTX950)
//2344|DDB RB575 Repeater|Roseburg, Or|WRTX950
if ($u[0]==2340){ $u[1]="DDB HS625 Hotspot"; $u[2]="Sutherlin,OR"; $u[3]="WRTX950"; $u[4]="R";} 




//2405|Brawlie|Romeoville IL|WRNQ331||
//2406|Brawlie|Romeoville IL|WRNQ331||
//2407|Brawlie|Romeoville IL|WRNQ331||
//2408|Brawlie|Romeoville IL|WRNQ331||
//2409|Brawlie|Romeoville IL|WRNQ331||
if ($u[0]>=2405 and $u[0]<=2409){ $u[2]="Romeoville,IL";} 


// All formated with nodata fields as a hub
//2460|Sparta 600 Hub (WROY240)
//2461|James - Cromwell, IN (WROY240)
//2462|James / Radio-less Node (WROY240)
//2463|Sparta 600 Repeater (WROY240)
//2464|James Sparta 600 Zello (WROY240)
if ($u[0]==2461 or $u[0]==2462){ $u[2]="Cromwell,IN";$u[3]="WROY240";$u[4]="N";}







//2300|CAPTAIN DOUG WROY 524
//2301|Doug|- Denham Spring,La|(WROY524)
//2302|Doug|- Denham Spring,La|(WROY524)
//2303|Doug|- Denham Spring,La|(WROY524)
//2304|Doug|- Denham Spring,La|(WROY524)
if($u[0]==2300){$u[2]="Denham Spring,LA";$u[3]="WROY524";$u[4]="R";} // is this a repeator


//2505|Slingshot Repeater System, San Jose, Ca| [WRKH273]
//2506|Slingshot Repeater System HUB, San Jose, Ca| [WRKH273]
//2507|SLINGSHOT CERT #1 [WRKH273]
//2508|SLINGSHOT CERT #2 [WRKH273]
//2509|SLINGSHOT CERT #3 [WRKH273]
if ($u[0]>=2505 and $u[0]<=2309){$u[2]="San Jose,CA"; $u[3]="WRKH273";}



//2555|Oregon Hub|Pacific NorthWest Network|WRTX950
//2556|Washington Hub|Pacific NorthWest Network|WRTX950
//2557||Idaho Hub|Pacific NorthWest Network|WRTX950
//2558|Northern California Hub|Pacific NorthWest Network|WRTX950
//2559|Alaska Hub|Pacific NorthWest Network|WRTX950

if ($u[0]==2555){$u[1]="$u[1] $u[2]";$u[2]="State,OR";$u[3]="WRTX950";$u[4]="H";}
if ($u[0]==2557){$u[1]="$u[2] $u[3]";$u[2]="State,ID";$u[3]="WRTX950";$u[4]="H";}
if ($u[0]==2556){$u[1]="$u[1] $u[2]";$u[2]="State,WA";$u[3]="WRTX950";$u[4]="H";}
if ($u[0]==2558){$u[1]="$u[1] $u[2]";$u[2]="North,CA";$u[3]="WRTX950";$u[4]="H";}
if ($u[0]==2559){$u[1]="$u[1] $u[2]";$u[2]="State,AK";$u[3]="WRTX950";$u[4]="H";}


// 2557||Idaho Hub|Pacific NorthWest Network|WRTX950
// field 1 is empty creating a 4th field and coruption 
if($u[0]==2557 and $u[1]<>"Idaho Hub"){$u[1]="$u[2] $u[3]";$u[2]="";$u[3]="WRTX950";$u4="H";}//automatic skip if fixed

//2630|Bucks-Mont PA Hub
//2631|Bucks-Mont PA Statewide Hub
//2632|Bucks-Mont PA Local Hub
if ($u[0]>=2630 and $u[0]<=2632){$u[2]="Bucks,PA";$u[4]="H";}


if ($u[0]==2813){if(!$u[2]){   $u[2]="Central,TX";}}

//2875|WP 444 El Yunque|||R|Invalid State , |
//2876|WP 444 Cerro Punta|||R|Invalid State , |
//2877|WP 444 Monte Del Estado|||R|Invalid State , |
//2878|WP 444 Cerro Atalaya|||R|Invalid State , |
//2879|WP 444 Isla De Mona|||R|Invalid State , |

if ($u[0]==2875 and !$u[2]){$u[2]="El Yunque,PR";}
if ($u[0]==2876 and !$u[2]){$u[2]="Cerro Punta,PR";}
if ($u[0]==2877 and !$u[2]){$u[2]="Monte Del Estadoe,PR";}
if ($u[0]==2878 and !$u[2]){$u[2]="Cerro Atalaya,PR";}
if ($u[0]==2879 and !$u[2]){$u[2]="Isla De Mona,PR";}

if ($u[0]==31691){$u[1]="$u[1] $u[2]";$u[2]="";$u[3]=""; $u[4]="N";}  // 31691|VOIP Live Connection|Hosted By GMRS Live

//4131	* Central Texas GMRS HUB		
//4132	* Repeater [WRWI879]		WRWI879
//4133	Dave - Home/Mobile Node [WRWI879]		WRWI879
//4134	* Dave - DVSwitch Node [WRWI879]		WRWI879
if ($u[0]>=4131 and $u[0]<=4134){$u[2]="Harrision,TX";}



//4220	Antioch 712 repeater
if ($u[0]==4220){$u[2]="Antioch,CA";}

if ($u[0]==4251){$u[3]="WRUI413";$u[2]="";$u[4]="N";}
if ($u[0]==4254){$u[3]="WRUI413";$u[2]="";$u[4]="H";}


if ($u[0]==4270){if(!$u[2]){   $u[2]="Goldsboro,NC";}}




if ($u[0]==4301){if(!$u[2]){   $u[2]="Blue Mound,TX";}}

//4405|Holger / herman the german| - Meridian, ID| (WROM586)
//4406|Holger / herman the german| - Meridian, ID| (WROM586)
//4407|Holger / herman the german| - Meridian, ID| (WROM586)
//4408|SW Idaho GMRS Hub
//4409|Holger \ herman the german -Meridian, Idaho wrom586 
// Coruption detected
// Not sure is this a hub or a node?  I think its a node. 
if ($u[0]==4409){$u[2]="Meridian,ID";$u[3]="WROM586";$u[4]="N";}
 
//4445	Ryan - Lockwood, MT (WRXV321)		WRXV321  (false detected as a hub)
if ($u[0]==4445){$n[2]="Lockwood,MT";$u[4]="N";} // address in wrong field


//4516|Lake Wales, FL
//4517|White River Jct., VT
//4518|Claremont, NH
//4519|Melbourne, FL
if ($u[0]>=4516 and $u[0]<=4519){$u[4]="R";}// i think these are repeaters not hubs


//4520|ThrashedNet - 725 Repeater - Seminole, FL
//4521|Thrasher - Seminole, FL (WRXT441)
//4522|ThrashedNet - Seminole, FL
//4523|ThrashedNet - Seminole, FL
//4524|ThrashedNet - Seminole, FL

if ($u[0]>=4520 and $u[0]<=4524){$u[2]="Seminole,FL";$u[3]="WRXT441";$u[4]="N";}
if ($u[0]==4520){$u[4]="R";}



// 4659 duplicate nodelist bug   (what to do about this)
//4569	Brooksville. FL	WRZF316			
//4569	Brooksville. FL	WRZF316			
//4569	Brooksville. FL	WRZF316			
//4569	Brooksville. FL	WRZF316			
//4569	Brooksville. FL	WRZF316			
//4569	Goody	Lafayette	IN	WRQZ654	


// All formated as a hub with no datafields
//4585|Cowboy Robbie - Buffalo, NY (WRWP511)
if ($u[0]>=4585 and $u[0]<=4589){$u[1]="Cowboy Robbie";$u[2]="Buffalo, NY";$u[3]="WRWP511";$u[4]="N";}

//4621	So. Oregon Hub - Pacific NorthWest Network
if ($u[0]==4621){$u[2]="South,OR";}
//4635	Apex 675		
//4636	WRHS260 - Super Freq.		
//4637	WRHS260 - Squelch Crash		
//4638	* Greg	Apex,NC	WRHS260
//4639	* Greg	Apex,NC	WRHS260

if ($u[0]>=4635 and $u[0]<=4639){$u[2]="Apex,NC";$u[3]="WRHS260";$u[4]="N";}
if ($u[0]==4635){$u[4]="R";}


// looks like all nodes but 46
//4845|Eric Portable Node (WRUK935)
//4846|Casper, Wyoming 675 Repeater (WRUK935)
//4847|Eric - Casper, WY (WRUK935)
//4848|Eric - Casper, WY (WRUK935)
//4849|Eric - Casper, WY (WRUK935) 
if ($u[0]==4845 or $u[0] ==4847 or $u[0] ==4848 or $u[0] ==4849 ){
 if (!$u[2]){$u[2]="Casper, WY";$u[3]="WRUK935";$u[4]="N";}
 }

//50160	Max - WRUV246 - MaxOffRoadin - Florida		
//50161	* Max	Miami,FL	WRUV246
//50162	* Max	Miami,FL	WRUV246
//50163	* Max	Miami,FL	WRUV246
//50164	* Max	Miami,FL	WRUV246
if ($u[0] >=50160 and $u[0] <=50164 ){$u[2]="Clewiston,FL";$u[3]="WRUV246";}
//Node#: 50160  (request)
//Location/Address / City State /loc: Clewiston, FL 33440
//Type your Message Here: Clewiston, FL 33440



//50210|GK - Slidell, LA (WRYM479)
//50211|GK - Slidell, LA (WRYM479)
if ($u[0] ==50210 or $u[0] ==50211 ){$u[4]="N";}

// False detection as hubs ? 
//50245|Mr. Statewide| - Owens Cross Roads, AL| (WRXD909)
//50246|Mr. Statewide| - Owens Cross Roads, AL| (WRXD909)
//50247|Mr. Statewide| - Owens Cross Roads, AL| (WRXD909)
//50248|Mr. Statewide| - Owens Cross Roads, AL| (WRXD909)
//50249|Mr. Statewide| - Owens Cross Roads, AL| (WRXD909)
if ($u[0] >=50245 and $u[0] <=50249 ){$u[4]="N";}

//50790|AREA 51 - St. Cloud, FL
//50791|Patrick| - St. Cloud, Fl| (WRUW660)
//50792|Patrick| - St. Cloud, Fl| (WRUW660)
//50793|Patrick| - St. Cloud, Fl| (WRUW660)
//50794|Patrick| - St. Cloud, Fl| (WRUW660)
if ($u[0] >=50791 and $u[0] <=50794 ){$u[4]="N";}


if ($u[0] == 50834){$u[4]="N";$u[2]="Mirage,AZ";}// 50834	Scott-El Mirage, AZ (WRZQ882)
//50930|Ezra - Belle Chasse, LA (WRYW618)
if ($u[0] ==50930){$u[4]="N";}

if ($u[0] ==50952){if(!$u[2]){  $u[2]="State,RI";}}
if ($u[0] ==50831){if(!$u[2]){  $u[2]="Whittier,CA";}}

if ($u[0] ==50976){if(!$u[2]){  $u[2]="Peculiar,MO";}}




//51004|WRYI790
if ($u[0] == 51000){$u[2]="New Braunfels,TX";$u[3]="WRYI790";$u[4]="R";}	
if ($u[0] >= 51001 and $u[0] <= 51004){$u[2]="New Braunfels,TX";$u[3]="WRYI790";$u[4]="N";}



//51390	* Truck Node WRVN707		
//51391	Grand Tower. Illinois. Repeater. WRVN707	Grand Tower,IL	
//51392	* Larry	Grand Tower,IL	WRVN707
//51393	Josh Freeman. WRVN707 unit two	Grand Tower,IL	WRVN707
if ($u[0]>=51390 and $u[0]<=51393){$u[2]="Grand Tower,IL";$u[3]="WRVN707";$u[4]="N";}
if ($u[0]==51391){$u[4]="R";}

// if ($u[0] ==51011){if(!$u[2]){  $u[2]="South West,LA";}} // is this LA or CA???????

if ($u[0] ==51495 or $u[0]==51498 or $u[0]==51499 ){if(!$u[2]){  $u[2]="Melbourne,FL";}} 

if ($u[0] ==51630){if(!$u[2]){  $u[2]="Boise,ID";}} 


//51800|WRMG753| - Seagrove, NC
//51801|WRMG753| - Seagrove, NC
//51802|WRMG753| - Seagrove, NC
//51803|WRMG753| - Seagrove, NC
//51804|WRMG753| - Seagrove, NC
if ($u[0] >= 51800 and $u[0] <= 51804){$u[2]="Seagrove,NC";$u[3]="WRMG753";$u[4]="N";} 



//52535	* NORM - WRZW864		WRZW864
//52536	* NORM - WRZW864		WRZW864
//52537	* NORM - WRZW864		WRZW864
//52538	* NORM - WRZW864		WRZW864
//52539	* NORM - WRZW864		WRZW864
if ($u[0] >= 52535 and $u[0] <= 52539){$u[2]="Baton Rouge,LA";$u[3]="WRZW864";$u[4]="N";} 


//52695	* Catdaddys Roadkill RV - Louisiana	Unknown,LA	
//52696	* Kenneth	Baton Rouge,LA	WRCF487
//52697	* Kenneth	Baton Rouge,LA	WRCF487
//52698	* Kenneth	Baton Rouge,LA	WRCF487
//52699	* Kenneth	Baton Rouge,LA	WRCF487
if ($u[0] == 52695){$u[2]="Baton Rouge,LA";$u[3]="WRCF487";$u[4]="N";} 



// fix unknown error causeing , to go to . 
//52755|Blake   Pilger. NE||WSBV571||Invalid State|
//52756|Blake   Pilger. NE||WSBV571||Invalid State|
//52757|Blake   Pilger. NE||WSBV571||Invalid State|
//52758|Blake   Pilger. NE||WSBV571||Invalid State|
//52759|Blake   Pilger. NE||WSBV571||Invalid State|
if ($u[0] >= 52755 and $u[0]<= 52759){$u[2]="Pilger,NE";} 
if($u[0]==4846){$u[2]="Casper,WY";} 
if($u[0]==51230){$u[2]="Shenandoah Valley,WV";}
if($u[0]==1604){$u[2]="Sorrento,FL";} 


//52865|CV Live. La Quinta, CA
//52866|Chris| - La Quinta, CA| (WROJ613)
//52867|Chris| - La Quinta, CA| (WROJ613)
//52868|Chris| - La Quinta, CA| (WROJ613)
//52869|Chris| - La Quinta, CA| (WROJ613)

if ($u[0] >= 52865 and $u[0]<= 52869){$u[2]="La Quinta,CA";} 

if ($u[0] == 51567){$u[4]="H";$u[2]="Amite,LA";}
if ($u[0] == 51568){$u[4]="H";$u[2]="Amite,LA";}


//
//
// This block only runs if no city state
//
if(!$u[2]){
$stateTest = strtoupper($u[1]); 
$stateTest = str_replace("-", " ", $stateTest); 
$stateTest = str_replace(",", " ", $stateTest);
$stateTest = str_replace(".", " ", $stateTest);   
$stateTest2= str_replace(".", ". ", $stateTest); 

//Mishigami Repeater System 
$posW = strpos("-$stateTest ", "MISHIGAMI");if($posW){ $u[2]="Great Lakes,MI";}




$posW = strpos("-$u[1]", "Gainesville GA");if($posW){$u[2]="Gainesville,GA";}





$posW = strpos("-$stateTest", "ALASKA");//Alaska
if($posW){
  if ($u[0]=2559) {$u[2]="State,AK";}
}


$posW = strpos($stateTest, " VT");
 if ($posW){
$posW = strpos("-$stateTest", "WHITE RIVER JCT");    if($posW){$u[2]="White River Jct,VT";} 
}

$posW = strpos("-$stateTest", "NC "); if ($posW and !$u[2] ){$u[2]="State,NC";} // default to this NC GMRS Net Hub
$posW = strpos("-$stateTest", " NC");
 if ($posW){
$posW = strpos("-$stateTest", "RALEIGH");       if($posW){$u[2]="Raleigh,NC";} 
$posW = strpos("-$stateTest", "WILMINGTON");    if($posW){$u[2]="Wilmington,NC";} 
$posW = strpos("-$stateTest", "SILVER VALLEY"); if($posW){$u[2]="Silver Valley,NC";} 
 }
$posW = strpos("-$stateTest", "NORTH CAROLINA");
 if ($posW){
 $u[2]="State,NC"; // default to this
 
 }




//COOLBAUGH PA

$posW = strpos($stateTest, " PA");
 if ($posW){
$posW = strpos("-$stateTest", "COOLBAUGH");       if($posW){$u[2]="Coolbaugh,PA";} 
$posW = strpos("-$stateTest", "MONTCO");          if($posW){$u[2]="Montco,PA";} 
$posW = strpos("-$stateTest", "TOBYHANNA");       if($posW){$u[2]="Tobyhanna,PA";} 

}
// Richboro
$posW = strpos("-$u[1]", "Richboro");if($posW){$u[2]="Richboro,PA";}

$posW = strpos("-$u[1]", "Buffalo, NY");     if($posW){$u[2]="Buffalo,NY";}

//Bronx NY


$posW = strpos("-$u[1]", "Lockwood, MT");    if($posW){$u[2]="Lockwood,MT";}  
$posW = strpos("-$u[1]", "Nashville, TN");   if($posW){$u[2]="Nashville,TN";} 
$posW = strpos("-$u[1]", "BRONX");           if($posW){$u[2]="Bronx,NY";}  
$posW = strpos("-$u[1]", "RHODE ISLAND");    if($posW){$u[2]="Rhode Island,NY";}  

//West Lafayette. IN
$posW = strpos($stateTest, " IL ");
 if ($posW){
$posW = strpos("-$stateTest", "BLOOMINGTON");  if($posW){$u[2]="Bloomington,IL";} 
$posW = strpos("-$stateTest", "LINCOLN");      if($posW){$u[2]="Lincoln,IL";} 
$posW = strpos("-$stateTest", "VILLA RIDGE");  if($posW){$u[2]="Villa Ridge,IL";}  // Villa Ridge. IL
}
$posW = strpos($stateTest, " ILLINOIS");//Grand Tower. Illinois
 if ($posW){
$posW = strpos("-$stateTest", "GRAND TOWER");  if($posW){$u[2]="Grand Tower,IL";} 
//Grand Tower. Illinois 
}


$posW = strpos($stateTest, " RI");
 if ($posW){
$posW = strpos("-$stateTest", "RIVERSIDE"); if($posW){$u[2]="Riverside,RI";}  
$posW = strpos("-$stateTest", "WARWICK");   if($posW){$u[2]="Warwick,RI";} 
$posW = strpos("-$stateTest", "PROVIDENCE");if($posW){$u[2]="East Providence,RI";} 
}



$posW = strpos($stateTest, " CA ");
 if ($posW){
$posW = strpos("-$stateTest", "BAKERSFIELD");  if($posW){$u[2]="Bakersfield,CA";} 
$posW = strpos("-$stateTest", "SAN JOSE");     if($posW){$u[2]="San Jose,CA";}
}
$posW = strpos("-$u[1]", "Bakersfield Ca");  if($posW){$u[2]="Bakersfield,Ca";}


// florida block 
$posW = strpos($stateTest, " FL");$posWW = strpos($stateTest, " FLORIDA");
 if ($posW or $posWW){
$posW = strpos("-$stateTest", "VIERA");       if($posW){$u[2]="Viera,FL";}  
$posW = strpos("-$stateTest", "AVON PARK");   if($posW){$u[2]="Avon Park,FL";}  
$posW = strpos("-$stateTest", "KISSIMMEE");   if($posW){$u[2]="Kissimmee,FL";}  
$posW = strpos("-$stateTest", "BLANTON");     if($posW){$u[2]="Blanton,FL";}  
$posW = strpos("-$stateTest", "BROOKSVILLE"); if($posW){$u[2]="Brooksville,FL";} 
$posW = strpos("-$stateTest", "PALMETTO");    if($posW){$u[2]="Palmetto,FL";}
$posW = strpos("-$stateTest", "SORRENTO")    ;if($posW){$u[2]="Sorrento,FL";}
$posW = strpos("-$stateTest", "APOPKA")      ;if($posW){$u[2]="Apopka,FL";}
$posW = strpos("-$stateTest", "TAMPA")       ;if($posW){$u[2]="Tampa,FL";}
$posW = strpos("-$stateTest", "ST CLOUD")    ;if($posW){$u[2]="St. Cloud,FL";}//St. Cloud
$posW = strpos("-$stateTest", "CLOUD")       ;if($posW){$u[2]="St. Cloud,FL";}//St. Cloud 
$posW = strpos("-$stateTest", "LAKE WALES")  ;if($posW){$u[2]="Lake Wales,FL";}
$posW = strpos("-$stateTest", "SEMINOLE")    ;if($posW){$u[2]="Seminole,FL";}
$posW = strpos("-$stateTest", "MELBOURNE")   ;if($posW){$u[2]="Melbourne,FL";}
$posW = strpos("-$stateTest", "SPRING HILL") ;if($posW){$u[2]="Spring Hill,FL";}
$posW = strpos("-$stateTest", "PALM BAY")    ;if($posW){$u[2]="Palm Bay,FL";} 
$posW = strpos("-$stateTest", "TAMPA BAY")   ;if($posW){$u[2]="Tampa Bay,FL";} 
$posW = strpos("-$stateTest", "SANFORD")     ;if($posW){$u[2]="Sanford,FL";}
$posW = strpos("-$stateTest", "KEYS")        ;if($posW){$u[2]="Keys,FL";} 
$posW = strpos("-$stateTest", "OCALA")       ;if($posW){$u[2]="Ocala,FL";} //Ocala Fl
$posW = strpos("-$stateTest", "HOMESTEAD")   ;if($posW){$u[2]="Homestead,FL";} //Homestead Fl  
$posW = strpos("-$stateTest", "DAVENPORT")   ;if($posW){$u[2]="Davenport,FL";} //Homestead Fl  
 


   if (!$u[2]){$u[2]="Unknown,FL";} 
}


// No state ident. Only city provided
$posW = strpos("-$stateTest", "YALAHA");      if($posW){$u[2]="Yalaha,FL";}
$posW = strpos("-$stateTest", "MINNEOLA");    if($posW){$u[2]="Minneola,FL";}
$posW = strpos("-$stateTest", "MIAMI DADE");  if($posW){$u[2]="Miami Dade,FL";} 
$posW = strpos("-$stateTest", "FLORIDA KEYS");if($posW){$u[2]="Keys,FL";}
$posW = strpos("-$stateTest", "EAST ORLANDO");if($posW){$u[2]="East Orlando,FL";} 
$posW = strpos("-$stateTest", "FLORIDA STATEWIDE");if($posW){$u[2]="State,FL";} 
$posW = strpos("-$stateTest", "TAMPA BAY")   ;if($posW){$u[2]="Tampa Bay,FL";}
$posW = strpos("-$stateTest", "TAMPABAY")    ;if($posW){$u[2]="Tampa Bay,FL";}
// end florida




// start MI

$posW = strpos($stateTest, " MI");$posWW = strpos($stateTest, " MICHIGAN");
 if ($posW or $posWW){
 $posW = strpos("-$stateTest", "ST JOSEPH")   ;if($posW){$u[2]="St. Joseph,MI";}
 $posW = strpos("-$stateTest", "GRAND RAPIDS");if($posW){$u[2]="Grand Rapids,MI";}
 $posW = strpos("-$stateTest", "OTTAWA LAKE"); if($posW){$u[2]="Ottawa Lake,MI";}  //Ottawa Lake. MI
 $posW = strpos("-$stateTest", "LAMBERTVILLE");if($posW){$u[2]="Lambertville,MI";} //Lambertville
 $posW = strpos("-$stateTest", "HOLLAND");     if($posW){$u[2]="Holland,MI";}
 $posW = strpos("-$stateTest", "CURTIS");      if($posW){$u[2]="Curtis,MI";}
 $posW = strpos("-$stateTest", "BATH");        if($posW){$u[2]="Bath,MI";}
 $posW = strpos("-$stateTest", "GAYLORD");     if($posW){$u[2]="Gaylord,MI";}
 $posW = strpos("-$stateTest", "IRON RIVER");  if($posW){$u[2]="Iron River,MI";}	
 $posW = strpos("-$stateTest", "STEVENSVILLE");if($posW){$u[2]="Stevensville,MI";}
 $posW = strpos("-$stateTest", "MAYVILLE");    if($posW){$u[2]="Mayville,MI";}	//Mayville Mi '52601|Mayville Mi 600 Repeater'
 $posW = strpos("-$stateTest", "IRONWOOD");    if($posW){$u[2]="Ironwood,MI";}	//Mayville Mi '52601|Mayville Mi 600 Repeater'
 
 
 
 
 
 $posW = strpos("-$stateTest", "UPPER PENINSULA")   ;if($posW){$u[2]="Upper Peninsula,MI";}
 $posW = strpos("-$stateTest", "NORTHERN")          ;if($posW){$u[2]="North Michigan,MI";}
 $posW = strpos("-$stateTest", "CENTRAL")           ;if($posW){$u[2]="Central Michigan,MI";}
 $posW = strpos("-$stateTest", "SOUTH WEST")        ;if($posW){$u[2]="South West Michigan,MI";}
 $posW = strpos("-$stateTest", "SOUTH EAST")        ;if($posW){$u[2]="South East Michigan,MI";}
 $posW = strpos("-$stateTest", "GRAYLING")          ;if($posW){$u[2]="Grayling,MI";} 
   if (!$u[2]){$u[2]="Unknown,MI";}  
 
}
// end mi



//if ($u[0] == 51076){$u[2]="Cudahy,WI";}// 51076	LRN Repeater - Cudahy. WI

$posW = strpos($stateTest, " WI");$posWW = strpos("-$stateTest", " WISCONSIN");
 if ($posW or $posWW){
  $posW = strpos($stateTest, "CUDAHY")      ;if($posW){$u[2]="Cudahy,WI";}  
  $posW = strpos($stateTest, "STATEWIDE")   ;if($posW){$u[2]="Dewey,WI";}
  $posW = strpos($stateTest, "ROME")        ;if($posW){$u[2]="Rome,WI";}
}





$posW = strpos($stateTest, " MS");$posWW = strpos($stateTest, " MISSISSIPPI");
 if ($posW or $posWW){
  $posW = strpos($stateTest, "JONESCOUNTY")   ;if($posW){$u[2]="Jonescounty,MS";}
 }



// ID test
$posW = strpos($stateTest, " ID");
 if ($posW){   
  $posW = strpos($stateTest, "MOUNTAIN HOME");if($posW){$u[2]="Mountain Home,ID";} 
  $posW = strpos($stateTest, "BOISE")      ;if($posW){$u[2]="Boise,ID";}
  $posW = strpos($stateTest, "MERIDIAN")   ;if($posW){$u[2]="Meridian,ID";}
  $posW = strpos($stateTest, "NAMPA")      ;if($posW){$u[2]="Nampa,ID";}
  $posW = strpos($stateTest, "KUNA")       ;if($posW){$u[2]="Kuna,ID";}
}
//52695	Catdaddys Roadkill RV - Louisiana


// Test for louisiana
$posW      = strpos($stateTest, " LA");
$posWstate = strpos($stateTest, " LOUISIANA");
if ($posW or $posWstate){
  $posW = strpos("-$stateTest", "NEW ORLEANS");  if($posW){$u[2]="New Orleans,LA";}
  $posW = strpos("-$stateTest", "LAKE CHARLES"); if($posW){$u[2]="Lake Charles,LA";} 
  $posW = strpos("-$stateTest", "PRAIRIEVILLE") ;if($posW){$u[2]="Prairieville,LA";}
  $posW = strpos("-$stateTest", "JACKSON") ;     if($posW){$u[2]="Jackson,LA";} 
  $posW = strpos("-$stateTest", "LACOMBE");      if($posW){$u[2]="Lacombe,LA";}  
  $posW = strpos("-$stateTest", "HAMMOND");      if($posW){$u[2]="Hammond,LA";}      
  $posW = strpos("-$stateTest", "BATON ROUGE");  if($posW){$u[2]="Baton Rouge,LA";}  
  $posW = strpos("-$stateTest", "ROUGE");        if($posW){$u[2]="Baton Rouge,LA";}  
  $posW = strpos("-$stateTest", "LAFAYETTE");    if($posW){$u[2]="Lafayette,LA";} 
  $posW = strpos("-$stateTest", "LFT")      ;    if($posW){$u[2]="Lafayette,LA";}  
  $posW = strpos("-$stateTest", "ALEXANDRIA");   if($posW){$u[2]="Alexandria,LA";}  
  $posW = strpos("-$stateTest", "RIDDER");       if($posW){$u[2]="De Ridder,LA";} 
  $posW = strpos("-$stateTest", "LEESVILLE");    if($posW){$u[2]="Leesville,LA";}   
  $posW = strpos("-$stateTest", "SLIDELL");      if($posW){$u[2]="Slidell,LA";} 
  $posW = strpos("-$stateTest", "BELLE CHASSE"); if($posW){$u[2]="Belle Chasse,LA";}
   if (!$u[2]){$u[2]="State,LA";}
}

if ($u[0] == 4507){$u[2]="Lafayette,LA";}// safety check to be removed

if (!$u[2]){ 
   $posW = strpos("-$stateTest", "SWLA");
   if($posW){$u[2]="SWLA,LA";}
}
 

$posW = strpos($stateTest, " OR");$posWW = strpos($stateTest, " OREGON");
 if ($posW or $posWW){
  $posW = strpos("-$stateTest", "GRANTS PASS");if($posW){$u[2]="Grants Pass,OR";}
  $posW = strpos("-$stateTest", "SELMA")      ;if($posW){$u[2]="Selma,OR";}
  $posW = strpos("-$stateTest", "WEIMER")     ;if($posW){$u[2]="Weimer,OR";}
  $posW = strpos("-$stateTest", "PHOENIX");    if($posW){$u[2]="Phoenix,OR";}
  $posW = strpos("-$stateTest", "SOUTHERN");   if($posW){$u[2]="Southern,OR";}
    if (!$u[2]){$u[2]="Unknown,OR";}
 }


$posW = strpos($stateTest, " OH");$posWW = strpos($stateTest, " OHIO");
 if ($posW or $posWW){
  $posW = strpos("-$stateTest", "PERRYSBURG")   ;if($posW){$u[2]="Perrysburg,OH";}
  $posW = strpos("-$stateTest", "GREENVILLE")   ;if($posW){$u[2]="Greenville,OH";}
  $posW = strpos("-$stateTest", "NORTHWEST")    ;if($posW){$u[2]="North West,OH";}
  $posW = strpos("-$stateTest", "NORTH WESTERN");if($posW){$u[2]="North Western,OH";}
 }




//4030|West Lafayette GMRS Hub (WRNE507)
if ($u[0] == 4030 or $u[0] == 4260 or $u[0]== 4264){$u[2]="West Lafayette,IN";}
$posW = strpos("-$stateTest", "WEST LAFAYETTE");if($posW){$u[2]="West Lafayette,IN";}  // Gets a false detection from LA this fixes it
// IN test
$posW = strpos($stateTest, " IN");$posWW = strpos("-$stateTest", "INDIANA");
 if ($posW or $posWW){
$posW = strpos("-$stateTest", "LARUNCE");     if($posW){$u[2]="Larunce,IN";} 
$posW = strpos("-$stateTest", "WILLIAMSPORT");if($posW){$u[2]="Williamsport,IN";}
$posW = strpos("-$stateTest", "HAMMOND")     ;if($posW){$u[2]="Hammond,IN";}  //Hammond. IN
$posW = strpos("-$stateTest", "BURLINGTON")  ;if($posW){$u[2]="Burlington,IN";}
$posW = strpos("-$stateTest", "DAYTON")      ;if($posW){$u[2]="Dayton,IN";}
$posW = strpos("-$stateTest", "WEST LAFAYETTE");if($posW){$u[2]="West Lafayette,IN";}  
$posW = strpos("-$stateTest", "FRANKFORT");  if($posW){$u[2]="Frankfort,IN";}
$posW = strpos("-$stateTest", "FOWLER");     if($posW){$u[2]="Fowler,IN";}////4262	BC-700 Repeater (Fowler. IN)	
}


//Memphis TN
$posW = strpos($stateTest, " TN");
 if ($posW){
  $posW = strpos("-$stateTest", "MEMPHIS")  ;if($posW){$u[2]="Memphis,TN";} 
} 

// TX test
$posW = strpos($stateTest, " TX");
 if ($posW){
  $posW = strpos("-$stateTest", "PORT ARTHUR")  ;if($posW){$u[2]="Port Arthur,Tx";} 
  $posW = strpos("-$stateTest", "THORNTON")     ;if($posW){$u[2]="Thornton,TX";} 
  $posW = strpos("-$stateTest", "TEMPLE")       ;if($posW){$u[2]="Temple,TX";} 
  $posW = strpos("-$stateTest", "WATAUGA")      ;if($posW){$u[2]="Watauga,TX";} 
  $posW = strpos("-$stateTest", "LAMPASAS")     ;if($posW){$u[2]="Lampasas,TX";} 
  $posW = strpos("-$stateTest", "EASTLAND")     ;if($posW){$u[2]="Eastland,TX";} //Eastland
  $posW = strpos($stateTest, "GRANBURY")        ;if($posW){$u[2]="Granbury,TX";} 
  $posW = strpos($stateTest, "WEATHERFORD")     ;if($posW){$u[2]="Weatherford,TX";}
  $posW = strpos($stateTest, "BELL COUNTY")     ;if($posW){$u[2]="Bell County,TX";}
  $posW = strpos($stateTest, "DUBLIN")          ;if($posW){$u[2]="Dublin,TX";}
  $posW = strpos($stateTest, "STEPHENVILLE")    ;if($posW){$u[2]="Stephenville,TX";} 
  $posW = strpos($stateTest, "PLANO");           if($posW){$u[2]="Plano,TX";}      //Plano. TX
  $posW = strpos($stateTest, "HUNTSVILLE");      if($posW){$u[2]="Huntsville,TX";}
  $posW = strpos($stateTest, "FARMERS BRANCH");  if($posW){$u[2]="Farmers Branch,TX";} 
  $posW = strpos($stateTest, "DALLAS");          if($posW){$u[2]="Dallas,TX";}  
  $posW = strpos($stateTest, "MINERAL WELLS");   if($posW){$u[2]="Mineral Wells,TX";}  
  $posW = strpos($stateTest, "JACKSBORO");       if($posW){$u[2]="Jacksboro,TX";}  
 
}
// klidge for no state names
$posW = strpos("-$stateTest", "BRAZOS VALLEY");if($posW){$u[2]="Brazos Valley,TX";} 
$posW = strpos("-$stateTest", "RIESEL RANCH"); if($posW){$u[2]="Riesel,TX";}// << Shutdown
$posW = strpos("-$stateTest", "LAMPASAS");  if($posW){$u[2]="Lampasas,TX";}
$posW = strpos("-$stateTest", "LAVERNIA");  if($posW){$u[2]="La Vernia,TX";}


//if ($u[0] == 2159){$u[2]="Plano,TX";}//2159	Blind GMRS Haven. Plano. TX

$posW = strpos($stateTest, " AR");
 if ($posW){
$posW = strpos("-$stateTest", "MALVERN");  if($posW){$u[2]="Malvern,AR";}
}




$posW = strpos($stateTest, " PR");$posWW = strpos("-$stateTest", "PUERTO RICO");
if ($posW or $posWW){
 $posW = strpos("-$stateTest", "SAN JUAN")    ;if($posW){$u[2]="San Juan,PR";}
 $posW = strpos("-$stateTest", "CAROLINA")    ;if($posW){$u[2]="Carolina,PR";}
}


$posW = strpos("-$stateTest", " CALIFORNIA");//Northern California Hub
if ($posW){
 $posW = strpos("-$stateTest", "NORTHERN")    ;if($posW){$u[2]="Northern,CA";}
}

$posW = strpos($stateTest, " NH");
if ($posW){
$posW = strpos("-$stateTest", "CLAREMOUNT")   ;if($posW){$u[2]="Claremont,NH";}  // Claremont, NH
$posW = strpos("-$stateTest", "CLAREMONT")    ;if($posW){$u[2]="Claremont,NH";}  // Claremont, NH
}

$posW = strpos("-$stateTest", " GEORGIA");
if ($posW){
 $posW = strpos("-$stateTest", "SOUTH GEORGIA")    ;if($posW){$u[2]="Tifton,GA";}
}



$posW = strpos("-$stateTest", "VIRGINIA");
if ($posW){
$posW = strpos("-$stateTest", "STATEWIDE")   ;if($posW){$u[2]="State,VA";}  
}


$posW = strpos("-$stateTest", "OKLAHOMA");
if ($posW){
$posW = strpos("-$stateTest", "STATEWIDE")   ;if($posW){$u[2]="State,OK";} 
$posW = strpos("-$stateTest", "EAST")        ;if($posW){$u[2]="East,OK";}  
$posW = strpos("-$stateTest", "WEST")        ;if($posW){$u[2]="West,OK";} 
}


}// end - This block only runs if no city state


// add a comma in needed.
//if (preg_match('/\s\w{2}$/', $u[2])) { $u[2] = substr_replace($u[2], ',', -3, 1);}

if (preg_match('/\s\w{2}[\s.,]?$/', $u[2])) {
    // Replace the space with a comma if not already present
    $u[2] = preg_replace('/(\w{2})[\s.,]?(\w{2}$)/', '$1, $2', $u[2]);
    // Replace any dot with a comma
    $u[2] = str_replace('.', ',', $u[2]);
}

// fix states
$state = explode(",",$u[2]);
// Extra error checking
if(!isset($state[0])){$state[0]="";}
if(!isset($state[1])){$state[1]="";}
 


$state[1] = strtoupper($state[1]);
$state[1] = str_replace(" ", "", $state[1]);

$test = str_replace(" ", "", $state[0]);
// kludge for known typos. This is automatic will be skipped when fixed Ocala Fl
if ($test=="Michigan"){    $state[1]="MI";}
if ($test=="Wesley Chapel"){$state[1]="FL";}

if ($test=="Ocala Fl"){    $state[1]="FL";$state[0]="Ocala";}
if ($test=="Homestead Fl"){$state[1]="FL";$state[0]="Homestead";}
if ($test=="Ironwood Mi"){$state[1]="MI";$state[0]="Ironwood";}
if ($test=="Bronx NY"){$state[1]="NY";$state[0]="Bronx";}
if ($test=="Lincoln NE"){$state[1]="NE";$state[0]="Lincoln";}
if ($test=="Davenport FL"){$state[1]="FL";$state[0]="Davenport";}



if ($test=="SanAntonioTx"){$state[1]="TX";$state[0]="San Antonio";}
if ($test=="BuckeyeAz"){   $state[1]="AZ";$state[0]="Buckeye";}
if ($test=="AshevilleNC"){ $state[1]="NC";$state[0]="Asheville";}
if ($test=="PlanoTX"){     $state[1]="TX";$state[0]="Plano";}
if ($test=="ElkhartIn"){   $state[1]="IN";$state[0]="Elkhart";}
if ($test=="HOUSTON"){     $state[1]="TX";$state[0]="Houston";} // Fix upercase typos

// $Statedata
// fix state names. Convert to proper abv
$validState=false;
foreach($Statedata as $line){ 
$line = strtoupper($line); $line  = str_replace(" ", "", $line );
$uu = explode(",",$line); 
if ($uu[0]==$state[1]){$state[1]=$uu[1];$validState=true;break;} // Louisiana,LA
if ($uu[1]==$state[1]){$validState=true;break;} // get some extra cpu cycles
}

$state[0]= ltrim( $state[0]);// Remove the leading spaces from the address
if($validState){$u[2]= "$state[0],$state[1]";}
else {$u[1]="$u[1] $u[2]";$u[2]="";$u[5]="Invalid State $state[0],$state[1] ";}


$u[0]=trim($u[0]);
$u[1]=trim($u[1]);




// start location fix
$u[2]=trim($u[2]);
$u[2] = preg_replace("/[^a-zA-Z0-9, ]/", "", $u[2]);
// end location fix


// start call fix
$u[3]=trim($u[3]);
// If anything passes thats longer than 7 put it in field one
$size=mb_strlen(trim($u[3]), 'UTF-8');

if ( $size >= 10) { $u[1]="$u[1] $u[3]";$u[3]="";$u[5]="Invalid Call $size";} 

$u[3] = strtoupper($u[3]); //  upercase 
$u[3] = preg_replace("/[^a-zA-Z0-9]/", "", $u[3]);// Remove all non text and numbers from the call
//$pattern = '/^[A-Za-z]{4}[0-9]{3}$/';if (preg_match($pattern, $u[3])) { $u[3] = "";}// This did not work
// end call fix


// Pull this running node info out the nodelist and save it. 
if($u[0]==$node){ 
$file= "$path/node-name.txt";
if(!file_exists($file)){
$fileOUT00 = fopen($file, "w") ;flock( $fileOUT00, LOCK_EX );fwrite ($fileOUT00, "$u[0],$u[1],$u[2],$u[3],$u[4],$u[5],\n");flock( $fileOUT00, LOCK_UN );fclose ($fileOUT00);
print"<$u[1] $u[2]>";// this is our info  (one time update)
 }
}
$count++;  if ($count % 1500 > 0 && $count % 1500 <= 10) {print".";}


//} // skips some but gives status

$antiDupe2 = preg_replace('/[ \-\.\(\)\[\]]/', '', $u[1]);


if ($antiDupe != $antiDupe2){
 $u[1]= str_replace(",", ".", $u[1]);
 fwrite ($fileOUT5,  "$u[0],$u[1],$u[2],$u[3],$u[4],$u[5],\n");  // this creates the mapping geocode database
 $antiDupe = preg_replace('/[ \-\.\(\)\[\]]/', '', $u[1]);
}  // this creates a list skipping blank loc
  
if ($u[2]==","){$u[2]="";}

               fwrite ($fileOUT,  "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|$u[5]|\n");
if($u[4]=="R"){fwrite ($fileOUT2, "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|$u[5]|\n");$countR++;}
if($u[4]=="H"){fwrite ($fileOUT3, "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|$u[5]|\n");$countH++;}
// Creates a list of live nodes for the connect box. Runs at night so must be 24hr
if($u[4]=="H"){
 if ($dnsScan){
   foreach($fileINdns as $lineDns){
    $lineDns = str_replace(" ", "", $lineDns);
    $uu = explode("=",$lineDns);
     if ($uu[0]==$u[0]){fwrite ($fileOUT4, "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]|$u[5]|\n");$countC++;break;}
   }
  }// end dns scan
 }  
}  // if >1

}  // end for each loop
fclose($fileOUT);fclose($fileOUT2);fclose($fileOUT3);fclose($fileOUT4);fclose($fileOUT5);//fclose($fileOUT6);// we are finished close them all
$datum = date('[H:i:s]');$out="Building Nodelist Database Nodes:$count Bytes:$sizeN";save_task_log ($out); 
print "<ok>\n$datum Bytes:$sizeN Nodes:$count Repeaters:$countR Hubs:$countH/$countC \n";
}
else{$out="Missing Nodelist $nodelist";save_task_log ($out);print "$datum $out\n";}
}
