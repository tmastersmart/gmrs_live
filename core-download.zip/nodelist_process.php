#!/usr/bin/php
<?php
// (c)2023 by The Master lagmrs.com
//
// Improved nodelist update with load sharing 
// Much improved random load sharing.
// Creates a clean index for supermon
// cleans the private nodelist
//
// http://register.gmrslive.com/cgi-bin/privatenodes.txt
// /var/log/asterisk/astdb.txt 
// astdb.php  replacement and upgrade
//
$cron=false;
if (!empty($argv[1])) { 
 if ($argv[1] =="cron"){$cron=true;}
 }


$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_start = $mtime;


$ver = "v1.5"; $release="07-24-2023";
$path="/etc/asterisk/local/mm-software";
include ("$path/load.php");


 // Get php timezone in sync with the PI
$line =	exec('timedatectl | grep "Time zone"'); //       Time zone: America/Chicago (CDT, -0500)
$line = str_replace(" ", "", $line);
$pos1 = strpos($line, ':');$pos2 = strpos($line, '(');
if ($pos1){  $zone   = substr($line, $pos1+1, $pos2-$pos1-1); }
else {$zone="America/Chicago";}
define('TIMEZONE', $zone);
date_default_timezone_set(TIMEZONE);
$phpzone = date_default_timezone_get(); // test it 
if ($phpzone == $zone ){$phpzone=$phpzone;}
else{$phpzone="$phpzone ERROR";}
$phpVersion= phpversion();


$datum   = date('m-d-Y H:i:s');
$gmdatum = gmdate('m-d-Y H:i:s');
print "
===================================================
GMRSLive Nodelist Update System   $coreVersion-c$ver
(c)2023 WRXB288 LAGMRS.com all rights reserved
$phpzone PHP v$phpVersion   Release date:$release
===================================================
$datum Model: $piVersion
$datum Node:$node UTC:$gmdatum 
";

$privatefile = "/etc/asterisk/local/privatenodes.txt";
$nodelist  =  "/var/log/asterisk/astdb.txt";
$update = false;
// only update if db is old
if (file_exists($nodelist)){
 $ft = time()-filemtime($nodelist);
 if ($ft > 48 * 3600){$update=true; }
}

// debugging
if (!$cron){$update=true;}
//$update = true;

if ($update ){
$seconds = mt_rand(0, 1800); $min= round(($seconds / 60),0);
$datum  = date('m-d-Y H:i:s');
print "$datum Updating nodelist\n";
if($cron){print"$datum Random Sleep for $min min(s)\n";
sleep($seconds);
}

//http://register.gmrslive.com/cgi-bin/privatenodes.txt
$domain ="register.gmrslive.com"; $url = "/cgi-bin/privatenodes.txt"; 
$datum  = date('m-d-Y H:i:s');
print "$datum Polling $domain >";
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-Encoding: gzip\r\n" 
));
$context = stream_context_create($options);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$html = @file_get_contents("http://$domain/$url",false,$context);
$html = gzinflate( substr($html,10,-8) ); 
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
test_data ($html);  


if ($trust ==0){ // try again gzip off
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "User-Agent: none\r\n" 
));
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$datum  = date('m-d-Y H:i:s');print "$datum Polling 2 $domain >";
$html = @file_get_contents("http://$domain/$url",false,$context);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
test_data ($html);
}

if ($trust ==0){// try again
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$datum  = date('m-d-Y H:i:s');print "$datum Polling 3 $domain >";
$html = @file_get_contents("http://$domain/$url",false,$context);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
test_data ($html);
}

$datum  = date('m-d-Y H:i:s');
if ($trust ==0){line_end("ERROR BAD DATA");}


$contents="";


if (file_exists($privatefile)) {
// test for private nodes and erase the bad header
$fileIN= file($privatefile);$compile="";$i=0;
foreach($fileIN as $line){
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $pos = strpos($line, "Freq. or Description");  
  if (!$pos){
   $pos2 = strpos($line, "|"); 
    if($pos2){ $compile="$compile $line\n";$i++;}
    }
}
if ($i>=1){
$size = strlen($compile);
$out="Importing Private Nodes $size bytes";save_task_log ($out);print"$datum $out\n";
$contents .= $compile;
}
else {unlink($privatefile);} // get rid of the trash. If this file is bad get rid of it
}

$contents .= $html;
$contents = preg_replace('/[\x00-\x09\x0B-\x0C\x0E-\x1F\x7F-\xFF]/', '', $contents);

if(file_exists($nodelist)){copy($nodelist,"/var/log/asterisk/astdb.txt.bak");} // keep backups

$fileOUT = fopen($nodelist,'w');fwrite ($fileOUT,$contents);fclose ($fileOUT);
$size = strlen($contents);
$out="Saving new nodelist $size bytes";save_task_log ($out);print"$datum $out\n";
sort_nodes ("nodes");
//built_sounds ("ok"); // internal use to build sound files.
line_end("finished");
} // end update

line_end("finished no update needed");



function test_data ($html){
global $trust,$poll_time;
$trust = 0;
$pos = strpos($html, "GMRSLive.com");if ($pos){$trust++;}
$pos = strpos($html, "RoadKill");if ($pos){$trust++;}
$pos = strpos($html, "Do No Edit");if ($pos){$trust++;}
$pos = strpos($html, "WRXB288");if ($pos){$trust++;}
$pos = strpos($html, "Texas GMRS Network");if ($pos){$trust++;}
// good trust should be 5
if ($trust >=1){$out="<ok> Trust level:$trust [$poll_time Sec.]";save_task_log ($out);print"$out\n";}

else {$out="<error> trust:$trust [$poll_time Sec.]";save_task_log ($out);print"$out\n";}
}

//NODENAMES=/var/lib/asterisk/sounds/rpt/nodenames


// Custom to build node audio names.
function built_sounds ($in){
global $path;
$datum  = date('m-d-Y H:i:s');
print "$datum Building HUB sound files >\n";

$soundPath="/var/lib/asterisk/sounds/rpt/nodenames"; 
chdir($soundPath);
$pathNode="$path/nodelist";
$nodelist3 =  "$pathNode/hubs.csv";
$fileIN= file($nodelist3);
natsort($fileIN); $i=0;
foreach($fileIN as $line){
 //Remove line feeds
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  $line = str_replace("!", "|", $line);
  $line = str_replace("(", "|", $line);
  $line = str_replace("[", "|", $line);
  $line = str_replace("www", "|", $line);
  $line = str_replace("-", "|", $line);
   
$u = explode("|",$line);
$nodeName=$u[0]; $name=$u[1];
if($nodeName==1195){$name="The Roadkill network";}
if($nodeName==1167){$name="Roadkill DV Switch";}

if($nodeName==700){$name="Nationwide Chat	By GMRS Live";}
if($nodeName==1196){$name="EMERGENCY Operations By Roadkill";}
if($nodeName==900){$name="EMERGENCY Operations By GMRS Live";}
if($nodeName==921){$name="EMERGENCY Operations By BROADNET SYSTEMS";}
if($nodeName==922){$name="EMERGENCY Operations By Texas GMRS Network";}
if($nodeName==923){$name="EMERGENCY Operations By South Dade GMRS";}
print "$datum processing $nodeName $name \n";


if(file_exists("$soundPath/$nodeName.txt")){unlink("$soundPath/$nodeName.txt");}
if(!file_exists("$soundPath/$nodeName.ul")and $name<>"" and $i<=20;{
$fileOUT  = fopen("$soundPath/$nodeName.txt",  "w");
fwrite ($fileOUT, "$name\n");
fclose($fileOUT);
print "$datum Building $nodeName $name $soundPath/$nodeName.txt\n";
exec ("tts_audio.sh $soundPath/$nodeName.txt",$output,$return_var);
unlink("$soundPath/$nodeName.txt");$i++;
}
}

}
function sort_nodes ($in){
global $beta,$path,$node,$datum;

$nodelist  =  "/var/log/asterisk/astdb.txt";
if(file_exists($nodelist)){

$pathNode="$path/nodelist";
if(!is_dir($pathNode)){ mkdir($pathNode, 0755);}
$nodelist  =  "/var/log/asterisk/astdb.txt";
$nodelist2 = "$pathNode/dirty.csv";
$newfile  =  "$pathNode/clean.csv";
$newfile2 =  "$pathNode/repeaters.csv";
$newfile3 =  "$pathNode/hubs.csv";

// moved to top
//if (file_exists($nodelist2)){
// $ft = time()-filemtime($nodelist2);
// if ($ft < 48 * 3600){ return; }
//}

$datum = date('[H:i:s]');$out="Updating Nodelist";save_task_log ($out); 
print "$datum $out";
copy($nodelist,$nodelist2); // make our own dirty backup

$fileOUT3 = fopen($newfile3, "w") ;
$fileOUT2 = fopen($newfile2, "w") ;
$fileOUT  = fopen($newfile,  "w") ;

$fileIN= file($nodelist2);
natsort($fileIN);
foreach($fileIN as $line){
 //Remove line feeds
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
  
$u = explode("|",$line);

// Extra error checking
if(!isset($u[0])){$u[0]="";}
if(!isset($u[1])){$u[1]="";}
if(!isset($u[2])){$u[2]="";}
if(!isset($u[3])){$u[3]="";}
if(!isset($u[4])){$u[4]="";}



$u[2] = str_replace("-", "", $u[2]);// remove from address

//  using() instead of []
//$u[1] = str_replace("(", "[", $u[1]);$u[1] = str_replace(")", "]", $u[1]); 
$u[2] = str_replace("(", "[", $u[2]);$u[2] = str_replace(")", "]", $u[2]); 
$u[3] = str_replace("(", "", $u[3]);$u[3] = str_replace(")", "", $u[3]); 


if ($u[0]==1000){// erase the header
    if($u[1]=="WB6XYZ"){
    $u[0]= 0;
    }     
 }

//1985|Inactive
//1986|Inactive
//1987|Inactive
//1988|Inactive
//1989|Inactive
$test= "-$u[1] $u[2]";  $test= strtolower($test);
// Unsure what this is remove it 
$pos = strpos($test, "Inactive");if ($pos){$u[0]=0;}
 
//if ($u[1]="" and $u[2]="" and $u[3]="") {$u[0]=0;}// UNknown why these are null   
// 10 is blank 300 is active

if ($u[0]>1){  
// if no call then its a repeater or a HUB- Guess HUB
if (!$u[3]){$u[4]="H";} 

// Auto Create the type field
//1195	The RoadKill !! Repeater System	Baton Rouge,LA		H
$pos = strpos($test, "repeater") ;if ($pos){$u[4]="R";}
$pos = strpos($test, "roadkill") ;if ($pos){$u[4]="R";}
$pos = strpos($test, "road kill") ;if ($pos){$u[4]="R";}
$pos = strpos($test, "statewide");if ($pos){$u[4]="H";}
$pos = strpos($test, "hub");      if ($pos){$u[4]="H";}
$pos = strpos($test, "node");     if ($pos){$u[4]="N";}
$pos = strpos($test, "iax");      if ($pos){$u[4]="I";}
$pos = strpos($test, "zello");    if ($pos){$u[4]="Z";}
$pos = strpos($test, "moble");    if ($pos){$u[4]="N";}
$pos = strpos($test, "dvswitch"); if ($pos){$u[4]="D";}
$pos = strpos($test, "emergency");if ($pos){$u[4]="H";}



// Not repeaters but a hub
if ($u[0] == 1195){$u[4]="H";}
 
// These are known repeaters. that fail autodetect
if ($u[0] == 1050){$u[4]="R";}
if ($u[0] == 1051){$u[4]="R";}
if ($u[0] == 1052){$u[4]="R";}
if ($u[0] == 1053){$u[4]="R";}
if ($u[0] == 1054){$u[4]="R";}

//1235|Manchac 675 - The Road Kill !!|Prairieville,LA|
//1236|Broadmoor 600 The Roadkill !!|Baton Rouge,LA|
//1237|Crescent City Connection 600 The Road Kill !!|New Orleans,LA|
//1238|Broadmoor 600 - The Road Kill !!|Baton Rouge,LA|
//1239|Lacombe 625 The Road Kill !! Lacombe, LA||

if ($u[0] == 1235){$u[4]="R";}
if ($u[0] == 1236){$u[4]="R";}
if ($u[0] == 1237){$u[4]="R";}
if ($u[0] == 1238){$u[4]="R";}
if ($u[0] == 1239){$u[4]="R";}
if ($u[0] == 1513){$u[4]="R";}
if ($u[0] == 1531){$u[4]="R";}
if ($u[0] == 1532){$u[4]="R";}
if ($u[0] == 1533){$u[4]="R";}
if ($u[0] == 1534){$u[4]="R";}
if ($u[0] == 1730){$u[4]="R";}
if ($u[0] == 1731){$u[4]="R";}
if ($u[0] == 1733){$u[4]="R";}
if ($u[0] == 2341){$u[4]="R";}
if ($u[0] == 2342){$u[4]="R";}


// These dont look like hubs force NODE
if ($u[0] == 1120){$u[4]="N";}
if ($u[0] == 1121){$u[4]="N";}
if ($u[0] == 1122){$u[4]="N";}
if ($u[0] == 1123){$u[4]="N";}
if ($u[0] == 1124){$u[4]="N";}
if ($u[0] == 1150){$u[4]="N";}
if ($u[0] == 1151){$u[4]="N";}
if ($u[0] == 1152){$u[4]="N";}
if ($u[0] == 1153){$u[4]="N";}
if ($u[0] == 1154){$u[4]="N";}

// hubs 
if ($u[0] == 900){$u[4]="H";}
if ($u[0] == 921){$u[4]="H";}
if ($u[0] == 922){$u[4]="H";}
if ($u[0] == 923){$u[4]="H";}

if ($u[0] == 2148){$u[4]="H";} //2148|Remote to WRQL436 462.550|Beatty,OR|[WRTX950]




 // false detections
if ($u[0]==750) {$u[4]= "Z";}
if ($u[0]==7501){$u[4]= "Z";} 

   
if ($u[0]==1105){$u[4]= "N";}
if ($u[0]==2978){$u[4]= "N";}// No named node?????


// Texas GMRS data 2250 - 2267 are corrupted. 
// This will auto fix. To Be removed.....
// 1 is blank 2 contains the data that should  be in 1

//2250||Texas GMRS Network - Statewide Link|
//2251||North Texas Hub|
//2252||South Texas Hub|
//2253||East Texas Hub|
//2254||West Texas Hub|
//2255||Memorial Park 550 Repeater|
//2256||Northwest Houston 725 Repeater|
//2257||Channelview 675 Repeater|
//2258||Dallas County REACT 675 Repeater|
//2259||Lufkin 725 Repeater|
//2260||Dickinson 650 Repeater|
//2261||La Marque 700 Repeater|
//2262||Montgomery 600 Repeater|
//2263||Conroe 700 Repeater|
//2264||La Grange 725 Repeater|
//2265||Lubbock 700 Repeater|
//2266||Sugar Land 600 Repeater|
//2267||Chappell Hill 650 Repeater|
//2268||Amarillo 650 Repeater|  

//slide over data to fix corruped entries above

// SLIDE 
if ($u[1] ==""){ $u[1]=$u[2]; $u[2]="";
   if($u[3]!=""){$u[2]=$u[3];$u[3]="";}
   
   }


//1040|Thomas,- Hammond, IN|(WRCW750)
//1041|Thomas,- Hammond, IN|(WRCW750)
//1042|Thomas|- Hammond, IN|(WRCW750)
//1043|Thomas|- Hammond, IN|(WRCW750)
//1044|Thomas|- Hammond, IN|(WRCW750)

// 1040 and 1041 have the wrong field have a , in place of a | 
// TBR if fixed
if ($u[0] ==1040){$u[1]="Thomas";$u[2]="Hammond, IN";$u[3]="[WRCW750]";$u[4]="N";}
if ($u[0] ==1041){$u[1]="Thomas";$u[2]="Hammond, IN";$u[3]="[WRCW750]";$u[4]="N";}



// pull id from the first field and put in 3 
$posL = strpos($u[1], "[W"); 
if ($posL>=1){
    $test = explode("[",$u[1]);$id= explode("]",$test[1]);
    $size= strlen($id[0]);
    if ($size <=8){$u[3]="[$id[0]]";} 
    }
     
// pull id from the first field and put in 3 
$posL = strpos($u[1], "(W"); 
if ($posL>=1){
    $test = explode("(",$u[1]);$id= explode(")",$test[1]);
    $size= strlen($id[0]);
    if ($size <=8){$u[3]="[$id[0]]";} 
    }
         
// FIX IDs in the wrong fields 
$posL = strpos("-$u[2]", "[W"); 
if ($posL>=1){
    $u[2]=str_replace("[", "", $u[2]);
    $u[2]=str_replace("]", "", $u[2]); 
    $u[2]=trim($u[2]);
    $u[3]="[$u[2]]";$u[2]="";
    }
    
    
    
// ID in wrong field 2 move to 3
//$posL = strpos($u[2], "W");$posR = strpos($u[2], "]"); 
//if($posL==1){
// if($posR==8){
//  $u[3]= "$u[2]";
//  $u[2]= "";
//}
//}

// fix states
$state = explode(",",$u[2]);

// Extra error checking
if(!isset($state[0])){$state[0]="";}
if(!isset($state[1])){$state[1]="";}


$state[1] = strtoupper($state[1]);
$state[1] = str_replace(" ", "", $state[1]);

if ($state[1]=="ALABAMA") {$state[1]="AL";}
if ($state[1]=="COLORADO"){$state[1]="CO";}
if ($state[1]=="GEORGIA") {$state[1]="GA";}
if ($state[1]=="NEWYORK") {$state[1]="NY";}
if ($state[1]=="INDIANA") {$state[1]="IN";}
if ($state[1]=="TEXAS")   {$state[1]="TX";}
if ($state[1]=="GEORGIA") {$state[1]="GA";}
if ($state[1]=="TXUSA")   {$state[1]="TX";}
if ($state[1]=="NCUSA")   {$state[1]="NC";}
if ($state[1]=="FLORIDA") {$state[1]="FL";}
if ($state[1]=="NORTHCAROLINA") {$state[1]="NC";}
if ($state[1]=="PENNSYLVANIA")  {$state[1]="PE";}
if ($state[1]=="OHIO")  {  $state[1]="OH";}
if ($state[1]=="OKLAHOMA"){$state[1]="OK";}
if ($state[1]=="OREGON")  {$state[1]="OR";}
if ($state[1]=="IDAHO")  { $state[1]="ID";}


$test = str_replace(" ", "", $state[0]);

if ($test=="Michigan"){    $state[1]="MI";$state[0]="";}
if ($test=="SanAntonioTx"){$state[1]="TX";$state[0]="San Antonio";}
if ($test=="BuckeyeAz"){   $state[1]="AZ";$state[0]="Buckeye";}
if ($test=="AshevilleNC"){ $state[1]="NC";$state[0]="Asheville";}
if ($test=="PlanoTX"){     $state[1]="TX";$state[0]="Plano";}
if ($test=="ElkhartIn"){   $state[1]="IN";$state[0]="Elkhart";}
 
$state[0]= ltrim( $state[0]);// Remove the leading spaces from the address
 
if($state[1]){  $u[2]= "$state[0],$state[1]";  } // cleaned up 

$u[3] = strtoupper($u[3]); // convert all IDS to upercase   

$u[0]=trim($u[0]);
$u[1]=trim($u[1]);
$u[2]=trim($u[2]);
$u[3]=trim($u[3]); 
$u[3] = str_replace("[", "", $u[3]);$u[3] = str_replace("]", "", $u[3]); 


               fwrite ($fileOUT,  "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]\n");
if($u[4]=="R"){fwrite ($fileOUT2, "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]\n");}
if($u[4]=="H"){fwrite ($fileOUT3, "$u[0]|$u[1]|$u[2]|$u[3]|$u[4]\n");}
 }
} 
fclose ($fileOUT);fclose ($fileOUT2);
print "<ok>
";
}

else{
$out="Missing Nodelist $nodelist";save_task_log ($out);
print "$datum $out\n";
}


}

