#!/usr/bin/php
// please download archive.php manualy from the repo

GMRS node manager

-New time temp weather system,Weather Alert system based on New API,
Supermon 1 click install,Setup screen. No editing files.,Supermon new weather forcast,
Supermon repeater and Hub index,Bridging notification and autofix,Reg Falure 
notification and autofix,Network Falure notification,High CPU Temp Alarm,CPU event alarms 
Alarms/Notificationover read by the node lady,Supermon Logbook,Uninstaller and Updater.
