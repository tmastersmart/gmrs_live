Node Manager for GMRSLive.com nodes.
GMRS Supermon customized for GMRS  (c)2023 lagmrs.com
=====================================================================

This software was written for GMRS nodes.  

* New time temp weather system
* Weather Alert system based on New API
* Weather temp system for NWS or Ambent Weather
* GMRS Supermon 1 click install
* DVSwitch 1 click install
* Setup Program in admin menu. No editing files.
* Supermon new weather forcast 
* Supermon repeater and Hub index
* Bridging notification and autofix 
* Reg Falure notification and autofix
* Network Falure notification
* High CPU Temp Alarms
* CPU event alarms 
* Uninstaller and Updater.
* Totaly new nodelist processor
* New bootup system gives IP,Reg status and CPU temp
* Muting of clock at night and during nets
* 


download the installer.
Drop to a shell
type

sudo wget https://raw.githubusercontent.com/tmastersmart/gmrs_live/main/install.php

This will download and install software to. /etc/asterisk/local/mm-software/
It will then run the setup program.

To run manualy, drop shell and type
cd /etc/asterisk/local/mm-software/
php setup.php


Select 1) Software edit 
Then 1) Weather setup

You will need to enter the weather station you wish to use. 

If you own a ambent weather station go to your ambent weather staton panel 
https://ambientweather.net/  click on my account https://ambientweather.net/account
Create a API Key and enter it in the setup.

Now enter a NWS station which includes APRS stations and MADIS stations.
Find your local station use the map https://madis-data.ncep.noaa.gov/MadisSurface/ 
make sure all DATASETS are turned on and find the code your closest station or 
airport and enter it. Defaults a Centrail Louisiana airport. 

Go back to edit menu and select 2) Level.
This is the level of what weather is spoken.

Select 3)Zipcode & 4)GPS position
The NWS has now geocoded all weather alerts and the new API requires this info to
get forcast and alerts.

Select 5)
Select the type of alerts you want read. 
Watch,Advisory,Statement

Select 6)
Temp monitor setup.

Select 7)
This should already be set to your node number

Select 8)
This displays LSNODES under your the status on your status page.
This is great for a signle node use. Turn on or off

Select A)
Auto connect to a hub on startup.
This allows you tu turn this on or off at will without manualy
editing files.

Select B)
Brididging detector system. Keep on unless you need it off

Select H)
Hide the IP at bootup. Controls if the ID is broadcast on bootup

Select I)
Allows you several options on how the local ID works. Or you can turn off ID

Select L)
Link down alarms. When on it will notify you if the node gets disconnected.

Select S) 
MDC1200 local burst. 

Select T)
Courtesy Tones. Lets you turn them on or off


Go back to main menu

Select 2)
Follow instructions to setup GMRS Supermon directory.

If you have problems keeping you  node registered
Select R)
register fix. Turn this option on to fix many register problems.



============================================================================  

 
Be sure that you are not running AUTOSKY.
Remove the start file that places the looping script in memory 
Edit /etc/rc.local file.
remove
/usr/local/bin/AUTOSKY/AutoSky
/usr/local/bin/AUTOSKY/AutoSky.ON





* licensing
Weather scripts use keys specialy created for this software licensed to me.
You may not use these keys in other software get your own.

All software is written by me.
You must have my permission to redistribute this software package. 
With I plan on granting I just need to list who is doing it thanks..... 



Modified supermon files which are in a seperate directory
and are licensed under the GNU General Public License v3.0
https://www.gnu.org/licenses/gpl-3.0.en.html



If you have any problems and need to uninstall please report them to me at www.lagmrs.com












  




* weather_pws.php Time and temp & weather
 
  I wrote this because the built in temp was not displaying the correct temp for
my area. I have my own weather station that submits data to the COWP which checks
and relays this data into the NWS system. Most all services use this for my city
but the node was not. This module pulls data from mesowest, madis, APRSWXNET/
Citizen Weather Observer Program (CWOP). APRSWXNET is the ham radio weather 
stations CWOP is the stations that submit through the net like mine.
 
  Find your local MADIS station and airport go to the map 
https://madis-data.ncep.noaa.gov/MadisSurface/  make sure all DATASETS are turned
on and find the code your station or a close station near you.

  
  I am using the new NWS API for forecast and alerts.  
  
  The module also has a high temp warning notice that will play after the weather. 
  It can warn of over temp and throttling of the CPU.

 Also included is a watchdog checking to see if net goes down and if you become unregistered.
 The automated reg fix will atempt to bring you back online. This wont work for everyone
 because it depends on why your unregistered. If your port is being blocked by your
 router, modem, isp or gateway after several days of use it will fix it.
 

Run the program by typing 

php weather_pws.php


Replace the time in cron
(source /usr/local/etc/allstar.env ; /usr/bin/nice -19 /usr/bin/perl /usr/local/sbin/saytime.p$

with this 
00 * * * * php /etc/asterisk/local/mm-software/weather_pws.php >/dev/null

* temp.php

 It will play High temp messages and any cpu code thrown including throttling.
For debugging you can have it say the current temp or
just talk when its over heating. Run it by typing 

php temp.php

You can run this by cron if you like but its built into the time and temp script also.
If you don't want to use time and temp you can just use temp.


* cap_warn.php
 The current alert script is way to hard to setup and most people are not even
using it. When they do it doesn't work right if not set up correctly. This is
my own version written from scratch in PHP. Its using the same sound files at
this time. Also the existing script uses a looping program that stays 
running in memory all the time. I do not like that I think its better to run 
it from cron on a schedule so its only in memory when it runs.

The second problem is the NWS is moving away from v1.1 cap to v1.2 and autosky will
stop working when its changed. I am using the NWS new API.
The new API is geocoded so you need to enter your LAT/LON

The program is backwards compatible with the autosky tailfile.
Supermon will have to be modified to read the new text files for alerts and forcast

edit rpt.conf to include this use , to add more than one file.
tailmessagelist=/tmp/AUTOSKY/WXA/wx-tail

Remove all other autosky settings and stop the looping script from running.

Edit cron and change

*/4 * * * * /usr/local/bin/AUTOSKY/AutoSky
to 
*/15 * * * * php /etc/asterisk/local/mm-software/skywarn.php >/dev/null

Use what ever time cycle you want. I prefer a longer cycle which keeps processes down.

Remove the start file that places the looping script in memory 
Edit /etc/rc.local file.
remove
/usr/local/bin/AUTOSKY/AutoSky
/usr/local/bin/AUTOSKY/AutoSky.ON

To test the alerts look for a feed on the alerts.weather.gov page with an alert
and enter that code in setup.

Run the program by typing ?php skywarn.php?


* config.php

 One of my main goals is to make it easer for new users who have never used a PI
before to edit things. The editor program solves that while allowing me to 
provide ongoing updates without requiring manual edits to files.


When running these programs from the command line you must enter 

php first then the program. 

====================================================================================
UPDATES

You need to run the U) update option about once a week until the software is finished.

In case of a major core update you will get a notice that a update is needed.
Minor module updates and bug fixes are out weekly.

====================================================================================
 
 






