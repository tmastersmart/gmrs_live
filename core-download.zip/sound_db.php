<?php
// (c)2023 by WRXB288 and LAgmrs.com  
//
// shared sound database processor 
//
// v2.0  07/27/2023
// v2.1  09/03/2023 ULAW bug fixed 
// v2.3  09/17/2023 fix for missing words and missing files


$soundDbWav = file("$path/sound_wav_db.csv");
$soundDbGsm = file("$path/sound_gsm_db.csv");
$soundDbUlaw= file("$path/sound_ulaw_db.csv");


$vpath ="/var/lib/asterisk/sounds";// old non database path


function check_wav_db ($in){
global $file1,$datum,$soundDbWav,$debug;
$filePlay=""; $file1="";
// search the database for the filename/location
foreach($soundDbWav as $line){
$u = explode(",", $line);

  if ($in==$u[1]){$filePlay="$u[0].wav";break;}
//if ($in==$u[1]){$filePlay=$u[0];break;}

}
if (file_exists($filePlay)){$file1 = $filePlay;}
else{$out="word $in [$filePlay.wav] not found";save_task_log ($out);print"$datum $out\n";}
if (!$filePlay){add_word($in);}
}

function check_gsm_db ($in){
global $file1,$datum,$soundDbGsm,$debug;
$filePlay="";$file1="";
// kludge to force weather sounds to match what we have
if($in=="thunderstorms"){$in="thunderstorm";}
if($in=="chance"){$in="chance-of";}
if($in=="showers"){$in="rain";} 
if($in=="nws"){$in="national weather service";} 
if($in=="then"){$in="later";}
 
// search the database for the filename/location
// path,filename,human readable name, 
foreach($soundDbGsm as $line){
$u = explode(",", $line);
if (isset($u[2])){ if ($in==$u[2]){$filePlay="$u[0]/$u[1].gsm";break;}}
if ($in==$u[1]){$filePlay="$u[0]/$u[1].gsm";break;}

//print"$datum Cycle though database failed to find $in\n";
}
if (file_exists($filePlay)){$file1 = $filePlay;}
else{$out="word $in [$filePlay.gsm] not found";save_task_log ($out);print"$datum $out\n";}
if (!$filePlay){add_word($in);}


}


function check_ulaw_db ($in){
global $file1,$datum,$soundDbUlaw,$debug;
$filePlay=""; $file1="";
foreach($soundDbUlaw as $line){
$u = explode(",", $line);
if ($in==$u[1]){$filePlay="$u[0]/$u[1]";break;} // filename
if ($in==$u[2]){$filePlay="$u[0]/$u[1]";break;} // This is the new common name
}

// We should not have to do this but sox is throwing this error
// sox FAIL formats: no handler for file extension `ulaw'
if (file_exists("$filePlay.ulaw")){ 
 if (!file_exists("$filePlay.ul")){copy("$filePlay.ulaw","$filePlay.ul");}
}

if (file_exists("$filePlay.ul")){$file1 = "$filePlay.ul";}
else{$out="word $in [$filePlay.ul] not found";save_task_log ($out);print"$datum $out\n";}
if (!$filePlay){add_word($in);}
}


// v2 non database number module 
// good for 0 - 1000
// not set up aything over 1000 yet. Use sincle number counts.
function make_number ($in){
global $datum,$vpath,$file0,$file1,$file2,$file3,$negative,$oh,$debug,$actionOut;
// Speak all possible numbers
// PHP Number matrix
$vpath ="/var/lib/asterisk/sounds";
$file0="";$file1="";$file2="";$file3="";$file4="";$negative="";$actionOut="";

if ($in <0 ){$negative = "$vpath/digits/minus.gsm";}
$in = abs($in);
$in = round($in); $input=$in;

if ($in >= 1000){         $file2  = "$vpath/digits/thousand.gsm";}
if ($in >= 10000){        $file2  = "$vpath/digits/million.gsm";} 



if ($in >= 100){          $file2  = "$vpath/digits/hundred.gsm"; 
if ($in>=100 and $in<200 ){$file0  = "$vpath/digits/1.gsm";$in = ($in -100);}
if ($in>=200 and $in<300 ){$file0  = "$vpath/digits/2.gsm";$in = ($in -200);}
if ($in>=300 and $in<400 ){$file0  = "$vpath/digits/3.gsm";$in = ($in -300);}
if ($in>=400 and $in<500 ){$file0  = "$vpath/digits/4.gsm";$in = ($in -400);}
if ($in>=500 and $in<600 ){$file0  = "$vpath/digits/5.gsm";$in = ($in -500);}
if ($in>=600 and $in<700 ){$file0  = "$vpath/digits/6.gsm";$in = ($in -600);}
if ($in>=700 and $in<800 ){$file0  = "$vpath/digits/7.gsm";$in = ($in -700);}
if ($in>=800 and $in<900 ){$file0  = "$vpath/digits/8.gsm";$in = ($in -800);}
if ($in>=900 and $in<1000){$file0  = "$vpath/digits/9.gsm";$in = ($in -900);}
}


if ($in>=20 and $in<30  ){$file3  = "$vpath/digits/20.gsm";$in=$in-20;} 
if ($in>=30 and $in<40  ){$file3  = "$vpath/digits/30.gsm";$in=$in-30;}
if ($in>=40 and $in<50  ){$file3  = "$vpath/digits/40.gsm";$in=$in-40;} 
if ($in>=50 and $in<60  ){$file3  = "$vpath/digits/50.gsm";$in=$in-50;}
if ($in>=60 and $in<70  ){$file3  = "$vpath/digits/60.gsm";$in=$in-60;} 
if ($in>=70 and $in<80  ){$file3  = "$vpath/digits/70.gsm";$in=$in-70;}
if ($in>=80 and $in<90  ){$file3  = "$vpath/digits/80.gsm";$in=$in-80;} 
if ($in>=90 and $in<100 ){$file3  = "$vpath/digits/90.gsm";$in=$in-90;}

if ($oh){
if ($in <=9 and !$file3) {$file3  = "$vpath/digits/oh.gsm";}
}
if ($in ==0 and !$file3 and !$file2) {$file4  = "$vpath/digits/0.gsm";}
if ($in >=1 and $in<20  ){$file4  = "$vpath/digits/$in.gsm";}  


if($file0){$actionOut = "$actionOut $file0";}
if($file1){$actionOut = "$actionOut $file1";}
if($file2){$actionOut = "$actionOut $file2";}
if($file3){$actionOut = "$actionOut $file3";}
if($file4){$actionOut = "$actionOut $file4";}

if($debug){print"$datum DEBUG: in:$input $actionOut\n"; }        

}


// This keeps track of words not in the database
function add_word($in){
global $datum,$path,$fileplay,$file1,$debug;
$file="$path/logs/words_to_add.txt";
$save=true;
if (is_readable($file)) {
$fileIN1= file($file);
foreach($fileIN1 as $line){ 
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
if ($line==$in){$save=false;break;}
 }
}

if($save){
$fileOUT = fopen($file, 'a+') ;flock ($fileOUT, LOCK_EX );
fwrite ($fileOUT, "$in\n");
flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
print"$datum Adding [$in] to the missing sounds list\n";
}
if($debug){ print"$datum DEBUG: in:$in is not in the database\n"; }        
}


?>
