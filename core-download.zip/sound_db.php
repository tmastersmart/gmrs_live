<?php
// (c)2023/2025 by WRXB288 / LAgmrs.com LA2way.com all rights reseved  
//
// shared sound processor 
// v2.0  07/27/2023
// v2.1  09/03/2023 ULAW bug fixed 
// v2.3  09/17/2023 fix for missing words and missing files
// v2.4  10/14/2023 if not in wav auto search gsm
// v2.5  01/24/24  Some debugging after new sounds . Error correction added
// v2.6  10/31/24 added date support 
// v2.7  11/25/24  Added dates and protection
// v2.8  2/13/2025 Better database error checking
//------------------------------------------------------------------------------
// v2.9  7/11/2025 Major upgrade. New non database version.  Saves 100k of memory
// v3.1  updated_weather_info,updated weather information
// v3.3 .4
// v3.4 cleanup of old code- major rewrite 
// 
$soundDbWav = [];$soundDbGsm = [];$soundDbUlaw = [];// they must exist because they might be in old code

require_once("$path/voicerss_tts.php");
//$vpath ="/var/lib/asterisk/sounds";// old non database path

// following is the upgrade functions 
// everything gets redirected to the new routine
function check_wav_db ($in){global $tts,$file1,$datum,$debug,$path;check_sound($in);}
function check_gsm_db ($in){global $tts,$file1,$datum,$debug,$path;check_sound($in);}
function check_ulaw_db($in){global $tts,$file1,$datum,$debug,$path;check_sound($in);}

// new function to find a file with no database.
function check_sound($in) {
    global $tts,$file1,$datum,$debug,$path;

if (trim($in) === '') {
 $out="Warning: Sound input was blank.";save_task_log ($out);print"$datum $out\n";
 return false;
}
  $raw_in = $in; // Save original input for logging

    $file1 = ""; // Clear output
    $filePlay = "";
    $cache_file = "$path/sound_cache.csv";    
    
      // Map known replacements
    $replacements = [
        // Months
        'january'   => 'mon-0',
        'february'  => 'mon-1',
        'march'     => 'mon-2',
        'april'     => 'mon-3',
        'may'       => 'mon-4',
        'june'      => 'mon-5',
        'july'      => 'mon-6',
        'august'    => 'mon-7',
        'september' => 'mon-8',
        'october'   => 'mon-9',
        'november'  => 'mon-10',
        'december'  => 'mon-11',

        // Days
        'sunday'    => 'day-0',
        'monday'    => 'day-1',
        'tuesday'   => 'day-2',
        'wednesday' => 'day-3',
        'thursday'  => 'day-4',
        'friday'    => 'day-5',
        'saturday'  => 'day-6',

        // AM/PM
        'am'        => 'a-m',
        'pm'        => 'p-m',
    
       // extras
    
        'nws'       => 'national-weather-service',
  'warning-bridged' => 'bridged',
  'updated-weather-information' => 'updated_weather_info',
  // NWS is famous for creating these warnings on the fly  
  'extreme-heat-warning' => 'excessive_heat_warning',
  'extreme-heat-watch'   => 'excessive_heat_watch',  
// these files were lost Temp fix
    
  'strong-click'=> 'boop',
  'light-click' => 'boop',
  'star-dull'   => 'boop', 
   
    
    
        // Special characters
        '.'  => 'dot',
        '`'  => 'ascii96',
        '_'  => 'ascii95',
        '^'  => 'ascii94',
        ']'  => 'ascii93',
        '\\' => 'ascii92',
        '['  => 'ascii91',
        '?'  => 'ascii63',
        '>'  => 'ascii62',
        '<'  => 'ascii60',
        ';'  => 'ascii59',
        ':'  => 'ascii58',
        ','  => 'comma1',
        '*'  => 'ascii42',
        ')'  => 'ascii41',
        '('  => 'ascii40',
        "'"  => 'ascii39',
        '&'  => 'ascii38',
        '%'  => 'ascii37',
        '$'  => 'ascii36',
        '"'  => 'ascii34',
        '~'  => 'ascii126',
        '}'  => 'ascii125',
        '|'  => 'ascii124',
        '{'  => 'ascii123'
    ];


// Normalize the input:
$lookup = strtolower(trim($in));
$lookup = str_replace(['_', ' '], '-', $lookup); // treat _, space as dash


    if (isset($replacements[$lookup])) {        $lookup = $replacements[$lookup];    }
    $lookup = str_replace(' ', '-', $lookup);
    $variants = [$lookup];
    if (strpos($lookup, '-') !== false) {        $variants[] = str_replace('-', '_', $lookup);    }
    if (strpos($lookup, '_') !== false) {        $variants[] = str_replace('_', '-', $lookup);    }


// Remove duplicates just in case
$variants = array_unique($variants);

   // All sound paths to check
  $paths = [
        "/usr/local/sbin/sounds",
        "/var/lib/asterisk/sounds",
        "/var/lib/asterisk/sounds/wx",
        "/var/lib/asterisk/sounds/rpt",
        "/var/lib/asterisk/sounds/phonetic",
        "/var/lib/asterisk/sounds/letters",
        "/var/lib/asterisk/sounds/ha",
        "/var/lib/asterisk/sounds/followme",
        "/var/lib/asterisk/sounds/digits",
        "/var/lib/asterisk/sounds/dictate",
        "/etc/asterisk/local/mm-software/sounds"
    ];

// File extensions to check

  // Step 1: Check cache
    if (file_exists($cache_file)) {
        $handle = fopen($cache_file, "r");
        if ($handle) {
            while (($line = fgetcsv($handle, 0, '|')) !== false) {
                if (strtolower($line[0]) === strtolower($lookup) && file_exists($line[1])) {
                    $file1 = $line[1];
                    fclose($handle);
                    return $file1;
                }
            }
            fclose($handle);
        }
    }


    // ?? Step 2: Dynamic search
$extensions = ['gsm', 'ul', 'wav', 'ulaw'];

    // Step 2: Search filesystem
    foreach ($variants as $variant) {
        foreach ($paths as $pathSound) {
            foreach ($extensions as $ext) {
                $filePlay = "$pathSound/$variant.$ext";
                if (file_exists($filePlay)) {
                    $file1 = ($ext === 'ulaw') ? "$pathSound/$variant.ul" : $filePlay;

                    if ($ext === 'ulaw' && !file_exists($file1)) {
                        copy($filePlay, $file1);
                    }

                    file_put_contents($cache_file, "$lookup|$file1\n", FILE_APPEND);
                    return $file1;
                }
            }
        }
    }
    
    $out="$raw_in ($lookup) not found in search";save_task_log ($out);print"$datum $out\n";
    $out="Warning: Input was [$in] with length: " . strlen($in);save_task_log($out);print"$datum $out \n";


// we will now build a new audio file if we have a key
if($tts ){
$out="Using our tts key to create ($lookup)";save_task_log ($out);print"$datum $out\n";
$raw_in = str_replace(['_', '-'], ' ', $raw_in); // make sure there no non text stuff

$makeFile="/etc/asterisk/local/mm-software/sounds/$lookup.gsm";
$ttsDir = "/tmp/tts";
$dateTag = date("Ymd_His");  // Example: 20250730_151105
$tmpSound = "$ttsDir/tts_$dateTag.wav";
// Ensure the directory exists
if (!is_dir($ttsDir)) {
    if (!mkdir($ttsDir, 0777, true)) { $out = "Failed to create TTS directory: $ttsDir"; save_task_log($out); print "$datum $out\n"; add_word($in);return false; }
}

// Create an instance of the VoiceRSS class
$voiceRSS = new VoiceRSS();
// Define the settings for the speech request
$settings = array(
    'key' => $tts,
    'src' => $raw_in, // Your text here
    'hl' => 'en-us', // Language (English - US)
    'v'  => 'Amy', // Voice (optional)
    'r'  => '0', // Rate (optional)
    'f'  => '8khz_16bit_mono',
    'c'  => 'wav', 
);

// Call the speech function to get the response
$response = $voiceRSS->speech($settings);
// Check if there was an error in the response
if ($response['error']) {
    echo "Error: " . $response['error'];
} else {
    $mp3Data = $response['response']; // The MP3 binary data
    if (file_put_contents($tmpSound, $mp3Data)) { $out="created $tmpSound ok";save_task_log($out);print"$datum $out \n";} 
   else {$out="failed to create a sound file";save_task_log($out);print"$datum $out \n"; add_word($in); return false;} 
}
// exec("lame --decode -b800 /tmp/cyclone.mp3 /tmp/cyclone.wav",$output,$return_var);
// sox -V ${TMPDIR}/audio.wav -r 8000 -c 1 -t ul ${TMPDIR}/audio${PID}.gsm
exec("sox -V $tmpSound -r 8000 -c 1 -t gsm $makeFile",$output,$return_var); 
if (file_exists($tmpSound)){unlink($tmpSound);}
    $out="created $makeFile" . strlen($in);save_task_log($out);print"$datum $out \n";
    $file1=$makeFile;
    return $file1;
}

else {  add_word($in);  return false;}


}





// v3 cleaned up my AI to handel all numbers
function make_number($in) {
    global $datum, $vpath, $debug, $oh, $actionOut;
    $vpath = "/var/lib/asterisk/sounds/digits";
    $actionOut = "";
    $input = $in;

    $files = [];

    if ($in < 0) {
        $files[] = "$vpath/minus.gsm";
        $in = abs($in);
    }

    // Handle thousands
    if ($in >= 1000) {
        $thousands = floor($in / 1000);
        if ($thousands > 0) {
            $files[] = "$vpath/$thousands.gsm";
            $files[] = "$vpath/thousand.gsm";
        }
        $in %= 1000;
    }

    // Handle hundreds
    if ($in >= 100) {
        $hundreds = floor($in / 100);
        if ($hundreds > 0) {
            $files[] = "$vpath/$hundreds.gsm";
            $files[] = "$vpath/hundred.gsm";
        }
        $in %= 100;
    }

    // Handle tens + teens
    if ($in >= 20) {
        $tens = floor($in / 10) * 10;
        $files[] = "$vpath/$tens.gsm";
        $in %= 10;
    }

    // Handle 1–19 (including leftover ones)
    if ($in > 0) {
        if ($oh && $in < 10 && empty($files)) {
            $files[] = "$vpath/oh.gsm";
        }
        $files[] = "$vpath/$in.gsm";
    }

    // Handle zero explicitly
    if (empty($files)) {
        $files[] = "$vpath/0.gsm";
    }

    // Join files for sox
    $actionOut = implode(" ", $files);

    if ($debug) { print "$datum DEBUG: in:$input $actionOut\n";}

    return $actionOut;
}



// v2 cleanded up by the IA
// Makes a proper day of the week string
function make_date_number($in) {
    global $datum, $debug, $actionOut;
    $vpath = "/var/lib/asterisk/sounds/digits";
    $actionOut = "";
    $in = abs(round($in));
    $input = $in;

    // irregular ordinals (special GSM files you already have)
    $special = [
        1  => "h-1.gsm",   // first
        2  => "h-2.gsm",   // second
        3  => "h-3.gsm",   // third
        5  => "h-5.gsm",   // fifth
        8  => "h-8.gsm",   // eighth
        9  => "h-9.gsm",   // ninth
        12 => "h-12.gsm",  // twelfth
        20 => "h-20.gsm",  // twentieth
        30 => "h-30.gsm",  // thirtieth
    ];

    // exact matches (covers all the exceptions)
    if (isset($special[$in])) {$actionOut = "$vpath/".$special[$in];}
    // 21–29 → "twenty" + "first..ninth"
    elseif ($in >= 21 && $in <= 29) {$actionOut = "$vpath/20.gsm $vpath/h-".($in-20).".gsm";}
    // 31–32 → "thirty" + "first/second"
    elseif ($in >= 31 && $in <= 32) { $actionOut = "$vpath/30.gsm $vpath/h-".($in-30).".gsm";}
    // everything else (4th, 6th, 7th, 10th, 11th, 13–19th)
    else { $actionOut = "$vpath/h-$in.gsm";}

    if ($debug) {print "$datum DEBUG: in:$input $actionOut\n";}
}


// This keeps track of words not in the database
function add_word($in){
    global $datum, $path, $fileplay, $file1, $debug;

    $file = "/etc/asterisk/local/mm-software/logs/words_to_add.txt";
    $save = true;

    // Ensure file is readable before checking for duplicates
    if (is_readable($file)) {
        $fileIN1 = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($fileIN1 === false) { save_task_log ("$datum ERROR: Failed to read $file");}
        
        // Check if the word is already in the file
        if (in_array(trim($in), $fileIN1, true)) { $save = false; }
    }

    if ($save) {
        // Try to open the file for writing
        $fileOUT = fopen($file, 'a+');
        if (!$fileOUT) {  save_task_log ("$datum ERROR: Failed to open $file for writing");}

        // Lock the file and attempt to write
        if (flock($fileOUT, LOCK_EX)) {
            $write_result = fwrite($fileOUT, "$in\n");
            flock($fileOUT, LOCK_UN);
        } 
        else {  save_task_log ("$datum ERROR: Could not lock $file for writing");   }

        fclose($fileOUT);

        // Verify if the write operation was successful
        if ($write_result === false) {  save_task_log ("$datum ERROR: Failed to write to $file");}
        else { print "$datum Adding [$in] to the missing sounds list\n";}
    }

    if ($debug) { print "$datum DEBUG: in:$in is not in the database\n"; }
}


?>
