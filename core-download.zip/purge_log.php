<?php
//  ------------------------------------------------------------
//  (c) 2023 by WRXB288 lagmrs.com all rights reserved
//
// Log purging system.
// Purges the data for the charts . 
// v1.2  Changed purge to 30 days for weather ( you can change if you wish)


$path="/etc/asterisk/local/mm-software";
include_once  ("$path/load.php");
$datum   = date('m-d-Y H:i:s');// always set date after load to set timezone

$purgeDays =7; // cpu
$purgeDays2 =30; // weather
$trim=0;
print"$datum Purging cpu temp log $purgeDays days "; 
$mmlogfile="$path/logs/cpu_temp_log.txt";
$datum = date('m-d-Y-H:i:s');
if (is_readable($mmlogfile)) {
$log="$path/logs/cpu_temp_log.txt2";
$fileOUT = fopen($log, "w") ;
flock( $fileOUT, LOCK_EX );
$fileIN = file($mmlogfile);
foreach($fileIN as $line){
 $line = str_replace('"', "", $line); // 01-06-2024-19:13:45,26.8, 
 $u = explode(",",$line);// 0 date 1=value
  $days=1; $len=strlen($u[0]);
      $ldate = explode("-",$u[0]); $len=strlen($ldate[2]);
//      print "$ldate[0]-$ldate[1]-$ldate[2] len $len\n";
      if ($len >=5){continue;}
      $first_date = mktime(12,0,0,$ldate[0],$ldate[1],$ldate[2]);
      $second_date = mktime(12,0,0,date('m'),date('d'),date('Y'));
      $offset = $second_date-$first_date;
      $days = floor($offset/60/60/24); // how old is the log in days
//print "$days";
 if ($days<=$purgeDays){ fwrite ($fileOUT, $line);}
 else{$trim++;}
}
print"ok trimed:$trim\n";
flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
if (file_exists($log)) {
 unlink ($mmlogfile);
 rename ($log, $mmlogfile);
}
}
$datum   = date('m-d-Y H:i:s');
$trim=0;
print"$datum Purging Weather logs $purgeDays2 days "; 
$weatherLogs  ="$path/logs/weather.csv";
$datum = date('m-d-Y-H:i:s');
if (is_readable($weatherLogs)) {
$log="$path/logs/weather_bak.csv";
$fileOUT = fopen($log, "w") ;
flock( $fileOUT, LOCK_EX );
$fileIN = file($weatherLogs);

foreach($fileIN as $line){
 $line = str_replace('"', "", $line); // 01-06-2024-19:13:45,26.8, 
 $u = explode(",",$line);// 0 date 1=value
  $days=1; $len=strlen($u[0]);
      $ldate = explode("-",$u[0]); $len=strlen($ldate[2]);
//      print "$ldate[0]-$ldate[1]-$ldate[2] len $len\n";
      if ($len >=5){continue;}
      $first_date = mktime(12,0,0,$ldate[0],$ldate[1],$ldate[2]);
      $second_date = mktime(12,0,0,date('m'),date('d'),date('Y'));
      $offset = $second_date-$first_date;
      $days = floor($offset/60/60/24); // how old is the log in days
// print "$days\n";
 if ($days<=$purgeDays2){ fwrite ($fileOUT, $line);}
  else{$trim++;}
}
print"ok trimed:$trim\n";
flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
if (file_exists($log)) {
 unlink ($weatherLogs);
 rename ($log, $weatherLogs);
}
}





