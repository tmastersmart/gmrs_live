<?php
//  ------------------------------------------------------------
//  (c) 2023 by WRXB288 lagmrs.com all rights reserved
//
// Log purging system.

$purgeDays =7;

$path="/etc/asterisk/local/mm-software";
include_once  ("$path/load.php");

//$log="/tmp/cpu_temp_log.txt";
$mmlogfile="$path/logs/cpu_temp_log.txt";
$datum = date('m-d-Y-H:i:s');


if (is_readable($mmlogfile)) {
$log="$path/logs/cpu_temp_log.txt2";
$fileOUT = fopen($log, "a") ;
flock( $fileOUT, LOCK_EX );
$fileIN = file($mmlogfile);

foreach($fileIN as $line){
 $line = str_replace('"', "", $line); // 01-06-2024-19:13:45,26.8, 
 $u = explode(",",$line);// 0 date 1=value
 $tmp=$u[1];
 $diff = $datum ->diff($u[0])->format("%a");
 if($diff<=$purgeDays){ fwrite ($fileOUT, "$line,$tmp, \n");}

 }


flock( $fileOUT, LOCK_UN );
fclose ($fileOUT);
}




