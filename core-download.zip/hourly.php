<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
//  00 * * * * php /etc/asterisk/local/mm-software/hourly.php >/dev/null
//
// Chron system calls this to run hr events 

// v1.2 09/30/23 cpu temp reg check moved out of weather file
// v1.3 11/03/23 HR cleanup added. 

$path="/etc/asterisk/local/mm-software";
include_once ("$path/load.php");        // main settings and functons

 
print"
==============Start Hourly cron loader=============

(c)2023 WRXB288 LAGMRS.com all rights reserved
===================================================
";

include_once ("$path/weather_pws.php") ;
sleep(15);
include_once ("$path/bridge_alarm.php");
$datum   = date('m-d-Y H:i:s');$hour=date('H');$day=date('D');
$mute=false;
if($MuteNet1){ if($hour>=$Net1Start and $hour <=$Net1Stop and $day=="Wed"){ $mute=true;$out="Net1 $day $hour Muted";}}
if($MuteNet2){ if($hour>=$Net2Start and $hour <=$Net2Stop and $day=="Sun"){ $mute=true;$out="Net2 $day $hour Muted";}}
if($MuteNet3){ if($hour>=$Net3Start and $hour <=$Net3Stop and $day=="Fri"){ $mute=true;$out="Net3 $day $hour Muted";}}
if($sleep)   { if($hour>=1 and $hour <=6){ $mute=true;$out="Sleep Mute $day $hour am";}}
if($mute){$out = "$out Muted sounds temp-alert";save_task_log ($out);print "$datum $out\n";}

sleep(10);
if(!$mute){include_once ("$path/temp.php");sleep(10);}
include_once ("$path/watchdog.php");

if($hour==12){ include_once ("$path/midnight.php");} 

unset ($soundDbWav);
unset ($soundDbGsm);
unset ($soundDbUlaw);


print"
================END Hourly cron loader=============\n";

?>
