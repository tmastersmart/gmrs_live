<?php
// (c)2023/24 by WRXB288 and LAgmrs.com all rights reserved
//

$path="/etc/asterisk/local/mm-software";
include_once ("$path/load.php");        // main settings and functons
$datum   = date('m-d-Y H:i:s');
print"
==============Start Midnight =============

(c)2023/24 WRXB288 LAGMRS.com all rights reserved
===================================================
";
include_once ("$path/purge_log.php"); 



// cleanup unnedded files
$file ="/tmp/xnodes.txt"; if(file_exists($file)){unlink($file);} // debugging file
$file ="/tmp/talk.gsm";   if(file_exists($file)){unlink($file);} // hubitat to node speaker link
$file ="/tmp/current-time.gsm";   if(file_exists($file)){unlink($file);} 
$file ="/tmp/current-bad.xml";   if(file_exists($file)){unlink($file);} 
$file ="/tmp/nodelist_needs_update.txt";   if(file_exists($file)){unlink($file);} 

// old left overs from older versions
$file ="/tmp/cpu_temp_log.txt";   if(file_exists($file)){unlink($file);} 
$file ="/etc/asterisk/local/mm-software/allstar_node_info.conf";if(file_exists($file)){unlink($file);}



print"
================END Midnight =============\n";

?> 
