<?php
// (c)2023/24 by WRXB288 and LAgmrs.com all rights reserved
//
//  0 0 23 ? * MON * php /etc/asterisk/local/mm-software/midnight.php >/dev/null
//
// Chron system calls this to do nightly maintance
 

$path="/etc/asterisk/local/mm-software";
include_once ("$path/load.php");        // main settings and functons
$datum   = date('m-d-Y H:i:s');
 
print"
==============Start Midnight cron loader=============

(c)2023/24 WRXB288 LAGMRS.com all rights reserved
===================================================
";

include_once ("$path/purge_log.php"); 






// add cleanup here
$file ="/tmp/xnodes.txt"; if(file_exists($file)){unlink($file);} // debugging file
$file ="/tmp/talk.gsm";   if(file_exists($file)){unlink($file);} // hubitat to node speaker link


print"
================END Hourly cron loader=============\n";

?> 
