<?php
// (c)2023  lagmrs.com
// Logs the IP (Dymanic ip detection) 
//
// v1  beta 

$path="/etc/asterisk/local/mm-software"; 
include_once ("$path/load.php"); 

$ver= "v1.b"; $release="11/2/2023";

if (!isset($counterNet)){$counterNet =0;}// safety

$datum = date('m-d-Y-H:i:s');

print"
===================================================
External IP ADDRESS Update $coreVersion $ver 
(c)2023 WRXB288 LAGMRS.com all rights reserved
===================================================
"; 

// We must have internet to do this
if ($counterNet <=2){ 
print "$datum ONLINE \n";
$file="";$out="";$myip="";$line="";// clear varables
$file="/tmp/external_ip.txt";

if (file_exists($file)){
 $ft = time()-filemtime($file); $fth=round($ft /3600);
  $fileIN= file($file);
 foreach($fileIN as $line){ print "$datum IP cached $fth hrs ago: $line\n"; }
 if ($ft > 8 * 3600){ unlink($file);} 
}
// $fth hrs old.


if(!file_exists($file)){

print "$datum Checking ipecho.net for external IP: ";
$myip = file_get_contents("http://ipecho.net/plain"); // better code

if (!$myip){ print"error\n"; save_task_log ("ipecho.net error");}

// doesnt work 
// http://checkip.dyndns.org:8245    =  Current IP Address: xx.xx.xx.xx
//print "$datum Checking checkip.dyndns.org for external IP: ";
//$myip = file_get_contents("checkip.dyndns.org:8245"); 
//if($myip){$u= explode(":",$myip);$myip=$u[1];}
//else{print"error\n"; save_task_log ("checkip.dyndns.org error");}


if($myip ){
 print"ok\n";
 $domain = gethostbyaddr($myip); 
 $out="[IP:$myip = $domain]"; print "$datum NEW: $out\n";  
 $fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$out);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
 if($line<>$out){save_task_log ($out);} // IP has changed from last check
 }
else{print"error\n"; save_task_log ("IP Lookup failed"); }
}
$file="";$out="";$myip="";$line="";// clear varables

}
else {print"$datum Skipping lookup we are Offline \n";}

print"===================================================
"; 

?>
