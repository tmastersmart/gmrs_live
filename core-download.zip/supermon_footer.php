<?php
// (c)2023 by WRXB288 and LAgmrs.com  
// Import this into link.php on supermon
// added conditions by WRXB288
$path         = "/etc/asterisk/local/mm-software";
include_once ("$path/load.php");
$memory = memory_get_usage() ;$memory =formatBytes($memory);

if (!isset($verGMRS)){$verGMRS="";}
print "<br><br>
<div align=\"center\">
<center><p style=\"margin-bottom:5px;margin-top:10px;\">$verGMRS Memory used $memory</p>
<table style=\"border-collapse: collapse\" bordercolor=\"#111111\" cellpadding=\"0\" cellspacing=\"0\" bgcolor=\"#000080\" width=\"100%\">
<tr>
<td align=\"center\"> <img src = \"/gmrs/images/node-manager.png\"> &emsp;<a href=\"http://www.lagmrs.com\"><img src = \"/gmrs/images/lagmrs-com.png\"></a> &emsp;<a href=\"http://www.gmrslive.com\"><img src = \"/gmrs/images/gmrs-live.png\"></a> &emsp;<img src = \"/gmrs/images/php.gif\"> &emsp; 
</td>
</tr>
</table>
</center>
</div>
";

?>
