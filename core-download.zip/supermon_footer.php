<?php
// (c)2023 by WRXB288 and LAgmrs.com  
// Import this into link.php on supermon
// added conditions by WRXB288
$path         = "/etc/asterisk/local/mm-software";
include_once ("$path/supermon_load_setup.php");
$memory = memory_get_usage() ;$memory =formatBytes($memory);
if (!isset($verGMRS)){$verGMRS="";}
if (!isset($betatest)){$betatest=false;}
$dateTime= date("m-d-Y h:i A");


print "<br><br>
<div align=\"center\">
<table style=\"border-collapse: collapse\" border=0 cellpadding=0 cellspacing=0  width=100%>
<tr>
<td align=\"center\"><small>$verGMRS | Memory used $memory | $dateTime</small>";
if($betatest){print"<br><small>This Page is in beta and may have problems, Please be paitent updates are on the way.</small>";}

print"</td>
</tr>
<tr>
<td align=\"center\" bgcolor=\"#000080\"> <img src = \"/gmrs/images/node-manager.png\"> &emsp;<a href=\"http://www.lagmrs.com\"><img src = \"/gmrs/images/lagmrs-com.png\"></a> &emsp;<a href=\"http://www.gmrslive.com\"><img src = \"/gmrs/images/gmrs-live.png\"></a> &emsp;<img src = \"/gmrs/images/php.gif\"> &emsp; 
</td>
</tr>
</table>

</div>
";

?>
