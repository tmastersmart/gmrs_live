<?php
// (c)2023 by WRXB288 and LAgmrs.com  
// Import this into link.php on supermon
// added conditions by WRXB288

print "<amall> GMRS Supermon </small>";

?>
