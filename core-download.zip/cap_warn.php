<?php
// (c)2023 by WRXB288 and LAgmrs.com  
//
//   _____ _       __          __                 _____          _____  
//  / ____| |      \ \        / /                / ____|   /\   |  __ \ 
// | (___ | | ___   \ \  /\  / /_ _ _ __ _ __   | |       /  \  | |__) |
//  \___ \| |/ / | | \ \/  \/ / _` | '__| '_ \  | |      / /\ \ |  ___/ 
//  ____) |   <| |_| |\  /\  / (_| | |  | | | | | |____ / ____ \| |     
// |_____/|_|\_\\__, | \/  \/ \__,_|_|  |_| |_|  \_____/_/    \_\_|     
//               __/ |                                                  
//              |___/   
//
//   weather.gov 
//
//What is CAP?
//Common Alerting Protocol (CAP)  is an XML-based information standard used to facilitate emergency information sharing and data exchange across
// local, state, tribal, national and non-governmental organizations of different professions that provide emergency response and management services.
//
//NWS produces CAP for NWS weather and hydrologic alerts including watches, warnings, advisories, and special statements. 
//NWS CAP messages follow the CAP v1.2 standard defined by the Organization for the Advancement of Structured Information Standards (OASIS) and 
//comply with the Federal Emergency Management Agency (FEMA) Integrated Public Alert and Warning System (IPAWS) CAP profile.  
//The National Weather Service (NWS) CAP v1.2 Documentation provided on this site supplements the OASIS CAP v1.2 standard and IPAWS CAP
// profile by identifying the formats of NWS information contained within NWS CAP messages. 

//Uses of CAP
//NWS CAP can be used to launch Internet messages, trigger alerting systems, feed mobile device applications, news feeds, television/radio display
// and audio, digital highway signs, synthesized voice over automated telephone calls, and much more.


// The goal of this project is to control the software and how it works without using any prior closed source scripts in the node.
// a total rewrite allows me to control how my node works. I wrote this for myself but am releaseing it to other GMRS users.
// This is ground up written from scratch php using
//
// Notice this is only as reliable as the weather.gov server which goes down from time to time & your node.
// Not responiable for any failed reports use as is at your own risk.
//
// Notes the tailfile is shorter for repeated use in tail file settings
//
// skywarn-tm.wav is temp file the program creates on a update. This should not be used as a tail file. it should be autodeleted

// v3.4 10-05-23  Major changes to weather API
// v3.5 10/14/2023  FEMAQ added
// v3.6 10/21/2023  Muteing adjustments.
// v3.7 10/31/2023  Loggoing
// v3.8 11/02/2023  Fixed Old files not getting cleared. Removed artifacts from before we played our own sounds.

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_start = $mtime;

$path      ="/etc/asterisk/local/mm-software";
$outTmp    ="/tmp/tmp.wav"; if (file_exists($outTmp)){unlink($outTmp);} 
$alertTxt  ="/tmp/skywarn.txt"; 
$alertTxtHeadline ="/tmp/skywarn_headline.txt"; 
$tailfile  ="/tmp/skywarn-tail.wav";  

$clash     ="/tmp/mmweather-task.txt";
// Safety if no tailfile reset. repair
if (!file_exists($tailfile)){  
 if (file_exists($alertTxt)){unlink($alertTxt);} 
 if (file_exists($alertTxtHeadline)){unlink($alertTxtHeadline);} 
}

$ver= "v3.8"; $release="11/02/2023";
  
include_once ("$path/load.php"); 
include_once ("$path/sound_db.php");



// do not change this its only for debugging 
//$skywarn="ARC111";// for live testing ONLY. Find a zone with an alert and enter it.


$phpVersion= phpversion();
$time= date('H:i');
$date =  date('m-d-Y');
$datum   = date('m-d-Y H:i:s');
$gmdatum = gmdate('m-d-Y H:i:s');
print "
===================================================
Cap Warn NWS API $coreVersion $ver 
(c)2023 WRXB288 LAGMRS.com all rights reserved
$phpzone PHP v$phpVersion   Release date:$release
===================================================
$datum Model: $piVersion
$datum Node:$node UTC:$gmdatum 
";
$action=""; 
// We dont want 2 voices at the same time playing
// This could happen if cron calls 2 at the same time.
if(file_exists($clash)){unlink($clash);
$out="Pausing for other thread(s) to finish";
print "$datum $out
"; save_task_log ($out);
sleep(25);
}



if (file_exists($tailfile)){print "$datum found: $tailfile\n";}   
if (file_exists($alertTxt)){print "$datum found: $alertTxt\n";} 
if (file_exists($alertTxtHeadline)){print "$datum found: $alertTxtHeadline\n";}




// test for mute move to start
$hour=date('H');$day=date('D');
$mute=false;
if($MuteNet1){ if($hour>=$Net1Start and $hour <=$Net1Stop and $day=="Wed"){ $mute=true;$out="Net1 $day $hour Muted";}}
if($MuteNet2){ if($hour>=$Net2Start and $hour <=$Net2Stop and $day=="Sun"){ $mute=true;$out="Net2 $day $hour Muted";}}
if($MuteNet3){ if($hour>=$Net3Start and $hour <=$Net3Stop and $day=="Fri"){ $mute=true;$out="Net3 $day $hour Muted";}}
if($sleep)   { if($hour>=1 and $hour <=6){ $mute=true;$out="Sleep Mute $day $hour am";}}
if($mute){save_task_log ($out);print "$datum $out\n";}

$forcastxml  ="/tmp/geocode.xml";
$forcastxml2 ="/tmp/forcast.xml";
$alertxml    ="/tmp/skywarn.xml";
$currentxml  ="/tmp/current.xml"; $currentTxt  ="/tmp/current.txt";
$acuwxml     ="/tmp/accuweather.xml";

//if (!$mute){
include_once ("$path/weather_api_pull.php"); 
include_once ("$path/forcast.php"); 
// returns  $apiVer,$description,$headline,$event,$icon,$shortForcast,$detailedForecast,

//$html = str_replace('"', "", $html);
//$pos = strpos($html, "features: []");if ($pos){$event="clear";}
//if (!$event){$out="Error Bad CAP data";save_task_log ($out);$CAPstatus="Bad Data";$event="";}

if ($event){$CAPstatus="new";} // default to a new event
if ($event=="clear"){all_clear("ok");$event="";}
if($debug){print "$datum CAPstatus--->:$CAPstatus\n";} 

if ($event){
$alertTxt  ="/tmp/skywarn.txt";$tailfile  ="/tmp/skywarn-tail.wav";

if (file_exists($alertTxt) ){ 
 $test = file_get_contents($alertTxt);
 if ($test <> $event){print "$datum Events have changed\n";$CAPstatus="new";save_task_log ("new Alert $event");}
else{ 
 $CAPstatus="no change";print "$datum Existing Event file [$CAPstatus]\n";
 $min  = date('i'); 
 if($min >=20 and $min <=40){
 
 if($burst){
   print "$datum MDC-1200 bursts $burst\n";
   exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);
 } 
 
 
 exec("sudo asterisk -rx 'rpt localplay $node /tmp/skywarn-tail'",$output,$return_var);
 print "$datum Playing alert at 30min mark : $tailfile\n"; $CAPstatus="Playing Tail File";
 }
}
}

//print "$datum Status [$CAPstatus]\n";
if ($CAPstatus=="new"){
print "$datum Creating new event files.\n";
$fileOUT = fopen($alertTxt,'w');fwrite ($fileOUT,$event);fclose ($fileOUT);
$fileOUT = fopen($alertTxtHeadline,'w');fwrite ($fileOUT,$headline);fclose ($fileOUT);
save_task_log ($event); // save it to the log

$file = $tailfile;if(file_exists($file)){unlink($file);} // kill the last tail file to prevent it launching during play

// has-issued-a,has-expired,weather-station,weather,
check_wav_db  ("silence1"); if($file1){$action = "$action $file1";}
check_wav_db  ("strong click");if($file1){$action = "$action $file1";}
check_wav_db  ("updated weather information"); if($file1){$action = "$action $file1";}
check_wav_db  ("weather service"); if($file1){if($file1){$action = "$action $file1";}}

$u= explode(",",$event); 

check_wav_db ("star dull"); if($file1){$action = "$action $file1";}
//check_gsm_db ("alert");if($file1){$action = "$action $file1";} 

$burnban=false;
foreach($u as $line){
if($line){ check_wav_db($line);if($file1){$action = "$action $file1";} } 
// check for major warrnings.
// persons in path of 
if($line=="Tornado Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("tornado");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Severe Thunderstorm Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("thunderstorm");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Hurricane Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("hurricane");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
if($line=="Blizzard Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("blizzard");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
// Sets a burnband message once
if($line=="Red Flag Warning" or $line=="Fire Weather Watch"){
 if(!$burnban){
   check_wav_db ("Burn Ban");
   if($file1){ $action = "$action $file1"; $burnban=true;}
  }
 }
 
}  
check_wav_db  ("light click"); if($file1){$action = "$action $file1";}  

$datum   = date('m-d-Y H:i:s'); 
//$hour=date('H');$day=date('D');
//$mute=false;
//if($MuteNet1){ if($hour>=$Net1Start and $hour <=$Net1Stop and $day=="Wed"){ $mute=true;$out="Net1 $day $hour Muted";}}
//if($MuteNet2){ if($hour>=$Net2Start and $hour <=$Net2Stop and $day=="Sun"){ $mute=true;$out="Net2 $day $hour Muted";}}
//if($MuteNet3){ if($hour>=$Net3Start and $hour <=$Net3Stop and $day=="Fri"){ $mute=true;$out="Net3 $day $hour Muted";}}
//if($sleep)   { if($hour>=1 and $hour <=6){ $mute=true;$out="Sleep Mute $day $hour am";}}
//if($mute){save_task_log ($out);print "$datum $out\n";}


if(!$mute){
// if($burst){
// print "$datum MDC-1200 bursts $burst\n";
// exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);
//} 


$outTmp    ="/tmp/tmp.wav";
exec ("sox $action $outTmp",$output,$return_var);
$datum   = date('m-d-Y H:i:s');
print "$datum Playing file $outTmp
";
$status= exec("sudo asterisk -rx 'rpt localplay $node /tmp/tmp'",$output,$return_var);
}

// build the shorter tail file
$action="";
check_wav_db  ("silence1"); if($file1){$action = "$action $file1";}
$u= explode(",",$event);
$burnban=false;
foreach($u as $line){
check_wav_db  ("star dull"); if($file1){$action = "$action $file1";}

if($line){ check_wav_db($line); if($file1){$action = "$action $file1";} }

// check for major warrnings.
// persons in path of 
if($line=="Tornado Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("tornado");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Severe Thunderstorm Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("thunderstorm");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Hurricane Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("hurricane");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
if($line=="Blizzard Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("blizzard");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
// Sets a burnband message once
if($line=="Red Flag Warning" or $line=="Fire Weather Watch"){
 if(!$burnban){
   check_wav_db ("Burn Ban");
   if($file1){ $action = "$action $file1"; $burnban=true;}
  }
 }

check_wav_db  ("light click"); if($file1){$action = "$action $file1";}
}
// $tailfile  ="/tmp/skywarn-tail.wav";  
exec ("sox $action $tailfile",$output,$return_var);
print "$datum Tailfile updated $tailfile\n";
}
} // if event
//else {all_clear("ok");}/// this is a dupe just to be safe 

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_end = $mtime;$script_time = ($script_end - $script_start);$script_time = round($script_time,2);
$datum  = date('m-d-Y H:i:s');
$memory = memory_get_usage() ;$memory =formatBytes($memory);

print "$datum ";$tagline="";tagline($tagline);print "\n";

print "$datum Line end Status:[$CAPstatus] Used:$memory $script_time Sec\n";
print"===================================================\n";





function all_clear($in){
global $file1,$file,$alertTxt,$tailfile,$node,$outTmp,$alertTxtHeadline;

$action="";
$datum   = date('m-d-Y H:i:s');
print "$datum Processing all Clear\n";

$outTmp    ="/tmp/tmp.wav"; if (file_exists($outTmp)){unlink($outTmp);} 


if (file_exists($tailfile)){unlink($tailfile);}
if (file_exists($alertTxtHeadline)){unlink($alertTxtHeadline);} 

// has-issued-a,has-expired,weather-station,weather,
// There has been a past alert so we need to clear
if (file_exists($alertTxt)){unlink($alertTxt);
check_wav_db  ("silence1");                    if($file1){$action = "$action $file1";}
check_wav_db  ("updated weather information"); if($file1){$action = "$action $file1";}
check_wav_db  ("strong click");                if($file1){$action = "$action $file1";}
check_wav_db  ("clear");                       if($file1){$action = "$action $file1";}
check_wav_db  ("star dull");                   if($file1){$action = "$action $file1";}
exec ("sox $action $outTmp",$output,$return_var);

$status ="Playing all clear $file";save_task_log ("All Events now Clear");print "$datum $status
";

$status= exec("sudo asterisk -rx 'rpt localplay $node /tmp/tmp'",$output,$return_var);
if(!$status){$status="OK";}
}


// we dont need this anymore. Was for system to play files. We play our own files now in cron.
//if (!file_exists($tailfile)){
//$file = $tailfile; 
//check_wav_db  ("silence1");if ($file1){ $fileIN = file_get_contents ($file1);file_put_contents ($file,$fileIN, FILE_APPEND);}
//$datum   = date('m-d-Y H:i:s');
//print "$datum tail file reset to silence. $tailfile\n";
//}


}




?>
