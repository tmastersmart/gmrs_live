<?php
// (c)2023 by WRXB288 and LAgmrs.com  
//
//   _____ _       __          __                 _____          _____  
//  / ____| |      \ \        / /                / ____|   /\   |  __ \ 
// | (___ | | ___   \ \  /\  / /_ _ _ __ _ __   | |       /  \  | |__) |
//  \___ \| |/ / | | \ \/  \/ / _` | '__| '_ \  | |      / /\ \ |  ___/ 
//  ____) |   <| |_| |\  /\  / (_| | |  | | | | | |____ / ____ \| |     
// |_____/|_|\_\\__, | \/  \/ \__,_|_|  |_| |_|  \_____/_/    \_\_|     
//               __/ |                                                  
//              |___/   
//
//   weather.gov 
//
//What is CAP?
//Common Alerting Protocol (CAP)  is an XML-based information standard used to facilitate emergency information sharing and data exchange across
// local, state, tribal, national and non-governmental organizations of different professions that provide emergency response and management services.
//
//NWS produces CAP for NWS weather and hydrologic alerts including watches, warnings, advisories, and special statements. 
//NWS CAP messages follow the CAP v1.2 standard defined by the Organization for the Advancement of Structured Information Standards (OASIS) and 
//comply with the Federal Emergency Management Agency (FEMA) Integrated Public Alert and Warning System (IPAWS) CAP profile.  
//The National Weather Service (NWS) CAP v1.2 Documentation provided on this site supplements the OASIS CAP v1.2 standard and IPAWS CAP
// profile by identifying the formats of NWS information contained within NWS CAP messages. 

//Uses of CAP
//NWS CAP can be used to launch Internet messages, trigger alerting systems, feed mobile device applications, news feeds, television/radio display
// and audio, digital highway signs, synthesized voice over automated telephone calls, and much more.

// Replaces existing no warning scripts with the mode modern CAP.


// v3.4 10-05-23  Major changes to weather API
// v3.5 10/14/2023  FEMAQ added
// v3.6 10/21/2023  Muteing adjustments.
// v3.7 10/31/2023  Loggoing
// v3.8 11/02/2023  Fixed Old files not getting cleared. Removed artifacts from before we played our own sounds.
// v3.9 11/07 23    stop duplicate burst
// v4.0 11/20       Added debugging info on muting
// v4.2 1/13 cleanup and changes to the anti clash routines
// v4.3 1/17 Bug fix in clear status  
// v4.4 1/21  Watch statement flags


$ver= "v4.4"; $release="1/22/2023";
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_start = $mtime;

$path      ="/etc/asterisk/local/mm-software";
$outTmp    ="/tmp/tmp.wav"; if (file_exists($outTmp)){unlink($outTmp);} 
$alertTxt  ="/tmp/skywarn.txt";
$tailfile  ="/tmp/skywarn-tail.wav";
$alertTxtHeadline    ="/tmp/skywarn_headline.txt";
$alertTxtDescription ="/tmp/skywarn_description.txt";  
$clash       ="/tmp/mmweather-task.txt";
$forcastxml  ="/tmp/geocode.xml";
$forcastxml2 ="/tmp/forcast.xml";
$alertxml    ="/tmp/skywarn.xml";
$currentxml  ="/tmp/current.xml"; 
$currentTxt  ="/tmp/current.txt";
$acuwxml     ="/tmp/accuweather.xml";

// Safety if no tailfile repair start over
if (!file_exists($tailfile)){  
 if (file_exists($alertTxt)){unlink($alertTxt);} 
 if (file_exists($alertTxtHeadline)){unlink($alertTxtHeadline);} 
}
 
include_once ("$path/load.php"); 
include_once ("$path/sound_db.php");

// do not change this its only for debugging 
//$skywarn="ARC111";// for live testing ONLY. Find a zone with an alert and enter it.

$phpVersion= phpversion();$CAPstatus="Clear";
$time= date('H:i');
$date =  date('m-d-Y');
$datum   = date('m-d-Y H:i:s');
$gmdatum = gmdate('m-d-Y H:i:s');
print "
===================================================
Cap Warn NWS API $coreVersion $ver 
(c)2023 WRXB288 LAGMRS.com all rights reserved
$phpzone PHP v$phpVersion   Release date:$release
===================================================
$datum Model: $piVersion
$datum Node:$node UTC:$gmdatum 
";
$action=""; 
// We dont want 2 voices at the same time playing
// keep seeing overlaps
// test for clash (only 1 thread allowed)
if(file_exists($clash)){
 $out="Waiting for other thread. "; save_task_log($out);print"$datum $out\n";
 sleep(90);
 // safety clear abandoned flags
 $ft = time()-filemtime($clash);
 $ft = round(($ft)/60); 
 if ($ft > 10){unlink($clash);}  // 10 mins
}
$fileOUT = fopen($clash,'w');fwrite ($fileOUT,$datum);fclose ($fileOUT);
if (file_exists($tailfile)){print "$datum found: $tailfile\n";}   
if (file_exists($alertTxt)){print "$datum found: $alertTxt\n";} 
if (file_exists($alertTxtHeadline)){print "$datum found: $alertTxtHeadline\n";}
// test for mute move to start
$hour=date('H');$day=date('D');
$mute=false;
if($MuteNet1){ if($hour>=$Net1Start and $hour <=$Net1Stop and $day=="Wed"){ $mute=true;$out="Net1 $day $hour Muted";}}
if($MuteNet2){ if($hour>=$Net2Start and $hour <=$Net2Stop and $day=="Sun"){ $mute=true;$out="Net2 $day $hour Muted";}}
if($MuteNet3){ if($hour>=$Net3Start and $hour <=$Net3Stop and $day=="Fri"){ $mute=true;$out="Net3 $day $hour Muted";}}
if($sleep)   { if($hour>=1 and $hour <=6){ $mute=true;$out="Sleep Mute $day $hour am";}}
if($mute){save_task_log ($out);print "$datum $out\n";}

include_once ("$path/weather_api_pull.php"); 
include_once ("$path/forcast.php"); 


if ($event=="clear"){all_clear("ok");$event="";}

// set the status
if ($event){
  $CAPstatus="new";
  if (file_exists($alertTxt) ){
  $test = file_get_contents($alertTxt);
  if ($test <> $event){print "$datum Events have changed\n";$CAPstatus="new";save_task_log ("new Alert $event");}
 else {$CAPstatus="no change";print "$datum Existing Event file [$CAPstatus]\n";}
 }
}
 

if($CAPstatus=="no change"){
$min  = date('i');if($min >=20 and $min <=45){
 if (!isset($bursted)) { $bursted =false;}
 if(!$bursted) {
  if($burst){
   print "$datum MDC-1200 bursts for ID $burst\n";
   exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);
   $bursted=true;
  } 
} 
 
 exec("sudo asterisk -rx 'rpt localplay $node /tmp/skywarn-tail'",$output,$return_var);
 $out ="Playing existing alert at 30min mark : $tailfile";save_task_log ($out);print "$datum $out\n";
 $CAPstatus="Playing Tail File";
}
 else {print"$datum Skipping must be 20 - 40 mins after the hr its $min\n"; $CAPstatus="mute";}
}


if ($CAPstatus=="new"){
print "$datum Creating new event files.\n";
$fileOUT = fopen($alertTxt,'w');fwrite ($fileOUT,$event);fclose ($fileOUT);
$fileOUT = fopen($alertTxtHeadline,'w');fwrite ($fileOUT,$headline);fclose ($fileOUT);
$fileOUT = fopen($alertTxtDescription,'w');fwrite ($fileOUT,$description);fclose ($fileOUT);

save_task_log ($event); // save it to the log

$file = $tailfile;if(file_exists($file)){unlink($file);} // kill the last tail file to prevent it launching during play

// has-issued-a,has-expired,weather-station,weather,
check_wav_db  ("silence1"); if($file1){$action = "$action $file1";}
check_wav_db  ("strong click");if($file1){$action = "$action $file1";}
check_wav_db  ("updated weather information"); if($file1){$action = "$action $file1";}
check_wav_db  ("weather service"); if($file1){if($file1){$action = "$action $file1";}}

$watchSTATUS="alert";
if ($watchS) { $watchSTATUS="Special Weather Statement";check_wav_db ($watchSTATUS);if($file1){$action = "$action $file1";$watchSTATUS="";} }
if ($watchA) { $watchSTATUS="advisory";                 }
if ($watchW) { $watchSTATUS="watch";                    }
if ($watchWa){ $watchSTATUS="warning";                  }
print "$datum Alert(s) Detected $watchSTATUS\n";
if ($watchSTATUS){check_gsm_db ($watchSTATUS);if($file1){$action = "$action $file1";}} 
check_wav_db  ("strong click");if($file1){$action = "$action $file1";}

$u= explode(",",$event); 
//check_wav_db ("star dull"); if($file1){$action = "$action $file1";}
//check_gsm_db ("alert");if($file1){$action = "$action $file1";} 

$burnban=false;
foreach($u as $line){
if($line){ check_wav_db($line);if($file1){$action = "$action $file1";} } 
// check for major warrnings.
// persons in path of 
if($line=="Tornado Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("tornado");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Severe Thunderstorm Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("thunderstorm");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Hurricane Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("hurricane");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
if($line=="Blizzard Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("blizzard");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
// Sets a burnband message once
if($line=="Red Flag Warning" or $line=="Fire Weather Watch"){
 if(!$burnban){
   check_wav_db ("Burn Ban");
   if($file1){ $action = "$action $file1"; $burnban=true;}
  }
 }
 
}  
check_wav_db  ("light click"); if($file1){$action = "$action $file1";}  

$datum   = date('m-d-Y H:i:s'); 

if(!$mute){
$outTmp    ="/tmp/tmp.wav";
exec ("sox $action $outTmp",$output,$return_var);
$datum   = date('m-d-Y H:i:s');print "$datum Playing file $outTmp\n";
$status= exec("sudo asterisk -rx 'rpt localplay $node /tmp/tmp'",$output,$return_var);
$out ="Playing new alert $outTmp";save_task_log ($out);print "$datum $out\n";
}

// build the shorter tail file
$action="";
check_wav_db  ("silence1"); if($file1){$action = "$action $file1";}
$u= explode(",",$event);$burnban=false;

foreach($u as $line){
check_wav_db  ("star dull"); if($file1){$action = "$action $file1";}

if($line){ check_wav_db($line); if($file1){$action = "$action $file1";} }

// check for major warrnings.
// persons in path of 
if($line=="Tornado Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("tornado");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Severe Thunderstorm Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("thunderstorm");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Hurricane Warning"){
 check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
 check_gsm_db ("hurricane");if($file1){$action = "$action $file1";}
 check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
if($line=="Blizzard Warning"){
 check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
 check_gsm_db ("blizzard");if($file1){$action = "$action $file1";}
 check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
// Sets a burnband message once Prevents dupes
if($line=="Red Flag Warning" or $line=="Fire Weather Watch"){
 if(!$burnban){
   check_wav_db ("Burn Ban");
   if($file1){ $action = "$action $file1"; $burnban=true;}
  }
 }

check_wav_db  ("light click"); if($file1){$action = "$action $file1";}
}

// $tailfile  ="/tmp/skywarn-tail.wav";  
exec ("sox $action $tailfile",$output,$return_var);
print "$datum Tailfile updated $tailfile\n";
 }
 // if event

//else {all_clear("ok");}/// this is a dupe just to be safe 
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_end = $mtime;$script_time = ($script_end - $script_start);$script_time = round($script_time,2);
$datum  = date('m-d-Y H:i:s');
$memory = memory_get_usage() ;$memory =formatBytes($memory);
print "$datum Line end Status:[$CAPstatus] Used:$memory $script_time Sec\n";
$tagline="";tagline($tagline);print "\n";
print"===================================================\n";
if(file_exists($clash)){unlink($clash);}



function all_clear($in){
global $file1,$file,$alertTxt,$tailfile,$node,$outTmp,$alertTxtHeadline;
$action="";$datum   = date('m-d-Y H:i:s');
print "$datum Processing all Clear\n";
$outTmp    ="/tmp/tmp.wav"; if (file_exists($outTmp)){unlink($outTmp);} 
if (file_exists($tailfile)){unlink($tailfile);}
if (file_exists($alertTxtHeadline)){unlink($alertTxtHeadline);} 
// has-issued-a,has-expired,weather-station,weather,
// There has been a past alert so we need to clear
if (file_exists($alertTxt)){
 unlink($alertTxt);
 check_wav_db  ("silence1");                    if($file1){$action = "$action $file1";}
 check_wav_db  ("updated weather information"); if($file1){$action = "$action $file1";}
 check_wav_db  ("strong click");                if($file1){$action = "$action $file1";}
 check_wav_db  ("clear");                       if($file1){$action = "$action $file1";}
 check_wav_db  ("star dull");                   if($file1){$action = "$action $file1";}
 exec ("sox $action $outTmp",$output,$return_var);
 $out ="All Events now Clear $file";save_task_log ($out);print "$datum $out\n";
 $status = exec("sudo asterisk -rx 'rpt localplay $node /tmp/tmp'",$output,$return_var);
 if(!$status){$status="OK";}
 }
}

?>
