<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
//
// Link check timming logic is in calling module
// This is just the alarm BidgeCheck takes care of detection.
//
// v1.1 09/03/2023 
// v1.2 09/18/23  reduced silence
// v1.3 02/11/24  cleanup.   
// v1.4 02/12     fix so it can run standalone for debuging  
// v1.5  needs flags $NUMLINKS,$connecting,$established,$connectingLine
// v1.6 2/25 mods for image 
// v1.7 2/25 anti clash to prevent talk over at reboot
// v1.8 2/25 recheck link down after the delay it was missing updates
// v2   3/8  Bug fix

$ver="v2.0";$release = "03/8/2025";
$path="/etc/asterisk/local/mm-software"; 
include_once ("$path/load.php");
include_once ("$path/sound_db.php");
$flag="/tmp/link-check-flag.txt";

$phpVersion= phpversion();
$datum = date('m-d-Y-H:i:s');
$out="";
// these incomming flags should be set.
if(!isset($mute)){$mute=false;}
if(!isset($cron)){$cron=false;}


print "
===================================================
Link monitor $coreVersion $ver 
(c) 2023/2025 by WRXB288 LAGMRS.com all rights reserved 
$phpzone PHP $phpVersion    Release date:$release
===================================================
$datum Model: $piVersion\n";
chdir($path);
$file = "/tmp/bridged.gsm";if(file_exists($file)){unlink($file);}
$clash         = "/tmp/mmweather-task.txt";
$start_test="/tmp/start-ok.txt";
// We dont want 2 voices talking at the same time.
// In alerts this might run before power up ip so we delay for a sec
print "$datum Pausing for other processes 40sec.\n";
sleep(40);
if(file_exists($clash)){
 $out="Waiting for other thread. "; save_task_log($out);print"$datum $out\n";
 sleep(90);
 // safety clear abandoned flags
 if(file_exists($clash)){   // fix for file being erased in loop
 $ft = time()-filemtime($clash);
 $ft = round(($ft)/60); 
 if ($ft > 10){unlink($clash);} 
 } // 10 mins
}


$nodes=0; $array1=false; $connectingLine=""; 
$status= exec("sudo asterisk -rx \"rpt xnode $node\" ",$output,$return_var); 

$fileIN= $output;  // use from memory
foreach($fileIN as $line){  if ($debug){ print "$line\n";}
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line); 
$line = str_replace(" ", "", $line); 
$posC = strpos("-$line", "CONNECTING");if($posC){$connecting=true;$connectingLine=$line;print"$datum Connecting\n";} // this is used by link_check.php
$posC = strpos("-$line", "ESTABLISHED");if($posC){$established=true;print"$datum established\n";}  // passed to link_check.php future usage                         
// get the network name
$pos2 = strpos("-$line", ",");if($pos2 and !$array1){$v = explode(",",$line);$array1=true;} // first array
$pos3 = strpos("-$line", "RPT_NUMLINKS"); if ($pos3){ $vv = explode("=",$line);$NUMLINKS=$vv[1];print"$datum RPT_NUMLINKS =$NUMLINKS\n";}
$pos1 = strpos("-$line", "RPT_ALINKS"); // RPT_ALINKS=1,1195TU   RPT_NUMLINKS=35 
if ($pos1){
$u = explode("=",$line);// get the value
$u3 = explode(",",$u[1]);
if (isset($u3[1])) {  
 $line =$u3[1];
 $networkNode  = (int) filter_var($line, FILTER_SANITIZE_NUMBER_INT);print"$datum RPT_ALINKS =$networkNode\n";
 //$networkNode  = substr($line, 0,strlen($line-2));// RPT_ALINKS=1,1196TU
 } // RPT_ALINKS=1,1195TU   RPT_NUMLINKS=35
else{break;} // if not connected to anything this will be blank
}

// print "RPT_ALINKS $line";
// links
$pos = strpos("-$line", "RPT_LINKS");
if ($pos){
$u = explode("=",$line);// get the value
$u2 = explode(",",$u[1]);// break up the fields
$nodes=$u2[0];print"$datum RPT_LINKS =$nodes\n";
}

}

if(!isset($NUMLINKS)){$NUMLINKS=0;$established=false;}
if(!isset($connecting)){$connecting=false;}
if(!isset($connectingLine)){$connectingLine="";}
if(!isset($established)){
 if ($NUMLINKS>=1){$established=true;}
 else{$established=false;}
}

$uptime = intval(trim(shell_exec("awk '{print $1}' /proc/uptime"))); // Get uptime in seconds
if ($uptime < 1800) { // 1800 seconds = 30 minutes
    $out = "mute: up for less than 30 minutes.";save_task_log($out);
    $mute = true;
} 



$HoldTime=30;
if(file_exists($flag)){   
$ft = time()-filemtime($flag);$minutes = floor($ft / 60); print "$datum $minutes mins since last play\n"; 
if ($LinkCheck==1){$HoldTime=15;}
if ($LinkCheck==2){$HoldTime=30;}
if ($LinkCheck==3){$HoldTime=60;}
if ($LinkCheck==4){$HoldTime=120;}
if ($ft > $HoldTime * 60 or $cron) {unlink($flag);print "$datum Ready to play.";} 
}

if(!file_exists($flag)){ 
 if($NUMLINKS <1 and !$connecting){
print "$datum Node:$node Is disconnected\n";
if (!$mute){
if($burst){print "$datum MDC-1200 bursts $burst\n";exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);} 
$action="";

check_wav_db ("strong click");if($file1){$action = "$action $file1";} 
check_gsm_db ("warning");     if($file1){$action = "$action $file1";} 
check_gsm_db ("this");     if($file1){$action = "$action $file1";} 
check_gsm_db ($nodeName);        if($file1){$action = "$action $file1";} 
//$oh=false;$x = (string)$node;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
check_gsm_db ("is");          if($file1){$action = "$action $file1";} 
//if($connecting) {check_gsm_db ("connecting");if($file1){$action = "$action $file1";}}  
check_gsm_db ("disconnected");if($file1){$action = "$action $file1";}
//check_gsm_db ("silence1");if($file1){$action = "$action $file1";} 
check_ulaw_db ("alllinksdisconnected"); if($file1){$action = "$action $file1";}
exec("sox $action $file",$output,$return_var); if($debug){print "DEBUG:$action";}
exec("sudo asterisk -rx 'rpt localplay $node /tmp/bridged'",$output,$return_var);
$fileOUT = fopen($flag, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,played link,$action\n");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
 } // not mute
} // numblinks -0
} // end flag check



if ($NUMLINKS <=1 and $connecting){
print "$datum Node:$node Is connecting\n";
if (!$mute){
if($burst){print "$datum MDC-1200 bursts $burst\n";exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);} 
$action="";
check_wav_db ("strong click");if($file1){$action = "$action $file1";}
check_gsm_db ($nodeName);         if($file1){$action = "$action $file1";} 
//$oh=false;$x = (string)$node;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
check_gsm_db ("is");          if($file1){$action = "$action $file1";} 
check_gsm_db ("connecting");if($file1){$action = "$action $file1";}
//check_gsm_db ("silence1");if($file1){$action = "$action $file1";} 
exec("sox $action $file",$output,$return_var); if($debug){print "DEBUG:$action";}
sleep(3);
exec("sudo asterisk -rx 'rpt localplay $node /tmp/bridged'",$output,$return_var);
 } 
}

if ($established){print "$datum Node:$node Is Established\n";}



// connection manager
// If we are stuck connecting make sure its our start up node and fix it
// Varables set from bridge_ararm.php file imported here
if($connecting) {
  $pos= strpos("-$connectingLine", $startUpNode); 
  if ($pos){
   watchdog ("man");// add to counter
   if($counterMan>=2){
   print "$datum Connection Manager triggered\n"; save_task_log ("Connection Manager triggered");

// needs a voice here.


   sleep(6);  //rpt fun 1998 *340000  //$startUp,$startUpNode 
   exec("sudo asterisk -rx 'rpt fun $node *71$startUpNode'",$output,$return_var);
   print "$datum Sending disconnect\n"; save_task_log ("Disconnect - waiting");
   sleep(40);// Delay neededto clear retry blocks at hub
   exec("sudo asterisk -rx 'rpt fun $node *73$startUpNode'",$output,$return_var);
   print "$datum Sending Reconnect \n"; save_task_log ("Reconnect");   
   watchdog ("okman");   
  }
 }
 else {watchdog ("okman");}
}
else {watchdog ("okman");}








print "===================================================\n";
?>

