<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
//
// Link check timming logic is in calling module
//
// v1.1 09/03/2023     

include_once ("$path/load.php");
include_once ("$path/sound_db.php");

$datum = date('m-d-Y-H:i:s');

if ($NUMLINKS <1 ){
// were not connected play the not connected alarm.
// node,is,disconnected,this
print "$datum Node:$node Is disconnected\n";

if($burst){
print "$datum MDC-1200 bursts $burst\n";
exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);
} 

if (!$mute){
$action="";
check_wav_db ("strong click");if($file1){$action = "$action $file1";}
check_gsm_db ("warning");     if($file1){$action = "$action $file1";} 

check_gsm_db ("node");        if($file1){$action = "$action $file1";} 
$oh=false;$x = (string)$node;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
check_gsm_db ("is");          if($file1){$action = "$action $file1";} 
check_gsm_db ("disconnected");if($file1){$action = "$action $file1";} 
check_gsm_db ("silence2");if($file1){$action = "$action $file1";} 


check_ulaw_db ("alllinksdisconnected"); if($file1){$action = "$action $file1";}


$file = "/tmp/bridged.gsm";if(file_exists($file)){unlink($file);}

exec("sox $action $file",$output,$return_var); if($debug){print "DEBUG:$action";}
exec("sudo asterisk -rx 'rpt localplay $node /tmp/bridged'",$output,$return_var);
}
}
?>

