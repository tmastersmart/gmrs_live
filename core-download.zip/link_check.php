<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
//
// Link check timming logic is in calling module
// This is just the alarm BidgeCheck takes care of detection.
//
// v1.1 09/03/2023 
// v1.2 09/18/23  reduced silence
// v1.3 02/11/24  cleanup.   
// v1.4 02/12     fix so it can run standalone for debuging  
// v1.5  needs flags $NUMLINKS,$connecting,$established,$connectingLine

$ver="v1.5";$release = "07/08/2024";
$path="/etc/asterisk/local/mm-software"; 
include_once ("$path/load.php");
include_once ("$path/sound_db.php");
$phpVersion= phpversion();
$datum = date('m-d-Y-H:i:s');
$out="";
// these incomming flags should be set.
if(!isset($mute)){$mute=false;}
if(!isset($NUMLINKS)){$NUMLINKS=0;$established=false;}
if(!isset($connecting)){$connecting=false;}
if(!isset($connectingLine)){$connectingLine="";}
if(!isset($established)){
 if ($NUMLINKS>=1){$established=true;}
 else{$established=false;}
}

print "
===================================================
Link monitor $coreVersion $ver 
(c) 2023/2024 by WRXB288 LAGMRS.com all rights reserved 
$phpzone PHP $phpVersion    Release date:$release
===================================================
$datum Model: $piVersion\n";
chdir($path);
$file = "/tmp/bridged.gsm";if(file_exists($file)){unlink($file);}
if ($NUMLINKS <1 and !$connecting){
print "$datum Node:$node Is disconnected\n";
if (!$mute){
if($burst){print "$datum MDC-1200 bursts $burst\n";exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);} 
$action="";
check_wav_db ("strong click");if($file1){$action = "$action $file1";}
check_gsm_db ("warning");     if($file1){$action = "$action $file1";} 
check_gsm_db ("node");        if($file1){$action = "$action $file1";} 
$oh=false;$x = (string)$node;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
check_gsm_db ("is");          if($file1){$action = "$action $file1";} 
//if($connecting) {check_gsm_db ("connecting");if($file1){$action = "$action $file1";}}  
check_gsm_db ("disconnected");if($file1){$action = "$action $file1";}
check_gsm_db ("silence1");if($file1){$action = "$action $file1";} 
check_ulaw_db ("alllinksdisconnected"); if($file1){$action = "$action $file1";}
exec("sox $action $file",$output,$return_var); if($debug){print "DEBUG:$action";}
exec("sudo asterisk -rx 'rpt localplay $node /tmp/bridged'",$output,$return_var);
 }
}




if ($NUMLINKS <=1 and $connecting){
print "$datum Node:$node Is connecting\n";
if (!$mute){
if($burst){print "$datum MDC-1200 bursts $burst\n";exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);} 
$action="";
check_wav_db ("strong click");if($file1){$action = "$action $file1";}
check_gsm_db ("node");        if($file1){$action = "$action $file1";} 
$oh=false;$x = (string)$node;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
check_gsm_db ("is");          if($file1){$action = "$action $file1";} 
check_gsm_db ("connecting");if($file1){$action = "$action $file1";}
check_gsm_db ("silence1");if($file1){$action = "$action $file1";} 
exec("sox $action $file",$output,$return_var); if($debug){print "DEBUG:$action";}
sleep(3);
exec("sudo asterisk -rx 'rpt localplay $node /tmp/bridged'",$output,$return_var);
 } 
}

if ($established){print "$datum Node:$node Is Established\n";}



// connection manager
// If we are stuck connecting make sure its our start up node and fix it
// Varables set from bridge_ararm.php file imported here
if($connecting) {
  $pos= strpos("-$connectingLine", $startUpNode); 
  if ($pos){
   watchdog ("man");// add to counter
   if($counterMan>=2){
   print "$datum Connection Manager triggered\n"; save_task_log ("Connection Manager triggered");

// needs a voice here.


   sleep(6);  //rpt fun 1998 *340000  //$startUp,$startUpNode 
   exec("sudo asterisk -rx 'rpt fun $node *71$startUpNode'",$output,$return_var);
   print "$datum Sending disconnect\n"; save_task_log ("Disconnect - waiting");
   sleep(40);// Delay neededto clear retry blocks at hub
   exec("sudo asterisk -rx 'rpt fun $node *73$startUpNode'",$output,$return_var);
   print "$datum Sending Reconnect \n"; save_task_log ("Reconnect");   
   watchdog ("okman");   
  }
 }
 else {watchdog ("okman");}
}
else {watchdog ("okman");}








print "===================================================\n";
?>

