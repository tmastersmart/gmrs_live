<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
//
// Link check timming logic is in calling module
// This is just the alarm BidgeCheck takes care of detection.
//
// v1.1 09/03/2023 
// v1.2 09/18/23  reduced silence
// v1.3 02/11/24  cleanup.   
 
$ver="v1.3";$release = "02/11/2024";

include_once ("$path/load.php");
include_once ("$path/sound_db.php");
$phpVersion= phpversion();
$datum = date('m-d-Y-H:i:s');
$out="";
print "
===================================================
Link monitor $coreVersion $ver 
(c) 2023/2024 by WRXB288 LAGMRS.com all rights reserved 
$phpzone PHP $phpVersion    Release date:$release
===================================================
$datum Model: $piVersion\n";
chdir($path);
$file = "/tmp/bridged.gsm";if(file_exists($file)){unlink($file);}
if ($NUMLINKS <1 ){
print "$datum Node:$node Is disconnected\n";
if (!$mute){
if($burst){print "$datum MDC-1200 bursts $burst\n";exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);} 
$action="";
check_wav_db ("strong click");if($file1){$action = "$action $file1";}
check_gsm_db ("warning");     if($file1){$action = "$action $file1";} 
check_gsm_db ("node");        if($file1){$action = "$action $file1";} 
$oh=false;$x = (string)$node;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
check_gsm_db ("is");          if($file1){$action = "$action $file1";} 
check_gsm_db ("disconnected");if($file1){$action = "$action $file1";} 
check_gsm_db ("silence1");if($file1){$action = "$action $file1";} 
check_ulaw_db ("alllinksdisconnected"); if($file1){$action = "$action $file1";}
exec("sox $action $file",$output,$return_var); if($debug){print "DEBUG:$action";}
exec("sudo asterisk -rx 'rpt localplay $node /tmp/bridged'",$output,$return_var);
 }
}
else{print "$datum Node:$node Is Connected\n";}
print "===================================================\n";
?>

