<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
//
// Loads the setup or if being edited the current edited setup.

$basename=basename($_SERVER['PHP_SELF']);
$piVersion = file_get_contents ("/proc/device-tree/model");
$phpzone = date_default_timezone_get();
$status="Error";
$path  = "/etc/asterisk/local/mm-software"; 
$fileWEB="/tmp/setup.txt";  // We have write permission
$fileSET="$path/setup.txt"; // We have read only permissions

//loadSetup ($in);

//function loadSetup($status){
//global $ambientApiKey,$parishCounty,$fema,$startUp,$startUpNode,$coreVersion,$burst,$DisplayNodes,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$MuteNet1;
//global $MuteNet2,$MuteNet3,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$LinkCheck,$beta,$saveDate,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch;
//global $sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog,$bridgeCheck,$hideIP,$idType,$fileWEB,$fileSET,$status;

print"<!-- Loading setup -->\n";

if (is_readable($fileWEB)) { $file=$fileWEB;$status="Reading from SAVE pending update";}
else{$file=$fileSET;$status="Reading from LIVE settings";}

if (is_readable($file)) {
   $fileIN= file($file); 

   foreach($fileIN as $line){
//     print"<!-- $line -->\n" ;
     $u = explode(",",$line);
           $Fheader =  $u[0];// 
             $node  =  $u[1];
          $station  =  $u[2];
             $level =  $u[3];
         $zipcode   =  $u[4];
         $IconBlock =  $u[5];
               $lat =  $u[6];
               $lon =  $u[7];
           $sayWarn =  $u[8];
          $sayWatch =  $u[9];
       $sayAdvisory = $u[10];
      $sayStatement = $u[11];
             $sleep = $u[12];
              $high = $u[13]; 
               $hot = $u[14];
          $nodeName = $u[15];
         $reportAll = $u[16];
          $saveDate = $u[17];
         $LinkCheck = $u[18];
              $beta = $u[19];
          $watchdog = $u[20];
             $debug = $u[21];
               $tts = $u[22];   
       $bridgeCheck = $u[23];
       $MuteNet1    = $u[24]; 
       $MuteNet2    = $u[25];
       $MuteNet3    = $u[26];
       $Net1Start   = $u[27]; 
       $Net1Stop    = $u[28];
       $Net2Start   = $u[29];
       $Net2Stop    = $u[30]; 
       $Net3Start   = $u[31];
       $Net3Stop    = $u[32];
       $DisplayNodes= $u[33];
       $burst       = $u[34];
       $startUp     = $u[35];
       $startUpNode = $u[36];
       $parishCounty= $u[37];
       $fema        = $u[38];
      $ambientApiKey= $u[39]; 
            $hideIP = $u[40];
             $idType= $u[41];
             $inTone= $u[42];
           $outToneL= $u[43];
           $outToneU= $u[44];
      $bridgeMonitor= $u[45]; 
             $banner= $u[46];  
                                           
    }
$status="$status $saveDate";
}
$i=0;
 foreach($u as $line){
 print"<!--#$i - $line -->\n"; 
 $i++;
 }
if (is_readable($fileWEB)) { $file=$fileWEB;$status="Reading from SAVE pending update";}
else{$file=$fileSET;$status="Reading from LIVE settings $saveDate";}

print"<!-- $status $file -->\n";
     
print"<!-- End setup -->\n";

?>
