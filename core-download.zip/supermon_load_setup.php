<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
//
// Loads the setup or if being edited the current edited setup.
// 1/6/24 added       $brokenBridge
// 1/12  Node password storage
// 1/21 rootpath added
// 2/4 Added timeout timer adjust
// 2/9 added adverts jingles

$basename=basename($_SERVER['PHP_SELF']);
$piVersion = file_get_contents ("/proc/device-tree/model");
$phpzone = date_default_timezone_get();
$status="Error";
$path  = "/etc/asterisk/local/mm-software"; 


$safe="";
print"<!-- Load -->\n";

$fileWEB="/tmp/setup.txt";  // We have write permission                                                                                   
if (is_readable($fileWEB)) {
   $fileIN= file($fileWEB);
   foreach($fileIN as $line){
//     print"<!-- $line -->\n" ;
     $u = explode(",",$line);
           $Fheader =  $u[0];// 
             $node  =  $u[1];
          $station  =  $u[2];
             $level =  $u[3];
         $zipcode   =  $u[4];
         $IconBlock =  $u[5];
               $lat =  $u[6];
               $lon =  $u[7];
           $sayWarn =  $u[8];
          $sayWatch =  $u[9];
       $sayAdvisory = $u[10];
      $sayStatement = $u[11];
             $sleep = $u[12];
              $high = $u[13]; 
               $hot = $u[14];
          $nodeName = $u[15];
         $reportAll = $u[16];
          $saveDate = $u[17];
         $LinkCheck = $u[18];
              $beta = $u[19];
          $watchdog = $u[20];
             $debug = $u[21];
               $tts = $u[22];   
       $bridgeCheck = $u[23];
       $MuteNet1    = $u[24]; 
       $MuteNet2    = $u[25];
       $MuteNet3    = $u[26];
       $Net1Start   = $u[27]; 
       $Net1Stop    = $u[28];
       $Net2Start   = $u[29];
       $Net2Stop    = $u[30]; 
       $Net3Start   = $u[31];
       $Net3Stop    = $u[32];
       $DisplayNodes= $u[33];
       $burst       = $u[34];
       $startUp     = $u[35];
       $startUpNode = $u[36];
       $parishCounty= $u[37];
       $fema        = $u[38];
      $ambientApiKey= $u[39]; 
            $hideIP = $u[40];
             $idType= $u[41];
             $inTone= $u[42];
           $outToneL= $u[43];
           $outToneU= $u[44];
      $bridgeMonitor= $u[45]; 
             $banner= $u[46];  
      $brokenBridge = $u[47];
      $NodePassword = $u[48];
         $docRouteP = $u[49];
// Auto upgrade from older versions
$levelForcast=true;if(isset($u[50])){$levelForcast= $u[50];}//new levels  
$levelDew=false;   if(isset($u[51])){$levelDew    = $u[51];}
$levelRain=true;   if(isset($u[52])){$levelRain   = $u[52];}
$levelPress=true;  if(isset($u[53])){$levelPress  = $u[53];}                 
$levelUvi=false;   if(isset($u[54])){$levelUvi    = $u[54];}
$levelTemp=true;   if(isset($u[55])){$levelTemp   = $u[55];}                 
$levelCond=true;   if(isset($u[56])){$levelCond   = $u[56];}         
$levelHum=true;    if(isset($u[57])){$levelHum    = $u[57];}
$levelWind=true;   if(isset($u[58])){$levelWind   = $u[58];} 
$tot=120000;       if(isset($u[59])){$tot         = $u[59];} // tx_timeout=180000 rx_timeout=120000   
$blipVerts = false;if(isset($u[60])){$blipVerts   = $u[60];} 
//$spare1    = "";   if(isset($u[61])){$spare1      = $u[61];} 
//$spare2    = "";   if(isset($u[62])){$spare2      = $u[62];}                                   
 }
$status="Tmp SAVE pending update $saveDate";$safe="<font color=red>Importing dont restart</font>";     
}
else {
// if cant read read the live file
$fileSET="$path/setup.txt"; // We have read only permissions
if (is_readable($fileSET)) {
   $fileIN= file($fileSET);  
   foreach($fileIN as $line){
//     print"<!-- $line -->\n" ;
     $u = explode(",",$line);
           $Fheader =  $u[0];// 
             $node  =  $u[1];
          $station  =  $u[2];
             $level =  $u[3];
         $zipcode   =  $u[4];
         $IconBlock =  $u[5];
               $lat =  $u[6];
               $lon =  $u[7];
           $sayWarn =  $u[8];
          $sayWatch =  $u[9];
       $sayAdvisory = $u[10];
      $sayStatement = $u[11];
             $sleep = $u[12];
              $high = $u[13]; 
               $hot = $u[14];
          $nodeName = $u[15];
         $reportAll = $u[16];
          $saveDate = $u[17];
         $LinkCheck = $u[18];
              $beta = $u[19];
          $watchdog = $u[20];
             $debug = $u[21];
               $tts = $u[22];   
       $bridgeCheck = $u[23];
       $MuteNet1    = $u[24]; 
       $MuteNet2    = $u[25];
       $MuteNet3    = $u[26];
       $Net1Start   = $u[27]; 
       $Net1Stop    = $u[28];
       $Net2Start   = $u[29];
       $Net2Stop    = $u[30]; 
       $Net3Start   = $u[31];
       $Net3Stop    = $u[32];
       $DisplayNodes= $u[33];
       $burst       = $u[34];
       $startUp     = $u[35];
       $startUpNode = $u[36];
       $parishCounty= $u[37];
       $fema        = $u[38];
      $ambientApiKey= $u[39]; 
            $hideIP = $u[40];
             $idType= $u[41];
             $inTone= $u[42];
           $outToneL= $u[43];
           $outToneU= $u[44];
      $bridgeMonitor= $u[45]; 
             $banner= $u[46];  
      $brokenBridge = $u[47];
      $NodePassword = $u[48];
         $docRouteP = $u[49];
// Auto upgrade from older versions
$levelForcast=true;if(isset($u[50])){$levelForcast= $u[50];}//new levels  
$levelDew=false;   if(isset($u[51])){$levelDew    = $u[51];}
$levelRain=true;   if(isset($u[52])){$levelRain   = $u[52];}
$levelPress=true;  if(isset($u[53])){$levelPress  = $u[53];}                 
$levelUvi=false;   if(isset($u[54])){$levelUvi    = $u[54];}
$levelTemp=true;   if(isset($u[55])){$levelTemp   = $u[55];}                 
$levelCond=true;   if(isset($u[56])){$levelCond   = $u[56];}         
$levelHum=true;    if(isset($u[57])){$levelHum    = $u[57];}
$levelWind=true;   if(isset($u[58])){$levelWind   = $u[58];} 
$tot=120000;       if(isset($u[59])){$tot         = $u[59];} // tx_timeout=180000 rx_timeout=120000   
$blipVerts = false;if(isset($u[60])){$blipVerts   = $u[60];} 
//$spare1    = "";   if(isset($u[61])){$spare1      = $u[61];} 
//$spare2    = "";   if(isset($u[62])){$spare2      = $u[62];}  

                                                    
    }
$status="LIVE settings $saveDate";$safe="<font color=green>LIVE</font>";    
}


}



if($debug){
$i=0; foreach($u as $line){ print"<!--#$i - $line -->\n"; $i++; }
} 

// double check that the file did not save while we were loading
//if (is_readable($fileWEB)) { $file=$fileWEB;$status="Tmp SAVE pending update";$safe="<font color=red>Importing dont restart</font>";}

print"<!-- $status -->\n";
print"<!-- End Load -->\n";

function formatBytes($size, $precision = 2)
{
    $base = log($size, 1024);
    $suffixes = array('B', 'KB', 'MB', 'GB', 'TB');   

    return round(pow(1024, $base - floor($base)), $precision) . $suffixes[floor($base)];
}


?>
