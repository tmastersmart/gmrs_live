<?php
//  ------------------------------------------------------------
//  (c) 2023 by WRXB288 lagmrs.com all rights reserved
//
// -------------------------------------------------------------
//
//   _____ _____  _    _   _______                     __  __             _ _             
//  / ____|  __ \| |  | | |__   __|                   |  \/  |           (_) |            
// | |    | |__) | |  | |    | | ___ _ __ ___  _ __   | \  / | ___  _ __  _| |_ ___  _ __ 
// | |    |  ___/| |  | |    | |/ _ \ '_ ` _ \| '_ \  | |\/| |/ _ \| '_ \| | __/ _ \| '__|
// | |____| |    | |__| |    | |  __/ | | | | | |_) | | |  | | (_) | | | | | || (_) | |   
//  \_____|_|     \____/     |_|\___|_| |_| |_| .__/  |_|  |_|\___/|_| |_|_|\__\___/|_|   


// Load the pi temp
print "<!--  Temp module -->\n";

$line= exec("/opt/vc/bin/vcgencmd measure_temp",$output,$return_var);// SoC BCM2711 temp

$line = str_replace("'", "", $line);
$line = str_replace("C", "", $line);
$u= explode("=",$line);
$temp=$u[1];
$tempf = (float)(($temp * 9 / 5) + 32);

// check for throttled
$line= exec("/opt/vc/bin/vcgencmd get_throttled",$output,$return_var);
$throttled = "";
$u= explode("x",$line);
if($u[1]== "0"){$throttled = "";}
if($u[1]== "1"){$throttled = "under-voltage-detected";}
if($u[1]== "2"){$throttled = "arm-frequency-capped";}
if($u[1]== "4"){$throttled = "currently-throttled";}
if($u[1]== "8"){$throttled = "soft-temp-limit-active";}
if($u[1]== "10000"){$throttled = "under-voltage-detected";}
if($u[1]== "20000"){$throttled = "arm-frequency-capping";}
if($u[1]== "80000"){$throttled = "throttling-has-occurred";}
if($u[1]== "80000"){$throttled = "soft-temp-limit-occurred";}


$date = date('H:i:s');
  
$span="<span style=\"background-color: palegreen;\">";
if ($temp >50){$span="<span style=\"background-color: yellow;\">";}
if ($temp >65){$span="<span style=\"background-color: red;\">";}
if ($temp >70){$span="<span style=\"font-weight: bold; color: yellow; background-color: red;\">";}

$span2="<span style=\"background-color: palegreen;\">";
if ($throttled){$span2="<span style=\"font-weight: bold; color: yellow; background-color: red;\">";}
else {$throttled = "No";}

// C is used for processors not F
// For Raspberry Pi 3+ 85c is the max temp 
// above 60C throttling will start.
// 30 -45 is a normal temp range. 


print "[CPU:$span $temp&deg;C</span> $tempf&deg;F Throttled:$span2 $throttled </span>Measured @ $date]";



$file = "/tmp/registered_flag.txt";
$file2= "/tmp/not_registered_flag.txt";

if(!file_exists($file) and !file_exists($file2)){ print"[Status: NA]";}

if(file_exists($file)){
$fileIN= file($file);
foreach($fileIN as $line){ 
print"[Status:<span style=\"background-color: palegreen;\">$line</span>]";
 }
}

if(file_exists($file2)){
$fileIN= file($file2);
foreach($fileIN as $line){
print"[Status:<span style=\"background-color: red;\">$line</span>]"; 
 }
} 


?>



