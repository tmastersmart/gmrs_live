<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved

// v1.1 node connect disconnect controler.
// 
// actions take place outside webspace for security.
// only works on this local server.
//
$path         = "/etc/asterisk/local/mm-software";
include_once ("$path/load.php");


function disconnect($in){
global $datum,$node,$output; 
exec("sudo asterisk -rx 'rpt cmd $node ilink 6 '",$output,$return_var);
print "Disconnect from all";
}






}
