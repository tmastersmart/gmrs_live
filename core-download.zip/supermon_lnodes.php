<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
// lsnodes replacement for GMRS... 
// 100 from scratch  
// No more CGI. 100% PHP using a clean database

// v1.2 09/18/23    Version check moved elsewhere
// v1.3 10/18/23    No permission to write to log from webserver.                logging removd

$ver="v1.9  10/24/2023";  // bug fix data leak from shared varables.

$u = array(); // fix for dataleaking
//unset ($u); 

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_start = $mtime;

$path          = "/etc/asterisk/local/mm-software";
$nodelist      = "/var/log/asterisk/astdb.txt";
$nodelistBU    = "$path/nodelist/astdb.txt";
$nodelistClean = "$path/nodelist/clean.csv";// nodelist

include_once ("$path/load.php");

// you can adjust this (for GMRS LIVE)
// none of these should ever bridge to each other
$BridgeAlarm1=1195;$BridgeDetect1=false;
$BridgeAlarm2=700; $BridgeDetect2=false;
//$BridgeAlarm2=1000;$BridgeDetect1=false; // test node
$BridgeAlarm3=611; $BridgeDetect3=false;
$BridgeAlarm4=900; $BridgeDetect4=false;
$BridgeDetect=0;

// a missing nodelist on reboot needs to be fixed for ast
// We dont use this ourself
if(!file_exists($nodelist)){
 //save_task_log ("Fixing missing nodelist"); when run from web directory we have no permission 
 if(file_exists($nodelistBU)){copy($nodelistBU,$nodelist );} // install backup
 exec("php $path/nodelist_process.php",$output,$return_var); // Force background
 }





if (!$DisplayNodes){
print"<!-- ListNODES is turned off -->\n";
die;
}



$datum   = date('m-d-Y H:i:s');$gmdatum = gmdate('m-d-Y H:i:s');
$nodes=0; $array1=false;


//$status= exec("sudo /bin/asterisk -rx \"rpt xnode $node\" > $lxnodes",$output,$return_var);
$status= exec("sudo /bin/asterisk -rx \"rpt xnode $node\" ",$output,$return_var);


if($debug){
$lxnodes ="/tmp/xnodes.txt"; if(file_exists($lxnodes)){unlink($lxnodes);}
foreach($output as $out){fwrite($fileOUT,"$out\n");}// loop through array and save 
flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
}

// using memory buffer
foreach($output as $line){ 

$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line); 
$line = str_replace(" ", "", $line); // print "<! -----$line----->\n";
// get the network name
$pos2 = strpos("-$line", ",");if($pos2 and !$array1){ $line= "*$node,$line"; $v = explode(",",$line);$array1=true;} // first array
$pos3 = strpos("-$line", "RPT_NUMLINKS"); 
if ($pos3){
$vv = explode("=",$line);// get the value
$NUMLINKS=$vv[1];}


$pos1 = strpos("-$line", "RPT_ALINKS"); // RPT_ALINKS=1,1195TU   RPT_NUMLINKS=35 
if ($pos1){
$u = explode("=",$line);// get the value
$u3 = explode(",",$u[1]);
$line =$u3[1];// this is the node# of the network 
$networkNode  = substr($line, 0,strlen($line-2)); // remove 2 letters  1195TU 
}

// print "RPT_ALINKS $line";
// links
$pos = strpos("-$line", "RPT_LINKS");  
if ($pos){
$u = explode("=",$line);// get the value
//print "$u[1]\n";
$u2 = explode(",",$u[1]);// break up the fields
$nodes=$u2[0]; 
$u2[0]="*$node";// insert our node
  }
}

// In some cases no data is returned on u2 but v always has data
// we use u2 if its provided and v as a backup.
// This is expermental not sure which one is best to use.
$nodes1=count($v); $nodes2=count($u2);
//$debug=true;

if ($debug){print"<!-- aray1 count:$nodes1 ";foreach($v as $line){print" $line";}print " -->\n";}  // this may be pesorted?
if ($debug){print"<!-- aray2 count:$nodes2 ";foreach($u2 as $line){print" $line";}print " -->\n";}

if ($nodes1 > $nodes2){// if there are more on v then thats a problem
$u2=$v;$nodes=count($v);
print "<!-- Using aray1 aray1 count:$nodes1 aray2 count:$nodes2-->\n";
}
else{print "<!-- Using aray2 aray1 count:$nodes1 aray2 count:$nodes2-->\n";}

//print "RPT_LINKS $line";
//sort($u2); 
if ($debug){print"<!-- Unsorted State on Left ";foreach($u2 as $line){print" $line";}print " -->\n";}
// do a strange sort
$i=0;$new=""; $st="";$stn="";
foreach($u2 as $line){
$i++;
$size=strlen($line);// only works if we do math first Why old php bug?
$st = substr($line, 0,1); // lleter in front T1195
$stn= substr($line, 1,$size); // string less 1st letter
if (!$new){$new="$stn$st";}
else{$new="$new,$stn$st";}
}
$unew = explode(",",$new);sort ($unew);$u2= $unew;

if ($debug){print"<!-- Sorted State on Right ";foreach($u2 as $line){print" $line";}print " -->\n";}

$line="";
$fileIN= file($nodelistClean); 
$hubName="Not in Nodelist";
// first get the name of the hub
foreach($fileIN as $line3){
$u = explode("|",$line3);
if($networkNode==$u[0]){$hubName=$u[1];break;} 
}

if ($nodes>1){
$pnt=""; $pntD=""; $i=0; $status=""; $dvs="";$tr=""; $prt="";$action="";$action2="";$action3="";$pntC="";$pntD=""; // if status is U unknown state
foreach ($u2 as $line){ 
$dvswitch=false;  $status ="";
$pos = strpos("-$line", "T");if ($pos){$status ="Transceive";}
$pos = strpos("-$line", "*");if ($pos){$status ="Transceive *";}
$pos = strpos("-$line", "C");if ($pos){$status ="Connecting";}
$pos = strpos("-$line", "R");if ($pos){$status ="Receive Only";}   //Receive-Only     print"<!-- $line -->\n";
$size=strlen($line);$size=$size-1;// only works if we do math first Why old php bug?
$line = substr($line, 0,$size);  


if (is_numeric($line)) {
// you can adjust this (for GMRS LIVE)
// none of these should ever bridge to each other
if($line==$BridgeAlarm1){$BridgeDetect1=true;$BridgeDetect++;print"<!--- $BridgeAlarm1 detected --->\n";}
if($line==$BridgeAlarm2){$BridgeDetect2=true;$BridgeDetect++;print"<!--- $BridgeAlarm2 detected --->\n";}
if($line==$BridgeAlarm3){$BridgeDetect3=true;$BridgeDetect++;print"<!--- $BridgeAlarm3 detected --->\n";}
foreach($fileIN as $line2){
$u = explode("|",$line2);
if(trim($u[4])=="N"){$u[4]="";}
if($line==$u[0]){
 $pnt="<td>$u[0]</td><td>$u[1]</td><td>$u[2]</td><td>$u[3]</td><td>$status</td><td>$u[4]</td></tr>";
  if ($u[2]=="" ){$pnt="<td>$u[0]</td><td colspan=2> $u[1]</td><td>$u[3]</td><td>$status</td><td>$u[4]</td></tr>";}
  if ($u[2]=="" and $u[3]=="" ){$pnt="<td>$u[0]</td><td colspan=3> $u[1]</td><td>$status</td><td>$u[4]</td></tr>";}
  break;
}
if (!$pnt){$pnt="<td>$line</td><td colspan=3>This Node is not in the Database!</td><td>$status</td><td></td></tr>";} // failed to find it
 }
}
// its IAX
else{$pntD="<td colspan=3>DV switch - IAX connection</td><td>$line</td><td>Transceive</td><td>IAX</td></tr>";$status="";}

if ($status == "Connecting" ){$tr="<tr class=\"gColor\">";$pntC="<td>$u[0]</td><td>$u[1]</td><td>$u[2]</td><td>$u[3]</td><td>$status</td><td>$u[4]</td></tr>";$pnt="";}   
else{
$i++;$st="";
if ($i == 1){$tr="<tr class=\"tColor\">";}
if ($i == 2){$tr="<tr class=\"wColor\">";$i=0;}

if ($BridgeDetect>=2){
if($BridgeDetect1){ if ($u[0]==$BridgeAlarm1){$tr="<tr class=\"rColor\">";} }
if($BridgeDetect2){ if ($u[0]==$BridgeAlarm2){$tr="<tr class=\"rColor\">";} }
if($BridgeDetect3){ if ($u[0]==$BridgeAlarm3){$tr="<tr class=\"rColor\">";} }
if($BridgeDetect4){ if ($u[0]==$BridgeAlarm4){$tr="<tr class=\"rColor\">";} }
}


}
if($pnt) {$action= "$action $tr $pnt\n";  $pnt="";}
if($pntD){$action2="$action2 $tr $pntD\n"; $pntD="";}
if($pntC){$action3="$action3 $tr $pntC\n"; $pntC="";}
//if($pntE){$action3="$action3 <tr class=\"lColor\"> $pntE\n"; $pntE="";$i=$i-1; }
}

//    rColor=darkblue cColor=red bColor=palegreen gColor=lightgray tColor=lemonchiffon lColor=powderblue  <tr class="gColor">    
//$fdate="last modified: " . date ("F d Y H:i:s.", filemtime($lxnodes));
$title = "Scan found ($nodes) nodes connected to the [$hubName] HUB/Node<br>
 This full network scan finds all Hidden nodes connected down stream on other connected HUBS.";

//save_task_log ("$nodes nodes connected to the $hubName");



print "<table border=0 class=gridtable id=AutoNumber1 '> ";
print "<tr class=\"gColor\"><td colspan=8 align=center><font size=small>$title</font></td></tr>";

// phase 1 of bridging detection
if ($BridgeDetect>=2){
$line="";
if ($BridgeDetect1){$line="$line $BridgeAlarm1";}
if ($BridgeDetect2){$line="$line $BridgeAlarm2";}
if ($BridgeDetect3){$line="$line $BridgeAlarm3";}
if ($BridgeDetect4){$line="$line $BridgeAlarm4";}
print "<tr class=\"cColor\"><td colspan=8 align=center><font size=small>ALARM Bridged ($line)</font></td></tr>";
}

print "<tr class=\"gColor\"><td>NODE</td><td style='text-align: center; vertical-align: middle;'>Description</td><td>Location</td><td>call<td>status</td><td>TYPE</td></tr>";
print "$action";
if ($action2){
print"<tr class=\"gColor\"><td colspan=3 align=center> DVSWITCH / (Inter-Asterisk eXchange) Clients</td><td>CALL</td><td>Status</td><td>Type</td></tr>";  
print "$action2";
}
if ($action3){
print "<tr class=\"gColor\"><td>NODE</td><td style='text-align: center; vertical-align: middle;'>Problem Nodes - Description</td><td>Location</td><td>call<td>status</td><td>TYPE</td></tr>";
print "$action3";
}
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_end = $mtime;$script_time = ($script_end - $script_start);$script_time = round($script_time,2);

print"<tr class=\"gColor\"><td colspan=8 align=center><input type=\"button\" class=\"submit\" Value=\"POPUP Refresh\" onclick=\"window.open('lsnodes.php','All nodes in the hub link','status=no,location=no,toolbar=no,width=800,height=550,left=100,top=100')\"> (c)2023 by WRXB288  (Total Time to process $script_time Sec) </td></tr>";  
print"</table>";   
}
else{
print"<!-- nothing here to display -->";
print"<p> No nodes detected please try again in a few secs.</p>";
print"<input type=\"button\" class=\"submit\" Value=\"POPUP Refresh\" onclick=\"window.open('lsnodes.php','All nodes in the hub link','status=no,location=no,toolbar=no,width=800,height=550,left=100,top=100')\"> (c)2023 by WRXB288  (Total Time to process $script_time Sec)";  

}



?>
