<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
// lsnodes replacement for GMRS... 
// 100 from scratch  
// No more CGI. 100% PHP using a clean database

// v1.2 09/18/23 Version check moved elsewhere
// v1.3 10/18/23 No permission to write to log from webserver.                logging removd
// v2.0 10/29/23 Tweeks to coloring when bridged. Remove botom comment when not connected.
// v2.1 10/30/23 Added detection if IAX clients by nodelist   // bug fix data leak from shared varables.
// v2.2 10/31/23 trying to find the cross linked varabls
// v2.3 11/01/23 FORCE IAX into upercase
// v2.5 11/8/23  When a node is not in the database request nodelist update
// v2.6 11/10/23 adjustments to iax lookip
// v2.7 11/16   Changes to class  and nodelist IAX lookup database changes
// v2.8 11/26   Fix for blank data in IAX ID crashing script. Bug was looking in nodelist and db.
// v2.9 12/19   Changes in nodelist rebuild request

$ver="v2.9  12/19/2023";  

$Btest = false;

$u = array();
$u2 = array();
$u3 = array();

$line=""; $i=0;$i2=0;$i3=0;$v=0;$networkNode="";$script_time=0;// fix
//unset ($u); 

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_start = $mtime;

$path          = "/etc/asterisk/local/mm-software";
$nodelist      = "/var/log/asterisk/astdb.txt";
$nodelistBU    = "$path/nodelist/astdb.txt";
$nodelistClean = "$path/nodelist/clean.csv";// nodelist
$localDatabase = "$path/lookup-database.csv";
$NodeListCache = "/tmp/nodes-cache.csv";// this holds active nodes being used
include_once ("$path/load.php");

// you can adjust this (for GMRS LIVE)
// none of these should ever bridge to each other
$BridgeAlarm1=1195;$BridgeDetect1=false;
$BridgeAlarm2=700; $BridgeDetect2=false;
//$BridgeAlarm2=1000;$BridgeDetect1=false; // test node
$BridgeAlarm3=611; $BridgeDetect3=false;
$BridgeAlarm4=900; $BridgeDetect4=false;
$BridgeDetect=0;

// a missing nodelist on reboot needs to be fixed for ast
// We dont use this ourself
if(!file_exists($nodelist)){
 print"\n<!--Requesting a nodelist rebuild -->\n";
 if(file_exists($nodelistBU)){copy($nodelistBU,$nodelist );} // install backup
 $flag  ="/tmp/nodelist_updated.txt"; if(file_exists($flag)){unlink($flag);}
 $flag  ="/tmp/nodelist_needs_update.txt"; $fileOUT = fopen($flag,'w');fwrite ($fileOUT,"$datum");fclose ($fileOUT);
 }





if (!$DisplayNodes){
print"<!-- ListNODES is turned off -->\n";
die;
}

print"<!-- ListNODES $ver -->\n";

$datum   = date('m-d-Y H:i:s');$gmdatum = gmdate('m-d-Y H:i:s');
$nodes=0; $array1=false;

$output="";$line="";$out="";
//$status= exec("sudo /bin/asterisk -rx \"rpt xnode $node\" > $lxnodes",$output,$return_var);
$status= exec("sudo /bin/asterisk -rx \"rpt xnode $node\" ",$output,$return_var);

// running debug 

//$lxnodes ="/tmp/xnodes.txt"; if(file_exists($lxnodes)){unlink($lxnodes);} // We dont have permision to unlink from webserver
//if($Btest){
//$fileOUT = fopen($lxnodes, 'w') ;flock ($fileOUT, LOCK_EX );
//foreach($output as $out){fwrite($fileOUT,"$out\n");}// loop through array and save 
//flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
//}

// using memory buffer
foreach($output as $line){ 

$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line); 
$line = str_replace(" ", "", $line); if($Btest){ print "<! -----$line----->\n";}
// get the network name
$pos2 = strpos("-$line", ",");if($pos2 and !$array1){ $line= "*$node,$line"; $v = explode(",",$line);$array1=true;} // first array
$pos3 = strpos("-$line", "RPT_NUMLINKS"); 
if ($pos3){
$vv = explode("=",$line);// get the value
$NUMLINKS=$vv[1];}


$pos1 = strpos("-$line", "RPT_ALINKS"); // RPT_ALINKS=1,1195TU   RPT_NUMLINKS=35 
if ($pos1){
$u = explode("=",$line);// get the value
$u3 = explode(",",$u[1]);
$line =$u3[1];// this is the node# of the network 
$networkNode  = substr($line, 0,strlen($line-2)); // remove 2 letters  1195TU 
}

// print "RPT_ALINKS $line";
// links
$pos = strpos("-$line", "RPT_LINKS");  
if ($pos){
$u = explode("=",$line);// get the value
//print "$u[1]\n";
$u2 = explode(",",$u[1]);// break up the fields
$nodes=$u2[0]; 
$u2[0]="*$node";// insert our node
  }
}

// In some cases no data is returned on u2 but v always has data
// we use u2 if its provided and v as a backup.
// This is expermental not sure which one is best to use.
$nodes1=count($v); $nodes2=count($u2);
//$debug=true;

if ($Btest){
print"<!-- aray1 count:$nodes1 ";foreach($v as $line){print" $line";}print " -->\n";  // this may be pesorted?
print"<!-- aray2 count:$nodes2 ";foreach($u2 as $line){print" $line";}print " -->\n";}

if ($nodes1 > $nodes2){// if there are more on v then thats a problem
$u2=$v;$nodes=count($v);
print "<!-- Using aray1 aray1 count:$nodes1 aray2 count:$nodes2-->\n";
}
else{print "<!-- Using aray2 aray1 count:$nodes1 aray2 count:$nodes2-->\n";}

//print "RPT_LINKS $line";
//sort($u2); 
if ($Btest){print"<!-- Unsorted State on Left ";foreach($u2 as $line){print" $line";}print " -->\n";}
// do a strange sort
$i=0;$new=""; $st="";$stn="";
foreach($u2 as $line){
$i++;
$size=strlen($line);// only works if we do math first Why old php bug?
$st = substr($line, 0,1); // lleter in front T1195
$stn= substr($line, 1,$size); // string less 1st letter
if (!$new){$new="$stn$st";}
else{$new="$new,$stn$st";}
}
$unew = explode(",",$new);sort ($unew);$u2= $unew;

if ($Btest){print"<!-- Sorted State on Right ";foreach($u2 as $line){print" $line";}print " -->\n";}

$line="";
$fileIN= file($nodelistClean); 
$hubName="Not in Nodelist";
// first get the name of the hub
foreach($fileIN as $line3){
$u = explode("|",$line3);
if($networkNode==$u[0]){$hubName=$u[1];break;} 
}

if ($nodes>1){
$pnt=""; $i=0; $status=""; $dvs="";$tr=""; $prt="";$action="";$action2="";$action3="";$pntC="";$pntD=""; // if status is U unknown state
foreach ($u2 as $line){ 
$dvswitch=false;  $status ="";
if($Btest){ print "<! -----$line----->\n";}
$pos = strpos("-$line", "T");if ($pos){$status ="Transceive";}
$pos = strpos("-$line", "*");if ($pos){$status ="Transceive *";}
$pos = strpos("-$line", "C");if ($pos){$status ="Connecting";}
$pos = strpos("-$line", "R");if ($pos){$status ="Receive Only";}   //Receive-Only     print"<!-- $line -->\n";
$size=strlen($line);$size=$size-1;// only works if we do math first Why old php bug?
$line = substr($line, 0,$size);  


if (is_numeric($line)) {
// you can adjust this (for GMRS LIVE)
// none of these should ever bridge to each other
if($line==$BridgeAlarm1){$BridgeDetect1=true;$BridgeDetect++;print"<!--- $BridgeAlarm1 detected --->\n";}
if($line==$BridgeAlarm2){$BridgeDetect2=true;$BridgeDetect++;print"<!--- $BridgeAlarm2 detected --->\n";}
if($line==$BridgeAlarm3){$BridgeDetect3=true;$BridgeDetect++;print"<!--- $BridgeAlarm3 detected --->\n";}   //611
if($line==$BridgeAlarm4){$BridgeDetect4=true;$BridgeDetect++;print"<!--- $BridgeAlarm4 detected --->\n";}   //900
foreach($fileIN as $line2){
$u = explode("|",$line2);
if(trim($u[4])=="N"){$u[4]="";}
if($line==$u[0]){
// print "<!-- $u[1] -->\n";
 $pnt="<td class=\"nodeNum\">$u[0]</td><td>$u[1]</td><td>$u[2]</td><td>$u[3]</td><td>$status</td><td>$u[4]</td></tr>";
  if ($u[2]=="" ){$pnt="<td class=\"nodeNum\">$u[0]</td><td colspan=2> $u[1]</td><td>$u[3]</td><td>$status</td><td>$u[4]</td></tr>";} // if second field blank
  if ($u[2]=="" and $u[3]=="" ){$pnt="<td class=\"nodeNum\">$u[0]</td><td colspan=3> $u[1]</td><td>$status</td><td>$u[4]</td></tr>";} // if 2nd and 3rd blank
  break;
 }
}
if (!$pnt){
 if($line >1000){  // ignore private nodes 
 $pnt="<td>$line</td><td colspan=3>This Node is not in the Database!</td><td>$status</td><td></td></tr>";
// print"\n<!--Requesting a nodelist rebuild -->\n";
// $flag  ="/tmp/nodelist_updated.txt"; if(file_exists($flag)){unlink($flag);}
 $flag  ="/tmp/nodelist_needs_update.txt"; $fileOUT = fopen($flag,'w');fwrite ($fileOUT,"$datum");fclose ($fileOUT);
 }
 else{$pnt="<td>$line</td><td colspan=3>Private node</td><td>$status</td><td></td></tr>"; }
 } 
}
// (Inter-Asterisk eXchange) Clients  
// if IAX call id matches something in the nodelist
else{

$pntD=""; if(!$line){$line="NO-CID";}
$line=strtoupper($line); 
$line=trim($line," \n\r\t\v\x00");
$lineTest=$line; print "<!-- Search for $lineTest in nodelist-->\n";
if (strlen($lineTest)>7){ $lineTest=substr($lineTest,0,7);} // fix for the extra abc after the call
foreach($fileIN as $line2){
$line2=strtoupper($line2); $line2 = str_replace("\r", "", $line2); $line2 = str_replace("\n", "", $line2); 
$u = explode("|",$line2);
$pos = strpos("-$line2", $lineTest);
if($pos >= 1){ 
 if ($u[4]<>"R" and $u[4]<>"H" ){$pntD="<td colspan=2>$u[1]</td><td>$u[2]</td><td>$line</td><td>Transceive</td><td>IAX</td></tr>"; print "<!-- found -->\n"; break; }
// print "<!-- $u[4] rejected -->\n";
 }
// print "<!-- $pos,$line,<>,$line2 -->\n";
}

// scan our database.
// Database will be auto once FCC lookup API is working (imposible now)
if(!$pntD){
print "<!-- Search for $lineTest in database-->\n";
$localDatabase = "$path/lookup-database.csv";
$fileIN2= file($localDatabase ); 
foreach($fileIN2 as $line2){
$u = explode(",",$line2);
$pos = strpos("-$line2", $lineTest);
if($pos >= 1){ $pntD="<td colspan=2>$u[0] [$u[3]]</td><td>$u[1],$u[2]</td><td>$line</td><td>Transceive</td><td>IAX</td></tr>"; print "<!-- found-->\n"; break;}
 }
}


if (!$pntD){$pntD="<td colspan=3>IAX - Not in nodelist -</td><td>$line</td><td>Transceive</td><td>IAX</td></tr>";$status="";print "<!-- NOT found-->\n";}
}

if ($status == "Connecting" ){$pntC="<td>$u[0]</td><td>$u[1]</td><td>$u[2]</td><td>$u[3]</td><td>$status</td><td>$u[4]</td></tr>";$pnt="";} // Problem nodes  


if($pnt) {
 $i++;$st=""; 
 if ($i <= 1){$tr="<tr class=\"tColor\">";}
 if ($i >= 2){$tr="<tr class=\"wColor\">";$i=0;}
 
 if ($BridgeDetect>=2){
   if($BridgeDetect1){ if ($u[0]==$BridgeAlarm1){$tr="<tr class=\"cColor\">";} }
   if($BridgeDetect2){ if ($u[0]==$BridgeAlarm2){$tr="<tr class=\"cColor\">";} }
   if($BridgeDetect3){ if ($u[0]==$BridgeAlarm3){$tr="<tr class=\"cColor\">";} }  //611
   if($BridgeDetect4){ if ($u[0]==$BridgeAlarm4){$tr="<tr class=\"cColor\">";} }  //900
 }
 
 
 
$action= "$action $tr $pnt\n";  $pnt="";}     // stacking nodes

if($pntD){
 $i3++; 
 if ($i3 <= 1){$tr="<tr class=\"tColor\">";}
 if ($i3 >= 2){$tr="<tr class=\"wColor\">";$i3=0;}
$action2="$action2 $tr $pntD\n"; $pntD="";}   // stacking iax (need to check for dupes)

if($pntC){
 $i2++; 
 if ($i2 <= 1){$tr="<tr class=\"pColor\">";}
 if ($i2 >= 2){$tr="<tr class=\"lpColor\">";$i2=0;}
$action3="$action3 $tr $pntC\n"; $pntC="";}   // problem nodes
}

//    rColor=darkblue cColor=red bColor=palegreen gColor=lightgray tColor=lemonchiffon lColor=powderblue pColor=pink <tr class="gColor">    
//$fdate="last modified: " . date ("F d Y H:i:s.", filemtime($lxnodes));
$title = "Scan found ($nodes) nodes connected to the [$hubName] HUB/Node<br>
 This full network scan finds all Hidden nodes connected down stream on other connected HUBS.";


print "<table border=0 class=gridtable id=AutoNumber1 '> ";
print "<tr class=\"gColor\"><td colspan=8 align=center><font size=small>$title</font></td></tr>";

// phase 1 of bridging detection
if ($BridgeDetect>=2){
$line="";
if ($BridgeDetect1){$line="$line $BridgeAlarm1";}
if ($BridgeDetect2){$line="$line $BridgeAlarm2";}
if ($BridgeDetect3){$line="$line $BridgeAlarm3";}
if ($BridgeDetect4){$line="$line $BridgeAlarm4";}
print "\n<tr class=\"cColor\"><td colspan=8 align=center><font size=small>ALARM Bridged ($line)</font></td></tr>";
}

print "\n<tr class=\"gColor\"><td>NODE</td><td style='text-align: center; vertical-align: middle;'>Description</td><td>Location</td><td>call<td>status</td><td>TYPE</td></tr>";
print "$action";  // This is a stacked aray

if ($action2){
print"\n<tr class=\"gColor\"><td colspan=2 align=center>(Inter-Asterisk eXchange) Clients (nodelist or local DB)</td><td>Location</td><td>CALL</td><td>Status</td><td>Type</td></tr>";  
print "$action2";  // This is a stacked aray
}

if ($action3){
print "\n<tr class=\"gColor\"><td>NODE</td><td style='text-align: center; vertical-align: middle;'>Problem Nodes - Description</td><td>Location</td><td>call<td>status</td><td>TYPE</td></tr>";
print "$action3";  // This is a stacked aray
}


$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_end = $mtime;$script_time = ($script_end - $script_start);$script_time = round($script_time,2);
print"<tr class=\"gColor\"><td colspan=8 align=center><input type=\"button\" class=\"submit\" Value=\"POPUP Refresh\" onclick=\"window.open('lsnodes.php','All nodes in the hub link','status=no,location=no,toolbar=no,width=800,height=550,left=100,top=100')\"> (c)2023 by WRXB288  (Total Time to process $script_time Sec) </td></tr>";  
print"</table>";   
}
else{
print "<!-- nothing here to display $script_time Sec (lsnodes) -->";  
}



?>
