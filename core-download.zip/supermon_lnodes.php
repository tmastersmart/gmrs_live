<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
// lsnodes replacement for GMRS... 
// 100 from scratch  
// No more CGI. 100% PHP using a clean database

$path="/etc/asterisk/local/mm-software";
$nodelist  =  "/var/log/asterisk/astdb.txt";
$nodelistBU=  "$path/nodelist/astdb.txt";
include_once ("$path/load.php");

// a missing nodelist on reboot needs to be fixed 
if(!file_exists($nodelist)){
 if(file_exists($nodelistBU)){copy($nodelistBU,$nodelist );} // use the last backup
 else {include_once ("$path/nodelist_process.php");} // if no backup get a new one
}


if (!$DisplayNodes){
print "<input type=\"button\" class=\"submit\" Value=\"List All Nodes in the HUB\" onclick=\"window.open('lsnodes.php','All nodes in the hub link','status=no,location=no,toolbar=no,width=800,height=550,left=100,top=100')\">";
die;
}



// v1.2    08/07/2023
// Get php timezone in sync with the PI
$line =	exec('timedatectl | grep "Time zone"'); //       Time zone: America/Chicago (CDT, -0500)
$line = str_replace(" ", "", $line);
$pos1 = strpos($line, ':');$pos2 = strpos($line, '(');
if ($pos1){  $zone   = substr($line, $pos1+1, $pos2-$pos1-1); }
else {$zone="America/Chicago";}
define('TIMEZONE', $zone);
date_default_timezone_set(TIMEZONE);
$phpzone = date_default_timezone_get(); // test it 
if ($phpzone == $zone ){$phpzone=$phpzone;}
else{$phpzone="$phpzone ERROR";}


$datum   = date('m-d-Y H:i:s');$gmdatum = gmdate('m-d-Y H:i:s');
$nodes=0; $array1=false;
$lxnodes ="/tmp/xnodes.txt"; if(file_exists($lxnodes)){unlink($lxnodes);}

//$status= exec("sudo /bin/asterisk -rx \"rpt xnode $node\" > $lxnodes",$output,$return_var);
$status= exec("sudo /bin/asterisk -rx \"rpt xnode $node\" ",$output,$return_var);

// save for debugging
$file=$lxnodes;
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX ); 
foreach($output as $out){fwrite($fileOUT,"$out\n");}// loop through array and save 
flock ($fileOUT, LOCK_UN );fclose ($fileOUT);

$fileIN= $output;  // use from memory
//$fileIN= file($lxnodes);
foreach($fileIN as $line){ 

$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line); 
$line = str_replace(" ", "", $line);  print "<! -----$line----->\n";
// get the network name
$pos2 = strpos("-$line", ",");if($pos2 and !$array1){$v = explode(",",$line);$array1=true;} // first array
$pos3 = strpos("-$line", "RPT_NUMLINKS"); 
if ($pos3){
$vv = explode("=",$line);// get the value
$NUMLINKS=$vv[1];}


$pos1 = strpos("-$line", "RPT_ALINKS"); // RPT_ALINKS=1,1195TU   RPT_NUMLINKS=35 
if ($pos1){
$u = explode("=",$line);// get the value
$u3 = explode(",",$u[1]);
$line =$u3[1];// this is the node# of the network 

//print "$line\n";
$line = str_replace("T", "", $line);
$line = str_replace("C", "", $line);
$line = str_replace(" ", "", $line);
$line = str_replace("U", "", $line);$line = str_replace("K", "", $line); // not sure what U and K are later check
$networkNode=$line;
}

// print "RPT_ALINKS $line";
// links
$pos = strpos("-$line", "RPT_LINKS");  
if ($pos){
$u = explode("=",$line);// get the value
//print "$u[1]\n";
$u2 = explode(",",$u[1]);// break up the fields
$nodes=$u2[0]; 
$u2[0]="*$node";// insert our node
  }
}

// use the first array if second empty
if ($nodes<=1){$u2=$v;$nodes=count($v);print "<! ----Using aray1 count:-$nodes----->\n";}
else{print "<! ----Using aray2 count:-$nodes----->\n";}

//print "RPT_LINKS $line";
sort($u2); $line="";//  C will get sorted before T 
// data is in u2
// RPT_LINKS=70,T1195,T1169,T2290,T2250,T2251,T4130,T2258,T2401,T4380,T2301,T2835,T4145,T2505,T2506,T2299,T2296,T2253,T2267,T2260,T2255,T2262,T2259,T2421,T4475,T2261,T1538,T1941,T2235,T4035,T1000,TWRXD297,TWRWS746,TWRWP511,TWQRH320,T2254,T2265,T2252,C2264,T4051,T2300,T1856,T1967,T4521,T1110,T4365,T2778,T2970,T1113,T1111,T2775,T2292,T1217,T1525,T1165,T1168,T1745,T1167,T1171,T1170,TWRFT828-B,T1334,T1746,T1114,T2060,T1237,T2399,T2755,T1166,T1239,T1215     

$filename = "$path/nodelist/clean.csv";// nodelist
$fileIN= file($filename); 
$hubName="Not in Nodelist";
// first get the name of the hub
foreach($fileIN as $line3){
$u = explode("|",$line3);
if($networkNode==$u[0]){$hubName=$u[1];break;} 
}

if ($nodes>1){
$title = "Scan detects ($nodes) nodes connected to the [$hubName] and Connected HUBS<br>
 This scan sees all hidden nodes hiding from the status page(s).";

print "<table border=0 class=gridtable id=AutoNumber1 '> ";
print "<tr class=\"gColor\"><td colspan=8 align=center><font size=small>$title</font></td></tr>";
print "<tr class=\"gColor\"><td>NODE</td><td style='text-align: center; vertical-align: middle;'>Description</td><td>Location</td><td>call<td>status</td><td>TYPE</td></tr>";

//    rColor=darkblue cColor=red bColor=palegreen gColor=lightgray tColor=lemonchiffon lColor=powderblue  <tr class="gColor">    
$pnt="";  $i=0; $status="*";
foreach ($u2 as $line){ 
$dvswitch=false;
if(!$line){continue;}
$pnt="<td>$line</td><td colspan=7>Not in Database</td></tr>";
$pos = strpos("-$line", "W");if ($pos){$dvswitch=true;}
$pos = strpos("-$line", "T");if ($pos){$status ="Transceive";}
$pos = strpos("-$line", "*");if ($pos){$status ="Transceive *";}
$pos = strpos("-$line", "C");if ($pos){$status ="Connecting";}
$pos = strpos("-$line", "R");if ($pos){$status ="Receive Only";}

$line = substr($line, 1);
$line = str_replace(" ", "", $line);

if(!$dvswitch){
foreach($fileIN as $line2){
$u = explode("|",$line2);
if(trim($u[4])=="N"){$u[4]="";}
if($line==$u[0]){$pnt="<td>$u[0]</td><td>$u[1]</td><td>$u[2]</td><td>$u[3]</td><td>$status</td><td>$u[4]</td></tr>";break;} 
}
} 
else{$pnt="<td>$line</td><td colspan=3>DV switch - IAX connection</td><td>Transceive</td><td></td></tr>";}

$i++;
if ($i == 1){print"<tr class=\"tColor\">";}
if ($i == 2){print"<tr class=\"wColor\">";$i=0;}
print "$pnt\n";
  } 
  
 $fdate="last modified: " . date ("F d Y H:i:s.", filemtime($lxnodes));

print"<tr class=\"gColor\"><td colspan=8 align=center><input type=\"button\" class=\"submit\" Value=\"POPUP Refreash\" onclick=\"window.open('lsnodes.php','All nodes in the hub link','status=no,location=no,toolbar=no,width=800,height=550,left=100,top=100')\"> List all Nodes (c)2023 by WRXB288 $fdate</td></tr>";  
print"</table>";   
}
else{  
print"<p> No nodes to display. Wait a few mins and try again...</p>
<input type=\"button\" class=\"submit\" Value=\"List All Nodes in the HUB\" onclick=\"window.open('lsnodes.php','All nodes in the hub link','status=no,location=no,toolbar=no,width=800,height=550,left=100,top=100')\">";

}


?>
