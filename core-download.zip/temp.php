<?php
//  ------------------------------------------------------------
//  (c) 2023 by WRXB288 lagmrs.com all rights reserved
//
//    for allstar gmrs nodes to keep track of the temp
// -------------------------------------------------------------
//
//   _____ _____  _    _   _______                     __  __             _ _             
//  / ____|  __ \| |  | | |__   __|                   |  \/  |           (_) |            
// | |    | |__) | |  | |    | | ___ _ __ ___  _ __   | \  / | ___  _ __  _| |_ ___  _ __ 
// | |    |  ___/| |  | |    | |/ _ \ '_ ` _ \| '_ \  | |\/| |/ _ \| '_ \| | __/ _ \| '__|
// | |____| |    | |__| |    | |  __/ | | | | | |_) | | |  | | (_) | | | | | || (_) | |   
//  \_____|_|     \____/     |_|\___|_| |_| |_| .__/  |_|  |_|\___/|_| |_|_|\__\___/|_|   
//                                            | |                                         
//                                            |_| 
// The node image is missing the CPU temp monitor at
// /sys/class/thermal/thermal_zone0/temp
//
// I am using the GPU temp monitor at
// /opt/vc/bin/vcgencmd measure_temp
// Supermon uses the same monitor
//
//
// From the PI specs: https://www.raspberrypi.com/documentation/computers/processors.html
//Pi must stay below 85c at all times. To be safe 70 is my danger zone. 
//The PI will regulate its own temp by throttling down when its hot, 
//but throttling down reduces cpu cycles. 
// 
// on testing my node restarts at 65 this does not make any sence since
// a standard pi will keep running and just slow down to cool itself.
// more testing is needed.
//


//
// NOTES:
//
//If you need it there is a script that will turn the fan on and off with the temp.
//This is a old script thats no longer used on the new PIs since its now built in the OS.
//https://howchoo.com/g/ote2mjkzzta/control-raspberry-pi-fan-temperature-python
//Do not run the autoinstall script. Its not compatable with the node image
//Only install the script here.
//https://github.com/Howchoo/pi-fan-controller/blob/master/fancontrol.py 
//and run it at load time.  /etc/rc.local
//

// v2.4 09/18/23 intergration into odd_min.php chron. 

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_start = $mtime;

$path="/etc/asterisk/local/mm-software";
include_once  ("$path/load.php");
include_once  ("$path/sound_db.php");



$phpVersion= phpversion();
$datum = date('m-d-Y-H:i:s');
$ver="v2.4";$release = "09/18/2023";
$out="";
print "
===================================================
PI temp Monitor  $coreVersion $ver 
(c) 2023 by WRXB288 LAGMRS.com all rights reserved 
$phpzone PHP $phpVersion    Release date:$release
===================================================
$datum Model: $piVersion
";
chdir($path);


$log="/tmp/cpu_temp_log.txt";
$datum = date('m-d-Y-H:i:s');
$line= exec("/opt/vc/bin/vcgencmd measure_temp",$output,$return_var);// SoC BCM2711 temp

$line = str_replace("'", "", $line);
$line = str_replace("C", "", $line);
$u= explode("=",$line);
$temp=$u[1];
$tempf = (float)(($temp * 9 / 5) + 32);
print "$datum Temp is $tempf F $temp C \n";

$line= exec("/opt/vc/bin/vcgencmd get_throttled",$output,$return_var);

$throttled = "";
$u= explode("x",$line);
if($u[1]== "0"){$throttled = "";}
if($u[1]== "1"){$throttled = "under-voltage-detected";}
if($u[1]== "2"){$throttled = "arm-frequency-capped";}
if($u[1]== "4"){$throttled = "currently-throttled";}
if($u[1]== "8"){$throttled = "soft-temp-limit-active";}
if($u[1]== "10000"){$throttled = "under-voltage-detected";}
if($u[1]== "20000"){$throttled = "arm-frequency-capping";}
if($u[1]== "80000"){$throttled = "throttling-has-occurred";}
if($u[1]== "80000"){$throttled = "soft-temp-limit-occurred";}

if($throttled){$status =$throttled;save_task_log ($status);print "$datum $status\n";}
// This is to create a temp chart
$fileOUT = fopen($log, "a") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,$temp, \n");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);

if (!$reportAll and $temp <=$hot){$TMPstatus="ok";}
else{
$TMPstatus="REPORT";
$cmd=""; $action="";


check_wav_db("star dull");if($file1){$action = "$action $file1";}

check_gsm_db ($nodeName);if($file1){$action = "$action $file1";} // Name (server,repeater,node,tower,temperature) or any name in the database.");
list($whole, $decimal) = explode('.', $temp);
$oh=false;make_number ($whole);$action = "$action $actionOut";

if($decimal>=1){
check_gsm_db ("point");if($file1){$action = "$action $file1";} 
$oh=false;make_number ($decimal); $action = "$action $actionOut";

}
check_gsm_db ("degrees");if($file1){$action = "$action $file1";} 
check_gsm_db ("celsius");if($file1){$action = "$action $file1";} 

if ($temp >=$hot){ //emergency,beep,attention-required 
  $status ="CPU HOT $temp";save_task_log ($status);
 if ($temp >=$high){
  check_gsm_db ("emergency");if($file1){$action = "$action $file1";}
  check_gsm_db ("warning");if($file1){$action = "$action $file1";}
  check_gsm_db ("attention-required");if($file1){$action = "$action $file1";}
  } 
else{
  check_gsm_db ("alert");if($file1){$action = "$action $file1";}
  check_gsm_db ("high");if($file1){$action = "$action $file1";}
  }
check_gsm_db ("beep");if($file1){$action = "$action $file1";} 
}


if ($throttled){check_ulaw_db ($throttled);if($file1){$action = "$action $file1";}  }
//check_wav_db("star dull");if($file1){$action = "$action $file1";}
check_gsm_db ("silence1");if($file1){$action = "$action $file1";}

$datum   = date('m-d-Y H:i:s');


$file="/tmp/cpu.gsm";if(file_exists($file)){unlink($file);}
print "$datum Playing file $cpufile\n";

exec ("sox $action $file",$output,$return_var);
$status= exec("sudo asterisk -rx 'rpt localplay $node /tmp/cpu'",$output,$return_var);
}


$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_end = $mtime;$script_time = ($script_end - $script_start);$script_time = round($script_time,2);
$datum  = date('m-d-Y H:i:s');
$memory = memory_get_usage() ;$memory =formatBytes($memory);

print "$datum ";$tagline="";tagline($tagline);print "\n";

print "$datum $TMPstatus [Line end] Used:$memory $script_time Sec\n";


print"===================================================\n";





?>

