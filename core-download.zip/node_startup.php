#!/usr/bin/php
<?php
// (c)2015/2025 by The Master lagmrs.com 
// Not for use on anything but GMRS ONLY! 
// No part of this code is opensource 
//
// Node start up routine.   (replace all the old out of date shell scripts with php)

// v1.0 first beta version
// v1.2 Option to hide the local IP
// v1.3 Added a delay and retry if not registered.
// v1.4 First jingle added 
// v1.5 changes for the hub
// v1.6 autofix for conf files
// v1.7 2024 Mods for GMRSHUB  (backup system improved for monthly backups) 
// v1.8 2/25 Support for private nodes

$ver= "v1.9";$release="2/24/2025"; 
srand (time ()); 
$action ="";
$path="/etc/asterisk/local/mm-software";
include_once ("$path/load.php");      // settings .. Functions
include_once ("$path/sound_db.php");  // functions
include_once ("$path/check_reg.php"); 

$file= "$path/mm-node.txt"; 


if(file_exists($file)){
$line = file_get_contents($file);
$u= explode(",",$line);
$AutoNode=$u[0];$call=$u[1];$autotts=$u[2];
}
$phpVersion= phpversion();
$datum   = date('m-d-Y H:i:s');$gmdatum = gmdate('m-d-Y H:i:s');

$piSystem=false;if (is_readable("/proc/device-tree/model")) {$piVersion = file_get_contents ("/proc/device-tree/model");$piSystem=true;}
else {$piVersion =	exec('uname -m -p');}

print "
===================================================
Node Startup $coreVersion $ver
(c)2013/2025 WRXB288 LAGMRS.com all rights reserved
$phpzone PHP v$phpVersion  Release date:$release
===================================================
$datum Model: $piVersion
$datum Node:$node UTC:$gmdatum Level:$level
";



$out="node startup in progress"; save_task_log($out);

if($burst){
print "$datum MDC-1200 bursts $burst\n";
exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);
sleep(1);
} 

$ip = getHostByName(getHostName());

$currentTime = "/tmp/current-time.gsm";if(file_exists($currentTime)){unlink($currentTime);}


// system-crashed  server restarting linux initiating hello groovy  box an-error-has-occurred
check_gsm_db ("silence2");if($file1){$action = "$action $file1";}

$hour = date('H');$day  = date('l');$hr =   date('h');$min  = date('i');
$randomS = mt_rand(1, 5);
if ($randomS==1){check_wav_db("star dull");   if($file1){$action = "$action $file1";}}
if ($randomS==2){check_wav_db("light click"); if($file1){$action = "$action $file1";}}
if ($randomS==3){check_gsm_db("beep");        if($file1){$action = "$action $file1";}}  
if ($randomS==4){check_wav_db("strong click");if($file1){$action = "$action $file1";}} 

//good,good-afternoon,good-evening,good-morning, (need good night)
$status ="";
if ($hour < 12)                {check_gsm_db("good-morning");  if($file1){$action="$action $file1";}}
if ($hour >=12 and $hour <=18) {check_gsm_db("good-afternoon");if($file1){$action="$action $file1";}}
if ($hour >=19)                {check_gsm_db("good-evening");  if($file1){$action="$action $file1";}}

//check_gsm_db ("power-failure");if($file1){$action = "$action $file1";} 
check_gsm_db ("restarting");   if($file1){$action = "$action $file1";} 

// -----------------------------------------welcome---------------------------------------------
$random = mt_rand(1, 2);
 if ($random == 1){check_gsm_db ("welcome");   if($file1){$action = "$action $file1";}
                   check_gsm_db ("to");        if($file1){$action = "$action $file1";}
                   check_gsm_db ("linux");     if($file1){$action = "$action $file1";}      
 }
 if ($random == 2){check_gsm_db ("hello");     if($file1){$action = "$action $file1";}
                   check_gsm_db ("welcome");   if($file1){$action = "$action $file1";}  
 } 


// -----------------------------------------jokes----------------------------------------------
$random2 = mt_rand(1, 8);
if ($random2 == 1){check_gsm_db ("step-in-stream");if($file1){$action = "$action $file1";} 
                   check_gsm_db ("giggle1");       if($file1){$action = "$action $file1";}
}  
if ($random2 == 2){check_gsm_db ("access-granted");if($file1){$action = "$action $file1";} }  
if ($random2 == 3){check_gsm_db ("channel-insecure-warn");if($file1){$action = "$action $file1";} }  
if ($random2 == 4){check_gsm_db ("computer-friend1");if($file1){$action = "$action $file1";} }  
if ($random2 == 5){check_gsm_db ("blue-eyed-polar-bear");if($file1){$action = "$action $file1";} 
                   check_gsm_db ("giggle1");        if($file1){$action = "$action $file1";}
} 
if ($random2 == 6){check_gsm_db ("giggle1");        if($file1){$action = "$action $file1";}
                   check_gsm_db ("groovy");         if($file1){$action = "$action $file1";}
                   }
if ($random2 == 7){check_gsm_db ("gmrshub1");       if($file1){$action = "$action $file1";}
                   check_gsm_db ("groovy");         if($file1){$action = "$action $file1";}
                   }
if ($random2 == 8){check_gsm_db ("gmrshub2");       if($file1){$action = "$action $file1";}
                   check_gsm_db ("groovy");         if($file1){$action = "$action $file1";}
                   }                  
                   
                  


if (!$hideIP){ // set in setup for security
check_gsm_db ("silence1");if($file1){$action = "$action $file1";}
check_gsm_db ("i");       if($file1){$action = "$action $file1";} 
check_gsm_db ("p");       if($file1){$action = "$action $file1";} 
check_gsm_db ("address"); if($file1){$action = "$action $file1";} 
check_gsm_db ("is-at"); if($file1){$action = "$action $file1";}

$oh=false;
$x = (string)$ip;
for($i=0;$i<strlen($x);$i++)
{
if ($x[$i]=="."){check_gsm_db ("dot"); if($file1){$action = "$action $file1";}} 
else{make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
 } 

 
}// end say ip

//http://gmrsnode.local/


// say something in place of the IP.
else{
check_gsm_db ("i");       if($file1){$action = "$action $file1";} 
check_gsm_db ("p");       if($file1){$action = "$action $file1";} 
check_gsm_db ("secure");if($file1){$action = "$action $file1";}
}


//  "Auth. Sent"  "Registered"    rejected: 'Registration Refused' // Request,Auth.,
reg_check ("check");// $node1 $ip $port2 $registered

check_gsm_db ("silence1");if($file1){$action = "$action $file1";}
check_gsm_db ("this");    if($file1){$action = "$action $file1";}
check_gsm_db ("node");if($file1){$action = "$action $file1";}

 

$pos1 = strpos("-$registered", 'Private'); 
if ($pos1) { check_gsm_db ("is-not-registered");if($file1){$action = "$action $file1";}
//             check_wav_db ("num-not-in-db");if($file1){$action = "$action $file1";}
//             check_gsm_db ("unallocated_number");if($file1){$action = "$action $file1";}
}



$pos1 = strpos("-$registered", 'Registered'); 
if ($pos1) { check_gsm_db ("is-registered");    if($file1){$action = "$action $file1";}
             check_gsm_db ("silence1");if($file1){$action = "$action $file1";}
             check_gsm_db ("groovy"); if($file1){$action = "$action $file1";}
             check_gsm_db ("giggle1");if($file1){$action = "$action $file1";}
}

$pos2 = strpos("-$registered", 'Unregistered');
if ($pos2) { check_gsm_db ("is-not-registered");if($file1){$action = "$action $file1";}
             check_gsm_db ("beeperr");if($file1){$action = "$action $file1";}
             check_gsm_db ("we-apologize");if($file1){$action = "$action $file1";}
             check_gsm_db ("sorry-youre-having-problems");if($file1){$action = "$action $file1";}  
             check_gsm_db ("computer-friend2");if($file1){$action = "$action $file1";}  // computer-friend1
}

        

$pos3 = strpos("-$registered", 'Refused');
if ($pos3) { check_gsm_db ("is-rejected");      if($file1){$action = "$action $file1";}
             check_gsm_db ("beeperr");if($file1){$action = "$action $file1";}   // refused
             check_gsm_db ("we-apologize");if($file1){$action = "$action $file1";}
             check_gsm_db ("sorry-youre-having-problems");if($file1){$action = "$action $file1";}
             check_gsm_db ("an-error-has-occurred");if($file1){$action = "$action $file1";} 
             check_gsm_db ("please-contact-tech-supt");if($file1){$action = "$action $file1";}
}

$pos4 = strpos("-$registered", 'Auth');
$pos5 = strpos("-$registered", 'Sent');
if($pos4 or $pos5){  
             check_gsm_db ("is");       if($file1){$action = "$action $file1";}
             check_gsm_db ("connecting");       if($file1){$action = "$action $file1";}
}


$pos6 = strpos("-$registered", 'Request');
if ($pos6) { 
             check_gsm_db ("is");       if($file1){$action = "$action $file1";}
             check_gsm_db ("not-yet-connected");if($file1){$action = "$action $file1";}
             check_gsm_db ("beeperr");if($file1){$action = "$action $file1";} 
             check_gsm_db ("we-apologize");if($file1){$action = "$action $file1";}
             check_gsm_db ("sorry-youre-having-problems");if($file1){$action = "$action $file1";} 
             check_gsm_db ("computer-friend2");if($file1){$action = "$action $file1";}  // computer-friend1
}



$datum = date('m-d-Y-H:i:s');

// dont do this if on a non pi system
if($piSystem){
$line= exec("/opt/vc/bin/vcgencmd measure_temp",$output,$return_var);// SoC BCM2711 temp
$line = str_replace("'", "", $line);
$line = str_replace("C", "", $line);
$u= explode("=",$line);
$temp=$u[1];
$tempf = (float)(($temp * 9 / 5) + 32);
print "$datum Temp is $tempf F $temp C \n";
$line= exec("/opt/vc/bin/vcgencmd get_throttled",$output,$return_var);
$throttled = "";
$u= explode("x",$line);
if($u[1]== "0"){$throttled = "";}
if($u[1]== "1"){$throttled = "under-voltage-detected";}
if($u[1]== "2"){$throttled = "arm-frequency-capped";}
if($u[1]== "4"){$throttled = "currently-throttled";}
if($u[1]== "8"){$throttled = "soft-temp-limit-active";}
if($u[1]== "10000"){$throttled = "under-voltage-detected";}
if($u[1]== "20000"){$throttled = "arm-frequency-capping";}
if($u[1]== "80000"){$throttled = "throttling-has-occurred";}
if($u[1]== "80000"){$throttled = "soft-temp-limit-occurred";}
if($throttled){$status =$throttled;save_task_log ($status);print "$datum $status\n";}
$TMPstatus="REPORT";
check_gsm_db ("server");    if($file1){$action = "$action $file1";}

list($whole, $decimal) = explode('.', $temp);
$oh=false;make_number ($whole);$action = "$action $actionOut";

if($decimal>=1){
check_gsm_db ("point");if($file1){$action = "$action $file1";} 
$oh=false;make_number ($decimal); $action = "$action $actionOut";

}
check_gsm_db ("degrees");if($file1){$action = "$action $file1";} 
check_gsm_db ("celsius");if($file1){$action = "$action $file1";} 

if ($temp >=$hot){ //emergency,beep,attention-required 
  $status ="CPU HOT $temp";save_task_log ($status);
 if ($temp >=$high){
  check_gsm_db ("emergency");if($file1){$action = "$action $file1";}
  check_gsm_db ("warning");if($file1){$action = "$action $file1";}
  check_gsm_db ("attention-required");if($file1){$action = "$action $file1";}
  } 
else{
  check_gsm_db ("alert");if($file1){$action = "$action $file1";}
  check_gsm_db ("high");if($file1){$action = "$action $file1";}
  }
check_gsm_db ("beep");if($file1){$action = "$action $file1";} 
}
if ($throttled){check_ulaw_db ($throttled);if($file1){$action = "$action $file1";}  }
}// end if not a pi

print "$datum Playing file $currentTime\n";
check_gsm_db ("silence1");if($file1){$action = "$action $file1";}
exec("sox $action $currentTime",$output,$return_var);if($debug){print "DEBUG $action";}
exec("sudo asterisk -rx 'rpt localplay $node /tmp/current-time'",$output,$return_var);
print "$datum Waiting to close clash file\n";

// if we are registered play the time
//if ($pos1) {sleep(60);include_once ("$path/weather_pws.php");}
// else just exit and wait for the system to register.

// do a auto restore in case of blank corupted files
$in="";
$iax          = "/etc/asterisk/iax.conf";
$rpt          = "/etc/asterisk/rpt.conf";
$manager      = "/etc/asterisk/manager.conf";
$extensions   = "/etc/asterisk/extensions.conf";
check_backup($in);

sleep(60); //We need to sleep before clearing this flag To hold other sounds

if(file_exists($clash)){unlink($clash);}
$start_test="/tmp/start-ok.txt"; $fileOUT = fopen($start_test,'w');fwrite ($fileOUT,"$datum -we started ok");fclose ($fileOUT);
$out="startup Ok"; save_task_log($out);












function check_backup($in) {
    global $iax, $rpt, $datum, $extensions, $damaged;
    $damaged = false;

    // Array of files to check and back up
    $files = [
        'extensions' => $extensions,
        'iax' => $iax,
        'rpt' => $rpt,
    ];

    foreach ($files as $name => $file) {
        $fileBu = "$file-.bak";

        // Check if file is missing or blank, then restore
        if (!file_exists($file) || filesize($file) === 0) {
            $damaged = true;
            if (file_exists($fileBu)) {
                copy($fileBu, $file);
                print "$file was null or missing. Restored from backup.\n";
            } else {
                print "No backup found for $file. File cannot be restored.\n";
            }
            continue; // Skip to the next file
        }

        // Check for monthly backup updates
        if (file_exists($fileBu)) {
            $lastModified = filemtime($fileBu);
            $currentTime = time();
            $oneMonth = 30 * 24 * 60 * 60; // 30 days in seconds

            if (($currentTime - $lastModified) >= $oneMonth) {
                copy($file, $fileBu);
                print "Monthly backup updated for $file.\n";
            }
        } else {
            // If no backup exists, create one
            copy($file, $fileBu);
            print "$file backed up.\n";
        }
    }
}










?>
