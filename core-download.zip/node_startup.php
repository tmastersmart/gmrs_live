<?php
// (c)2015/2023 by The Master lagmrs.com  by pws.winnfreenet.com

// I license you to use this on your copy of this software only.
// Not for use on anything but GMRSlive.  GMRS ONLY! 

// No part of this code is opensource 
//

// Node start up routine.   (replace all the old out of date shell scripts with php)

// v1.0 first beta version
// v1.2 Option to hide the local IP  

$ver= "v1.2";$release="11/02/2023"; 
srand (time (0)); 
$action ="";
$path="/etc/asterisk/local/mm-software";
include_once ("$path/load.php");      // settings .. Functions
include_once ("$path/sound_db.php");  // functions
include_once ("$path/check_reg.php"); 

$file= "$path/mm-node.txt"; 
if(file_exists($file)){
$line = file_get_contents($file);
$u= explode(",",$line);
$AutoNode=$u[0];$call=$u[1];$autotts=$u[2];
}
$phpVersion= phpversion();
$datum   = date('m-d-Y H:i:s');$gmdatum = gmdate('m-d-Y H:i:s');
print "
===================================================
Node Startup $coreVersion $ver
(c)2013/2023 WRXB288 LAGMRS.com all rights reserved
$phpzone PHP v$phpVersion  Release date:$release
===================================================
$datum Model: $piVersion
$datum Node:$node UTC:$gmdatum Level:$level
";



if($burst){
print "$datum MDC-1200 bursts $burst\n";
exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);
sleep(1);
} 

$ip = getHostByName(getHostName());

$currentTime = "/tmp/current-time.gsm";if(file_exists($currentTime)){unlink($currentTime);}


// system-crashed  server restarting linux initiating hello groovy  box an-error-has-occurred
check_gsm_db ("silence1");if($file1){$action = "$action $file1";}

$hour = date('H');$day  = date('l');$hr =   date('h');$min  = date('i');
$randomS = mt_rand(1, 5);
if ($randomS==1){check_wav_db("star dull");   if($file1){$action = "$action $file1";}}
if ($randomS==2){check_wav_db("light click"); if($file1){$action = "$action $file1";}}
if ($randomS==3){check_gsm_db("beep");        if($file1){$action = "$action $file1";}}  
if ($randomS==4){check_wav_db("strong click");if($file1){$action = "$action $file1";}} 

//good,good-afternoon,good-evening,good-morning, (need good night)
$status ="";
if ($hour < 12)                {check_gsm_db("good-morning");  if($file1){$action="$action $file1";}}
if ($hour >=12 and $hour <=18) {check_gsm_db("good-afternoon");if($file1){$action="$action $file1";}}
if ($hour >=19)                {check_gsm_db("good-evening");  if($file1){$action="$action $file1";}}


$random = mt_rand(1, 4);
 if ($random == 1){check_gsm_db ("welcome");   if($file1){$action = "$action $file1";}
                   check_gsm_db ("to");        if($file1){$action = "$action $file1";}
                   check_gsm_db ("linux");     if($file1){$action = "$action $file1";}      
                   
 }
 
  if ($random == 2){check_gsm_db ("hello");     if($file1){$action = "$action $file1";}
                    check_gsm_db ("welcome");   if($file1){$action = "$action $file1";}  
 } 

  if ($random == 3){check_gsm_db ("hello");   if($file1){$action = "$action $file1";}
                    check_gsm_db ("welcome"); if($file1){$action = "$action $file1";}
                    check_gsm_db ("to");      if($file1){$action = "$action $file1";}
                    check_gsm_db ("this");    if($file1){$action = "$action $file1";}
                    check_gsm_db ("repeater");if($file1){$action = "$action $file1";}
 }
  if ($random == 4){check_gsm_db ("welcome"); if($file1){$action = "$action $file1";}
                    check_gsm_db ("to");      if($file1){$action = "$action $file1";}
                    check_gsm_db ("g");       if($file1){$action = "$action $file1";}
                    check_gsm_db ("m");       if($file1){$action = "$action $file1";}
                    check_gsm_db ("r");       if($file1){$action = "$action $file1";}
                    check_gsm_db ("s");       if($file1){$action = "$action $file1";}
              
 } 
 
 
$random2 = mt_rand(1, 6);
if ($random2 == 1){check_gsm_db ("step-in-stream");if($file1){$action = "$action $file1";} 
                   check_gsm_db ("giggle1");if($file1){$action = "$action $file1";}
}  
if ($random2 == 2){check_gsm_db ("access-granted");if($file1){$action = "$action $file1";} }  
if ($random2 == 3){check_gsm_db ("channel-insecure-warn");if($file1){$action = "$action $file1";} }  
if ($random2 == 4){check_gsm_db ("computer-friend1");if($file1){$action = "$action $file1";} }  
 
if ($random2 == 5){check_gsm_db ("blue-eyed-polar-bear");if($file1){$action = "$action $file1";} 
                   check_gsm_db ("giggle1");if($file1){$action = "$action $file1";}
} 
if ($random2 == 6){check_gsm_db ("giggle1");if($file1){$action = "$action $file1";}
                   check_gsm_db ("groovy"); if($file1){$action = "$action $file1";}}

//if ($random2 == 4){check_gsm_db ("because-paranoid");if($file1){$action = "$action $file1";} }  
//if ($random == 1){check_gsm_db ("enabled");if($file1){$action = "$action $file1";} }   
//if ($random == 3){check_gsm_db ("restarting");if($file1){$action = "$action $file1";}    } 
//if ($random == 4){check_gsm_db ("initiating");if($file1){$action = "$action $file1";}   }                  
//if ($random == 5){check_gsm_db ("activated");  if($file1){$action = "$action $file1";}   }

 
//  because-paranoid   blue-eyed-polar-bear busy-hangovers channel-insecure-warn computer-friend1   gambling-drunk
// giggle1 shiny-brass-lamp  something-terribly-wrong  step-in-stream  system-status-msg



if (!$hideIP){ // set in setup for security
check_gsm_db ("silence1");if($file1){$action = "$action $file1";}
check_gsm_db ("i");       if($file1){$action = "$action $file1";} 
check_gsm_db ("p");       if($file1){$action = "$action $file1";} 
check_gsm_db ("address"); if($file1){$action = "$action $file1";} 
check_gsm_db ("is-at"); if($file1){$action = "$action $file1";}

$oh=false;
$x = (string)$ip;
for($i=0;$i<strlen($x);$i++)
{
if ($x[$i]=="."){check_gsm_db ("dot"); if($file1){$action = "$action $file1";}} 
else{make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
 } 
}// end say ip

// say something in place of the IP.

//else{
//check_gsm_db ("i");       if($file1){$action = "$action $file1";} 
//check_gsm_db ("p");       if($file1){$action = "$action $file1";} 
//check_gsm_db ("secure");if($file1){$action = "$action $file1";}
//}


check_gsm_db ("silence1");if($file1){$action = "$action $file1";}
check_gsm_db ("this");    if($file1){$action = "$action $file1";}
check_gsm_db ("node");if($file1){$action = "$action $file1";}

reg_check ("check");// $node1 $ip $port2 $registered 

// dont say the node #  for faster load
//$oh=false;
//$x = (string)$node;
//for($i=0;$i<strlen($x);$i++)
//{ 
//make_number ($x[$i]);$action = "$action $actionOut"; //say the numbers one at a time not as a set 
//}


//  "Auth. Sent"  "Registered"    rejected: 'Registration Refused' // Request,Auth.,
$pos1 = strpos("-$registered", 'Registered');  if($pos1){check_gsm_db ("is-registered");    if($file1){$action = "$action $file1";}}
$pos2 = strpos("-$registered", 'Unregistered');if($pos2){check_gsm_db ("is-not-registered");if($file1){$action = "$action $file1";}}
$pos3 = strpos("-$registered", 'Refused');     if($pos3){check_gsm_db ("is-rejected");      if($file1){$action = "$action $file1";}}
$pos4 = strpos("-$registered", 'Auth');        if($pos4){
                                               check_gsm_db ("is");       if($file1){$action = "$action $file1";}
                                               check_gsm_db ("connecting");       if($file1){$action = "$action $file1";}}
$pos5 = strpos("-$registered", 'Sent');        if($pos5){
                                               check_gsm_db ("is");       if($file1){$action = "$action $file1";}
                                               check_gsm_db ("connecting");       if($file1){$action = "$action $file1";}}
$pos6 = strpos("-$registered", 'Request');     if($pos6){
                                               check_gsm_db ("is");       if($file1){$action = "$action $file1";}
                                               check_gsm_db ("not-yet-connected");if($file1){$action = "$action $file1";}}
                                               
                                               
check_gsm_db ("silence1");if($file1){$action = "$action $file1";}

if ($pos1) { check_gsm_db ("groovy"); if($file1){$action = "$action $file1";}
             check_gsm_db ("giggle1");if($file1){$action = "$action $file1";}
}

if ($pos2) { check_gsm_db ("beeperr");if($file1){$action = "$action $file1";}
             check_gsm_db ("we-apologize");if($file1){$action = "$action $file1";}
             check_gsm_db ("sorry-youre-having-problems");if($file1){$action = "$action $file1";}  
             check_gsm_db ("computer-friend2");if($file1){$action = "$action $file1";}  // computer-friend1
}
if ($pos3) { check_gsm_db ("beeperr");if($file1){$action = "$action $file1";} 
             check_gsm_db ("we-apologize");if($file1){$action = "$action $file1";}
             check_gsm_db ("sorry-youre-having-problems");if($file1){$action = "$action $file1";}
             check_gsm_db ("an-error-has-occurred");if($file1){$action = "$action $file1";} 
             check_gsm_db ("please-contact-tech-supt");if($file1){$action = "$action $file1";}
}

if ($pos6) { check_gsm_db ("beeperr");if($file1){$action = "$action $file1";} 
             check_gsm_db ("we-apologize");if($file1){$action = "$action $file1";}
             check_gsm_db ("sorry-youre-having-problems");if($file1){$action = "$action $file1";} 
             check_gsm_db ("computer-friend2");if($file1){$action = "$action $file1";}  // computer-friend1
}


$log="/tmp/cpu_temp_log.txt";
$datum = date('m-d-Y-H:i:s');
$line= exec("/opt/vc/bin/vcgencmd measure_temp",$output,$return_var);// SoC BCM2711 temp

$line = str_replace("'", "", $line);
$line = str_replace("C", "", $line);
$u= explode("=",$line);
$temp=$u[1];
$tempf = (float)(($temp * 9 / 5) + 32);
print "$datum Temp is $tempf F $temp C \n";

$line= exec("/opt/vc/bin/vcgencmd get_throttled",$output,$return_var);

$throttled = "";
$u= explode("x",$line);
if($u[1]== "0"){$throttled = "";}
if($u[1]== "1"){$throttled = "under-voltage-detected";}
if($u[1]== "2"){$throttled = "arm-frequency-capped";}
if($u[1]== "4"){$throttled = "currently-throttled";}
if($u[1]== "8"){$throttled = "soft-temp-limit-active";}
if($u[1]== "10000"){$throttled = "under-voltage-detected";}
if($u[1]== "20000"){$throttled = "arm-frequency-capping";}
if($u[1]== "80000"){$throttled = "throttling-has-occurred";}
if($u[1]== "80000"){$throttled = "soft-temp-limit-occurred";}

if($throttled){$status =$throttled;save_task_log ($status);print "$datum $status\n";}
// This is to create a temp chart
$fileOUT = fopen($log, "a") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,$temp, \n");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);

//if (!$reportAll and $temp <=$hot){$TMPstatus="ok";}
//else{
$TMPstatus="REPORT";
check_gsm_db ("server");    if($file1){$action = "$action $file1";}

list($whole, $decimal) = explode('.', $temp);
$oh=false;make_number ($whole);$action = "$action $actionOut";

if($decimal>=1){
check_gsm_db ("point");if($file1){$action = "$action $file1";} 
$oh=false;make_number ($decimal); $action = "$action $actionOut";

}
check_gsm_db ("degrees");if($file1){$action = "$action $file1";} 
check_gsm_db ("celsius");if($file1){$action = "$action $file1";} 

if ($temp >=$hot){ //emergency,beep,attention-required 
  $status ="CPU HOT $temp";save_task_log ($status);
 if ($temp >=$high){
  check_gsm_db ("emergency");if($file1){$action = "$action $file1";}
  check_gsm_db ("warning");if($file1){$action = "$action $file1";}
  check_gsm_db ("attention-required");if($file1){$action = "$action $file1";}
  } 
else{
  check_gsm_db ("alert");if($file1){$action = "$action $file1";}
  check_gsm_db ("high");if($file1){$action = "$action $file1";}
  }
check_gsm_db ("beep");if($file1){$action = "$action $file1";} 
}


if ($throttled){check_ulaw_db ($throttled);if($file1){$action = "$action $file1";}  }




print "$datum Playing file $currentTime\n";

check_gsm_db ("silence1");if($file1){$action = "$action $file1";}

exec("sox $action $currentTime",$output,$return_var);if($debug){print "DEBUG $action";}
exec("sudo asterisk -rx 'rpt localplay $node /tmp/current-time'",$output,$return_var);

// if we are registered lets play the time
if ($pos1) { 
sleep(50);
include_once ("$path/weather_pws.php") ;
}


?>
