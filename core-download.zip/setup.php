#!/usr/bin/php
<?php
//  ------------------------------------------------------------
//  (c) 2023 by WRXB288 lagmrs.com all rights reserved
//
// Setup program
//
// -------------------------------------------------------------

// PHP is in UTC Get in sync with the PI

$ver="v3.3"; $release="07-29-2023";

$line =	exec('timedatectl | grep "Time zone"'); //       Time zone: America/Chicago (CDT, -0500)
$line = str_replace(" ", "", $line);
$pos1 = strpos($line, ':');$pos2 = strpos($line, '(');
if ($pos1){  $zone   = substr($line, $pos1+1, $pos2-$pos1-1); }
else {$zone="America/Chicago";}
define('TIMEZONE', $zone);
date_default_timezone_set(TIMEZONE);
$phpzone = date_default_timezone_get(); // test it 
//if ($phpzone == $zone ){$phpzone="$phpzone set";}
//else{$phpzone="$phpzone ERROR";}

$phpVersion= phpversion();

$logRotate = 50000;// size to rotate at

$in="";
$path         = "/etc/asterisk/local/mm-software";
$iax          = "/etc/asterisk/iax.conf";
$rpi          = "/etc/asterisk/rpt.conf";
$manager      = "/etc/asterisk/manager.conf";
$supermonPath = "/srv/http/supermon";
$allmon       = "$supermonPath/allmon.ini";   
$favorites    = "$supermonPath/favorites.ini";
$global       = "$supermonPath/global.inc";
$tmpFile      = "/tmp/temp.dat";
$logger       = "/etc/asterisk/logger.conf";

// automatic node setup

$file=""; $in="check";
create_node ($file);// testing create it everytime 

$file= "$path/mm-node.txt"; 
if(file_exists($file)){
$line = file_get_contents($file);
$u= explode(",",$line);
$AutoNode=$u[0];$call=$u[1];$autotts=$u[2];
}
// make sure cron was installed
$file = "$path/cron-orginal.txt"; if (!file_exists($file)){setUpcron("cron");}

include ("$path/check_reg.php");

load($in); 
c64($in);
reg_check ($in);
check_bridge_installed ($in); // double check its installed.
$file="";

$stripe="============================================================";
start_menu($in);
start("start");

function start($in){
global $MuteNet1,$MuteNet2,$MuteNet3,$sleep,$call,$AutoNode,$stripe,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$search,$fileEdit,$ok;

$stdin = fopen('php://stdin', 'r');
$yes   = false;

while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Enter 1-2 E:_";
	$input = trim(fgets($stdin));
    if ($input == '1'){edit("edit");}
    if ($input == '2'){supermon("view");}

    if ($input == 'f'){reg_force("force");} 
 
    if ($input == 'd'){doc("view");}     
   	if ($input == 'u'){install("I");}
    if ($input == 'x'){uninstall("x");}  
	if ($input == 'e'){quit('EXIT');}
    if ($input == ''){quit('EXIT');}
}
}



function reg_force($in){
global $counter,$watchdog,$NotReg,$datum;

print"
Success rate for me is 100%. Your milage may vary. 
This is only for the following problem.
Your Router, Gateway, Modem or ISP Corrupts your open port so
it cant reach the reg server. 
I fix this by rotating the port# This forces a new path to the server.
Normaly registration is restored in a few seconds. 

After your back online the port will rotate back to default. On the next reboot.

Note: If you are using IAX client it wont be able to reconnect while on the alt port.

Watchdog can be set to run this fix automaticaly. 
";
reg_check ($in);
if($NotReg){reg_fix ("check");}
else {print"$datum This can only be run manualy if you are not registered.
"; }

start_menu($in);
}

function start_menu($in){
global $ver,$release,$call,$stripe,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll;
global  $phpzone,$phpVersion,$MuteNet1,$MuteNet2,$MuteNet3,$sleep;; 
print "
$stripe
(c) 2023 by WRXB288 LAGMRS.com all rights reserved 
PHP:$phpVersion  Installer:$ver  Release date:$release
Timezone: $phpzone
$stripe
Welcome $call  Made in Louisiana
  
 Setup.php  program 
          
 1) Edit program Options
 2) Supermon Easy Install
 
 F) Force Register Fix
 D) View the Docs
 U) Upgrade (get the latest version)
 x) Uninstall This software.
 E) Exit  
$stripe
";
} 
 

function editmenu(){
global $Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$tts,$MuteNet1,$MuteNet2,$MuteNet3,$sleep,$debug,$IconBlock,$forcast,$beta,$AutoNode,$stripe,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate,$watchdog,$bridgeCheck;
$displayIconBlock="false";$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; 
$displayStatement="false";$displayReport="false";$displayForcast="false";$displaydebug="false"; $displaybridgeCheck= "false";
$displayMuteNet1="false";$displayMuteNet2="false"; $displayMuteNet3="false"; $displaySleep ="false";
if ($sayWatch)    {$displayWatch =   "true";}
if ($sayWarn)     {$displayWarn     ="true";}
if ($sayAdvisory) {$displayAdvisory ="true";}
if ($sayStatement){$displayStatement="true";}
if ($forcast)     {$displayForcast  ="true";}
if ($reportAll)   {$displayReport   ="true";}
if ($IconBlock)   {$displayIconBlock="true";}
if ($debug)       {$displaydebug    ="true";}
if ($bridgeCheck) {$displaybridgeCheck= "true";}
if ($MuteNet1) {   $displayMuteNet1 ="true";}
if ($MuteNet2) {   $displayMuteNet2 ="true";}
if ($MuteNet3) {   $displayMuteNet3 ="true";}
if ($sleep)    {      $displaySleep ="true";}



print"

$stripe
 Setup editor.   Last write date:$saveDate

 1) Station [$station] Weather Station MADIS,APRSWXNET,Citizen Weather Observer Program (CWOP)
 2) Level Time [$level] 1=temp 2=cond 3=wind,hum,rain 4=Forcast (Levels to speak)
 3) Zipcode [$zipcode] for Acuweather conditions
 4) Location Lat:[$lat]/Lon:[$lon] needed for NWS API 
 5) SayWatch:$displayWatch SayAdvisory:$displayAdvisory SayStatement:$displayStatement 
 6) CPU Temp setup  HiTemp[$high]  Hot[$hot] All temps[$displayReport]
 7) Node   Auto:[$AutoNode]  Node:[$node]
 9) Automatic Clock Muting  net1[$displayMuteNet1] net2[$displayMuteNet2] net3[$displayMuteNet3] sleep[$displaySleep]
 0) Watchdog limit. will fix reg automaticaly after [$watchdog] falures 99=disable
 d) Debugging info [$displaydebug]
 b) Bridging detection system [$displaybridgeCheck]  
 c) Install into cron.
 u) Uninstall from cron. 
 W) Write to file.
 M) Main menu
 E) Exit (Remember to write to disk) 
$stripe
";

// i) Forcast Icon block on supermon page [$displayIconBlock]

}

function supermonMenu(){
global $forcast,$beta,$AutoNode,$stripe,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate,$search,$fileEdit,$ok;
print"
$stripe
This will set up GMRS Supermon for node: $node

* One click automated install supermon. 
* Upgrade supermon to GMRS Supermon
* Add GMRS live index HUBS,Repeaters and nodes
* Add GMRS Logbook (soon)
* Remove Allstar branding and links. Add GMRS ones
* Add redirect from root to /supermon

 More later as updates come out. Use Update to install them.
 
----------------------------------------------------------------        
 Your existing supermon will be backed up. But as always make
 sure you have a backup of your card just in case.
 Use win32diskimager.org for card backups.       
---------------------------------------------------------------

 i) Setup supermon. 
  
 M) Main menu
 E) Exit  
$stripe
";
}






function quit($in){
global $phpVersion,$ver,$stripe,$phpzone,$release,$MuteNet1,$MuteNet2,$MuteNet3,$sleep,$forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$bridgeCheck;
save($in);
$path= "/etc/asterisk/local/mm-software";

print "
$stripe
(c) 2023 by WRXB288 LAGMRS.com all rights reserved 
PHP:$phpVersion  Installer:$ver  Release date:$release
Timezone: $phpzone
$stripe


Thank you for downloading.........Made in Louisiana


to test type

cd $path

php weather_pws.php
php temp.php
php cap_warn.php


this program is located in $path 
And can be run from the admin menu or by typing
php setup.php


* SLMR v2.1 * Have many nice days.
$stripe
";
c64("c64");
die;
}


function edit($in){
global $Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$sleep,$forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$bridgeCheck;
editmenu();
$stdin = fopen('php://stdin', 'r');
$yes   = false;
while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Enter 1-9 M W E:_";
	$input = trim(fgets($stdin));
    if ($input == '1'){madis($station);}
    if ($input == '2'){level($level);}
    if ($input == '3'){zip($zipcode);}
    if ($input == '5'){warn($zipcode);}
    if ($input == '4'){location($lon);}
    if ($input == '6'){cpu($hot);}
    if ($input == '7'){setnode($node);}
 
    if ($input == '9'){muting("set");}
    if ($input == 'd'){debug("set");}
    if ($input == '0'){watchdog("set");}

    if ($input == 'b'){bridge("set");}
    if ($input == 'c'){setUpcron("set");}
    if ($input == 'u'){unSetcron("set");}
    if ($input == 'm'){start_menu($in);start("start");}
    if ($input == 'w'){save("save");}
	if ($input == 'e'){quit('EXIT');}
}

}



// FM no static at all.  
function supermon($in){
global $forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll;
supermonMenu();
$stdin = fopen('php://stdin', 'r');
$yes   = false;

while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Enter 1-7 M E:_";
	$input = trim(fgets($stdin));
    if ($input == 'i'){supermonGo("GO baby");}

    if ($input == 'm'){start_menu($in);start("start");}
	if ($input == 'e'){quit('EXIT');}
}

}




// -------------------------------------------------------------supermon ----------------------------------------------
function supermonGo($in){
global $zipcode,$call,$password,$forcast,$beta,$AutoNode,$path,$node,$iax,$rpi,$manager,$supermonPath,$allmon,$favorites,$global,$tmpFile,$logger,$watchdog,$name,$location,$ip,$search,$fileEdit,$ok ;
print "
---------------------------------------------------------------
Second notice safty screen... Please verify you want to do this

                 <<<<INSTALL>>>>

This will set up GMRS Supermon for node: $node

* One click automated install supermon. 
* Upgrade supermon to GMRS Supermon
* Add GMRS live index HUBS,Repeaters and nodes
* Add GMRS Logbook (soon)
* Remove Allstar branding and links. Add GMRS ones
* Add redirect from root to /supermon

 More later as updates come out. Use Update to install them.
 
----------------------------------------------------------------        
 Your existing supermon will be backed up. But as always make
 sure you have a backup of your card just in case.
 Use win32diskimager.org for card backups.       
---------------------------------------------------------------
        

  i) install 

 Any other key to abort 
";
$a = readline('Enter your command: ');
if ($a=="i"){
// first 
print "[Entering return anytime will abort]
";
save_task_log ("Installing Supermon");

print"
Backing up existing supermon into
$path/backup/supermon.tar.gz
=================================================================
";
$path4 = "$path/backup";if(!is_dir($path4)){ mkdir($path4, 0755);}
exec ("tar -czfv $path/backup/supermon.tar.gz /srv/http/supermon/",$output,$return_var);


print"
The supermon page will display this info its not used anywhere else.
=================================================================
";
$name = readline('Your Name for supermon page: ');
$location = readline('Your Location for supermon page: ');
print "Zipcode = $zipcode
=================================================================
";
$password = getRandomString(5);
print " Using random password of $password on IAX connections.
";

$manager= "/etc/asterisk/manager.conf";
$fileEdit=$manager;$search= "secret =";$hide=false;edit_config("secret =$password"); 

print "Password [$password] entered in $manager\n";
buildAllmon($node);
print "Password entered in $allmon  with custom links to GMRSLive\n";

chdir("$supermonPath");



$password = getRandomString(5);
$file="$supermonPath/.htpasswd";
if (file_exists($file)){ unlink($file); }
print "
Now create a password for the Old Supermon page. 
Here is a random password for you $password  or make your own

 /supermon  login password  Username:admin \n";
exec ("htpasswd -cB .htpasswd admin",$output,$return_var);


chdir("$supermonPath/admin");

$file="$supermonPath/admin/.htpasswd";
if (file_exists($file)){ unlink($file); }
print "
The new GMRS Supermon has a admin directory. It needs its own password.
It should likely be the same as above. But you need to enter it again.  

 /supermon/admin directory password  Username:admin \n";
exec ("htpasswd -c .htpasswd admin",$output,$return_var);






print "Building global.ini  $call \n"; buildGlobal($node);
print "Building fav  \n";buldFav("fav");
 
$rpi="/etc/asterisk/rpt.conf"; // debugging....Need to be sure which file we are editing
$fileEdit=$rpi;$search="connpgm=/usr/";$hide=false;edit_config("connpgm=/usr/local/sbin/supermon/smlogger 1");
$fileEdit=$rpi;$search="discpgm=/usr/";$hide=false;edit_config("discpgm=/usr/local/sbin/supermon/smlogger 0"); 

$logger="/etc/asterisk/logger.conf";
$fileEdit=$logger;$search= "messages =>";$hide=false;edit_config("messages => notice,warning,error");

//print "adding trimlog to cron\n";
//$in="10,25,40,55 * * * * /usr/local/sbin/trimlog.sh /var/log/asterisk/messages 1000";$search="trimlog.sh";cronAdd($in);



$file="/srv/http/index.html";if (file_exists($file)) {unlink ($file);}
$file="/srv/http/index.php" ;if (file_exists($file)) {unlink ($file);}






print"Requesting astres.sh restart\n";
exec ("astres.sh",$output,$return_var);  // Run restart


// install redirect
$file="/srv/http/index.php" ;
$fileOUT = fopen($file, "w");$out = "<?php
header('Location: /supermon/link.php?nodes=$node');
die();
?>";    // <?php
fwrite ($fileOUT, $out);fclose ($fileOUT);





print"Your supermon is setup visit the url with a web browser $ip\n";
}


start_menu($in);start("start");
}

//$MuteNet1,$MuteNet2,$MuteNet3

function muting($in){
global $Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$sleep;

$displayMuteNet1="false";$displayMuteNet2="false"; $displayMuteNet3="false"; $displaySleep ="false";

if ($MuteNet1) {   $displayMuteNet1 ="true";}
if ($MuteNet2) {   $displayMuteNet2 ="true";}
if ($MuteNet3) {   $displayMuteNet3 ="true";}
if ($sleep)    {      $displaySleep ="true";}

print "
Automatic muting of clock. (need more just ask)

Roadkill TexasGMRS nets  (all times are in 24 hr local time)
Wed net $Net1Start-$Net1Stop [$displayMuteNet1] Wind down wed
Sun net $Net2Start-$Net2Stop [$displayMuteNet2] Family fun night
Fri net $Net3Start-$Net3Stop [$displayMuteNet3] 

Mute at night 1-6am Local time [$displaySleep] sleep mode.  

Just press return to keep current values.
";
$line = readline("Mute net1 wed y/n: ");
if ($line=="y"){$MuteNet1=true;}
if ($line=="n"){$MuteNet1=false;}
$line = readline("Start time 24hr $Net1Start:");
if ($line){$Net1Start=$line;}
$line = readline("Stop time 24hr $Net1Stop:");
if ($line){$Net1Stop=$line;}

$line = readline("Mute net2 sun y/n: ");
if ($line=="y"){$MuteNet2=true;}
if ($line=="n"){$MuteNet2=false;}
$line = readline("Start time 24hr $Net2Start:");
if ($line){$Net2Start=$line;}
$line = readline("Stop time 24hr $Net2Stop:");
if ($line){$Net2Stop=$line;}

$line = readline("Mute net3 fri y/n: ");
if ($line=="y"){$MuteNet3=true;}
if ($line=="n"){$MuteNet3=false;}
$line = readline("Start time 24hr $Net3Start:");
if ($line){$Net3Start=$line;}
$line = readline("Stop time 24hr $Net3Stop:");
if ($line){$Net3Stop=$line;}



$line = readline("Mute     1-6am y/n: ");
if ($line=="y"){$sleep=true;}
if ($line=="n"){$sleep=false;}


editmenu();
}


function bridge($in){
global $bridgeCheck;

$displaybridgeCheck="false";
if ($bridgeCheck) {   $displaybridgeCheck ="true";}
print "
Automatic bridging detection and auto disconnect [$displaybridgeCheck]
Check is run on a schedule if bridging is detected a message will 
play warning you and a disconnect will be atempted.

Still in beta so if you see any problems just turn it off.
";
$line = readline("Set to t/f: ");
if ($line=="t"){$bridgeCheck=true;}
if ($line=="f"){$bridgeCheck=false;}
editmenu();
}



function debug($in){
global $debug,$forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayDebug="false";
if ($debug){        $displayDebug     ="true";}
print "
Debugging gives extra info on to the console. On the API will will print the log forcast to the console.
Debug is set to $displayDebug
";
$line = readline("Set to t/f: ");
if ($line=="t"){$debug=true;}
if ($line=="f"){$debug=false;}
editmenu();
}

function setnode($station){
global $forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false";
print "
Node1 is auto detected on install if you need to change this you can do so here

AutoDetect node:$AutoNode Node set to $node:

";
$line = readline("Node $node: ");
if($line){$node=$line;}
editmenu();

}


function madis($station){
global $forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false";
print "
We need the code for you local weather station. 
Find your local MADIS station code at 
https://madis-data.ncep.noaa.gov/MadisSurface/

The Meteorolical Assimilation Data Ingest System
contains stations from APRSWXNET
CWOP(Citizen Weather Observer Program) 

The APRSWXNET/Citizen Weather Observer Program (CWOP) is a private-public partnership
with the goals of collecting weather data contributed by citizens and making these
data available for weather services and research activities. Upon integration into
the MADIS database, the observations become available to hundreds of users in the
meteorological community, including the majority of National Weather Service (NWS)
forecast offices, the National Climatic Data Center (NCDC), the National Operational
Hydrologic Remote Sensing Center (NOHRSC), and many universities and private companies.

";
$line = readline("Local Station $station: ");
$station = $line;
editmenu();
}


function level($level){
global $forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false";
print "
When the time and temp runs how much detal do you want?
1=temp,2=cond 3=wind,hum,rain 4=Forcast  (Levels to speak)

";
$line = readline("Level $level: ");
$level = $line;
editmenu();
}

function zip($level){
global $zipcode;
$line = readline("Enter your ZipCode $zipcode: ");
$zipcode = $line;
editmenu();
}

function zip2($level){
global $zipcode;
$line = readline("Enter your ZipCode $zipcode: ");
$zipcode = $line;
location($zipcode);
}


function cpu($level){
global $forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false";
if ($reportAll)   {$displayReport   ="true";}
print "
 CPU Temp setup  HiTemp[$high]  Hot[$hot] All temps[$displayReport]
 HiTemp is the alarm
 Hot is a warning
 All temp either reports temp on every call or only on hot events.
";
$line = readline("HiTemp default 60: ");
if ($line>55){$high=$line;}

$line = readline("HotTemp default 50: ");
if ($line>49){$hot=$line;}

$line = readline("Report all temps y/n: ");
if ($line=="y"){$reportAll=true;}
if ($line=="n"){$reportAll=false;}

editmenu();
}


function location($in){
global $forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;

print "
We need your LAT/LON for the new GEO coded weather alerts.
The new National Weather Service api is now GEOCODED.
The more accurate your location is the better tornado/storm reports you will get.

Use your phone or go to http://gps-coordinates.org

 1) Enter Lat/Lon  [$lat]/[$lon] 
 2) Change Zipcode [$zipcode]

 B) go back  (Remember to write to disk)
 
";
$stdin = fopen('php://stdin', 'r');
$yes   = false;
while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Enter 1-2 B E:_";
	$input = trim(fgets($stdin));
    if ($input == '1'){locationEnter($station);}
    if ($input == '3'){lookupgps($zipcode);}
    if ($input == '2'){zip2($zipcode);}
    
    if ($input == 'b'){$yes= true;}
    if ($input == 'm'){$yes= true;}
    if ($input == 'q'){$yes= true;}
	if ($input == 'e'){quit('EXIT');}
}


editmenu();
}

function locationEnter($in){
global $lat,$lon;
$line = readline("Lat: ");
if($line){$lat=$line;}
$line = readline("Lon: ");
if($line){$lon=$line;}
location();
}


function lookupgps($in){
global $lat,$lon,$zipcode,$city,$state;
// This key is licensed to me do not reuse in anything else.
// Get your own.
$api="d8e8c050-2d0c-11ee-86e8-a9d406a2a91b";
$domain ="app.zipcodebase.com";
$datum   = date('m-d-Y H:i:s');
print "$datum Polling $domain $zipcode WAIT!>--";
$mtime = microtime(); $mtime = explode(" ",$mtime); $mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;

$attime = gmdate('YmdHi');
$url = "api/v1/search?apikey=$api&codes=$zipcode&country=US";

$options = array(
    'http'=>array(
        'timeout' => 30,  
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Content-Type: application/json\r\n".
                  "User-Agent: Allstar Node lagmrs.com \r\n" 
));
$context = stream_context_create($options);
$html = @file_get_contents("http://$domain/$url"); 
$file ="/tmp/zip-to-geo.xml";
if(file_exists($file)){unlink($file);}
//$json = json_decode($html);
$html = str_replace('"', "", $html);
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"https://$domain/$url\n $html ");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
$mtime = microtime(); $mtime = explode(" ",$mtime); $mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);



$u = explode(",",$html);  // latitude:31.74500000,longitude:-92.39520000
$uLat = explode(":",$u[4]) ; $uLon = explode(":",$u[5]);
$uCity = explode(":",$u[6]); $uState = explode(":",$u[7]);

$city="";$state="";
if ($uCity[0]=="city"){$city=$uCity[1];print"ok $poll_time sec ($city "; }
if ($uState[0]=="state"){$state=$uState[1];print"$state)\n"; }

if ($uLat[0]=="latitude"){print"$datum";$uLat[1]=round($uLat[1],4);print " [$uLat[1]/";}
if ($uLon[0]=="longitude"){
$uLon[1]=round($uLon[1],4);
print "$uLon[1]] <--Enter this\n";
}
else{print"ERROR\n";}


}


function watchdog($in){
global $watchdog;

print "
Watchdog timmer.  On this many falures [$watchdog] take action.

In case you get Not Registered abd it wont come back online it will rotate
the port to a random port and restart ast. This solves my ATT Fixed Wireless problem 

Which is designed to bypasses a port block on your modem, router or ISP.

3 or 4 recomended 

If you are having problems staying registered after a few days you can try this. 
If it doesnt work o well its something to try works for me....

Set to 99 to disable.   
";
$line = readline("Watchdog timmer $watchdog: ");
$watchdog = $line;
if($watchdog==""){$watchdog=2;}
editmenu();
}




function doc($in){
global $forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate,$stripe;
$i=0;
$file="$path/readme.txt";
print "
 Loading the readme.txt file
$stripe
";
$fileIN= file($file);
foreach($fileIN as $line){
print $line; $i++ ;
if ($i >42){$line = readline(" ");$i=0;}
}
print "$stripe
End of File
";
$line = readline("Hit Return for menu");
start_menu($in);start("start");
}

function warn($skywarn){
global $forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false"; 
if ($sayWatch)    {$displayWatch =   "true";}
if ($sayWarn)     {$displayWarn     ="true";}
if ($sayAdvisory) {$displayAdvisory ="true";}
if ($sayStatement){$displayStatement="true";}

print "
Cap Warn uses Common Alerting Protocol (CAP) from the NWS
The new API needs your LAT/LON  [$lat/$lon]


Customise what reports you want
SayWarning   true <hard coded>
SayWatch     $displayWatch
SayAdvisory  $displayAdvisory
SayStatement $displayStatement 
 
";
$line = readline("Say Watches y/n: ");
if ($line=="y"){$sayWatch=true;}
if ($line=="n"){$sayWatch=false;}

$line = readline("Say Advisory y/n: ");
if ($line=="y"){$sayAdvisory=true;}
if ($line=="n"){$sayAdvisory=false;}

$line = readline("Say Statement y/n: ");
if ($line=="y"){$sayStatement=true;}
if ($line=="n"){$sayStatement=false;}
editmenu();
}




function load($in){
global $Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$bridgeCheck,$autotts,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$forcast,$beta,$saveDate,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog;

if (is_readable("$path/setup.txt")) {
   $fileIN= file("$path/setup.txt");
//$datum = date('m-d-Y-H:i:s');
//print "$datum Loading settings
//";
   foreach($fileIN as $line){
    $u = explode(",",$line);
//            $path =  $u[0];
             $node  =  $u[1];
          $station  =  $u[2];
             $level =  $u[3];
         $zipcode   =  $u[4];
         $IconBlock =  $u[5];
               $lat =  $u[6];
               $lon =  $u[7];
           $sayWarn =  $u[8];
          $sayWatch =  $u[9];
       $sayAdvisory = $u[10];
      $sayStatement = $u[11];
        $sleep      = $u[12];
              $high = $u[13]; 
               $hot = $u[14];
          $nodeName = $u[15];
         $reportAll = $u[16];
          $saveDate = $u[17];
           $forcast = $u[18]; // not using
              $beta = $u[19];
          $watchdog = $u[20];
             $debug = $u[21];
               $tts = $u[22]; // later add on
       $bridgeCheck = $u[23]; 
       $MuteNet1    = $u[24]; 
       $MuteNet2    = $u[25];
       $MuteNet3    = $u[26];
       $Net1Start   = $u[27]; 
       $Net1Stop    = $u[28];
       $Net2Start   = $u[29];
       $Net2Stop    = $u[30]; 
       $Net3Start   = $u[31];
       $Net3Stop    = $u[33];
                 
    }
}

       

else {
// set default
$status ="Building default settings";save_task_log ($status);
print "$datum $status
";
$reportAll = false;$nodeName = "server";$high=60;$hot=50;
// https://madis-data.ncep.noaa.gov/MadisSurface/
$station="KAEX";$level = 3 ;  // Alexandria International Airport (AEX)
$zipcode="71432"; $IconBlock= true; $skywarn ="";
$lat ="31.3273"; $lon="-92.5485"; // Alexandria International Airport	31.3273717,-92.5485558
$sleep=true;$tts=$autotts;
$sayWarn=true;$sayWatch=true;$sayAdvisory=true;$sayStatement =true;
$node = $AutoNode;$forcast= false;$beta = false; $debug=false;
$watchdog = 10; 
$phpzone = date_default_timezone_get();
$MuteNet1 = false; $MuteNet2 = false; $MuteNet3 = false;
$Net1Start= 19; $Net1Stop= 20;$Net2Start= 18; $Net2Stop= 21;$Net3Start= 19; $Net3Stop= 20;

if ($phpzone=="America/Chicago"){ // louisiana
$MuteNet1 = true; $MuteNet2 = true; }
$Net1Start= 19; $Net1Stop= 20;$Net2Start= 18; $Net2Stop= 21;$Net3Start= 19; $Net3Stop= 20;
}

if ($phpzone=="America/Denver"){ // 
$MuteNet1 = true; $MuteNet2 = true; }
$Net1Start= 20; $Net1Stop= 21;$Net2Start= 19; $Net2Stop= 22;$Net3Start= 20; $Net3Stop= 21;
}
 
$bridgeCheck = true;
save ("save");
}
}


function save($in){
global $Net1Start,$Net1Stop,$Net2Start, $Net2Stop,$Net3Start,$Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$tts,$debug,$datum,$forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$IconBlock,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$sleep,$high,$hot,$nodeName,$reportAll,$watchdog,$bridgeCheck;
$fileOUT = fopen("$path/setup.txt", "w");
$status ="Writing settings";save_task_log ($status);
print "$datum $status
";
fwrite ($fileOUT, "$path,$node,$station,$level,$zipcode,$IconBlock,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$sleep,$high,$hot,$nodeName,$reportAll,$datum,$forcast,$beta,$watchdog,$debug,$tts,$bridgeCheck,$MuteNet1,$MuteNet2,$MuteNet3,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,,,,,,");
fclose ($fileOUT);
}

function uninstall($in){
global $datum,$file,$path;


print "
---------------------------------------------------------------
This will remove all the software and set back to orginal
be sure this is what you want to do.
---------------------------------------------------------------


-----> UNINSTALLER <-------
  
  u) uninstall 

 Any other key to abort 
";
$a = readline('Enter your command: ');

if ($a == "u"){
$datum = date('m-d-Y-H:i:s');
$path1 = "/srv/http/supermon";
$path  = "/etc/asterisk/local/mm-software"; 
$path2 = "$path/sounds";
$path3 = "$path/repo";
$path4 = "$path/backup";
$error = "";
chdir($path);
print"$datum Uninstalling files\n";
clean_repo($path); 
clean_repo($path2);
clean_repo($path3);
clean_repo("$path/nodelist/");
clean_repo("$path/logs/");
$nodesounds="/var/lib/asterisk/sounds/rpt/nodenames";clean_repo($nodesounds);

// remove dir will fail if not empty
rmdir($path2);
rmdir($path3);
rmdir("$path/nodelist/");
rmdir("$path/logs/");  

chdir($path);
$file = "$path/allstar_node_info.conf";if (file_exists($file)){unlink ($file);}
// clear the admin menu
$file ="/usr/local/sbin/firsttime/mmsoftware.sh";if (file_exists($file)){unlink ($file);}
// Erase the custom directory
$file = "/srv/http/supermon/gmrs-rep.php"; if (file_exists($file)){unlink ($file);}
$file = "/srv/http/supermon/gmrs-hubs.php";if (file_exists($file)){unlink ($file);}
$file = "/srv/http/supermon/gmrs-list.php";if (file_exists($file)){unlink ($file);}


// reinstall orginal file if exists.
chdir($path1); 
$fileBu = "$path1/links.php.bak"; 
if (file_exists($fileBu) and file_exists("$path3/link.merge")){
unlink ("link.php");
copy ($fileBu,"$path1/links.php"); 
}
else{
$file = "/srv/http/supermon/list.php";if (file_exists($file)){unlink ($file);}
$repo = "https://raw.githubusercontent.com/tmastersmart/gmrs_live/main";
exec("sudo wget $repo/supermon/list.php",$output,$return_var);
print"Reinstalling link.php from archive\n";
}

clean_repo("$path1/admin");// This is where my custom files are

// if a backup exist then use it.
$path4 = "$path/backup";

if (file_exists("$path4/supermon.tar.gz")){ 
print"$datum Restoring from Supermon backup....\n";
clean_repo("$path1");
exec ("tar -xfv $path4/supermon.tar.gz /srv/http/supermon",$output,$return_var);
}


// Remove the nodelist processor and orginal.
// Mine is better but if you say so.
$fileEdit ="/usr/local/sbin/sm-support/smlogger_background.sh";
$fileBu = "$fileEdit-.bak"; 
if (file_exists($fileBu)){
unlink ($fileEdit); 
copy ($fileBu,$fileEdit); 
}


unSetcron($in);


 // make backups
$cur   = date('mdyhis');
$file = "$path/setup.txt";   if (file_exists($file)){$file2= "$path4/setup-$cur.txt";  rename($file, $file2);} 
$file = "$path/mm-node.txt"; if (file_exists($file)){$file2= "$path4/mm-node-$cur.txt";rename($file, $file2);} 
$file = "$path/logs/log.txt";if (file_exists($file)){$file2= "$path4/log-$cur.txt"   ; rename($file, $file2);} 
$file = "$path/logs/log2.txt";if (file_exists($file)){$file2= "$path4/log2-$cur.txt"   ; rename($file, $file2);} 



print "$datum MM-Software Uninstalled. 
Some files may linker such as backups and unforseen files 
please report any problems you may have had to www.lagmrs.com
";


} 
quit('EXIT');
}


function clean_repo($in){
chdir($in);
$files = glob($in.'/*'); 
foreach($files as $filed) {
   if($filed == '.' || $filed == '..') continue;
   if (is_file($filed)) { unlink($filed);print"del $filed\n";  }
 }
}


function install($in){
global $datum,$file,$path;

print "
---------------------------------------------------------------
This will update to the software to the current version
---------------------------------------------------------------
        

  u) update 

 Any other key to abort 
";
$a = readline('Enter your command: ');

if ($a == "u"){
$repo = "https://raw.githubusercontent.com/tmastersmart/gmrs_live/main";
$path1 = "/srv/http/supermon";
$path  = "/etc/asterisk/local/mm-software";
$path2 = "$path/sounds";if(!is_dir($path2)){ mkdir($path2, 0755);}
$path3 = "$path/repo";  if(!is_dir($path3)){ mkdir($path3, 0755);}
$path4 = "$path/backup";if(!is_dir($path4)){ mkdir($path4, 0755);}
chdir($path3);

clean_repo($path3);  


  print "Downloading new repo \n";
  exec("sudo wget $repo/core-download.zip",$output,$return_var);
  exec("sudo wget $repo/sounds.zip",$output,$return_var);
  exec("sudo wget $repo/supermon.zip",$output,$return_var);
  exec("sudo wget $repo/nodenames.zip",$output,$return_var);  
  exec("unzip $path3/core-download.zip",$output,$return_var);

$files = "setup.php,supermon_weather.php,load.php,forcast.php,temp.php,cap_warn.php,weather_pws.php,sound_db.php,check_reg.php,nodelist_process.php,check_gmrs.sh,connect.php";
$u = explode(",",$files);
foreach($u as $file) {
  print "Installing -PHP $path/$file\n";
  if (file_exists("$path/$file")){unlink("$path/$file");}
  rename ("$path3/$file", "$path/$file");
  exec("sudo chmod +x $path/$file",$output,$return_var); 
 }  
 
$files = "sound_gsm_db.csv,sound_wav_db.csv,sound_ulaw_db.csv,states.csv,cron.txt,readme.txt,taglines.txt";   

$u = explode(",",$files);
foreach($u as $file) {
  print "Installing -database $path/$file\n";
  if (file_exists("$path/$file")){unlink("$path/$file");}
  if (file_exists("$path3/$file")){rename ("$path3/$file", "$path/$file");}
 }

if (file_exists("$path/taglines.txt")){
exec("touch -d 19910101 $path/taglines.txt",$output,$return_var);// Just being funny taglines are very old.
}

exec("unzip $path3/sounds.zip",$output,$return_var);
$files = "net_down.gsm,bridged.gsm,clear.wav,heat_advisory.wav,flood_advisory.wav,weather_service.wav,hot.ul,warning.ul,under-voltage-detected.ul,arm-frequency-capped.ul,currently-throttled.ul,soft-temp-limit-active.ul,arm-frequency-capping.ul,throttling-has-occurred.ul,soft-temp-limit-occurred.ul";

$path2 = "$path/sounds";$path3 = "$path/repo";$path4 = "$path/backup"; // just for debugging

chdir($path3);   
$u = explode(",",$files);
foreach($u as $file) {
  print "Installing -Sound $path2/$file\n";
  if (file_exists("$path2/$file")){unlink("$path2/$file");}  // the sounds dir
  if (file_exists("$path3/$file")){rename ("$path3/$file", "$path2/$file");} // should move into sound dir
} 
$path1 = "/srv/http/supermon";
exec("unzip $path3/supermon.zip",$output,$return_var);

//$files = "gmrs-rep.php,gmrs-hubs.php,gmrs-list.php,link.php";
//$u = explode(",",$files);
//foreach($u as $file) {
  $file="link.php"; // Move in only 1 file for now
  print "Installing -Supermon mods  $file\n";
  if (file_exists("$path1/$file")){unlink("$path1/$file");}
  rename ("$path3/$file", "$path1/$file");

//} 

// This is the new GMRS Supermon admin area
$path5 = "$path1/admin";
$files = "gmrs-node-index.php,input-scan.php";
$u = explode(",",$files);
foreach($u as $file) {
  print "Installing -Supermon mods  $file\n";
  if (file_exists("$path5/$file")){unlink("$path5/$file");}
  rename ("$path3/$file", "$path5/$file");
} 

$nodesounds="/var/lib/asterisk/sounds/rpt/nodenames";

 foreach (glob("*.ul") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { unlink($file);print"del $file\n";  }
    }

exec("unzip $path3/nodenames.zip",$output,$return_var); 

 foreach (glob("*.ul") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
     if (!file_exists("$path3/$file")){ 
     rename ("$path3/$file", "$nodesounds/$file");
     print"Installing sound file:$nodesounds/$file\n"; 
     }
     else(unlink("$path3/$file"));// cleanup
    }
  }

 

// make backups
$cur   = date('mdyhis');
$file = "$path/setup.txt";   $file2= "$path4/setup-$cur.txt";  copy($file, $file2);
$file = "$path/mm-node.txt"; $file2= "$path4/mm-node-$cur.txt";copy($file, $file2);
$file = "$path/logs/log.txt";$file2= "$path4/log-$cur.txt"   ; copy($file, $file2);

// clean_repo($path3);

}// end og U

start_menu("start");start("start");
}

function create_node ($file){
global $file,$path;
// keep this file up to date
$file ="/usr/local/etc/allstar_node_info.conf"; $autotts=""; 
//copy($file, "$path/allstar_node_info.conf"); we no longer need this
$fileIN= file($file);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$line = str_replace('"', "", $line);
$pos = strpos("-$line", 'NODE1=');
if ($pos){$u= explode("=",$line);
$node=$u[1];}
$pos2 = strpos("-$line", 'STNCALL='); 
if ($pos2){$u= explode("=",$line);
$call=$u[1];}
}
// Get any tss key if exists   RESERVED for Future use
$file ="/usr/local/etc/tts.conf";
$fileIN= file($file);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$line = str_replace('"', "", $line);
$pos = strpos("-$line", 'tts_key=');
if ($pos){$u= explode("=",$line);
$autotts=$u[1];}
}
$file= "$path/mm-node.txt";// This will be the AutoNode varable
$fileOUT = fopen($file, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$node,$call,$autotts, , ,");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
}


// anti Bridging system Check installed.
function check_bridge_installed ($status){
global $search,$path,$fileEdit,$ok;
$fileEdit ="/usr/local/sbin/sm-support/smlogger_background.sh";
$fileBu = "$fileEdit-.bak"; 

if (!file_exists($fileBu)){
print"Installing anti Bridiging system\n";
$search="exit 0"; 
$in="# Transfering connection info to the anti Bridging system.
# WRXB288 (c) 2023
";
$formated="php /etc/asterisk/local/mm-software/connect.php #LOGINFO

exit 0
";
$formated = str_replace('#', '$', $formated);
$in = "$in $formated";
$hide=false;edit_config($formated);
$search="";$path="";
} 

}

 //
// $status ="what to log ";save_task_log ($status);print "$datum $status
//";
//
function save_task_log ($status){
global $path,$error,$datum,$logRotate;

$datum  = date('m-d-Y H:i:s');
if(!is_dir("$path/logs/")){ mkdir("$path/logs/", 0755);}
chdir("$path/logs");
$log="$path/logs/log.txt";
$log2="$path/logs/log2.txt"; //if (file_exists($mmtaskTEMP)) {unlink ($mmtaskTEMP);} // Cleanup

// log rotation system
if (is_readable($log)) {
   $size= filesize($log);
   if ($size > $logRotate){
    if (file_exists($log2)) {unlink ($log2);}
    rename ($file, $log2);
    if (file_exists($log)) {print "error in log rotation";}
   }
}

$fileOUT = fopen($log, 'a+') ;
flock ($fileOUT, LOCK_EX );
fwrite ($fileOUT, "$datum,$status,,\r\n");
flock ($fileOUT, LOCK_UN );
fclose ($fileOUT);
}





//this is my own editor to search and replace
// v2 7/28/2023
// $search=search for line  $in=change to $fileEdit=file   out $ok=true
function edit_config($in){ 
global $search,$path,$fileEdit,$ok,$hide;

if(!$hide){print "Search for $search in file:$fileEdit ";}
$ok=false;$line="";
if (file_exists($fileEdit)){

$fileBu = "$fileEdit-.bak"; if (!file_exists($fileBu)){copy($fileEdit,$fileBu);} // This creates a orginal backup

if(!file_exists($fileBu)and !$hide){ print "Unable to BackUP.";}

$tmpFile="$fileEdit-new.txt"; // keep in the same dir so we wont have to copy

$fileIN= file($fileEdit);
$fileOUT = fopen($tmpFile, "w") or die ("Error $tmpFile Write falure");
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", $search); 
if ($pos>=1){
$line=$in;$ok=true;
if(!$hide){print"$line Replacing with $in <ok>"; } // Replace the found line with a new one.
}  
fwrite ($fileOUT, "$line\n");
}

fclose ($fileOUT);
// if ok then we found it
if ($ok){
if (file_exists($tmpFile)){ unlink($fileEdit);} 
rename ($tmpFile, $fileEdit); save_task_log ("$fileEdit edited $in");

   } // rename
else{
if(!$hide){print "not found";}
}   
  } //file exist

// try to prevent stray data
$fileEdit="";$search="";print"\n";
}





// global.inc'
function buildGlobal($in){
global $zipcode,$global,$path,$file,$tmpFile,$ok,$password,$node,$call,$name,$location;

$file = $global;

if (file_exists($file)){
$fileBu = "$file-.bak"; if (file_exists($fileBu)){ unlink($fileBu); }
copy($file,$fileBu);if(!file_exists($fileBu)){ print "Unable to make a BackUP.\n";}

$fileOUT = fopen($global, "w") or die ("Error $global Write falure\n");  // 


$formated="
<?php
#CALL = '$call';
#NAME = '$name';
#LOCATION = '$location';
#TITLE2 = 'GMRS Live Node ';
#TITLE3 = 'System Node Manager';
#BACKGROUND = 'background.jpg';
#BACKGROUND_COLOR = 'blue';
#BACKGROUND_HEIGHT = '124px';
#REFRESH_DELAY = '21600';
#SHOW_COREDUMPS = 'yes';
#LOCALZIP = '$zipcode';
#MAINTAINER = '';
?>
";//  <?php
$formated = str_replace("'", '"', $formated);
$formated = str_replace('#', '$', $formated);

fwrite ($fileOUT, $formated);
fclose ($fileOUT);

print "saving $global \n";


save_task_log ("$file saved");

}
}
 
function buldFav($in){
global $favorites,$path,$file,$tmpFile,$ok,$password,$node;
$favorites    = "$supermonPath/favorites.ini";
$file = $favorites;

if (file_exists($file)){
$fileBu = "$file-.bak"; if (file_exists($fileBu)){ unlink($fileBu); }
copy($file,$fileBu);if(!file_exists($fileBu)){ print "Unable to make a BackUP.";}

$fileOUT = fopen($file, "w") or die ("Error $file Write falure\n");  // 

$formated="
[general]

label[] = 'RoadKill 1195'
cmd[] = 'rpt cmd %node% ilink 3 1195'

label[] = 'RoadKill DV Switch 1167'
cmd[] = 'rpt cmd %node% ilink 3 1167'

label[] = 'Texas GMRS Network 2250'
cmd[] = 'rpt cmd %node% ilink 3 2250'

label[] = 'Nationwide Chat 700'
cmd[] = 'rpt cmd %node% ilink 3 700'

label[] = 'The Lone Wolf 1691'
cmd[] = 'rpt cmd %node% ilink 3 1691'

label[] = 'ALAMO CITY 1510'
cmd[] = 'rpt cmd %node% ilink 3 1510'

label[] = 'CENTRAL ILLINOIS 1915'
cmd[] = 'rpt cmd %node% ilink 3 1915'

label[] = 'Edit Favorties.ini to add content'
cmd[] = 'NONE'
";

$formated = str_replace("'", '"', $formated);
fwrite ($fileOUT, $formated);
fclose ($fileOUT);
print "saving $allmon \n";
save_task_log ("$file saved");
}
}






function buildAllmon($in){
global $allmon,$path,$file,$tmpFile,$ok,$password,$node;

$file = $allmon;

if (file_exists($file)){
$fileBu = "$file-.bak"; if (file_exists($fileBu)){ unlink($fileBu); }
copy($file,$fileBu);if(!file_exists($fileBu)){ print "Unable to make a BackUP.";}

$fileOUT = fopen($file, "w") or die ("Error $file Write falure\n");  // 

$formated="
[$node]
host=127.0.0.1:5038
user=admin
passwd=$password
menu=yes
system=Nodes
hideNodeURL=no

[All Nodes]
sstem=Display Groups
nodes=$node
menu=yes

[Directory]
url='/supermon/gmrs-hubs.php'
menu=yes

[lsNodes]
url='/cgi-bin/lsnodes_web?node=$node'
menu=yes

[GMRSLive]
url='http://gmrslive.com/status/link.php?nodes=700,900'
menu=yes

[RoadKill]
url='http://1195.node.gmrslive.com/link.php?nodes=1195,1196,1167'
menu=yes

[Texas]
url='https://link.texasgmrs.net/link.php?nodes=2250,2251,2252,2253,2254,1000,922'
menu=yes

[Alamo City]
url='http://1510.node.gmrslive.com/supermon/link.php?nodes=1510,1512,1513,1680,1684'
menu=yes

[Florida]
url='http://www.lonewolfsystem.org/supermon/link.php?nodes=1691'
menu=yes

[Broadnet NY]
url='https://statusbroadnetgmrs.net/link.php?nodes=1420,1428,1430,1431,1432,1433,1434,2107,2108,2109,921'
menu=yes

[Cen IL]
url='http://1915.node.gmrslive.com/supermon/link.php?nodes=1915'
menu=yes 

[Ottawa Lake MI]
url='http://1171.node.gmrslive.com/supermon/link.php?nodes=1114'
menu=yes

[Southwest MI]
url='http://1082.node.gmrslive.com/supermon/link.php?nodes=1082'
menu=yes


";
$formated = str_replace("'", '"', $formated);
fwrite ($fileOUT, $formated);
fclose ($fileOUT);
print "saving $allmon \n";
save_task_log ("$file saved");
}
}



// build a password
function getRandomString($n){
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';

    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }
    save_task_log ("IAX password $randomString");
    return $randomString;
}



// remove from chron
function unSetcron($in){
global $search,$node1,$path;
print"restoring cron ";
 
// install the backup

$file = "$path/cron-orginal.txt";
if (file_exists($file)){exec ("crontab $file",$output,$return_var);print"from backup";}
else{
print"from default archive";
$replace="# Do not remove the following line
# required for lsnodes and allmon
15 03 * * * cd /usr/local/sbin; ./astdb.php cron
00 0-23 * * * (source /usr/local/etc/allstar.env ; /usr/bin/nice -19 /usr/bin/perl /usr/local/sbin/saytime.pl \$NODE1 > /dev/null)
";

$fileOUT = fopen($tmpFile, "w");fwrite ($fileOUT, $replace);fclose ($fileOUT);
exec ("crontab $tmpFile",$output,$return_var);
}
print "ok\n";
$tmpFile = "$path/cron-new.txt"; if (file_exists($tmpFile)){ unlink($tmpFile); }
$file = "$path/cron-orginal.txt";if (file_exists($file)){ unlink($file); }  // this may fail if permissions are wrong.
}

// sets up cron and removes old scripts.
function setUpcron($in){
global $fileEdit,$search,$path;
print "Installing Cron ";
// make a backup for uninstall
$file = "$path/cron-orginal.txt"; if (!file_exists($file)){exec ("crontab -l > $file",$output,$return_var);print"[made backup]";}
$file = "$path/cron.txt";

if (file_exists($file)){exec ("crontab $file",$output,$return_var);print" using[cron.txt] ";}
else{
$out="# GMRS Node Manager
# nodelist processor replaces astdb.php 
2 2-4 * * * php /etc/asterisk/local/mm-software/nodelist_process.php cron >/dev/null
00 * * * * php /etc/asterisk/local/mm-software/weather_pws.php >/dev/null
*/14 * * * * php /etc/asterisk/local/mm-software/cap_warn.php >/dev/null
*/19 * * * * php /etc/asterisk/local/mm-software/temp.php >/dev/null
10,25,40,55 * * * * /usr/local/sbin/trimlog.sh /var/log/asterisk/messages 1000
";
$file = "$path/cron.txt"; 
$fileOUT = fopen($file, "w");fwrite ($fileOUT, $out);fclose ($fileOUT);
print" using [memory] repo was missing ";
exec ("crontab $file",$output,$return_var);
}
print " <OK>\n";

//stop the looping script from being in memory
$fileEdit="/etc/rc.local"; $search="AutoSky";$hide=true;edit_config("#");



 
}
 
function c64($in){
print"






        **** COMODORE 64 BASIC V2 **** 
    64K RAM SYSTEM  38911 BASIC BYTES FREE
READY.
";
}







?>
