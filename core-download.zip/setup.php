<?php
// ***************************************************
// (c)2023/2024 by The Master lagmrs.com WRXB288 
//  all rights reserved
//
// Contains weather code (c)2015/2024 by The Master WRXB288 php.winnfreenet.com
// all rights reserved
//
// Setup program  
// -------------------------------------------------------------
// Release notes
// v5.9 .htacces for supermon had wrong path fixed
// v6.2 changes to updater and supermon menus
// v6.4 Protection for production server, Simplex repeater option.
// v6.5 Changes so burst can do text and any legenth
// v6.7  bug in supermon install for allmon fixed     
// v6.8  added ambent weather key
// v6.9  startup connect delay increased    
// v7.0  Bug in global.php file creation.
// v7.1  Changes to status page links updated
// v7.1  WEsite listings updated 
// v7.3  Hide IP at boot time
// v7.4  Adjusting node admin menu
// v7.5  All mon moved to external module(old supermon dir password check added back)
// v7.6  ID setup added, automated restore from backup on rpt.conf
// v7.7  Rewrote register fix setup menu
// v7.8  Tone setup menu added  
// v7.8.1 12-02-2023 wording change on bridge setup
// v7.9  Favorits removed from supermon in favor of hub index. RC.local checked for AUTOSKY 
// v8.0  Options to turn of bridge monitor Autofix settings adjusted
// v8.4  Cosmetic work in progress
// v8.5  Added header to setup file for coruption detection
// v8.6  Added blocklist setup. Database editing is still way off
// v8.7 - 8.8.1 1-3-24 Bug in tone save routine fixed. Check tone settings , bug in $changeall varable added in last version
// v8.8  1-3-24 Sets the default banner varable.
// v8.9  1/6/24 added option to turn off broken bridge 
// v9.0  1/7/24 Rewrite ID switching routine
// v9.1 ID bug fixed
// v9.2 Node password field added

$ver="v9.2"; $release="1-12-2024";  


$line =	exec('timedatectl | grep "Time zone"'); //       Time zone: America/Chicago (CDT, -0500)
$line = str_replace(" ", "", $line);
$pos1 = strpos($line, ':');$pos2 = strpos($line, '(');
if ($pos1){  $zone   = substr($line, $pos1+1, $pos2-$pos1-1); }
else {$zone="America/Chicago";}
define('TIMEZONE', $zone);
date_default_timezone_set(TIMEZONE);
$phpzone = date_default_timezone_get(); 

$basename=basename($_SERVER['PHP_SELF']);

$phpVersion= phpversion();

$logRotate = 50000;// size to rotate at

$in="";
$iax          = "/etc/asterisk/iax.conf";
$rpi          = "/etc/asterisk/rpt.conf";
$manager      = "/etc/asterisk/manager.conf";

$tmpFile      = "/tmp/temp.dat";
$logger       = "/etc/asterisk/logger.conf";

$path  = "/etc/asterisk/local/mm-software";
$pathS = "/srv/http/supermon";
$pathG = "/srv/http/gmrs";
$pathGA= "/srv/http/gmrs/admin"; 
$pathGE= "/srv/http/gmrs/edit";

$supermonPath = $pathG;
$allmon       = "$pathGA/allmon.ini"; // new secure path  
$favorites    = "$pathG/favorites.ini";
$global       = "$pathG/global.inc";

// automatic node setup
$file=""; $in="check"; $changeall=false;
create_node ($file);// testing create it everytime 

$file= "$path/mm-node.txt"; 
if(file_exists($file)){
$line = file_get_contents($file);
$u= explode(",",$line);
$AutoNode=$u[0];$call=$u[1];$autotts=$u[2];
}

$file= "$path/node-name.txt";// imported from nodelist 
$name="";$city="";$state="";
if(file_exists($file)){
$line = file_get_contents($file);
$u= explode(",",$line);
$name=$u[1];$city=$u[2];$state=$u[3];//1=node 4=call
}



// make sure cron was installed
$file = "$path/cron-orginal.txt"; if (!file_exists($file)){setUpcron("cron");}

include ("$path/check_reg.php");


load($in); 

find_port ($in);
$file ="/var/lib/asterisk/sounds/rpt/nodenames/$node.ul"; 
if (!file_exists($file)){setOurCall($node);}

include ("$path/tagline.php");// $tagline="";tagline($tagline);print "$tagline (Have many nice days.)";
include ("$path/setup_install.php");
include ("$path/setup_allmon.php");

c64($in);
reg_check ($in);
check_bridge_installed ($in); // double check its installed.

rcLocal($in);// Check that AUTOSKY is not set to load. 

$file="";

// automated recovery $rpi="/etc/asterisk/rpt.conf";
$size=0; $ok=false;
if (file_exists($rpi)){$size = filesize($rpi);}

if ($size ==0) { 
print "Error $rpt is corrupted atempting restore "; 
$fileBu1 = "$fileEdit-1.bak"; $fileBu = "$fileEdit-.bak"; 
if (file_exists($fileBu1)){copy($fileBu1,$rpt);$ok=true;} 
else{ if (file_exists($fileBu)){copy($fileBu,$rpt);$ok=true;}}

if ($ok){ 
print "[ok] Requesting ast restart......\n";
exec ("astres.sh",$output,$return_var);  // run script
sleep(10);
}
else {
print "[error] \n Restore failed cant find a backup. Manual repair of $rpt is needed \n"; die;} 
}


// Support for update from admin menu
$auto=false;
if (!empty($argv[1])) { if ($argv[1] =="update"){$auto=true;}}
if($auto){
 if($node<>2955){// protect the production server   
  install("I");
  quit('EXIT');
  }
}

$stripe="============================================================";
start_menu($in);
start("start");

function start($in){
global $port,$hide,$stripe,$testNewApi,$high,$hot,$nodeName,$reportAll,$search,$fileEdit,$ok;

global $parishCounty,$fema,$startUp,$startUpNode,$burst,$DisplayNodes,$name,$city,$state,$phpzone,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start;
global $Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$bridgeCheck,$autotts,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$LinkCheck,$beta,$saveDate,$path,$hideIP;
global $idType,$ambientApiKey,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog;
global $inTone,$outToneL,$outToneU,$bridgeMonitor,$banner,$changeall;
$stdin = fopen('php://stdin', 'r');
$yes   = false;

while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Main Enter 1-2 E:_";
	$input = trim(fgets($stdin));
    if ($input == '1'){edit("edit");}
    if ($input == '2'){supermon("view");}
    if ($input == '3'){dvswitch("install");}
    if ($input == '4'){blacklist("setup");}

    if ($input == 'r'){reg_menu("setup"); reg_edit($in);}  
 
    if ($input == 'a'){admin_sh_menu("reinstall");}
    if ($input == 'd'){doc("view");}
    if ($input == 's'){simplex("view");}
     
    if($node<>2955){// protect the production server   
       if ($input == 'u'){install("I");quit('EXIT');}  // I gives install prompt. Force exit so setup.php can be updated.
       if ($input == 'x'){uninstall("x");}
     }  
	if ($input == 'e'){quit('EXIT');}
    if ($input == ''){quit('EXIT');}
}
}


function port_reset($in){
global $counter,$datum,$node1,$registered,$ip,$node,$file,$path,$NotReg,$watchdog,$debug,$newPort,$changeall;
$datum   = date('m-d-Y H:i:s');
$out="Resetting port to default [4569]";
save_task_log ($out);print "$datum $out\n"; 
$newPort=4569;rotate_port("rotate"); 
$watchdog=99; // this disables rotation
sleep(9); 
print"$datum Requesting a AST restart\n";
$status= shell_exec("sudo /usr/local/sbin/astres.sh");
start_menu($in);
}

function reg_force($in){
global $counter,$datum,$node1,$registered,$ip,$node,$file,$path,$NotReg,$watchdog,$debug,$newPort,$changeall;
$watchdog=4;
reg_check ($in);
reg_fix ("check");
 // we are defaulting to 3 falures then rotate port
start_menu($in);
}

function reg_menu($in){
global $registered,$counter,$NotReg,$phpVersion,$ver,$release,$call,$node1,$ip,$file,$newPort; 

global $port,$hide,$stripe,$testNewApi,$high,$hot,$nodeName,$reportAll,$search,$fileEdit,$ok;

global $parishCounty,$fema,$startUp,$startUpNode,$burst,$DisplayNodes,$name,$city,$state,$phpzone,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start;
global $Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$bridgeCheck,$autotts,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$LinkCheck,$beta,$saveDate,$path,$hideIP;
global $idType,$ambientApiKey,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog;
global $inTone,$outToneL,$outToneU,$bridgeMonitor,$banner,$changeall;

reg_check ($in);
if($port<>4569){
$pout=" (Port $port is floating)";
if ($watchdog>50){$watchdog=4;}
} 
else{$pout=" (Port $port is at default. Not floating)";$watchdog=99;}


$displayRegD="I do not detect any Register problem at this time.";
if($NotReg){$displayRegD="You are curentaly having a register problem you can use \n Force Register fix to see if it solves the problem.";}
print " 
$stripe
Register setup menu  (you are [$registered])  Watchdog set to:$watchdog

This register fix is designed to get around port blocks which prevent you from registering.
Many ISPs will work fine and suddenly block your port. You will then be unable to get registered
when it worked fine before. Sometimes rebooting the router or hotspot will unlock the port by
getting a new IP address.

This solves the problem by creating a floating port that will change when you get blocked.
Please note floating port will not work with DVswitch.
On my ISP this corrected all my register problems with AT&T Fixed Wireless and Verizon. 

$displayRegD

$pout
 P) Reset port back to default
 S) Start Register Fix. 
 M) Main menu
 E) Exit   
$stripe
";
} 

function reg_edit($in){
global $registered,$counter,$NotReg,$phpVersion,$ver,$release,$call; 

global $port,$hide,$stripe,$testNewApi,$high,$hot,$nodeName,$reportAll,$search,$fileEdit,$ok;

global $parishCounty,$fema,$startUp,$startUpNode,$burst,$DisplayNodes,$name,$city,$state,$phpzone,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start;
global $Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$bridgeCheck,$autotts,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$LinkCheck,$beta,$saveDate,$path,$hideIP;
global $idType,$ambientApiKey,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog;
global $inTone,$outToneL,$outToneU,$bridgeMonitor,$banner,$changeall;



$stdin = fopen('php://stdin', 'r');
$yes   = false;
while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Reg cmd Enter s p M W E:_";
	$input = trim(fgets($stdin));
    
    if ($input == 's'){reg_force("force");}
    if ($input == 'p'){port_reset("reset");}  


    if ($input == 'm'){start_menu($in);start("start");}
    if ($input == 'w'){save("save");}
	if ($input == 'e'){quit('EXIT');}
}

}

function start_menu($in){
global $registered,$counter,$NotReg,$phpVersion,$ver,$release,$call; 

global $port,$hide,$stripe,$testNewApi,$high,$hot,$nodeName,$reportAll,$search,$fileEdit,$ok;

global $parishCounty,$fema,$startUp,$startUpNode,$burst,$DisplayNodes,$name,$city,$state,$phpzone,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start;
global $Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$bridgeCheck,$autotts,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$LinkCheck,$beta,$saveDate,$path,$hideIP;
global $idType,$ambientApiKey,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog;
global $inTone,$outToneL,$outToneU,$bridgeMonitor,$banner,$changeall;

$out="(get the latest version)";
if($node==2955){$out="<Disabled on production server>";}

print " 
$stripe
Setup Program  $ver  
(c)2023/2024 by WRXB288 LAGMRS.com all rights reserved 
PHP:$phpVersion Timezone: $phpzone  Release date:$release

Welcome $call  Made in Louisiana
  
 Setup.php  program 
          
 1) Edit program Options
 2) 1 Click Install GMRS Supermon
 3) 1 Click Install DVSwitch
 4) Whitelist/Blacklist setup
 
 A) Fix Reinstall admin menus
 D) View the Docs
 R) Register Fix Setup (fix register problems) 
 U) Upgrade $out

 s) Simplex Repeater Help
 x) Uninstall This software. 
 E) Exit  
$stripe
";
}  
 

function editmenu(){
global $registered,$counter,$NotReg,$phpVersion,$ver,$release,$call,$brokenBridge; 

global $port,$hide,$stripe,$testNewApi,$high,$hot,$nodeName,$reportAll,$search,$fileEdit,$ok;

global $parishCounty,$fema,$startUp,$startUpNode,$burst,$DisplayNodes,$name,$city,$state,$phpzone,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start;
global $Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$bridgeCheck,$autotts,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$LinkCheck,$beta,$saveDate,$path,$hideIP;
global $idType,$ambientApiKey,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog;
global $inTone,$outToneL,$outToneU,$bridgeMonitor,$banner,$changeall;


$displayWatch="false"    ;if ($sayWatch)    {$displayWatch =   "true";}
$displayWarn="false"     ;if ($sayWarn)     {$displayWarn     ="true";}
$displayAdvisory="false" ;if ($sayAdvisory) {$displayAdvisory ="true";}
$displayStatement="false";if ($sayStatement){$displayStatement="true";}
$displayReport="false"   ;if ($reportAll)   {$displayReport   ="true";}
$displayIconBlock="false";if ($IconBlock)   {$displayIconBlock="true";}
$displaydebug="false"    ;if ($debug)       {$displaydebug    ="true";}
$displaybridgeCheck= "false";if($bridgeCheck){$displaybridgeCheck= "true";}
$displayMuteNet1="false" ;if ($MuteNet1) {   $displayMuteNet1 ="true";}
$displayMuteNet2="false" ;if ($MuteNet2) {   $displayMuteNet2 ="true";}
$displayMuteNet3="false" ;if ($MuteNet3) {   $displayMuteNet3 ="true";}
$displaySleep ="false"   ;if ($sleep)    {   $displaySleep ="true";}
$displayNodes="No Popup" ;if ($DisplayNodes){$displayNodes ="true";}
$displaystartUp="false"  ;if ($startUp)  {   $displaystartUp ="true";}                         
$burstDisplay="off"      ;if ($burst){$burstDisplay=$burst;}
$femaDisplay= "off"      ;if ($parishCounty and $fema){$femaDisplay="true";}
$hideIPDisplay="false"   ;if ($hideIP){$hideIPDisplay="true";}
$displaybridgeMonitor="false"  ;if ($bridgeMonitor){$displaybridgeMonitor="true";}
$displaybrokenBridge="false"   ;if ($brokenBridge){$displaybrokenBridge="true";}


print"
$stripe
(c) 2023 by WRXB288 LAGMRS.com all rights reserved 
PHP:$phpVersion  Installer:$ver  Release date:$release
Timezone: $phpzone
$stripe
Welcome $call  Made in Louisiana

 Setup editor.   Last write date:$saveDate

 1) NWS Station [$station] Airport, MADIS, APRSWXNET, CWOP 
    Ambient Weather APIKEY [$ambientApiKey]
 2) Level Time [$level] 0=off 1=temp 2=cond 3=wind,hum,rain 4=Forcast (Levels to speak)
 3) Zipcode [$zipcode] for Acuweather conditions
 4) Location Lat:[$lat]/Lon:[$lon] needed for NWS API 
 5) SayWarn:$displayWarn SayWatch:$displayWatch SayAdvisory:$displayAdvisory SayStatement:$displayStatement 
 6) [$nodeName] CPU Temp setup  HiTemp[$high]  Hot[$hot] Report normal temp[$displayReport]
 7) Node   Auto:[$AutoNode]  Node:[$node]
 9) Automatic Mute  net1[$displayMuteNet1] net2[$displayMuteNet2] net3[$displayMuteNet3] sleep[$displaySleep]
 8) Display Node Scan on Supermon link page [$displayNodes].\n\n";
 
if ($startUp){print" a) Autoconnect to [$startUpNode] on startup [$displaystartUp]\n";}
else{print" a) Autoconnect on startup [$displaystartUp]\n";}
 
print" b) Bridging detection:[$displaybridgeCheck] Bridge Monitor:[$displaybridgeMonitor] Broken Bridge:[$displaybrokenBridge]

 c) Install into cron. (Done automaticaly. Manual reinstall)
 d) Debugging info [$displaydebug]
 f) FEMA Declared Emergency API [$femaDisplay] 
 h) Hide IP at bootup. [$hideIPDisplay]
 i) ID setup
 l) Link down Alarm [$LinkCheck] (0=off,1=15m,2=30m)
 s) MDC-1200 burst [$burstDisplay]
 t) Courtesy Tones   
 u) Uninstall from cron. (Allows manual uninstall)
 W) Write to file.  (now automatic)
 M) Main menu
 E) Exit 
$stripe
";

// i) Forcast Icon block on supermon page [$displayIconBlock]

}


function simplex($in){
global $stripe,$ok,$fileEdit,$search,$hide,$changeall;

print"
$stripe
Simplex repeater setup help

This node can be used as a simplex repeater for camping trips
and such. 
It works better on a repeater split channel that way you 
wont here people twice.
Be sure you dont use this mode when linked.

To activate the simplex repeater enter this DTMF command.

*971  SIMPLEX Mode On
*970  SIMPLEX Mode Off
*973  cleanup/flush
 
If you will have no internet access the clock will be wrong 
so you need to turn off the clock and link detection.

Macros are not installed from default. 
Checking install.....
"; 
checkSimplex($in);
print "$stripe\n";
$a = readline('Press any key: ');
start_menu($in);
}




function quit($in){
global $registered,$counter,$NotReg,$phpVersion,$ver,$release,$call; 

global $port,$hide,$stripe,$testNewApi,$high,$hot,$nodeName,$reportAll,$search,$fileEdit,$ok;

global $parishCounty,$fema,$startUp,$startUpNode,$burst,$DisplayNodes,$name,$city,$state,$phpzone,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start;
global $Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$bridgeCheck,$autotts,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$LinkCheck,$beta,$saveDate,$path,$hideIP;
global $idType,$ambientApiKey,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog;
global $inTone,$outToneL,$outToneU,$bridgeMonitor,$banner,$changeall;


save($in);

print"
$stripe
(c) 2023 by WRXB288 LAGMRS.com all rights reserved 
PHP:$phpVersion  Installer:$ver  Release date:$release
Timezone: $phpzone
$stripe

Thank you for downloading.........Made in Louisiana



this program can be run from the admin menu or by typing

cd $path

php weather_pws.php
php temp.php
php cap_warn.php
php setup.php
";

//$tagline="";tagline($tagline);print "$tagline (Have many nice days.)";

//c64("c64");

$file="$path/nodelist/clean.csv";
if (file_exists($file)){print "The Nodelist exists Skipping update.\n";}
else{ 
print "Starting Nodelist\n";
exec("php $path/nodelist_process.php",$output,$return_var); 
}  
print "$stripe\n";
die;
}


function edit($in){
global $registered,$counter,$NotReg,$phpVersion,$ver,$release,$call,$brokenBridge; 

global $port,$hide,$stripe,$testNewApi,$high,$hot,$nodeName,$reportAll,$search,$fileEdit,$ok;

global $parishCounty,$fema,$startUp,$startUpNode,$burst,$DisplayNodes,$name,$city,$state,$phpzone,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start;
global $Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$bridgeCheck,$autotts,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$LinkCheck,$beta,$saveDate,$path,$hideIP;
global $idType,$ambientApiKey,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog;
global $inTone,$outToneL,$outToneU,$bridgeMonitor,$banner,$changeall;


editmenu();
$stdin = fopen('php://stdin', 'r');
$yes   = false;
while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum EDIT Enter 1-9 M W E:_";
	$input = trim(fgets($stdin));
    if ($input == '1'){madis($station);}
    if ($input == '2'){level($level);}
    if ($input == '3'){zip($zipcode);}
    if ($input == '4'){location($lon);}
    if ($input == '5'){warn($zipcode);}
    if ($input == '6'){cpu($hot);}
    if ($input == '7'){setnode($node);}
    if ($input == '8'){lsnode("set");} 
    if ($input == '9'){muting("set");}

    
    if ($input == 'a'){setStartup("set");}
    if ($input == 'b'){bridge("set");}
    if ($input == 'c'){setUpcron("set");} 
    if ($input == 'd'){debug("set");}
    if ($input == 'h'){hideIPboot("set");}
    if ($input == 'i'){idSetup("set");}
    
        
    if ($input == 'l'){link_set("set");}
    if ($input == 'f'){femaSet("set");}   
    if ($input == 's'){setBurst("set");}
    if ($input == 't'){toneSetup("set");}
    if ($input == 'u'){unSetcron("set");}
    if ($input == 'm'){start_menu($in);start("start");}
    
    if ($input == 'w'){save("save");}
	if ($input == 'e'){quit('EXIT');}
}

}

function blacklist($in){
global $name,$city,$state,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi;
global $high,$hot,$nodeName,$reportAll,$changeall;
print" 
 ** BETA feature ** 
 You can have one a blacklist or a whitelist.
 This turns on or off the list. You edit the database from the CLI.
 Editing the database is not yet be working in the WEB GUI as of 12/23

 a) turn off both list
 b) Activate Blacklist
 w) Activate Whitelist
 
 m)menu
 e)exit
 ";
$rpi="/etc/asterisk/iax.conf"; $hide=true; $changeall=true;  
$a = readline('Enter your command:a b w m e _');

    if ($a == 'a'){block("off");}
    if ($a == 'b'){block("black");}
    if ($a == 'w'){block("white");}
   
    
    if ($a == 'm'){start_menu($in);start("start");}
	if ($a == 'e'){quit('EXIT');}
    
  
//;
//; To use the ban/allow (blacklist/whitelist) feature
//; comment with a ';' the context = radio-secure line and
//; remove the ';' from either the context = whitelist or
//; context = blacklist line. ONLY ONE of the three lines
//; can be active (uncommented).
//;
//; The best way to allow or ban nodes from the database is to
//; use the Supermon application or the node-ban-allow.sh script.
//
//context = radio-secure
//;context = whitelist
//;context = blacklist

// Clean out the comment blocks to stop interference   
print "Processing ";
$hide=true;$fileEdit=$rpi; $changeall=false;
print".";$search="context = radio-secure line";search_config("null")   ;if($ok){$in="; comment with a ';' the context = ra x line and";  $search="context = radio-secure line";   edit_config($in);}
print".";$search="either the context = whitelist";search_config("null");if($ok){$in="; remove the ';' from either the context = wh x or";$search="either the context = whitelist";edit_config($in);}
print".";$search="context = blacklist line";search_config("null")      ;if($ok){$in="; context = bl x line. ONLY ONE of the three lines";$search="context = blacklist line";      edit_config($in);}
print".\n";

    
if ($a == "a"){
print " Setting whitelist to OFF ";
$in=";context = whitelist";$fileEdit=$rpi;$search="whitelist";edit_config($in);
if($ok){print " OK.\n";}
else{print"Error\n";}

print " Setting blacklist to OFF ";
$in=";context = blacklist";$fileEdit=$rpi;$search="blacklist";edit_config($in);
if($ok){print " OK.\n";}
else{print"Error\n";}

print " Setting radio-secure ";
$in="context = radio-secure";$fileEdit=$rpi;$search="radio-secure";edit_config($in);
if($ok){print " OK.\n";}
else{print"Error\n";}

}     

if ($a == "b"){
print " Setting whitelist to OFF ";
$in=";context = whitelist";$fileEdit=$rpi;$search="whitelist";edit_config($in);
if($ok){print " OK.\n";}
else{print"Error\n";}

print " Setting blacklist to ON ";
$in="context = blacklist";$fileEdit=$rpi;$search="blacklist";edit_config($in);
if($ok){print " OK.\n";}
else{print"Error\n";}

print " Setting radio-secure ";
$in=";context = radio-secure";$fileEdit=$rpi;$search="radio-secure";edit_config($in);
if($ok){print " OK.\n";}
else{print"Error\n";}

}

if ($a == "w"){
print " Setting whitelist to ON ";
$in="context = whitelist";$fileEdit=$rpi;$search="whitelist";edit_config($in);
if($ok){print " OK.\n";}
else{print"Error\n";}

print " Setting blacklist to OFF ";
$in=";context = blacklist";$fileEdit=$rpi;$search="blacklist";edit_config($in);
if($ok){print " OK.\n";}
else{print"Error\n";}

print " Setting radio-secure ";
$in=";context = radio-secure";$fileEdit=$rpi;$search="radio-secure";edit_config($in);
if($ok){print " OK.\n";}
else{print"Error\n";}

}
//;context = whitelist
//;context = blacklist    
    
}


function supermonMenu(){
global $registered,$counter,$NotReg,$phpVersion,$ver,$release,$call; 
global $port,$hide,$stripe,$testNewApi,$high,$hot,$nodeName,$reportAll,$search,$fileEdit,$ok;
global $parishCounty,$fema,$startUp,$startUpNode,$burst,$DisplayNodes,$name,$city,$state,$phpzone,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start;
global $Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$bridgeCheck,$autotts,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$LinkCheck,$beta,$saveDate,$path,$hideIP;
global $idType,$ambientApiKey,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog;
global $inTone,$outToneL,$outToneU,$bridgeMonitor,$banner,$changeall;
print"
$stripe
This will set up GMRS Supermon for
Node:$node Name:$name City:$city State:$state

One click automated setup of GMRS supermon.

This does the config/password setup on GMRS Supermon.

Also use to update password or Web links.
$stripe
   
 i) install 
 M) Main menu
 E) Exit  
$stripe
";
}


function supermon($in){
global $station,$level,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi;
global $high,$hot,$nodeName,$reportAll;
global $name,$city,$state,$zipcode,$call,$password,$beta,$AutoNode,$path,$node,$iax,$rpi,$manager,$supermonPath,$allmon,$favorites,$global,$tmpFile,$logger;
global $watchdog,$name,$location,$ip,$search,$fileEdit,$ok,$in,$out,$docRouteP,$stripe,$changeall;
supermonMenu();
$stdin = fopen('php://stdin', 'r');
$yes   = false;

while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Supermon Enter 1-7 M E:_";
	$input = trim(fgets($stdin));
    if ($input == 'i'){supermonGo($in);}

    if ($input == 'm'){start_menu($in);start("start");}
	if ($input == 'e'){quit('EXIT');}
}

}


function supermonGo($in){
global $station,$level,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi;
global $high,$hot,$nodeName,$reportAll;
global $name,$city,$state,$zipcode,$call,$password,$beta,$AutoNode,$path,$node,$iax,$rpi,$manager,$supermonPath,$allmon,$favorites,$global,$tmpFile,$logger;
global $watchdog,$name,$location,$ip,$search,$fileEdit,$ok,$in,$out,$docRouteP,$stripe,$changeall;


// the APATCHIE config
//DocumentRoot "/srv/http"
//<Directory "/srv/http">
$out="";
$docRoute="Default"; $docRouteP="/srv/http";  $changeall=false;
$hide=false;$fileEdit="/etc/httpd/conf/httpd.conf"; $search="DocumentRoot ";search_config($out);
print $out;
if($ok and $out){
  $u = explode(" ",$out); //DocumentRoot "/srv/http"
  $docRoute=$u[0]; $docRouteP=$u[1]; 
  $docRouteP = str_replace('"', '', $docRouteP);
}  


print "
$stripe
<<< Verify you want to do this >>>
This will set up GMRS Supermon for
Node:$node Name:$name City:$city State:$state

Webserver [$docRoute $docRouteP]

Automates the process of setting up supermon

$stripe        

  i) install   Any other key to abort!
  
";
  
$a = readline('Enter your command: ');

if ($a=="i"){
save_task_log ("Setting up GMRS Supermon");

if (!$docRouteP){$docRouteP="/srv/http";}
$path  = "/etc/asterisk/local/mm-software";
$pathS = "$docRouteP/supermon";
$pathG = "$docRouteP/gmrs";
$pathGA= "$docRouteP/gmrs/admin"; $path5 = $pathGA ;
$pathGE= "$docRouteP/gmrs/edit";

$supermonPath = $pathG;

$favorites    = "$pathG/favorites.ini";
$global       = "$pathG/global.inc";


$line = readline("The Name for supermon page: $name ");if ($line){$name=$line;}
$location = readline("The Location for supermon page: $city $state");

// generage a 10 digit secure password.
$pass = getRandomString(10);
print "Using random generated password of [$pass]\n";
//$line = readline("Enter a password or just return for [$pass]");
//if ($line){$password=$line;}

$password=$pass;  $changeall=false;
$manager= "/etc/asterisk/manager.conf";// There is only 1 password in this file
$fileEdit=$manager;$search= "secret =";$hide=false;edit_config("secret =$password");
print "Password [$password] entered in $manager\n";

buildAllmon("gmrs");
if (file_exists($allmon)){print "Password entered GMRS Supermon in secured [$allmon].\n";}
else {print "error [$allmon] not found. Unable to build the file.\n";die;}

buildAllmon("supermon");
if (file_exists($allmon)){print "Password entered Supermon in [$allmon].\n";}
else {print "error [$allmon] not found. Unable to build the file.\n";die;}


chdir($pathGA);
print "
In order to secure GMRS Supermon a new ADMIN director was created that does not
use unsecure session keys. The new directory is secured by a web server password.
This requires you to enter a password now.   

$pathGA directory Username:admin \n";
exec ("htpasswd -c .htpasswd admin",$output,$return_var);

$out="#Protect Directory
AuthName \"GMRS Supermon\"
AuthType Basic
AuthUserFile $pathGA/.htpasswd
Require valid-user

<FilesMatch \"\.(htaccess|htpasswd|ini|ini.php|log|sh|inc|bak|save)$\">
Order Allow,Deny
Deny from all
</FilesMatch>";

$file="$pathG/admin/.htaccess";print"Protecting admin\n";
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$out); flock ($fileOUT, LOCK_UN );fclose ($fileOUT);


if (!file_exists("$pathS/.htpasswd")){
chdir($pathS);
print" The old supermon directory is not setup. Lets enter a password for it also.
 $pathS directory Username:admin \n";
 exec ("htpasswd -cB .htpasswd admin",$output,$return_var);
}

buildGlobal("gmrs"); buildGlobal("supermon");
print "Building global.ini  $call \n"; 

// buldFav("gmrs"); print "Building fav \n"; // not goin to use th
$rpi="/etc/asterisk/rpt.conf"; $changeall=false;
print "Insalling Connect and Disconnect logging into $rpi\n";
$fileEdit=$rpi;$search="connpgm=/usr/";$hide=false;edit_config("connpgm=/usr/local/sbin/supermon/smlogger 1");
$fileEdit=$rpi;$search="discpgm=/usr/";$hide=false;edit_config("discpgm=/usr/local/sbin/supermon/smlogger 0"); 


// gmrs
$fileEdit="$pathG/common.inc";
$search   = "TITLE_LOGGED";  // we dont use this varable
$formated = "#TITLE_LOGGED = 'GMRS Supermon Node Manager 6.2+ Mod';";
$formated = str_replace('#', '$', $formated); $formated = str_replace("'", '"', $formated);
$hide=false;edit_config($formated); 


// supermon directory (dont need to change)
//$fileEdit="$pathS/common.inc";
//$search   = "TITLE_NOT_LOGGED";
//$formated = "#TITLE_NOT_LOGGED = 'GMRS Supermon Node Manager';"; 
//$formated = str_replace('#', '$', $formated); $formated = str_replace("'", '"', $formated);
//$hide=false;edit_config($formated); 


$logger="/etc/asterisk/logger.conf";$changeall=false;
print "Adjusting settings to messages in $logger\n";
$fileEdit=$logger;$search= "messages =>";$hide=false;edit_config("messages => notice,warning,error");


print "Upgrading root directory of web server to modern 2023 standards.\n";
$file="$docRouteP/index.html";if (file_exists($file)) {unlink ($file);}
$file="$docRouteP/index.php" ;if (file_exists($file)) {unlink ($file);}


// install missing root redirect
$file="$docRouteP/index.php" ;
$fileOUT = fopen($file, "w");
$out = "<?php
header('Location: /gmrs/link.php?nodes=$node');
die();
?>";// <?php
fwrite ($fileOUT, $out);fclose ($fileOUT);




print"-----------------------------------------------------------
Requesting ast restart......";
exec ("astres.sh",$output,$return_var);  // Run restart
print "ok\n";
print"Your supermon is setup visit the url with a web browser $ip
=================================================================
One click supermon install finished.";

}
start_menu($in);
start("start");
}

//$MuteNet1,$MuteNet2,$MuteNet3

function muting($in){
global $Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$sleep,$changeall;

$displayMuteNet1="false";$displayMuteNet2="false"; $displayMuteNet3="false"; $displaySleep ="false";

if ($MuteNet1) {   $displayMuteNet1 ="true";}
if ($MuteNet2) {   $displayMuteNet2 ="true";}
if ($MuteNet3) {   $displayMuteNet3 ="true";}
if ($sleep)    {      $displaySleep ="true";}

print "
Automatic muting system for clock/alerts.
No more speaking during nets.
All times are your local time.

Roadkill TexasGMRS nets 
Wed net $Net1Start-$Net1Stop [$displayMuteNet1] Wind down wed
Sun net $Net2Start-$Net2Stop [$displayMuteNet2] Family fun night
Fri net $Net3Start-$Net3Stop [$displayMuteNet3] Friday Night 

Mute at night 1-6am [$displaySleep] sleep mode.  

Just press return to keep the current values.
";
$line = readline("Mute net1 wed y/n: ");
if ($line=="y"){$MuteNet1=true;}
if ($line=="n"){$MuteNet1=false;}

if($MuteNet1){
$line = readline("Start time 24hr $Net1Start:");
if ($line){$Net1Start=$line;}
$line = readline("Stop time 24hr $Net1Stop:");
if ($line){$Net1Stop=$line;}
}

$line = readline("Mute net2 sun y/n: ");
if ($line=="y"){$MuteNet2=true;}
if ($line=="n"){$MuteNet2=false;}

if($MuteNet2){
$line = readline("Start time 24hr $Net2Start:");
if ($line){$Net2Start=$line;}
$line = readline("Stop time 24hr $Net2Stop:");
if ($line){$Net2Stop=$line;}
}
$line = readline("Mute net3 fri y/n: ");
if ($line=="y"){$MuteNet3=true;}
if ($line=="n"){$MuteNet3=false;}

if($MuteNet3){
$line = readline("Start time 24hr $Net3Start:");
if ($line){$Net3Start=$line;}
$line = readline("Stop time 24hr $Net3Stop:");
if ($line){$Net3Stop=$line;}
 }


$line = readline("Mute at Night 1-6am y/n: ");
if ($line=="y"){$sleep=true;}
if ($line=="n"){$sleep=false;}

editmenu();
}


function hideIPboot($in){
global $hideIP;
$hideIPDisplay="false";if ($hideIP){$hideIPDisplay="true";}

print"
Hide the local IP at bootup. [$hideIPDisplay]
You will want to do this on a repeater or in a unsecure setting.
On a home node its likely ok to say the IP at boot up.
";
$line = readline("Set to t/f: ");
if ($line=="t"){$hideIP=true;}
if ($line=="f"){$hideIP=false;}
editmenu();
}
    
    
function bridge($in){                                             
global $bridgeCheck,$bridgeMonitor,$brokenBridge,$stripe;

$displaybridgeCheck  ="false";if ($bridgeCheck)  {$displaybridgeCheck  ="true";} 
$displaybridgeMonitor="false";if ($bridgeMonitor){$displaybridgeMonitor="true";}
$displaybrokenBridge ="false";if ($brokenBridge) {$displaybrokenBridge ="true";}
print "
$stripe
[$displaybridgeCheck] Automatic bridging detection with auto disconnect. If a bridge
is detected it will be stoped. Dont use if you normaly have more than 1 connection.
[$displaybridgeMonitor] Monitor bridging detection & notify you if others bridge. 
[$displaybrokenBridge] Look for a broken Bridge from TX to LA   
$stripe
";
$line = readline("[$displaybridgeCheck] Set Auto Bridging detect to t/f: ");
if ($line=="t"){$bridgeCheck=true;}
if ($line=="f"){$bridgeCheck=false;}


$line = readline("[$displaybridgeMonitor] Set Monitor bridging to t/f: ");
if ($line=="t"){$bridgeMonitor=true;}
if ($line=="f"){$bridgeMonitor=false;}

$line = readline("[$displaybrokenBridge] Set Broken Bridge t/f: ");
if ($line=="t"){$brokenBridge=true;}
if ($line=="f"){$brokenBridge=false;}


editmenu();
}



function debug($in){
global $debug,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayDebug="false";
if ($debug){        $displayDebug     ="true";}
print "
Debugging gives extra info..
Debug is set to [$displayDebug]
";
$line = readline("Set to t/f: ");
if ($line=="t"){$debug=true;}
if ($line=="f"){$debug=false;}
editmenu();
}

function setBurst($in){
global $burst,$call,$node;
$burstDisplay="off";if($burst){$burstDisplay=$burst;}
print "
MDC-1200 bursts can be sent on the local radio before the clock plays.
You can enter a node# call or something else. It does not transmit into the network.

Many MDC-1200 systems utilize the unit ID option. With each push-to-talk press,
the radio sends a data burst identifying the sending radio. Unit IDs are decoded
as unique hexadecimal four-digit numbers. Every radio would have a unique
four-digit ID.    [$burstDisplay]

 0) to turn off 
";
$line = readline("Change from $burstDisplay to: ");
if ($line) {$burst=$line;}
else {$burst="";}

editmenu();
}


function link_set($in){
global $LinkCheck;
print "
Link Check will notify you if the link drops. 
Select how often you want messages. 
LinkCheck:[$LinkCheck]

0 = off
1 = every 10 or 15 mn 
2 = once at the bottom of the hr. (Random around 30 min)
";
$line = readline("Change from $LinkCheck  to: ");
if($line >=0 or $line <=2){$LinkCheck=$line;}
editmenu();
}

function setnode($station){
global $beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false";
print "
Node1 is auto detected on install if you need to change this you can do so here

AutoDetect node:$AutoNode Node set to $node:

";
$line = readline("Node $node: ");
if($line){$node=$line;}
editmenu();

}

// Madis had to be removed To muh data on free option
// NEW Api or ambent API
function madis($station){
global $beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement;
global $ambientApiKey,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;

$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false";
print "
----------------------WEATHER APIs-----------------------------
We need the code for you local weather station. 

1) For NWS Find your local MADIS station code or local AIRPORT at 
   https://madis-data.ncep.noaa.gov/MadisSurface/
   NWS [$station]

2) If you own a Ambient weather station go to 
   https://ambientweather.net/account   
   and generate a APIKEY for your station.
   KEY [$ambientApiKey]  
   
3) reset and clear both keys.   

e) Edit menu
";

$stdin = fopen('php://stdin', 'r');
$yes   = false;

while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Weather Enter 1-2 E:_";
	$input = trim(fgets($stdin));
    if ($input == '1'){nws_edit("edit");}
    if ($input == '2'){nws_amb ("edit");}
    if ($input == '3'){$station="";$ambientApiKey="";madis("edit");}
	if ($input == 'e'){editmenu();}
    if ($input == ''){quit('EXIT');}
}
}

function nws_edit($in){
global $beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement;
global $ambientApiKey,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$line = readline("NWS Station $station:");
if ($line){$station = $line;}
}

function nws_amb($in){
global $beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement;
global $ambientApiKey,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$line = readline("Ambient weather station $ambientApiKey:");
if ($line){$ambientApiKey = $line;}
}


function level($level){
global $beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement;
global $testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;

$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false";
print "
When the time and temp runs how much detal do you want?
0= off 1=temp,2=cond 3=Dew 4=wind,hum,rain 5=Forcast  (Levels to speak)

";
$line = readline("Level $level: ");
$level = $line;
editmenu();
}

function zip($level){
global $zipcode;
$line = readline("Enter your ZipCode $zipcode: ");
$zipcode = $line;
editmenu();
}

function zip2($level){
global $zipcode;
$line = readline("Enter your ZipCode $zipcode: ");
$zipcode = $line;
location($zipcode);
}


function cpu($level){
global $beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false";
if ($reportAll)   {$displayReport   ="true";}
print "
 CPU Temp setup generates a report every 15min.
 
 HiTemp[$high] alarm.
 Hot   [$hot]  warning.
 Report Normal temps [$displayReport] for testing only
 Name of the node [$nodeName] (server,repeater,node,tower,temperature) 
 or any name in the sound_gsm_database. It will speak this name in alarms. 

";
$line = readline("HiTemp default 60: ");
if ($line>55){$high=$line;}

$line = readline("HotTemp default 50: ");
if ($line>49){$hot=$line;}

$line = readline("Report Normal temps y/n: ");
if ($line=="y"){$reportAll=true;}
else{$reportAll=false;}

$line = readline("Name (server,repeater,node,tower,temperature) : ");
if ($line){$nodeName=$line;}
else {$nodeName="server";}


editmenu();
}
function femaSet($in){
global $city,$state,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement;
global $parishCounty,$fema,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate,$tts,$autotts;
$femaDisplay= "off"      ;if ($parishCounty and $fema){$femaDisplay="true";}
print "
FEMA National Declared Emergency alerts. [$femaDisplay]
As part of the OpenFEMA initiative, FEMA is providing API based access to datasets.

These alerts have non standard words and phrases that are not yet in the database
and that I cant predict, so this module is a beta under construction.
 
TTS may be required so if you have a TTS key from www.voicerss.org be sure its entered.

This is a ongoing test because we wont likely see many alerts it will take some time to test this.
If you want to opt out use the erase option to erase the settings and turn it off..

 Parish or County :[$parishCounty] 
 State code :[$fema]  Your state:$state
 voicerss.org Text-to-speech KEY:[$tts]
 t) TTS KEY 
 c) Erase
 s) Setup 
 
 E) Edit Menu\n";
 
$stdin = fopen('php://stdin', 'r');
$yes   = false;
while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Enter C S E:_";
	$input = trim(fgets($stdin));
    if ($input == 'c'){femaSet2('set');}
    if ($input == 's'){femaSet3('set');}
    if ($input == 't'){ ttsSet2('set');}
    if ($input == 'm'){start_menu($in);start("start");}
    if ($input == 'e'){edit("edit");}
}

}

function femaSet3($in){
global $parishCounty,$fema,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate,$tts;
 $line = readline("Enter the Parish/County $parishCounty: ");
 if ($line){$parishCounty=$line;}
 $line = readline("Enter the State $fema: ");
 if ($line){$fema=strtoupper($line);} 
 femaSet($in);
} 

function femaSet2($in){
global $parishCounty,$fema,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate, $tts;
 $parishCounty="";$fema=""; 
 femaSet($in) ;
} 

function ttsSet2($in){
global $parishCounty,$fema,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate, $tts;
 $line = readline("What is your KEY $tts: ");
 if ($line){$tts=$line;} 
 femaSet($in) ;
} 


function location($in){
global $city,$state,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
print "
Your LAT/LON is required for the National Weather Service new forcast alert system.
The more accurate your location is the better tornado/storm reports you will get.
Setup will build a default based on node city state but you need to check it.

Use your phone or go to http://gps-coordinates.org

 1) Enter Lat/Lon  :[$lat]/[$lon] 
 2) Enter Zipcode  :[$zipcode]
 3) Look up Lat/Lon by ZIP code [$zipcode]
 4) Look up Zip for your city:[$city] State:[$state]
 B) Back to edit menu

 E) Exit\n";
 
$stdin = fopen('php://stdin', 'r');
$yes   = false;
while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Enter 1-2 B E:_";
	$input = trim(fgets($stdin));
    if ($input == '1'){locationEnter($station);}
    if ($input == '3'){lookupgps($zipcode);}
    if ($input == '2'){zip2($zipcode);}
    if ($input == '4'){lookupzip($city);location($in);}
    if ($input == 'b'){$yes= true;}
    if ($input == 'm'){$yes= true;}
    if ($input == 'q'){$yes= true;}
	if ($input == 'e'){quit('EXIT');}
}
editmenu();
}

function locationEnter($in){
global $lat,$lon;
$line = readline("Lat: ");
if($line){$lat=$line;}
$line = readline("Lon: ");
if($line){$lon=$line;}
location();
}

function lsnode($in){
global $DisplayNodes;
print "

Node Scan is my own version of lsnodes written from scratch in php with a better display
it finds all nodes connected to the HUB and finds all the nodes on other hubs connected
to that hub. 
So basicaly your seeing a static status page of all the nodes connected to the HUB.
It is static you have to reload it to update. Keeping cpu cycles low is important.

You have the choice of displaying this at the botom of the page.


\n";
$line = readline("Display nodes on supermon page y/n: ");
if ($line=="y"){$DisplayNodes=true;}
if ($line=="n"){$DisplayNodes=false;}
editmenu();
}
 








function doc($in){
global $beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate,$stripe;
$i=0;
$file="$path/readme.txt";
print "
 Loading the readme.txt file
$stripe
";
$fileIN= file($file);
foreach($fileIN as $line){
print $line; $i++ ;
if ($i >42){$line = readline(" ");$i=0;}
}
print "$stripe
End of File
";
$line = readline("Hit Return for menu");
start_menu($in);start("start");
}

function warn($skywarn){
global $beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false"; 
if ($sayWatch)    {$displayWatch =   "true";}
if ($sayWarn)     {$displayWarn     ="true";}
if ($sayAdvisory) {$displayAdvisory ="true";}
if ($sayStatement){$displayStatement="true";}

print "
Cap Warn uses Common Alerting Protocol (CAP) from the NWS
The new API needs your LAT/LON  [$lat/$lon]


Customise what reports you want
SayWarning   true <hard coded>
SayWatch     $displayWatch
SayAdvisory  $displayAdvisory
SayStatement $displayStatement 
 
";
$line = readline("Say Watches y/n: ");
if ($line=="y"){$sayWatch=true;}
if ($line=="n"){$sayWatch=false;}

$line = readline("Say Advisory y/n: ");
if ($line=="y"){$sayAdvisory=true;}
if ($line=="n"){$sayAdvisory=false;}

$line = readline("Say Statement y/n: ");
if ($line=="y"){$sayStatement=true;}
if ($line=="n"){$sayStatement=false;}
editmenu();
}




function load($in){
global $parishCounty,$fema,$startUp,$startUpNode,$burst,$DisplayNodes,$name,$city,$state,$phpzone,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start;
global $Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$bridgeCheck,$autotts,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$LinkCheck,$beta,$saveDate,$path,$hideIP;
global $idType,$ambientApiKey,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog;
global $inTone,$outToneL,$outToneU,$bridgeMonitor,$banner,$banner,$Fheader,$brokenBridge,$NodePassword;
  $Fheader="";
  
if (is_readable("$path/setup.txt")) {
   $fileIN= file("$path/setup.txt");
   
   foreach($fileIN as $line){
    $u = explode(",",$line);
           $Fheader =  $u[0];// now used as a protection header ="MMSOFTWARE"
             $node  =  $u[1];
          $station  =  $u[2];
             $level =  $u[3];
         $zipcode   =  $u[4];
         $IconBlock =  $u[5];
               $lat =  $u[6];
               $lon =  $u[7];
           $sayWarn =  $u[8];
          $sayWatch =  $u[9];
       $sayAdvisory = $u[10];
      $sayStatement = $u[11];
        $sleep      = $u[12];
              $high = $u[13]; 
               $hot = $u[14];
          $nodeName = $u[15];
         $reportAll = $u[16];
          $saveDate = $u[17];
         $LinkCheck = $u[18]; 
              $beta = $u[19];
          $watchdog = $u[20];
             $debug = $u[21];
               $tts = $u[22];  
       $bridgeCheck = $u[23]; 
       $MuteNet1    = $u[24]; 
       $MuteNet2    = $u[25];
       $MuteNet3    = $u[26];
       $Net1Start   = $u[27];
       $Net1Stop    = $u[28];
       $Net2Start   = $u[29];
       $Net2Stop    = $u[30]; 
       $Net3Start   = $u[31];
       $Net3Stop    = $u[32];
       $DisplayNodes= $u[33];
       $burst       = $u[34];
       $startUp     = $u[35];
       $startUpNode = $u[36]; 
       $parishCounty= $u[37];
       $fema        = $u[38];
      $ambientApiKey= $u[39];
             $hideIP= $u[40];
             $idType= $u[41];
             $inTone= $u[42];
           $outToneL= $u[43];
           $outToneU= $u[44];
      $bridgeMonitor= $u[45];  
             $banner= $u[46]; 
      $brokenBridge = $u[47];
      $NodePassword = $u[48];                
    }
    
if(!$tts and $autotts){$tts=$autotts;}    
    
}


// If its missing create a defult
else {
// set default
$status ="Building default settings";save_task_log ($status);
print "$datum $status\n";

$in="";
// https://madis-data.ncep.noaa.gov/MadisSurface/
$station="KAEX";$level = 3 ;  // Alexandria International Airport (AEX)
$zipcode="";lookupzip ($in);// get a zip from city state
$lat ="31.3273"; $lon="-92.5485"; // Alexandria International Airport	31.3273717,-92.5485558
lookupgps($in); // make one from zip or just use default


// Mute the time & Talking during the nets 18=6pm 19=7pm 20=8pm 21=9pm
// Set the defaults for cen time 24hrs

$Net1Start= 19; $Net1Stop= 20;$MuteNet1 = false;// Wed  
$Net2Start= 18; $Net2Stop= 19;$MuteNet2 = false;// Sun  
$Net3Start= 20; $Net3Stop= 21;$MuteNet3 = false;// Friday at 8 PM

// if cen time zone turn on net muting
if ($phpzone=="America/Chicago"){ $MuteNet1 = false;$MuteNet2 = true;$MuteNet3 = true;}

//Time zones across United States
//Eastern Standard Time (EST)Washington
//Central Standard Time (CST)Chicago
//Mountain Standard Time (MST)Denver
//Mountain Standard Time (MST)Phoenix
//Pacific Standard Time (PST)Los Angeles
//Alaska Standard Time (AKST)Anchorage
//Hawaii-Aleutian Standard Time (HAST)Honolulu
$IconBlock= true; $skywarn ="";$reportAll = false;$nodeName = "server";$high=60;$hot=50;
$sleep=true;$tts=$autotts; $DisplayNodes=false;
$sayWarn=true;$sayWatch=true;$sayAdvisory=true;$sayStatement =true;
$node = $AutoNode;$beta = false; $debug=false; $watchdog = 10; 
$burst=""; $LinkCheck=false;$startUp=false;$startUpNode = "0";
$parishCounty= "";$fema = "";if($state){$fema=$state;}
$ambientApiKey=""; $hideIP=""; $idType =0;$banner="back-default";
$inTone=true;$outToneL=true;$outToneU=true;$bridgeMonitor=true;// Default to true
$bridgeCheck = true;$brokenBridge=false; $NodePassword = "";  

save ("save");
 }
}

function save($in){
global $parishCounty,$fema,$startUp,$startUpNode,$burst,$DisplayNodes,$name,$city,$state,$phpzone,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start;
global $Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$bridgeCheck,$autotts,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$LinkCheck,$beta,$saveDate,$path,$hideIP;
global $idType,$ambientApiKey,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog;
global $inTone,$outToneL,$outToneU,$bridgeMonitor,$banner,$Fheader,$brokenBridge,$NodePassword;


$datum = date('m-d-Y-H:i:s');
$path4 = "$path/backup";if(!is_dir($path4)){ mkdir($path4, 0755);}
$file = "$path/setup.txt";$dow = date('w');$fileBU = "$path4/setup.txt.$dow";
if (file_exists($file)){
if (file_exists($fileBU)){unlink($fileBU);}
copy($file, $fileBU); $status ="Backup settings to $fileBU";save_task_log ($status); 
print"$datum $status\n";
} 

$fileOUT = fopen("$path/setup.txt", "w");
$status ="Writing settings";save_task_log ($status);
print "$datum $status\n";

// fix varables problem true/false for the webserver (Get rid of blank varables)
if(!$IconBlock){$IconBlock=0;}//5
if(!$sayWarn){$sayWarn=0;}//8
if(!$sayWatch){$sayWatch=0;}//9
if(!$sayAdvisory){$sayAdvisory=0;}//10
if(!$sayStatement){$sayStatement=0;}//11
if(!$sleep){$sleep=0;}//12
if(!$reportAll){$reportAll=0;}//16 
if(!$LinkCheck){$LinkCheck=0;}//18 
if(!$beta){$beta=0;}  // 19
if(!$debug){$debug=0;} // 23
if(!$bridgeCheck){$bridgeCheck=0;} //24        
if(!$MuteNet1){$MuteNet1=0;} //24 
if(!$MuteNet2){$MuteNet2=0;} //25
if(!$MuteNet3){$MuteNet3=0;} //26
if(!$DisplayNodes){$DisplayNodes=0;} //33
if(!$startUp){$startUp=0;} //35
if(!$hideIP){$hideIP=0;} //40
if(!$idType){$idType=0;} //41
if(!$bridgeMonitor){$bridgeMonitor=0;} //45
if(!$banner){$banner="back-default";}// fix a upgrade problem
if(!$brokenBridge){$brokenBridge=0;} //47


fwrite ($fileOUT, "MMSOFTWARE,$node,$station,$level,$zipcode,$IconBlock,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$sleep,$high,$hot,$nodeName,$reportAll,$datum,$LinkCheck,$beta,$watchdog,$debug,$tts,$bridgeCheck,$MuteNet1,$MuteNet2,$MuteNet3,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$DisplayNodes,$burst,$startUp,$startUpNode,$parishCounty,$fema,$ambientApiKey,$hideIP,$idType,$inTone,$outToneL,$outToneU,$bridgeMonitor,$banner,$brokenBridge,$NodePassword,,,,,,,,");
fclose ($fileOUT);
}








function create_node ($file){
global $file,$path;
// keep this file up to date
$file ="/usr/local/etc/allstar_node_info.conf"; $autotts=""; 
//copy($file, "$path/allstar_node_info.conf"); we no longer need this
$fileIN= file($file);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$line = str_replace('"', "", $line);
$pos = strpos("-$line", 'NODE1=');
if ($pos){$u= explode("=",$line);
$node=$u[1];}
$pos2 = strpos("-$line", 'STNCALL='); 
if ($pos2){$u= explode("=",$line);
$call=$u[1];}
}
// Get any tss key if exists   RESERVED for Future use
$file ="/usr/local/etc/tts.conf";
$fileIN= file($file);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$line = str_replace('"', "", $line);
$pos = strpos("-$line", 'tts_key=');
if ($pos){$u= explode("=",$line);
$autotts=$u[1];}
}
$file= "$path/mm-node.txt";// This will be the AutoNode varable
$fileOUT = fopen($file, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$node,$call,$autotts, , ,");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
}


// anti Bridging system Check installed.
function check_bridge_installed ($status){
global $search,$fileEdit,$ok,$in,$changeall;
$fileEdit ="/usr/local/sbin/sm-support/smlogger_background.sh";
$fileBu = "$fileEdit-.bak"; 

if (!file_exists($fileBu)){
 print"Installing anti Bridiging system\n";

$search='echo $LOGINFO'; 
$in="echo #LOGINFO |sed 's/ +/ /g' >> #LOGFILE

php /etc/asterisk/local/mm-software/connect.php #LOGINFO

";
$in = str_replace('#', '$', $in);
$hide=false;edit_config($in);// $search=search for line  $in=change to $fileEdit=file   out $ok=true

exec("sudo chmod +x /usr/local/sbin/sm-support/smlogger_background.sh",$output,$return_var); 
} 

$in=""; $search=""; $fileEdit ="";
}

// v2.1  
function save_task_log ($status){
global $basename,$path,$error,$datum,$logRotate;

// $logRotate = 40000;// size to rotate at set at top

$datum  = date('m-d-Y H:i:s');
if(!is_dir("$path/logs/")){ mkdir("$path/logs/", 0755);}
chdir("$path/logs");
$log="$path/logs/log.txt";
$log2="$path/logs/log2.txt"; 


// log rotation system 
if (is_readable($log)) {
   $size= filesize($log);
   if ($size > $logRotate){
    if (file_exists($log2)) {unlink ($log2);}
    rename ($log, $log2);
    if (file_exists($log)) {print "error in log rotation";}
   }
}
if (!file_exists($log)) {$fileOUT = fopen($log, 'w') ;flock ($fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,Start log,$basename,,,\r\n");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);}

if (is_writeable($log)) {
 $fileOUT = fopen($log, 'a+') ;flock ($fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,$status,$basename,,,\r\n");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
}
else { 
$log="/tmp/log.txt";// fixes supermon permissions. This is a temp fix
$fileOUT = fopen($log, 'a+') ;flock ($fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,$status,$basename,,,\r\n");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
}

}


function dvswitch($in){
global $node,$call,$changeall;
print " DV Switch easy installer. 

This Installs DV Switch but you will still need to open a port
on your router. Recomend you test your phone on your LAN and get that working
first before you try remote connections.  

In order for this to work with the anti bridging system you must use your
ID [$call] as the caller ID so it will be ignored and not treated as a bridge.
Using a ID other than the one listed above will create a bridge alarm. 

Press (i) to install DV Switch
";

$a = readline('Enter your command: ');

if ($a == "i"){

$password = getRandomString(6);
print "Using random password of [$password] on IAX connection.\n";
edit_iax_DV($password);
edit_extensions($password);

$localIP = getHostByName(getHostName());
   $myip = exec("/bin/wget -t 1 -T 3 -q -O- http://checkip.dyndns.org:8245 |/bin/cut -d':' -f2 |/bin/cut -d' ' -f2 |/bin/cut -d'<' -f1");

// This is the local machine's external IP address
$port = find_port ("port");

print " Thats it DV-Switch is installed.
Setup DV SWitch APP as listed here.

Protocol IAX2
Hostname $myip  or on a LAN $localIP
Port     $port
Password $password
CallerID $call 
Node     $node

";
}
}


function edit_extensions($in){ 
global $search,$path,$fileEdit,$ok,$node,$password,$changeall;

$ok=false;$line=""; $search= "[dvswitch-iaxrpt]";
$fileEdit= "/etc/asterisk/extensions.conf";
if (file_exists($fileEdit)){
$fileBu = "$fileEdit-.bak"; if (!file_exists($fileBu)){copy($fileEdit,$fileBu);} // This creates a orginal backup
$tmpFile="$fileEdit-new.txt"; 

$fileIN= file($fileEdit);
$fileOUT = fopen($tmpFile, "w") or die ("Error $tmpFile Write falure");
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", $search); 
if ($pos>=1){
$formated="[dvswitch-iaxrpt]  
exten => $node,1,Answer
exten => $node,n,Playback,rpt/node
exten => $node,n,Playback,digits/1
exten => $node,n,Playback,digits/9
exten => $node,n,Playback,digits/9
exten => $node,n,Playback,digits/8
exten => $node,n,Set(CALLERID(num)=0)
exten => $node,n,Rpt,2955|P|#{CALLERID(name)} 
"; $formated = str_replace('#', '$', $formated);

$ok=true;fwrite ($fileOUT, "$formated\n"); break;
}  
fwrite ($fileOUT, "$line\n");
}

if (!$ok){ $formated="[dvswitch-iaxrpt] 
exten => $node,1,Answer
exten => $node,n,Playback,rpt/node
exten => $node,n,Playback,digits/1
exten => $node,n,Playback,digits/9
exten => $node,n,Playback,digits/9
exten => $node,n,Playback,digits/8
exten => $node,n,Set(CALLERID(num)=0)
exten => $node,n,Rpt,2955|P|#{CALLERID(name)}
"; 
fwrite ($fileOUT, "$formated\n");
}


fclose ($fileOUT);
// if ok then we found it

if (file_exists($tmpFile)){ unlink($fileEdit);} 
rename ($tmpFile, $fileEdit); 

save_task_log ("Edit $fileEdit search:$search");


 


// try to prevent stray data
$fileEdit="";$search="";print"\n";
}
}

// THE Main IAX editor for DVSWITCH 
function edit_iax_DV($in){ 
global $search,$path,$fileEdit,$ok,$hide,$node,$password;

$ok=false;$line=""; 
$fileEdit= "/etc/asterisk/iax.conf";

if (file_exists($fileEdit)){
$fileBu = "$fileEdit-.bak"; if (!file_exists($fileBu)){copy($fileEdit,$fileBu);} // This creates a orginal backup
$tmpFile= "$fileEdit-new.txt"; 
$fileIN= file($fileEdit);
$fileOUT = fopen($tmpFile, "w") or die ("Error $tmpFile Write falure");

foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", "[DVSWITCH]"); if ($pos){$ok=true; break;}// if found stop...  
fwrite ($fileOUT, "$line\n");
}
// we are stoping here and adding our info. If it was already there we just rewrite it.
// This requires nothing be added under this or it will be erased.

$line="[DVSWITCH]
type=friend
context=dvswitch-iaxrpt
host=dynamic
auth=md5
secret=$password
disallow=all
allow=ulaw
transfer=no
calltokenoptional=0.0.0.0/0.0.0.0
requirecalltoken=no

";
fwrite ($fileOUT, "$line\n");
}
fclose ($fileOUT);

// now if we added we swap it in if it already existed we just stop.
// This needs to be changed so it can overwrite but not for now,.

if (file_exists($tmpFile)){ unlink($fileEdit);} 
rename ($tmpFile, $fileEdit); 
save_task_log ("Edit $fileEdit search:$search");


  


// try to prevent stray data It keeps showing up with left overs...
$fileEdit="";$search="";print"\n";
}



//this is my own editor to search and replace
// v2.0 7/28/2023
// v2.1 9/20/2023 Only save the first found line
// $search=search for line  $in=change to $fileEdit=file   out $ok=true 
// $hide=true; $changeall=true;
function edit_config($in){ 
global $search,$path,$fileEdit,$ok,$hide,$changeall;

if(!$hide){print "Search for $search in file:$fileEdit ";}
$ok=false;$line="";
if (file_exists($fileEdit)){
$fileBu = "$fileEdit-.bak"; if (!file_exists($fileBu)){copy($fileEdit,$fileBu);} // This creates a orginal backup

// create a backup about once a day
$fileBu = "$fileEdit-1.bak"; 
if (file_exists($fileBu)){
 $ft = time()-filemtime($fileBu);
 if ($ft < 24 * 3600){  unlink ($fileBu);}
 } 
if (!file_exists($fileBu)){copy($fileEdit,$fileBu);} // working backup  $fileBu = "$fileEdit-1.bak"; 


if(!file_exists($fileBu)and !$hide){ print "Unable to BackUP.";}
$tmpFile="$fileEdit-new.txt"; // keep in the same dir so we wont have to copy

$fileIN= file($fileEdit);
$fileOUT = fopen($tmpFile, "w") or die ("Error $tmpFile Write falure");
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", $search); 
if ($pos>=1){ 


if (!$ok){
$line=$in;$ok=true;
if(!$hide){print"$line Replacing with $in <ok>"; } // Replace the found line with a new one.
 }// only change the first found line
 
if ($ok and $changeall) {
$line=$in;$ok=true; // replace all of the found lines
if(!$hide){print"$line Replacing with $in <ok>"; } // Replace the found line with a new one.
} 
 
 
}// pos  
fwrite ($fileOUT, "$line\n");
}

fclose ($fileOUT);
// if ok then we found it
if ($ok){
 if (file_exists($tmpFile)){ unlink($fileEdit);} 
 rename ($tmpFile, $fileEdit); 
 save_task_log ("Edit $fileEdit search:$search");
} // rename
else{if(!$hide){print "not found";} }
   
} //file exist
// try to prevent stray data
save_task_log ("Edit $fileEdit ($in)");
$fileEdit="";$search="";print"\n";
}

function search_config($out){ 
global $search,$path,$fileEdit,$ok,$out,$hide;

if(!$hide){print "Search for $search in file:$fileEdit ";}
$ok=false;$line="";
if (file_exists($fileEdit)){
$fileIN= file($fileEdit);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
//print "$line\n";
$pos = strpos("-$line", $search);  
if ($pos>=1){
$out=$line;//print "$line - $search - $out\n"; 
$ok=true;if(!$hide){print"found $out\n";}
break;}
 }
}// end if exists
else {print"File Not Found $fileEdit\n";}

if(!$hide){
 if (!$ok){print"not found $search\n";}
 }
}


// global.inc'
function buildGlobal($in){
global $zipcode,$path,$file,$tmpFile,$ok,$password,$node,$call,$name,$location,$pathG;

$globalfile = "/srv/http/gmrs/global.php";
if ($in=="gmrs"){    $globalfile = "/srv/http/gmrs/global.php";     } 
if ($in=="supermon"){$globalfile = "/srv/http/supermon/global.inc"; } 


$file = $globalfile;
$fileOUT = fopen($file, "w") or die ("Error $file Write falure\n");  // 
// 21600 = 6 hrs 3600 = 1 hr  1320 = 22 min
$formated="
<?php
#CALL = '$call';
#NAME = '$name';
#LOCATION = '$location';
#TITLE2 = 'GMRS Live Node ';
#TITLE3 = 'System Node Manager';
#BACKGROUND = 'background.jpg';
#BACKGROUND_COLOR = 'blue';
#BACKGROUND_HEIGHT = '124px';
#REFRESH_DELAY = '1320';
#SHOW_COREDUMPS = 'yes';
#LOCALZIP = '$zipcode';
#MAINTAINER = '';
?>
";//  <?php
$formated = str_replace("'", '"', $formated);
$formated = str_replace('#', '$', $formated);
fwrite ($fileOUT, $formated);
fclose ($fileOUT);
print "saving $globalfile \n";
save_task_log ("$file saved");
 }


// Test that rc.local does not include AUTOSKY 
function rcLocal($in){
global $file,$ok,$search,$hide,$fileEdit,$in;
$file = "/etc/rc.local"; $fileBU="/etc/rc.local.bak";

$hide=true;$fileEdit=$file;$search="AUTOSKY";search_config("null");// Test for AUTOSKY and remove

if($ok){
$out="Removing AUTOSKY from $file";save_task_log ($out);print" $out\n";
if (!file_exists($fileBU)){copy($file, $fileBU);}
unlink($file);

$formated="
#!/bin/bash
#
# rc.local file

# Starts Allstar 

echo -1> /proc/sys/kernel/sched_rt_runtime_us

/usr/local/etc/rc.allstar 

exit 0
";

$fileOUT = fopen($file, "w") or die ("Error $file Write falure\n");  
fwrite ($fileOUT, $formated);fclose ($fileOUT);

  if (!file_exists($file)){
   if (file_exists($fileBU)){ copy($fileBU, $file);print"Reinstalling $file from BAK\n";}
  }
 }
//else {print"rc.local verified} 
$file="";
}







// build a password
function getRandomString($n){
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';

    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }
    save_task_log ("IAX password $randomString");
    return $randomString;
}



// remove from chron
function unSetcron($in){
global $search,$node1,$path;
print"restoring cron ";
 
// install the backup

$file = "$path/cron-orginal.txt";
if (file_exists($file)){exec ("crontab $file",$output,$return_var);print"from backup";}
else{
print"from default archive";
$replace="# Do not remove the following line
# required for lsnodes and allmon
15 03 * * * cd /usr/local/sbin; ./astdb.php cron
00 * * * * (source /usr/local/etc/allstar.env ; /usr/bin/nice -19 /usr/bin/perl /usr/local/sbin/saytime.pl \$NODE1 > /dev/null)
";

$fileOUT = fopen($file, "w");fwrite ($fileOUT, $replace);fclose ($fileOUT);
exec ("crontab $file",$output,$return_var);
}
print "ok\n";
$tmpFile = "$path/cron-new.txt"; if (file_exists($tmpFile)){ unlink($tmpFile); }
$file = "$path/cron-orginal.txt";if (file_exists($file)){ unlink($file); }  // this may fail if permissions are wrong.
}

// sets up cron and removes old scripts.
function setUpcron($in){
global $fileEdit,$search,$path;
print "Installing Cron ";
// make a backup for uninstall
$file = "$path/cron-orginal.txt"; if (!file_exists($file)){exec ("crontab -l > $file",$output,$return_var);print"[made backup]";}
$file = "$path/cron.txt";

if (file_exists($file)){exec ("crontab $file",$output,$return_var);print" using[cron.txt] ";}
else{
$out="# GMRS Node Manager
# nodelist processor replaces astdb.php
2 2-4 * * * php /etc/asterisk/local/mm-software/nodelist_process.php cron >/dev/null
00 * * * * php /etc/asterisk/local/mm-software/hourly.php >/dev/null
*/13 * * * * php /etc/asterisk/local/mm-software/odd_min.php >/dev/null
59 * * * * /usr/local/sbin/trimlog.sh /var/log/asterisk/messages 1000
";
$file = "$path/cron.txt"; 
$fileOUT = fopen($file, "w");fwrite ($fileOUT, $out);fclose ($fileOUT);
print" using [memory] repo was missing ";
exec ("crontab $file",$output,$return_var);
}
print " <OK>\n";

//stop the looping script from being in memory
$fileEdit="/etc/rc.local"; $search="AutoSky";$hide=true;edit_config("#");



 
}
 
function c64($in){
print"



        **** COMODORE 64 BASIC V2 **** 
    64K RAM SYSTEM  38911 BASIC BYTES FREE
READY.
";
}

function lookupgps($in){
global $lat,$lon,$zipcode,$city,$state;
// This key is licensed to me do not reuse in anything else.
// Get your own.
$api="d8e8c050-2d0c-11ee-86e8-a9d406a2a91b";
$domain ="app.zipcodebase.com";
$datum   = date('m-d-Y H:i:s');
print "$datum Polling $domain $zipcode WAIT!>--";
$mtime = microtime(); $mtime = explode(" ",$mtime); $mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;

$attime = gmdate('YmdHi');
$url = "api/v1/search?apikey=$api&codes=$zipcode&country=US";

$options = array(
    'http'=>array(
        'timeout' => 30,  
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Content-Type: application/json\r\n".
                  "User-Agent: Allstar Node lagmrs.com \r\n" 
));
$context = stream_context_create($options);
$html = @file_get_contents("http://$domain/$url"); 
$file ="/tmp/zip-to-geo.xml";
if(file_exists($file)){unlink($file);}
//$json = json_decode($html);
$html = str_replace('"', "", $html);
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"https://$domain/$url\n $html ");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
$mtime = microtime(); $mtime = explode(" ",$mtime); $mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);



$u = explode(",",$html);  // latitude:31.74500000,longitude:-92.39520000
$uLat = explode(":",$u[4]) ; $uLon = explode(":",$u[5]);
$uCity = explode(":",$u[6]); $uState = explode(":",$u[7]);

$city="";$state="";
if ($uCity[0]=="city"){$city=$uCity[1];print"ok $poll_time sec ($city "; }
if ($uState[0]=="state"){$state=$uState[1];print"$state)\n"; }

if ($uLat[0]=="latitude"){print"$datum";$uLat[1]=round($uLat[1],4);print " [$uLat[1]/";$lat=$uLat[1];}
if ($uLon[0]=="longitude"){$uLon[1]=round($uLon[1],4);print "$uLon[1]]\n";$lon=$uLon[1];}
else{print"ERROR\n";}

}


function lookupzip ($in){
global $lat,$lon,$zipcode,$city,$state,$path;

if (!$state){return;}

$stateName="";
$input= file("$path/states.csv");
//$state= trim($state) ; $state  = str_replace("\n","",$state);
foreach($input as $line){ 
$line  = str_replace("\n","",$line);
$u = explode(",",$line);
$u[1] = str_replace(" ","",$u[1]);
//$test1 = strtoupper($u[1]);
if ($u[1]==$state){print"*";$stateName=$u[0];break;}
 
}
if(!$stateName){print "error in database $state";$stateName=$state;}



// This key is licensed to me do not reuse in anything else.
// Get your own.
$api="d8e8c050-2d0c-11ee-86e8-a9d406a2a91b";
$domain ="app.zipcodebase.com";
$datum   = date('m-d-Y H:i:s');
print "$datum Polling $domain $stateName WAIT!>-- ";
$mtime = microtime(); $mtime = explode(" ",$mtime); $mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
//https://app.zipcodebase.com/api/v1/code/city?apikey=d8e8c050-2d0c-11ee-86e8-a9d406a2a91b&city=Amsterdam&state_name=Noord-Holland&country=nl
$attime = gmdate('YmdHi');
$url = "api/v1/code/city?apikey=$api&city=$city&state_name=$stateName&country=US";

$options = array(
    'http'=>array(
        'timeout' => 30,  
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Content-Type: application/json\r\n".
                  "User-Agent: Allstar Node lagmrs.com \r\n" 
));
$context = stream_context_create($options);
$html = @file_get_contents("http://$domain/$url"); 
$file ="/tmp/city-to-zip.xml";
if(file_exists($file)){unlink($file);}
//$json = json_decode($html);
$html = str_replace('"', "", $html);$html = str_replace('[', "", $html); $html = str_replace(']', "", $html); $html = str_replace('}', "", $html); $html = str_replace('{', "", $html);
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"https://$domain/$url\n $html ");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
$mtime = microtime(); $mtime = explode(" ",$mtime); $mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
$u  = explode(":",$html);  
if (isset($u[5])){$zipcode = $u[5];print "$zipcode <ok>\n";} 
else{print "<error>";}

}

function  setOurCall($in){
global $file1,$call,$node,$path,$datum,$soundDbGsm;;
$action="";$file1=""; $datum = date('m-d-Y H:i:s');
include_once ("$path/sound_db.php");  
unset ($soundDbWav);// not using these
unset ($soundDbUlaw);
$test =  strtolower($call);
$oh=false;
$x = (string)$test;
for($i=0;$i<strlen($x);$i++)
{check_gsm_db ($x[$i]);$action = "$action $file1";} //print"$file1\n";

$file ="/var/lib/asterisk/sounds/rpt/nodenames/$node.ul"; 
exec ("sox $action $file",$output,$return_var);
print "$datum Creating soundfile $file\n";
unset ($soundDbGsm);// save memor clear

}

function setStartup($in){
global $hide,$startUp,$startUpNode,$search,$path,$fileEdit,$ok,$hide,$changeall;

$displaystartUp ="false";if ($startUp){$displaystartUp ="true";} 

print "
 On start up connect to node:[$startUpNode]  $displaystartUp\n";
 
$line = readline("Enter Y or N: ");
if ($line=="y"){
$startUp=true;
$line = readline("Connect to Node:$startUpNode ");
if ($line<>""){$startUpNode=$line;}

//startup_macro = *731195
//				; Macro to run at startup (optional)
//startup_macro_delay=80
//				; Time in seconds to wait before executing
//				; the startup macro
 

print "Saving Connect to $startUpNode on start\n";
$rpi="/etc/asterisk/rpt.conf"; $hide=true; $changeall=false;
$fileEdit=$rpi;$search="startup_macro_delay";edit_config("startup_macro_delay=90");  //  dns updates
$fileEdit=$rpi;$search="startup_macro";      edit_config("startup_macro = *73$startUpNode");
}

if ($line=="n"){
$startUp=false;
print "Saving Disable startup\n";
$rpi="/etc/asterisk/rpt.conf"; $hide=true; $changeall=false;
$fileEdit=$rpi;$search="startup_macro_delay";edit_config(";startup_macro_delay=90");
$fileEdit=$rpi;$search="startup_macro";      edit_config(";startup_macro = *73$startUpNode");
}
editmenu();
}

// $inTone,$outToneL,$outToneU;
function toneSetup($in){
global $stripe,$burst,$idType,$ok,$fileEdit,$search,$hide,$call;
global $inTone,$outToneL,$outToneU,$changeall;

//$inTone=true;$outToneL=true;$outToneU=true;// Default to true

$out="Disabled";$displayT=$out;$displayTL=$out;$displayTU=$out;
$out="Enabled";
if ($inTone) {$displayT =$out;}     
if ($outToneL){$displayTL=$out;}
if ($outToneU){$displayTU=$out;}

print "
$stripe
Courtesy Tones setup menu

 1) Incoming tone [$displayT]
 2) Outgoing tone Linked [$displayTL]  
 3) Outgoing tone Unlinked [$displayTU]

 m) menu
 e) exit
";
$a = readline('Tones Enter cmd: 1 2 3 e _');

$rpi="/etc/asterisk/rpt.conf"; $hide=true;

//unlinkedct=ct2 ; Sent when not connected to another node
//remotect=ct3 ; Sent when remote base connected
//linkunkeyct=ct8 ; sent when a network user unkeys
//nounkeyct=0; Disable courtest tones (=1)
$changeall=false;
if ($a == "1"){
if ($inTone){
print " Disabling Incoming tone ";
$in=";linkunkeyct=ct8 ; sent when a network user unkeys - installed by node manager";
$fileEdit=$rpi;$search="linkunkeyct";edit_config($in);
if($ok){print " OK.\n";$inTone=false;}
else{print"Error\n";}
}
else {

print " Enabling Incoming tone ";
$in="linkunkeyct=ct8 ; sent when a network user unkeys - installed by node manager";
$fileEdit=$rpi;$search="linkunkeyct";edit_config($in);
if($ok){print " OK.\n";$inTone=true;}
else{print"Error\n";}
 }
}

if ($a == "2"){
if ($outToneL){
print " Disabling Outgoing Linked tone ";
$in=";remotect=ct3 ; Sent when remote base connected - installed by node manager";
$fileEdit=$rpi;$search="remotect";edit_config($in);
if($ok){print " OK.\n";$outToneL=false;}
else{print"Error\n";}
}
else {

print " Enabling Outgoing Linked tone ";
$in="remotect=ct3 ; Sent when remote base connected - installed by node manager";
$fileEdit=$rpi;$search="remotect";edit_config($in);
if($ok){print " OK.\n";$outToneL=true;}
else{print"Error\n";}
 }
}


if ($a == "3"){
if ($outToneU){
print " Disabling Outgoing Unlinked Linked tone ";
$in=";unlinkedct=ct2 ; Sent when not connected to another node - installed by node manager";
$fileEdit=$rpi;$search="unlinkedct";edit_config($in);
if($ok){print " OK.\n";$outToneU=false;}
else{print"Error\n";}
}
else {
print " Enabling Outgoing Unlinked Linked tone ";
$in="unlinkedct=ct2 ; Sent when not connected to another node - installed by node manager";
$fileEdit=$rpi;$search="unlinkedct";edit_config($in);
if($ok){print " OK.\n";$outToneU=true;}
else{print"Error\n";}
 }
}

if (!$inTone and !$outToneL and !$outToneU){
print " Disabling all courtest tones ";
$in="nounkeyct=1; Disable courtest tones (=1) - installed by node manager";
$fileEdit=$rpi;$search="nounkeyct";edit_config($in);
if($ok){print " OK.\n";}
else{print"Error\n";}
}
else {
// test that they are not disabled
$fileEdit=$rpi;$search="nounkeyct=0";search_config("null");
if(!$ok){
 print " Enabling Courtest tones ";
 $in="nounkeyct=0; Disable courtest tones (=1) - installed by node manager";
 $fileEdit=$rpi;$search="nounkeyct";edit_config($in);
 if($ok){print " OK.\n";}
 else{print"Error\n";}
 }
}



    if ($a == 'm'){start_menu($in);start("start");}
    if ($a == 'w'){save("save");}
	if ($a == 'e'){quit('EXIT');}
toneSetup($in);

}
function idSetup($in){
global $burst,$idType,$ok,$fileEdit,$search,$hide,$call,$changeall;

$call3 = substr($call, -3);
print "
=============================================================================
 ID is not required on GMRS but if you have local FRS traffic its recomended
 just to show that this is a repeater. Makes it sound more professional.
 
 
 Setup the local ID. [$idType] 
 0) no id
 1) [Voice/Morse] Voice ID fall back to morse [$call])
 2) [Morse] [$call]
 3) [Morse/ Short Morse]  Morse [$call] fall back to short morse [$call3]
 4) [Short Morse] [$call3]
 5) [MDC1200 burst] [$burst]
 6) [Voice/Short Morse] Voice ID fall back to short morse [$call3]  
 
 m) menu
 e) exit
";

$a = readline('Enter your command:[$idType] 0 1 2 e _');
$rpi="/etc/asterisk/rpt.conf"; $hide=true;$changeall=false;

if ($a >=0 and $a <=5){$idType=$a;

   if ($idType ==0 or $idType ==5){
   print " Setting option 0 OFF ";
   $in=";idtalkover =|iDE $call  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idtalkover";edit_config($in);
   $in=";idrecording=|iDE $call  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=|";edit_config($in);
   $in=";idrecording=/etc/asterisk/local/myid  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=/";edit_config($in);
   }
   if ($idType ==1){
   print " Setting option 1 Voice/Morse $call ";
   $in="idtalkover =|iDE $call  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idtalkover";edit_config($in);
   $in=";idrecording=|iDE $call  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=|";edit_config($in);
   $in="idrecording=/etc/asterisk/local/myid  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=/";edit_config($in);
   }
   if ($idType ==2){
   print " Setting option 2 Morse $call ";
   $in=";idtalkover =|iDE $call  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idtalkover";edit_config($in);
   $in="idrecording=|iDE $call  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=|";edit_config($in);
   $in=";idrecording=/etc/asterisk/local/myid  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=/";edit_config($in);
   }   
   if ($idType ==3){
   print " Setting option 3 Morse/Morse $call/$call3 ";
   $in="idtalkover =|iDE $call3  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idtalkover";edit_config($in);
   $in="idrecording=|iDE $call  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=|";edit_config($in);
   $in=";idrecording=/etc/asterisk/local/myid  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=/";edit_config($in);
   }

   if ($idType ==4){
   print " Setting option 4 Morse $call3 ";
   $in=";idtalkover =|iDE $call  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idtalkover";edit_config($in);
   $in="idrecording=|iDE $call3  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=|";edit_config($in);
   $in=";idrecording=/etc/asterisk/local/myid  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=/";edit_config($in);
  }
   if ($idType ==6){
   $in="idtalkover =|iDE $call3  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idtalkover";edit_config($in);
   $in=";idrecording=|iDE $call  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=|";edit_config($in);
   $in="idrecording=/etc/asterisk/local/myid  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=/";edit_config($in);
   }
  

if ($a == "5"){$idType=5; print " Setting option 5 MDC1200 burst";}
}
//save_task_log ("Edit ID Settings");

    if ($a == 'm'){start_menu($in);start("start");}
    if ($a == 'w'){save("save");}
	if ($a == 'e'){quit('EXIT');}
idSetup($in);

}


function checkSimplex($in){
global $ok,$fileEdit,$search,$hide,$changeall;
// install the custom macros but do it once

$rpi="/etc/asterisk/rpt.conf"; $hide=true;
$fileEdit=$rpi;$search="971=cop,21";search_config("null");

if($ok){print" Simplex Macros are already installed and active.\n";}

else{
print " Installing Simplex macros *971,*970,*973 
Must restart Asterisk server to activate them\n";

$hide=true; $changeall=false;
$in="915=cop,55                ; Parrot once if Parrot mode is disabled
971=cop,21                ; enable Parrot Mode
970=cop,22                ; disable Parrot Mode
973=cop,23                ; Parrot cleanup/flush
";
$fileEdit=$rpi;$search="915=cop,55";edit_config($in);
if($ok){print " OK installed.\n";}
else{
print" I am sorry a error has prevented the install\n\n";
  }
 }
}

function admin_sh_menu(){
global $release;
$file ="/usr/local/sbin/firsttime/adm01-shell.sh";
$file2="/usr/local/sbin/firsttime/mmsoftware.sh";  if (file_exists($file2)){unlink ($file2);}
$file3="/usr/local/sbin/firsttime/mmsoftware2.sh"; if (file_exists($file3)){unlink ($file3);}

                 
print " Built Admin menu $file2 "; copy($file, $file2);print "-";

//$coreVersion
$formated="#/!bin/bash
#MENUFT%055%Node Manager Setup Program Version:$release
";

$out='
$SON
reset

php /etc/asterisk/local/mm-software/setup.php

exit 0
';

$out = "$formated $out";


// overwrite with our menu.
$fileOUT = fopen($file2, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, $out);flock( $fileOUT, LOCK_UN );fclose ($fileOUT); print "-";
exec("sudo chmod +x $file2",$output,$return_var);
if (file_exists($file2)){print"<ok>\n";}
else{print"<Error>\n";}
 
print " Built Admin menu $file3 "; copy($file, $file3);print "-";
// build a second menu
$out='#/!bin/bash
#MENUFT%055%Say time and Weather 

$SON
reset

php /etc/asterisk/local/mm-software/weather_pws.php

exit 0
';
// overwrite with our menu.
$fileOUT = fopen($file3, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, $out);flock( $fileOUT, LOCK_UN );fclose ($fileOUT); print "-";
exec("sudo chmod +x $file3",$output,$return_var); 
if (file_exists($file3)){print"<ok>\n";}
else{print"<Error>\n";}

 
} 


?>
