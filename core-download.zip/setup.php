<?php
//  ------------------------------------------------------------
//  (c) 2023 by WRXB288 lagmrs.com all rights reserved
//
// Setup program  
//    
// !shebang doesnt work on node so using direct loading
// php setup.php
// -------------------------------------------------------------

// PHP is in UTC Get in sync with the PI
//
// Release notes
// v5.9 .htacces for supermon had wrong path fixed
// v6.2 changes to updater and supermon menus
// v6.4 Protection for production server, Simplex repeater option.
// v6.5 Changes so burst can do text and any legenth
// v6.7  bug in supermon install for allmon fixed     
// v6.8  added ambent weather key
// v6.9  startup connect delay increased    
// v7.0  Bug in global.php file creation. 

$ver="v7.0"; $release="10-24-2023";

$line =	exec('timedatectl | grep "Time zone"'); //       Time zone: America/Chicago (CDT, -0500)
$line = str_replace(" ", "", $line);
$pos1 = strpos($line, ':');$pos2 = strpos($line, '(');
if ($pos1){  $zone   = substr($line, $pos1+1, $pos2-$pos1-1); }
else {$zone="America/Chicago";}
define('TIMEZONE', $zone);
date_default_timezone_set(TIMEZONE);
$phpzone = date_default_timezone_get(); 

$basename=basename($_SERVER['PHP_SELF']);

$phpVersion= phpversion();

$logRotate = 50000;// size to rotate at

$in="";
$iax          = "/etc/asterisk/iax.conf";
$rpi          = "/etc/asterisk/rpt.conf";
$manager      = "/etc/asterisk/manager.conf";

$tmpFile      = "/tmp/temp.dat";
$logger       = "/etc/asterisk/logger.conf";

$path  = "/etc/asterisk/local/mm-software";
$pathS = "/srv/http/supermon";
$pathG = "/srv/http/gmrs";
$pathGA= "/srv/http/gmrs/admin"; 
$pathGE= "/srv/http/gmrs/edit";

$supermonPath = $pathG;
$allmon       = "$pathGA/allmon.ini"; // new secure path  
$favorites    = "$pathG/favorites.ini";
$global       = "$pathG/global.inc";

// automatic node setup
$file=""; $in="check";
create_node ($file);// testing create it everytime 

$file= "$path/mm-node.txt"; 
if(file_exists($file)){
$line = file_get_contents($file);
$u= explode(",",$line);
$AutoNode=$u[0];$call=$u[1];$autotts=$u[2];
}

$file= "$path/node-name.txt";// imported from nodelist 
$name="";$city="";$state="";
if(file_exists($file)){
$line = file_get_contents($file);
$u= explode(",",$line);
$name=$u[1];$city=$u[2];$state=$u[3];//1=node 4=call
}



// make sure cron was installed
$file = "$path/cron-orginal.txt"; if (!file_exists($file)){setUpcron("cron");}

include ("$path/check_reg.php");


load($in); 

find_port ($in);
$file ="/var/lib/asterisk/sounds/rpt/nodenames/$node.ul"; 
if (!file_exists($file)){setOurCall($node);}

include ("$path/tagline.php");// $tagline="";tagline($tagline);print "$tagline (Have many nice days.)";
include ("$path/setup_install.php");

c64($in);
reg_check ($in);
check_bridge_installed ($in); // double check its installed.
$file="";

$stripe="============================================================";
start_menu($in);
start("start");

function start($in){
global $port,$hide,$startUp,$startUpNode,$MuteNet1,$MuteNet2,$MuteNet3,$sleep,$call,$AutoNode,$stripe,$path,$node,$station,$level,$zipcode,$skywarn;
global $ambientApiKey,$parishCounty,$fema,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$search,$fileEdit,$ok;
 
$stdin = fopen('php://stdin', 'r');
$yes   = false;

while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Enter 1-2 E:_";
	$input = trim(fgets($stdin));
    if ($input == '1'){edit("edit");}
    if ($input == '2'){supermon("view");}
    if ($input == '3'){dvswitch("install");}
    
    if ($input == 'f'){reg_force("force");}
    if ($input == 'p'){port_reset("reset");}  
    if ($input == 'a'){admin_sh_menu("reinstall");}
    if ($input == 'd'){doc("view");}
    if ($input == 's'){simplex("view");}
     
    if($node<>2955){// protect the production server   
       if ($input == 'u'){install("I");quit('EXIT');}  // I gives install prompt. Force exit so setup.php can be updated.
       if ($input == 'x'){uninstall("x");}
     }  
	if ($input == 'e'){quit('EXIT');}
    if ($input == ''){quit('EXIT');}
}
}

function port_reset($in){
global $counter,$watchdog,$NotReg,$datum;

print"Resetting port to default [4569]
";
$newPort=4569;rotate_port("rotate");

start_menu($in);
}

function reg_force($in){
global $counter,$watchdog,$NotReg,$datum;

print"
AT&T Fixed Wireless (UVERSE)routers may work for days but sudenly start blocking your port.
Hotspots may do the same thing. 

Success rate for me is 100%. Your milage may vary. 
This is only for the following problem.
Your Router, Gateway, Modem,phone,hotspot or ISP Corrupts your open port so
it cant reach the reg server. 
I fix this by rotating the port# This forces a new path to the server.
Normaly registration is restored in a few seconds. 

Note: Not compatable with IAX client or DVSWITCH they wont be able to reconnect when the port changes.

Watchdog can be set to run this fix automaticaly. 
";
reg_check ($in);
if($NotReg){reg_fix ("check");}
else {print"$datum This can only be run manualy if you are not registered.
"; }

start_menu($in);
}

function start_menu($in){
global $startUp,$startUpNode,$stripe,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll;
global $ambientApiKey,$city,$state,$MuteNet1,$MuteNet2,$MuteNet3,$sleep;
global $port,$hide,$phpVersion,$ver,$release, $phpzone,$call,$parishCounty,$fema; 
$out="(get the latest version)";
if($node==2955){$out="<Disabled on production server>";}

if($port<>4569){$pout="P) Reset port (Port $port is floating";} 
else{$pout="   Port $port is default";}
print " 
$stripe
Setup Program  $ver  
(c) 2023 by WRXB288 LAGMRS.com all rights reserved 
PHP:$phpVersion Timezone: $phpzone  Release date:$release
$stripe
Welcome $call  Made in Louisiana
  
 Setup.php  program 
          
 1) Edit program Options
 2) 1 Click Install GMRS Supermon
 3) 1 Click Install DVSwitch
 
 A) Reinstall admin menu (fix menu)
 D) View the Docs
 F) Force Register Fix
 $pout
 U) Upgrade $out

 s) Simplex Repeater Help
 x) Uninstall This software. 
 E) Exit  
$stripe
";
}  
 

function editmenu(){
global $startUp,$startUpNode,$DisplayNodes,$city,$state,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$tts,$MuteNet1,$MuteNet2,$MuteNet3,$sleep,$debug,$IconBlock,$LinkCheck,$beta,$AutoNode,$stripe,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate,$watchdog,$bridgeCheck;
global $ambientApiKey,$hide,$burst,$phpVersion,$ver,$release, $phpzone,$call,$parishCounty,$fema,$tts; 

$displayWatch="false"    ;if ($sayWatch)    {$displayWatch =   "true";}
$displayWarn="false"     ;if ($sayWarn)     {$displayWarn     ="true";}
$displayAdvisory="false" ;if ($sayAdvisory) {$displayAdvisory ="true";}
$displayStatement="false";if ($sayStatement){$displayStatement="true";}
$displayReport="false"   ;if ($reportAll)   {$displayReport   ="true";}
$displayIconBlock="false";if ($IconBlock)   {$displayIconBlock="true";}
$displaydebug="false"    ;if ($debug)       {$displaydebug    ="true";}
$displaybridgeCheck= "false";if($bridgeCheck){$displaybridgeCheck= "true";}
$displayMuteNet1="false" ;if ($MuteNet1) {   $displayMuteNet1 ="true";}
$displayMuteNet2="false" ;if ($MuteNet2) {   $displayMuteNet2 ="true";}
$displayMuteNet3="false" ;if ($MuteNet3) {   $displayMuteNet3 ="true";}
$displaySleep ="false"   ;if ($sleep)    {   $displaySleep ="true";}
$displayNodes="No Popup" ;if ($DisplayNodes){$displayNodes ="true";}
$displaystartUp="false"  ;if ($startUp)  {   $displaystartUp ="true";}                         
$burstDisplay="off"      ;if ($burst){$burstDisplay=$burst;}
$femaDisplay= "off"      ;if ($parishCounty and $fema){$femaDisplay="true";}

print"
$stripe
(c) 2023 by WRXB288 LAGMRS.com all rights reserved 
PHP:$phpVersion  Installer:$ver  Release date:$release
Timezone: $phpzone
$stripe
Welcome $call  Made in Louisiana

 Setup editor.   Last write date:$saveDate

 1) NWS Station [$station] Airport, MADIS, APRSWXNET, CWOP 
    Ambient Weather APIKEY [$ambientApiKey]
 2) Level Time [$level] 0=off 1=temp 2=cond 3=wind,hum,rain 4=Forcast (Levels to speak)
 3) Zipcode [$zipcode] for Acuweather conditions
 4) Location Lat:[$lat]/Lon:[$lon] needed for NWS API 
 5) SayWatch:$displayWatch SayAdvisory:$displayAdvisory SayStatement:$displayStatement 
 6) [$nodeName] CPU Temp setup  HiTemp[$high]  Hot[$hot] Report normal temp[$displayReport]
 7) Node   Auto:[$AutoNode]  Node:[$node]
 9) Automatic Clock Muting  net1[$displayMuteNet1] net2[$displayMuteNet2] net3[$displayMuteNet3] sleep[$displaySleep]
 8) Display Node Scan on Supermon link page [$displayNodes] or in popup.
 0) Watchdog limit. will fix reg automaticaly after [$watchdog] falures 99=disable\n\n";
 
if ($startUp){print" a) Autoconnect to [$startUpNode] on startup [$displaystartUp]\n";}
else{print" a) Autoconnect on startup [$displaystartUp]\n";}
 
print" b) Bridging detection system [$displaybridgeCheck]
 c) Install into cron. (Done automaticaly. Manual reinstall)
 d) Debugging info [$displaydebug]
 f) FEMA Declared Emergency API [$femaDisplay]
 l) Link down Alarm [$LinkCheck] (0=off,1=15m,2=30m)
 s) MDC-1200 burst [$burstDisplay] 
 u) Uninstall from cron. (Allows manual uninstall)
 W) Write to file.  (now automatic)
 M) Main menu
 E) Exit 
$stripe
";

// i) Forcast Icon block on supermon page [$displayIconBlock]

}

function supermonMenu(){
global $name,$city,$state,$beta,$AutoNode,$stripe,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate,$search,$fileEdit,$ok;
print"
$stripe
This will set up GMRS Supermon for node:
$node $name $city $state

* One click automated install supermon. 
* Upgrade supermon to GMRS Supermon
* Add GMRS live index HUBS,Repeaters and nodes

* Remove Allstar branding and links. Add GMRS ones
* Add redirect from root to /supermon

 More later as updates come out. Use Update to install them.
 
----------------------------------------------------------------        
 Always make backups of your card just in case of problems.
 Use win32diskimager.org for card backups.       
---------------------------------------------------------------

 i) Setup supermon. 
  
 M) Main menu
 E) Exit  
$stripe
";
}

function simplex($in){
global $stripe,$ok,$fileEdit,$search,$hide;

print"
$stripe
Simplex repeater setup help

This node can be used as a simplex repeater for camping trips
and such. 
It works better on a repeater split channel that way you 
wont here people twice.
Be sure you dont use this mode when linked.

To activate the simplex repeater enter this DTMF command.

*971  SIMPLEX Mode On
*970  SIMPLEX Mode Off
*973  cleanup/flush
 
If you will have no internet access the clock will be wrong 
so you need to turn off the clock and link detection.

Macros are not installed from default. 
Checking install.....
"; 
checkSimplex($in);
print "$stripe\n";
$a = readline('Press any key: ');
start_menu($in);
}




function quit($in){
global $startUp,$startUpNode,$phpVersion,$ver,$stripe,$phpzone,$release,$MuteNet1,$MuteNet2,$MuteNet3,$sleep,$beta,$AutoNode,$path,$node,$station,$level,$zipcode;
global $parishCounty,$fema,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$bridgeCheck;
save($in);

print "
$stripe
(c) 2023 by WRXB288 LAGMRS.com all rights reserved 
PHP:$phpVersion  Installer:$ver  Release date:$release
Timezone: $phpzone
$stripe

Thank you for downloading.........Made in Louisiana



this program can be run from the admin menu or by typing

cd $path

php weather_pws.php
php temp.php
php cap_warn.php
php setup.php
";

//$tagline="";tagline($tagline);print "$tagline (Have many nice days.)";

//c64("c64");

$file="$path/nodelist/clean.csv";
if (file_exists($file)){print "The Nodelist exists Skipping update.\n";}
else{ 
print "Starting Nodelist\n";
exec("php $path/nodelist_process.php",$output,$return_var); 
}  
print "$stripe\n";
die;
}


function edit($in){
global $hide,$startUp,$startUpNode,$DisplayNodes,$city,$state,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3;
global $sleep,$LinkCheck,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi;
global $ambientApiKey,$high,$hot,$nodeName,$reportAll,$bridgeCheck,$parishCounty,$fema;

editmenu();
$stdin = fopen('php://stdin', 'r');
$yes   = false;
while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Enter 1-9 M W E:_";
	$input = trim(fgets($stdin));
    if ($input == '1'){madis($station);}
    if ($input == '2'){level($level);}
    if ($input == '3'){zip($zipcode);}
    if ($input == '4'){location($lon);}
    if ($input == '5'){warn($zipcode);}
    if ($input == '6'){cpu($hot);}
    if ($input == '7'){setnode($node);}
    if ($input == '8'){lsnode("set");} 
    if ($input == '9'){muting("set");}
    if ($input == '0'){watchdog_set("set");}
    
    if ($input == 'a'){setStartup("set");}
    if ($input == 'b'){bridge("set");}
    if ($input == 'c'){setUpcron("set");} 
    if ($input == 'd'){debug("set");}
    if ($input == 'l'){link_set("set");}
    if ($input == 'f'){femaSet("set");}   
    if ($input == 's'){setBurst("set");}
    if ($input == 'u'){unSetcron("set");}
    if ($input == 'm'){start_menu($in);start("start");}
    
    if ($input == 'w'){save("save");}
	if ($input == 'e'){quit('EXIT');}
}

}




function supermon($in){
global $name,$city,$state,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi;
global $high,$hot,$nodeName,$reportAll;
supermonMenu();
$stdin = fopen('php://stdin', 'r');
$yes   = false;

while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Enter 1-7 M E:_";
	$input = trim(fgets($stdin));
    if ($input == 'i'){supermonGo("GO baby");}

    if ($input == 'm'){start_menu($in);start("start");}
	if ($input == 'e'){quit('EXIT');}
}

}


                                            

// -------------------------------------------------------------supermon ----------------------------------------------
function supermonGo($in){
global $name,$city,$state,$zipcode,$call,$password,$beta,$AutoNode,$path,$node,$iax,$rpi,$manager,$supermonPath,$allmon,$favorites,$global,$tmpFile,$logger;
global $watchdog,$name,$location,$ip,$search,$fileEdit,$ok;
print "
---------------------------------------------------------------
Name:$name City:$city State:$state

This will set up GMRS Supermon for node:$node

One click automated setup of GMRS supermon.
GMRS Supermon should already have been instaled but you may
wish to run update to get the latest version.

Use to setup Supermon after install. This does not touch existing
orginal supermon.
---------------------------------------------------------------        

  i) install   Any other key to abort!
  
";
  
$a = readline('Enter your command: ');

if ($a=="i"){
save_task_log ("Setting up GMRS Supermon");


$path  = "/etc/asterisk/local/mm-software";
$pathS = "/srv/http/supermon";
$pathG = "/srv/http/gmrs";
$pathGA= "/srv/http/gmrs/admin"; $path5 = $pathGA ;
$pathGE= "/srv/http/gmrs/edit";

$supermonPath = $pathG;

$favorites    = "$pathG/favorites.ini";
$global       = "$pathG/global.inc";


$line = readline("The Name for supermon page: $name ");if ($line){$name=$line;}
$location = readline("The Location for supermon page: $city $state");

// generage a 10 digit secure password.
$pass = getRandomString(10);
print "Using random generated password of [$pass]\n";
//$line = readline("Enter a password or just return for [$pass]");
//if ($line){$password=$line;}

$password=$pass;
$manager= "/etc/asterisk/manager.conf";// There is only 1 password in this file
$fileEdit=$manager;$search= "secret =";$hide=false;edit_config("secret =$password");
print "Password [$password] entered in $manager\n";

buildAllmon("gmrs");
if (file_exists($allmon)){print "Password entered GMRS Supermon in secured [$allmon].\n";}
else {print "error [$allmon] not found. Unable to build the file.\n";die;}

buildAllmon("supermon");
if (file_exists($allmon)){print "Password entered Supermon in [$allmon].\n";}
else {print "error [$allmon] not found. Unable to build the file.\n";die;}


chdir($pathGA);
print "
In order to secure GMRS Supermon a new ADMIN director was created that does not
use unsecure session keys. The new directory is secured by a web server password.
This requires you to enter a password now.   

$pathGA directory Username:admin \n";
exec ("htpasswd -c .htpasswd admin",$output,$return_var);

$out="#Protect Directory
AuthName \"GMRS Supermon\"
AuthType Basic
AuthUserFile $pathGA/.htpasswd
Require valid-user

<FilesMatch \"\.(htaccess|htpasswd|ini|ini.php|log|sh|inc|bak|save)$\">
Order Allow,Deny
Deny from all
</FilesMatch>";

$file="$pathG/admin/.htaccess";print"Protecting admin\n";
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$out); flock ($fileOUT, LOCK_UN );fclose ($fileOUT);


buildGlobal("gmrs"); buildGlobal("supermon");
print "Building global.ini  $call \n"; 

buldFav("gmrs");
print "Building fav \n";

$rpi="/etc/asterisk/rpt.conf"; 
print "Insalling Connect and Disconnect logging into $rpi\n";
$fileEdit=$rpi;$search="connpgm=/usr/";$hide=false;edit_config("connpgm=/usr/local/sbin/supermon/smlogger 1");
$fileEdit=$rpi;$search="discpgm=/usr/";$hide=false;edit_config("discpgm=/usr/local/sbin/supermon/smlogger 0"); 

$fileEdit="$pathG/common.inc";
$search   = "TITLE_LOGGED";
$formated = "#TITLE_LOGGED = 'GMRS Supermon Node Manager 6.2+ Mod';";
$formated = str_replace('#', '$', $formated); $formated = str_replace("'", '"', $formated);
$hide=false;edit_config($formated); 

$fileEdit="$pathG/common.inc";
$search   = "TITLE_NOT_LOGGED";
$formated = "#TITLE_NOT_LOGGED = 'GMRS Supermon Node Manager';"; 
$formated = str_replace('#', '$', $formated); $formated = str_replace("'", '"', $formated);
$hide=false;edit_config($formated); 


$logger="/etc/asterisk/logger.conf";
print "Adjusting settings to messages in $logger\n";
$fileEdit=$logger;$search= "messages =>";$hide=false;edit_config("messages => notice,warning,error");


print "Upgrading root directory of web server to modern 2023 standards.\n";
$file="/srv/http/index.html";if (file_exists($file)) {unlink ($file);}
$file="/srv/http/index.php" ;if (file_exists($file)) {unlink ($file);}


// install redirect
$file="/srv/http/index.php" ;
$fileOUT = fopen($file, "w");
$out = "<?php
header('Location: /gmrs/link.php?nodes=$node');
die();
?>";// <?php
fwrite ($fileOUT, $out);fclose ($fileOUT);


print"-----------------------------------------------------------
Requesting ast restart......";
exec ("astres.sh",$output,$return_var);  // Run restart
print "ok\n";
print"Your supermon is setup visit the url with a web browser $ip
=================================================================
One click supermon install finished.";

}
start_menu($in);
start("start");
}

//$MuteNet1,$MuteNet2,$MuteNet3

function muting($in){
global $Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$sleep;

$displayMuteNet1="false";$displayMuteNet2="false"; $displayMuteNet3="false"; $displaySleep ="false";

if ($MuteNet1) {   $displayMuteNet1 ="true";}
if ($MuteNet2) {   $displayMuteNet2 ="true";}
if ($MuteNet3) {   $displayMuteNet3 ="true";}
if ($sleep)    {      $displaySleep ="true";}

print "
Automatic muting system for clock/alerts.
No more speaking during nets.
All times are your local time.

Roadkill TexasGMRS nets 
Wed net $Net1Start-$Net1Stop [$displayMuteNet1] Wind down wed
Sun net $Net2Start-$Net2Stop [$displayMuteNet2] Family fun night
Fri net $Net3Start-$Net3Stop [$displayMuteNet3] Bernies round table 

Mute at night 1-6am [$displaySleep] sleep mode.  

Just press return to keep the current values.
";
$line = readline("Mute net1 wed y/n: ");
if ($line=="y"){$MuteNet1=true;}
if ($line=="n"){$MuteNet1=false;}

if($MuteNet1){
$line = readline("Start time 24hr $Net1Start:");
if ($line){$Net1Start=$line;}
$line = readline("Stop time 24hr $Net1Stop:");
if ($line){$Net1Stop=$line;}
}

$line = readline("Mute net2 sun y/n: ");
if ($line=="y"){$MuteNet2=true;}
if ($line=="n"){$MuteNet2=false;}

if($MuteNet2){
$line = readline("Start time 24hr $Net2Start:");
if ($line){$Net2Start=$line;}
$line = readline("Stop time 24hr $Net2Stop:");
if ($line){$Net2Stop=$line;}
}
$line = readline("Mute net3 fri y/n: ");
if ($line=="y"){$MuteNet3=true;}
if ($line=="n"){$MuteNet3=false;}

if($MuteNet3){
$line = readline("Start time 24hr $Net3Start:");
if ($line){$Net3Start=$line;}
$line = readline("Stop time 24hr $Net3Stop:");
if ($line){$Net3Stop=$line;}
 }


$line = readline("Mute at Night 1-6am y/n: ");
if ($line=="y"){$sleep=true;}
if ($line=="n"){$sleep=false;}

editmenu();
}


function bridge($in){
global $bridgeCheck;

$displaybridgeCheck="false";
if ($bridgeCheck) {   $displaybridgeCheck ="true";}
print "
Automatic bridging detection/auto disconnect [$displaybridgeCheck]
If a bridge is detected it will be aborted.

This stops acidental bridging and stops someone from making a bridge from
DTMF tones. (Ongoing Beta) Please report any problems.
This is compatable with DV switch see comments in DV switch install. 
";
$line = readline("Set to t/f: ");
if ($line=="t"){$bridgeCheck=true;}
if ($line=="f"){$bridgeCheck=false;}
editmenu();
}



function debug($in){
global $debug,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayDebug="false";
if ($debug){        $displayDebug     ="true";}
print "
Debugging gives extra info..
Debug is set to [$displayDebug]
";
$line = readline("Set to t/f: ");
if ($line=="t"){$debug=true;}
if ($line=="f"){$debug=false;}
editmenu();
}

function setBurst($in){
global $burst,$call,$node;
$burstDisplay="off";if($burst){$burstDisplay=$burst;}
print "
MDC-1200 bursts can be sent on the local radio before the clock plays.
You can enter a node# call or something else. It does not transmit into the network.

Many MDC-1200 systems utilize the unit ID option. With each push-to-talk press,
the radio sends a data burst identifying the sending radio. Unit IDs are decoded
as unique hexadecimal four-digit numbers. Every radio would have a unique
four-digit ID.    [$burstDisplay]

 0) to turn off 
";
$line = readline("Change from $burstDisplay to: ");
if ($line) {$burst=$line;}
else {$burst="";}

editmenu();
}


function link_set($in){
global $LinkCheck;
print "
Link Check will notify you if the link drops. 
Select how often you want messages. 
LinkCheck:[$LinkCheck]

0 = off
1 = every 10 or 15 mn 
2 = once at the bottom of the hr. (Random around 30 min)
";
$line = readline("Change from $LinkCheck  to: ");
if($line >=0 or $line <=2){$LinkCheck=$line;}
editmenu();
}

function setnode($station){
global $beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false";
print "
Node1 is auto detected on install if you need to change this you can do so here

AutoDetect node:$AutoNode Node set to $node:

";
$line = readline("Node $node: ");
if($line){$node=$line;}
editmenu();

}

// Madis had to be removed To muh data on free option
// NEW Api or ambent API
function madis($station){
global $beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement;
global $ambientApiKey,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;

$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false";
print "
----------------------WEATHER APIs-----------------------------
We need the code for you local weather station. 

1) For NWS Find your local MADIS station code or local AIRPORT at 
   https://madis-data.ncep.noaa.gov/MadisSurface/
   NWS [$station]

2) If you own a Ambient weather station go to 
   https://ambientweather.net/account   
   and generate a APIKEY for your station.
   KEY [$ambientApiKey]  
   
3) reset and clear both keys.   

e) Edit menu
";

$stdin = fopen('php://stdin', 'r');
$yes   = false;

while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Enter 1-2 E:_";
	$input = trim(fgets($stdin));
    if ($input == '1'){nws_edit("edit");}
    if ($input == '2'){nws_amb ("edit");}
    if ($input == '3'){$station="";$ambientApiKey="";madis("edit");}
	if ($input == 'e'){editmenu();}
    if ($input == ''){quit('EXIT');}
}
}

function nws_edit($in){
global $beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement;
global $ambientApiKey,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$line = readline("NWS Station $station:");
if ($line){$station = $line;}
}

function nws_amb($in){
global $beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement;
global $ambientApiKey,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$line = readline("Ambient weather station $ambientApiKey:");
if ($line){$ambientApiKey = $line;}
}


function level($level){
global $beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement;
global $testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;

$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false";
print "
When the time and temp runs how much detal do you want?
0= off 1=temp,2=cond 3=wind,hum,rain 4=Forcast  (Levels to speak)

";
$line = readline("Level $level: ");
$level = $line;
editmenu();
}

function zip($level){
global $zipcode;
$line = readline("Enter your ZipCode $zipcode: ");
$zipcode = $line;
editmenu();
}

function zip2($level){
global $zipcode;
$line = readline("Enter your ZipCode $zipcode: ");
$zipcode = $line;
location($zipcode);
}


function cpu($level){
global $beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false";
if ($reportAll)   {$displayReport   ="true";}
print "
 CPU Temp setup generates a report every 15min.
 
 HiTemp[$high] alarm.
 Hot   [$hot]  warning.
 Report Normal temps [$displayReport] for testing only
 Name of the node [$nodeName] (server,repeater,node,tower,temperature) 
 or any name in the sound_gsm_database. It will speak this name in alarms. 

";
$line = readline("HiTemp default 60: ");
if ($line>55){$high=$line;}

$line = readline("HotTemp default 50: ");
if ($line>49){$hot=$line;}

$line = readline("Report Normal temps y/n: ");
if ($line=="y"){$reportAll=true;}
else{$reportAll=false;}

$line = readline("Name (server,repeater,node,tower,temperature) : ");
if ($line){$nodeName=$line;}
else {$nodeName="server";}


editmenu();
}
function femaSet($in){
global $city,$state,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement;
global $parishCounty,$fema,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate,$tts,$autotts;
$femaDisplay= "off"      ;if ($parishCounty and $fema){$femaDisplay="true";}
print "
FEMA National Declared Emergency alerts. [$femaDisplay]
As part of the OpenFEMA initiative, FEMA is providing API based access to datasets.

These alerts have non standard words and phrases that are not yet in the database
and that I cant predict, so this module is a beta under construction.
 
TTS may be required so if you have a TTS key from www.voicerss.org be sure its entered.

This is a ongoing test because we wont likely see many alerts it will take some time to test this.
If you want to opt out use the erase option to erase the settings and turn it off..

 Parish or County :[$parishCounty] 
 State code :[$fema]  Your state:$state
 voicerss.org Text-to-speech KEY:[$tts]
 t) TTS KEY 
 c) Erase
 s) Setup 
 
 E) Edit Menu\n";
 
$stdin = fopen('php://stdin', 'r');
$yes   = false;
while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Enter C S E:_";
	$input = trim(fgets($stdin));
    if ($input == 'c'){femaSet2('set');}
    if ($input == 's'){femaSet3('set');}
    if ($input == 't'){ ttsSet2('set');}
    if ($input == 'm'){start_menu($in);start("start");}
    if ($input == 'e'){edit("edit");}
}

}

function femaSet3($in){
global $parishCounty,$fema,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate,$tts;
 $line = readline("Enter the Parish/County $parishCounty: ");
 if ($line){$parishCounty=$line;}
 $line = readline("Enter the State $fema: ");
 if ($line){$fema=strtoupper($line);} 
 femaSet($in);
} 

function femaSet2($in){
global $parishCounty,$fema,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate, $tts;
 $parishCounty="";$fema=""; 
 femaSet($in) ;
} 

function ttsSet2($in){
global $parishCounty,$fema,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate, $tts;
 $line = readline("What is your KEY $tts: ");
 if ($line){$tts=$line;} 
 femaSet($in) ;
} 


function location($in){
global $city,$state,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
print "
Your LAT/LON is required for the National Weather Service new forcast alert system.
The more accurate your location is the better tornado/storm reports you will get.
Setup will build a default based on node city state but you need to check it.

Use your phone or go to http://gps-coordinates.org

 1) Enter Lat/Lon  :[$lat]/[$lon] 
 2) Enter Zipcode  :[$zipcode]
 3) Look up Lat/Lon by ZIP code [$zipcode]
 4) Look up Zip for your city:[$city] State:[$state]
 B) Back to edit menu

 E) Exit\n";
 
$stdin = fopen('php://stdin', 'r');
$yes   = false;
while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Enter 1-2 B E:_";
	$input = trim(fgets($stdin));
    if ($input == '1'){locationEnter($station);}
    if ($input == '3'){lookupgps($zipcode);}
    if ($input == '2'){zip2($zipcode);}
    if ($input == '4'){lookupzip($city);location($in);}
    if ($input == 'b'){$yes= true;}
    if ($input == 'm'){$yes= true;}
    if ($input == 'q'){$yes= true;}
	if ($input == 'e'){quit('EXIT');}
}
editmenu();
}

function locationEnter($in){
global $lat,$lon;
$line = readline("Lat: ");
if($line){$lat=$line;}
$line = readline("Lon: ");
if($line){$lon=$line;}
location();
}

function lsnode($in){
global $DisplayNodes;
print "

Node Scan is my own version of lsnodes written from scratch in php with a better display
it finds all nodes connected to the HUB and finds all the nodes on other hubs connected
to that hub. 
So basicaly your seeing a static status page of all the nodes connected to the HUB.
It is static you have to reload it to update. Keeping cpu cycles low is important.

You have the choice of displaying this at the botom of the page.


\n";
$line = readline("Display nodes on supermon page y/n: ");
if ($line=="y"){$DisplayNodes=true;}
if ($line=="n"){$DisplayNodes=false;}
editmenu();
}
 



function watchdog_set($in){
global $watchdog;

print "
Watchdog timmer.  On [$watchdog] falures take action.

What is this for:
AT&T Fixed Wireless (UVERSE)routers may work for days but sudenly start blocking your port.
Hotspots may do the same thing. 

Success rate for me is 100%. Your milage may vary. 
This is only for the following problem.
Your Router, Gateway, Modem,phone,hotspot or ISP Corrupts your open port so
it cant reach the reg server. 
I fix this by rotating the port# This forces a new path to the server.
Normaly registration is restored in a few seconds. 

Note: Not compatable with IAX client or DVSWITCH they wont be able to reconnect when the port changes.

If you are having problems staying registered. Try this. This is only for people that have trouble staying registered.
Check GMRS SuperMon status page to see if your are unregistered.

3 or 4 recomended 99=disable.   
";
$line = readline("Watchdog timmer $watchdog: ");
$watchdog = $line;
if($watchdog==""){$watchdog=2;}
editmenu();
}




function doc($in){
global $beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate,$stripe;
$i=0;
$file="$path/readme.txt";
print "
 Loading the readme.txt file
$stripe
";
$fileIN= file($file);
foreach($fileIN as $line){
print $line; $i++ ;
if ($i >42){$line = readline(" ");$i=0;}
}
print "$stripe
End of File
";
$line = readline("Hit Return for menu");
start_menu($in);start("start");
}

function warn($skywarn){
global $beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false"; 
if ($sayWatch)    {$displayWatch =   "true";}
if ($sayWarn)     {$displayWarn     ="true";}
if ($sayAdvisory) {$displayAdvisory ="true";}
if ($sayStatement){$displayStatement="true";}

print "
Cap Warn uses Common Alerting Protocol (CAP) from the NWS
The new API needs your LAT/LON  [$lat/$lon]


Customise what reports you want
SayWarning   true <hard coded>
SayWatch     $displayWatch
SayAdvisory  $displayAdvisory
SayStatement $displayStatement 
 
";
$line = readline("Say Watches y/n: ");
if ($line=="y"){$sayWatch=true;}
if ($line=="n"){$sayWatch=false;}

$line = readline("Say Advisory y/n: ");
if ($line=="y"){$sayAdvisory=true;}
if ($line=="n"){$sayAdvisory=false;}

$line = readline("Say Statement y/n: ");
if ($line=="y"){$sayStatement=true;}
if ($line=="n"){$sayStatement=false;}
editmenu();
}




function load($in){
global $parishCounty,$fema,$startUp,$startUpNode,$burst,$DisplayNodes,$name,$city,$state,$phpzone,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start;
global $Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$bridgeCheck,$autotts,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$LinkCheck,$beta,$saveDate,$path;
global $ambientApiKey,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog;
  $pathNull="";
  
if (is_readable("$path/setup.txt")) {
   $fileIN= file("$path/setup.txt");
   
   foreach($fileIN as $line){
    $u = explode(",",$line);
          $pathNull =  $u[0];// Just padding not really used 
             $node  =  $u[1];
          $station  =  $u[2];
             $level =  $u[3];
         $zipcode   =  $u[4];
         $IconBlock =  $u[5];
               $lat =  $u[6];
               $lon =  $u[7];
           $sayWarn =  $u[8];
          $sayWatch =  $u[9];
       $sayAdvisory = $u[10];
      $sayStatement = $u[11];
        $sleep      = $u[12];
              $high = $u[13]; 
               $hot = $u[14];
          $nodeName = $u[15];
         $reportAll = $u[16];
          $saveDate = $u[17];
         $LinkCheck = $u[18]; 
              $beta = $u[19];
          $watchdog = $u[20];
             $debug = $u[21];
               $tts = $u[22]; // test t speach 
       $bridgeCheck = $u[23]; 
       $MuteNet1    = $u[24]; 
       $MuteNet2    = $u[25];
       $MuteNet3    = $u[26];
       $Net1Start   = $u[27];
       $Net1Stop    = $u[28];
       $Net2Start   = $u[29];
       $Net2Stop    = $u[30]; 
       $Net3Start   = $u[31];
       $Net3Stop    = $u[32];
       $DisplayNodes= $u[33];
       $burst       = $u[34];
       $startUp     = $u[35];
       $startUpNode = $u[36]; 
       $parishCounty= $u[37];
       $fema        = $u[38];
      $ambientApiKey= $u[39];      
    }
    
if(!$tts and $autotts){$tts=$autotts;}    
    
}
// If its missing create a defult
else {
// set default
$status ="Building default settings";save_task_log ($status);
print "$datum $status\n";

$reportAll = false;$nodeName = "server";$high=60;$hot=50;$in="";
// https://madis-data.ncep.noaa.gov/MadisSurface/
$station="KAEX";$level = 3 ;  // Alexandria International Airport (AEX)
$zipcode="";lookupzip ($in);// get a zip from city state

$IconBlock= true; $skywarn ="";
$lat ="31.3273"; $lon="-92.5485"; // Alexandria International Airport	31.3273717,-92.5485558
lookupgps($in); // make from zip or just use default

$sleep=true;$tts=$autotts; $DisplayNodes=false;
$sayWarn=true;$sayWatch=true;$sayAdvisory=true;$sayStatement =true;
$node = $AutoNode;$beta = false; $debug=false;
$watchdog = 10; 

// set mute to off for default
$MuteNet1 = false; $MuteNet2 = false; $MuteNet3 = false;
$Net1Start= 19; $Net1Stop= 20;
$Net2Start= 18; $Net2Stop= 19;
$Net3Start= 20; $Net3Stop= 21;


if ($phpzone=="America/Chicago"){ // louisiana
$MuteNet1 = true; $MuteNet2 = true;
$Net1Start= 19; $Net1Stop= 20;
$Net2Start= 18; $Net2Stop= 19;
$Net3Start= 20; $Net3Stop= 21;
}

if ($phpzone=="America/Denver"){ // 
$Net1Start= 20; $Net1Stop= 21;
$Net2Start= 19; $Net2Stop= 20;
$Net3Start= 21; $Net3Stop= 22;
}
 
$bridgeCheck = true;$burst="";
$LinkCheck=false;

$startUp=false;$startUpNode = "0000";

$parishCounty= "";
$fema        = "";if($state){$fema=$state;}
$ambientApiKey="";

save ("save");
 }
}

function save($in){
global $ambientApiKey,$parishCounty,$fema,$startUp,$startUpNode,$burst,$DisplayNodes,$Net1Start,$Net1Stop,$Net2Start, $Net2Stop,$Net3Start,$Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$tts,$debug,$datum,$LinkCheck,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$IconBlock,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$sleep,$high,$hot,$nodeName,$reportAll,$watchdog,$bridgeCheck;

$path4 = "$path/backup";if(!is_dir($path4)){ mkdir($path4, 0755);}
$file = "$path/setup.txt";$dow = date('w');$fileBU = "$path4/setup.txt.$dow";
if (file_exists($file)){
if (file_exists($fileBU)){unlink($fileBU);}
copy($file, $fileBU); $status ="Backup settings to $fileBU";save_task_log ($status); 
print"$datum $status\n";
} 

$fileOUT = fopen("$path/setup.txt", "w");
$status ="Writing settings";save_task_log ($status);
print "$datum $status\n";

fwrite ($fileOUT, "$path,$node,$station,$level,$zipcode,$IconBlock,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$sleep,$high,$hot,$nodeName,$reportAll,$datum,$LinkCheck,$beta,$watchdog,$debug,$tts,$bridgeCheck,$MuteNet1,$MuteNet2,$MuteNet3,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$DisplayNodes,$burst,$startUp,$startUpNode,$parishCounty,$fema,$ambientApiKey,,,,,,,,,,,");
fclose ($fileOUT);
}








function create_node ($file){
global $file,$path;
// keep this file up to date
$file ="/usr/local/etc/allstar_node_info.conf"; $autotts=""; 
//copy($file, "$path/allstar_node_info.conf"); we no longer need this
$fileIN= file($file);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$line = str_replace('"', "", $line);
$pos = strpos("-$line", 'NODE1=');
if ($pos){$u= explode("=",$line);
$node=$u[1];}
$pos2 = strpos("-$line", 'STNCALL='); 
if ($pos2){$u= explode("=",$line);
$call=$u[1];}
}
// Get any tss key if exists   RESERVED for Future use
$file ="/usr/local/etc/tts.conf";
$fileIN= file($file);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$line = str_replace('"', "", $line);
$pos = strpos("-$line", 'tts_key=');
if ($pos){$u= explode("=",$line);
$autotts=$u[1];}
}
$file= "$path/mm-node.txt";// This will be the AutoNode varable
$fileOUT = fopen($file, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$node,$call,$autotts, , ,");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
}


// anti Bridging system Check installed.
function check_bridge_installed ($status){
global $search,$path,$fileEdit,$ok;
$fileEdit ="/usr/local/sbin/sm-support/smlogger_background.sh";
$fileBu = "$fileEdit-.bak"; 

if (!file_exists($fileBu)){
print"Installing anti Bridiging system\n";

$search='echo $LOGINFO'; 
$in="echo #LOGINFO |sed 's/ +/ /g' >> #LOGFILE

php /etc/asterisk/local/mm-software/connect.php #LOGINFO

";
$in = str_replace('#', '$', $in);
$hide=false;edit_config($in);// $search=search for line  $in=change to $fileEdit=file   out $ok=true


$search="";$path="";
} 
exec("sudo chmod +x /usr/local/sbin/sm-support/smlogger_background.sh",$output,$return_var); 
}

// v2 stop using $file confusion  
function save_task_log ($status){
global $basename,$path,$error,$datum,$logRotate;

// $logRotate = 40000;// size to rotate at set at top

$datum  = date('m-d-Y H:i:s');
if(!is_dir("$path/logs/")){ mkdir("$path/logs/", 0755);}
chdir("$path/logs");
$log="$path/logs/log.txt";
$log2="$path/logs/log2.txt"; 


// log rotation system 
// To be replaced with daily logs....   
if (is_readable($log)) {
   $size= filesize($log);
   if ($size > $logRotate){
    if (file_exists($log2)) {unlink ($log2);}
    rename ($log, $log2);
    if (file_exists($log)) {print "error in log rotation";}
   }
}

if (is_writeable($log)) {
 $fileOUT = fopen($log, 'a+') ;flock ($fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,$status,$basename,,,\r\n");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
}
else { 
unlink ($log);
$fileOUT = fopen($log, 'a+') ;flock ($fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,$status,$basename,,,\r\n");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
}

}


function dvswitch($in){
global $node,$call;
print " DV Switch easy installer. 

This Installs DV Switch but you will still need to open a port
on your router. Recomend you test your phone on your LAN and get that working
first before you try remote connections.  

In order for this to work with the anti bridging system you must use your
ID [$call] as the caller ID so it will be ignored and not treated as a bridge.
Using a ID other than the one listed above will create a bridge alarm. 

Press (i) to install DV Switch
";

$a = readline('Enter your command: ');

if ($a == "i"){

$password = getRandomString(6);
print "Using random password of [$password] on IAX connection.\n";
edit_iax_DV($password);
edit_extensions($password);

$localIP = getHostByName(getHostName());
   $myip = exec("/bin/wget -t 1 -T 3 -q -O- http://checkip.dyndns.org:8245 |/bin/cut -d':' -f2 |/bin/cut -d' ' -f2 |/bin/cut -d'<' -f1");

// This is the local machine's external IP address
$port = find_port ("port");

print " Thats it DV-Switch is installed.
Setup DV SWitch APP as listed here.

Protocol IAX2
Hostname $myip  or on a LAN $localIP
Port     $port
Password $password
CallerID $call 
Node     $node

";
}
}

function admin_sh_menu(){
$file ="/usr/local/sbin/firsttime/adm01-shell.sh";
$file2="/usr/local/sbin/firsttime/mmsoftware.sh";
if (file_exists($file2)){unlink ($file2);}
copy($file, $file2);// copy existing to get correct permissions
$file= $file2;
$out='#/!bin/bash
#MENUFT%055%Time/Weather/Node Manager Setup

$SON
reset

php /etc/asterisk/local/mm-software/setup.php

exit 0
';
// overwrite with our menu.
$fileOUT = fopen($file, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, $out);flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
 exec("sudo chmod +x $file",$output,$return_var);
} 

function edit_extensions($in){ 
global $search,$path,$fileEdit,$ok,$node,$password;

$ok=false;$line=""; $search= "[dvswitch-iaxrpt]";
$fileEdit= "/etc/asterisk/extensions.conf";
if (file_exists($fileEdit)){
$fileBu = "$fileEdit-.bak"; if (!file_exists($fileBu)){copy($fileEdit,$fileBu);} // This creates a orginal backup
$tmpFile="$fileEdit-new.txt"; 

$fileIN= file($fileEdit);
$fileOUT = fopen($tmpFile, "w") or die ("Error $tmpFile Write falure");
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", $search); 
if ($pos>=1){
$formated="[dvswitch-iaxrpt]  
exten => $node,1,Answer
exten => $node,n,Playback,rpt/node
exten => $node,n,Playback,digits/1
exten => $node,n,Playback,digits/9
exten => $node,n,Playback,digits/9
exten => $node,n,Playback,digits/8
exten => $node,n,Set(CALLERID(num)=0)
exten => $node,n,Rpt,2955|P|#{CALLERID(name)} 
"; $formated = str_replace('#', '$', $formated);

$ok=true;fwrite ($fileOUT, "$formated\n"); break;
}  
fwrite ($fileOUT, "$line\n");
}

if (!$ok){ $formated="[dvswitch-iaxrpt] 
exten => $node,1,Answer
exten => $node,n,Playback,rpt/node
exten => $node,n,Playback,digits/1
exten => $node,n,Playback,digits/9
exten => $node,n,Playback,digits/9
exten => $node,n,Playback,digits/8
exten => $node,n,Set(CALLERID(num)=0)
exten => $node,n,Rpt,2955|P|#{CALLERID(name)}
"; 
fwrite ($fileOUT, "$formated\n");
}


fclose ($fileOUT);
// if ok then we found it

if (file_exists($tmpFile)){ unlink($fileEdit);} 
rename ($tmpFile, $fileEdit); 

save_task_log ("Edit $fileEdit search:$search");


 


// try to prevent stray data
$fileEdit="";$search="";print"\n";
}
}

// THE Main IAX editor for DVSWITCH 
function edit_iax_DV($in){ 
global $search,$path,$fileEdit,$ok,$hide,$node,$password;

$ok=false;$line=""; 
$fileEdit= "/etc/asterisk/iax.conf";

if (file_exists($fileEdit)){
$fileBu = "$fileEdit-.bak"; if (!file_exists($fileBu)){copy($fileEdit,$fileBu);} // This creates a orginal backup
$tmpFile= "$fileEdit-new.txt"; 
$fileIN= file($fileEdit);
$fileOUT = fopen($tmpFile, "w") or die ("Error $tmpFile Write falure");

foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", "[DVSWITCH]"); if ($pos){$ok=true; break;}// if found stop...  
fwrite ($fileOUT, "$line\n");
}
// we are stoping here and adding our info. If it was already there we just rewrite it.
// This requires nothing be added under this or it will be erased.

$line="[DVSWITCH]
type=friend
context=dvswitch-iaxrpt
host=dynamic
auth=md5
secret=$password
disallow=all
allow=ulaw
transfer=no
calltokenoptional=0.0.0.0/0.0.0.0
requirecalltoken=no

";
fwrite ($fileOUT, "$line\n");
}
fclose ($fileOUT);

// now if we added we swap it in if it already existed we just stop.
// This needs to be changed so it can overwrite but not for now,.

if (file_exists($tmpFile)){ unlink($fileEdit);} 
rename ($tmpFile, $fileEdit); 
save_task_log ("Edit $fileEdit search:$search");


  


// try to prevent stray data It keeps showing up with left overs...
$fileEdit="";$search="";print"\n";
}



//this is my own editor to search and replace
// v2.0 7/28/2023
// v2.1 9/20/2023 Only save the first found line
// $search=search for line  $in=change to $fileEdit=file   out $ok=true
function edit_config($in){ 
global $search,$path,$fileEdit,$ok,$hide;

if(!$hide){print "Search for $search in file:$fileEdit ";}
$ok=false;$line="";
if (file_exists($fileEdit)){
$fileBu = "$fileEdit-.bak"; if (!file_exists($fileBu)){copy($fileEdit,$fileBu);} // This creates a orginal backup
if(!file_exists($fileBu)and !$hide){ print "Unable to BackUP.";}
$tmpFile="$fileEdit-new.txt"; // keep in the same dir so we wont have to copy

$fileIN= file($fileEdit);
$fileOUT = fopen($tmpFile, "w") or die ("Error $tmpFile Write falure");
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", $search); 
if ($pos>=1){ 
if (!$ok){
$line=$in;$ok=true;
if(!$hide){print"$line Replacing with $in <ok>"; } // Replace the found line with a new one.
 }// only change the first found line
}// pos  
fwrite ($fileOUT, "$line\n");
}

fclose ($fileOUT);
// if ok then we found it
if ($ok){
 if (file_exists($tmpFile)){ unlink($fileEdit);} 
 rename ($tmpFile, $fileEdit); 
 save_task_log ("Edit $fileEdit search:$search");
} // rename
else{if(!$hide){print "not found";} }
   
} //file exist
// try to prevent stray data
$fileEdit="";$search="";print"\n";
}

function search_config($in){ 
global $search,$path,$fileEdit,$ok,$hide;

if(!$hide){print "Search for $search in file:$fileEdit ";}
$ok=false;$line="";
if (file_exists($fileEdit)){
$fileIN= file($fileEdit);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", $search); 
if ($pos>=1){ 
$line=$in;
$ok=true;
break;}
 }
}// end if exists

if(!$hide){
 if ($ok){print"found\n";}
 else {print"not found\n";}
}


}


// global.inc'
function buildGlobal($in){
global $zipcode,$path,$file,$tmpFile,$ok,$password,$node,$call,$name,$location,$pathG;

$globalfile = "/srv/http/gmrs/global.php";
if ($in=="gmrs"){    $globalfile = "/srv/http/gmrs/global.php";     } 
if ($in=="supermon"){$globalfile = "/srv/http/supermon/global.inc"; } 


$file = $globalfile;
$fileOUT = fopen($file, "w") or die ("Error $file Write falure\n");  // 
// 21600 = 6 hrs 3600 = 1 hr
$formated="
<?php
#CALL = '$call';
#NAME = '$name';
#LOCATION = '$location';
#TITLE2 = 'GMRS Live Node ';
#TITLE3 = 'System Node Manager';
#BACKGROUND = 'background.jpg';
#BACKGROUND_COLOR = 'blue';
#BACKGROUND_HEIGHT = '124px';
#REFRESH_DELAY = '3600';
#SHOW_COREDUMPS = 'yes';
#LOCALZIP = '$zipcode';
#MAINTAINER = '';
?>
";//  <?php
$formated = str_replace("'", '"', $formated);
$formated = str_replace('#', '$', $formated);
fwrite ($fileOUT, $formated);
fclose ($fileOUT);
print "saving $globalfile \n";
save_task_log ("$file saved");
 }

 
function buldFav($in){
global $favorites,$path,$file,$tmpFile,$ok,$password,$node,$pathG;
//$favorites    = "$pathG/favorites.ini";
$file = $favorites;

// no backup needed we now install into our own directory
//if (file_exists($file)){
//$fileBu = "$file-.bak"; if (file_exists($fileBu)){ unlink($fileBu); }
//copy($file,$fileBu);if(!file_exists($fileBu)){ print "Unable to make a BackUP.";}

$fileOUT = fopen($file, "w") or die ("Error $file Write falure\n");  // 

$formated="
[general]

label[] = 'RoadKill 1195'
cmd[] = 'rpt cmd %node% ilink 3 1195'

label[] = 'RoadKill DV Switch 1167'
cmd[] = 'rpt cmd %node% ilink 3 1167'

label[] = 'Texas GMRS Network 2250'
cmd[] = 'rpt cmd %node% ilink 3 2250'

label[] = 'Nationwide Chat 700'
cmd[] = 'rpt cmd %node% ilink 3 700'

label[] = 'The Lone Wolf 1691'
cmd[] = 'rpt cmd %node% ilink 3 1691'

label[] = 'ALAMO CITY 1510'
cmd[] = 'rpt cmd %node% ilink 3 1510'

label[] = 'CENTRAL ILLINOIS 1915'
cmd[] = 'rpt cmd %node% ilink 3 1915'

label[] = 'Edit Favorties.ini to add content'
cmd[] = 'NONE'
";

$formated = str_replace("'", '"', $formated);
fwrite ($fileOUT, $formated);
fclose ($fileOUT);
print "saving $favorites  \n";
save_task_log ("$file saved");
}






//  This builds a secure allmon in the ADMIN area
function buildAllmon($in){
global $allmon,$path,$file,$tmpFile,$ok,$password,$node,$pathG,$pathGA;


$pathSUPERMON="gmrs";
$allmon="/srv/http/gmrs/admin/allmon.ini"; // new secure path

if ($in=="gmrs"){    $allmon="/srv/http/gmrs/admin/allmon.ini";$pathSUPERMON="gmrs";} 
if ($in=="supermon"){$allmon="/srv/http/supermon/allmon.ini";  $pathSUPERMON="supermon";} 

$file= $allmon;

if (file_exists($file)){ unlink($file);}
$fileOUT = fopen($file, "w") or die ("Error $file Write falure\n");  // 

$formated="
[$node]
host=127.0.0.1:5038
user=admin
passwd=$password
menu=yes
system=Nodes
hideNodeURL=no

[All Nodes]
system=Display Groups
nodes=$node
menu=yes


[Directory]
system=Local Menu
url='/gmrs/gmrs-node-index.php?type=hub&sort=live&code=08082023'
menu=yes

[List Nodes]
system=Local Menu
url='/gmrs/lsnodes.php'
menu=yes

[Freq Chart]
system=Local Menu
url='/gmrs/gmrs-chart.php'
menu=yes

[System Map]
system=Local Menu
url='/gmrs/map.php'
menu=yes

[Status]
system=Local Menu
url='/$pathSUPERMON/link.php?nodes=$node'
menu=yes

[Admin]
system=Local Menu
url='/gmrs/admin/link.php?nodes=$node'
menu=yes

[Logs]
system=Local Menu
url='/gmrs/admin/log.php?log=mmsoftware'
menu=yes

 

[RoadKill Website]
url='http://roadkill.network'
menu=yes
system= Bookmarks

[Texas GMRS Website]
url='https://www.texasgmrs.net/'
menu=yes
system= Bookmarks

[Alamo City GMRS Community]
url='http://1510.node.gmrslive.com/supermon'
menu=yes
system= Network Status Pages

[Broadnet GMRS Repeater Systems]
url='https://status.broadnetgmrs.net/'
menu=yes
system= Network Status Pages

[Central Illinois GMRS Live Hub]
url='http://1915.node.gmrslive.com/supermon'
menu=yes
system= Network Status Pages

[GMRS Live Hub]
url='http://gmrslive.com/status/link.php?nodes=700,900'
menu=yes
system= Network Status Pages

[Hammond HUB]
url='http://1171.node.gmrslive.com/supermon/link.php?nodes=1171'
menu=yes
system= Network Status Pages

[Lone Wolf System]
url='http://www.lonewolfsystem.org/supermon/link.php?nodes=1691'
menu=yes
system= Network Status Pages

[Ottawa Lake MI]
url='http://1171.node.gmrslive.com/supermon/link.php?nodes=1114'
menu=yes
system= Network Status Pages

[South Dade GMRS Club]
url='http://1806.node.gmrslive.com/supermon'
menu=yes
system= Network Status Pages

[Southeast Mishigami Hub - Ottawa Lake, MI]
url='http://1114.node.gmrslive.com/supermon/link.php?nodes=1114'
menu=yes
system= Network Status Pages

[Southwest Michigan HUB]
url='http://1082.node.gmrslive.com/supermon/link.php?nodes=1082'
menu=yes
system= Network Status Pages

[Texas GMRS Network]
url='https://link.texasgmrs.net/link.php?nodes=2250,2251,2252,2253,2254,1000,922'
menu=yes
system= Network Status Pages

[The RoadKill !! Repeater System]
url='http://1195.node.gmrslive.com/link.php?nodes=1195,1196,1167'
menu=yes
system= Network Status Pages
";
$formated = str_replace("'", '"', $formated);

fwrite ($fileOUT, $formated);
fclose ($fileOUT);
print "saving $allmon \n";
save_task_log ("$file saved");
}


// build a password
function getRandomString($n){
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';

    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }
    save_task_log ("IAX password $randomString");
    return $randomString;
}



// remove from chron
function unSetcron($in){
global $search,$node1,$path;
print"restoring cron ";
 
// install the backup

$file = "$path/cron-orginal.txt";
if (file_exists($file)){exec ("crontab $file",$output,$return_var);print"from backup";}
else{
print"from default archive";
$replace="# Do not remove the following line
# required for lsnodes and allmon
15 03 * * * cd /usr/local/sbin; ./astdb.php cron
00 * * * * (source /usr/local/etc/allstar.env ; /usr/bin/nice -19 /usr/bin/perl /usr/local/sbin/saytime.pl \$NODE1 > /dev/null)
";

$fileOUT = fopen($file, "w");fwrite ($fileOUT, $replace);fclose ($fileOUT);
exec ("crontab $file",$output,$return_var);
}
print "ok\n";
$tmpFile = "$path/cron-new.txt"; if (file_exists($tmpFile)){ unlink($tmpFile); }
$file = "$path/cron-orginal.txt";if (file_exists($file)){ unlink($file); }  // this may fail if permissions are wrong.
}

// sets up cron and removes old scripts.
function setUpcron($in){
global $fileEdit,$search,$path;
print "Installing Cron ";
// make a backup for uninstall
$file = "$path/cron-orginal.txt"; if (!file_exists($file)){exec ("crontab -l > $file",$output,$return_var);print"[made backup]";}
$file = "$path/cron.txt";

if (file_exists($file)){exec ("crontab $file",$output,$return_var);print" using[cron.txt] ";}
else{
$out="# GMRS Node Manager
# nodelist processor replaces astdb.php
2 2-4 * * * php /etc/asterisk/local/mm-software/nodelist_process.php cron >/dev/null
00 * * * * php /etc/asterisk/local/mm-software/hourly.php >/dev/null
*/13 * * * * php /etc/asterisk/local/mm-software/odd_min.php >/dev/null
59 * * * * /usr/local/sbin/trimlog.sh /var/log/asterisk/messages 1000
";
$file = "$path/cron.txt"; 
$fileOUT = fopen($file, "w");fwrite ($fileOUT, $out);fclose ($fileOUT);
print" using [memory] repo was missing ";
exec ("crontab $file",$output,$return_var);
}
print " <OK>\n";

//stop the looping script from being in memory
$fileEdit="/etc/rc.local"; $search="AutoSky";$hide=true;edit_config("#");



 
}
 
function c64($in){
print"






        **** COMODORE 64 BASIC V2 **** 
    64K RAM SYSTEM  38911 BASIC BYTES FREE
READY.
";
}

function lookupgps($in){
global $lat,$lon,$zipcode,$city,$state;
// This key is licensed to me do not reuse in anything else.
// Get your own.
$api="d8e8c050-2d0c-11ee-86e8-a9d406a2a91b";
$domain ="app.zipcodebase.com";
$datum   = date('m-d-Y H:i:s');
print "$datum Polling $domain $zipcode WAIT!>--";
$mtime = microtime(); $mtime = explode(" ",$mtime); $mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;

$attime = gmdate('YmdHi');
$url = "api/v1/search?apikey=$api&codes=$zipcode&country=US";

$options = array(
    'http'=>array(
        'timeout' => 30,  
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Content-Type: application/json\r\n".
                  "User-Agent: Allstar Node lagmrs.com \r\n" 
));
$context = stream_context_create($options);
$html = @file_get_contents("http://$domain/$url"); 
$file ="/tmp/zip-to-geo.xml";
if(file_exists($file)){unlink($file);}
//$json = json_decode($html);
$html = str_replace('"', "", $html);
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"https://$domain/$url\n $html ");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
$mtime = microtime(); $mtime = explode(" ",$mtime); $mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);



$u = explode(",",$html);  // latitude:31.74500000,longitude:-92.39520000
$uLat = explode(":",$u[4]) ; $uLon = explode(":",$u[5]);
$uCity = explode(":",$u[6]); $uState = explode(":",$u[7]);

$city="";$state="";
if ($uCity[0]=="city"){$city=$uCity[1];print"ok $poll_time sec ($city "; }
if ($uState[0]=="state"){$state=$uState[1];print"$state)\n"; }

if ($uLat[0]=="latitude"){print"$datum";$uLat[1]=round($uLat[1],4);print " [$uLat[1]/";$lat=$uLat[1];}
if ($uLon[0]=="longitude"){$uLon[1]=round($uLon[1],4);print "$uLon[1]]\n";$lon=$uLon[1];}
else{print"ERROR\n";}

}


function lookupzip ($in){
global $lat,$lon,$zipcode,$city,$state,$path;

if (!$state){return;}

$stateName="";
$input= file("$path/states.csv");
//$state= trim($state) ; $state  = str_replace("\n","",$state);
foreach($input as $line){ 
$line  = str_replace("\n","",$line);
$u = explode(",",$line);
$u[1] = str_replace(" ","",$u[1]);
//$test1 = strtoupper($u[1]);
if ($u[1]==$state){print"*";$stateName=$u[0];break;}
 
}
if(!$stateName){print "error in database $state";$stateName=$state;}



// This key is licensed to me do not reuse in anything else.
// Get your own.
$api="d8e8c050-2d0c-11ee-86e8-a9d406a2a91b";
$domain ="app.zipcodebase.com";
$datum   = date('m-d-Y H:i:s');
print "$datum Polling $domain $stateName WAIT!>-- ";
$mtime = microtime(); $mtime = explode(" ",$mtime); $mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
//https://app.zipcodebase.com/api/v1/code/city?apikey=d8e8c050-2d0c-11ee-86e8-a9d406a2a91b&city=Amsterdam&state_name=Noord-Holland&country=nl
$attime = gmdate('YmdHi');
$url = "api/v1/code/city?apikey=$api&city=$city&state_name=$stateName&country=US";

$options = array(
    'http'=>array(
        'timeout' => 30,  
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Content-Type: application/json\r\n".
                  "User-Agent: Allstar Node lagmrs.com \r\n" 
));
$context = stream_context_create($options);
$html = @file_get_contents("http://$domain/$url"); 
$file ="/tmp/city-to-zip.xml";
if(file_exists($file)){unlink($file);}
//$json = json_decode($html);
$html = str_replace('"', "", $html);$html = str_replace('[', "", $html); $html = str_replace(']', "", $html); $html = str_replace('}', "", $html); $html = str_replace('{', "", $html);
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"https://$domain/$url\n $html ");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
$mtime = microtime(); $mtime = explode(" ",$mtime); $mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
$u  = explode(":",$html);  
if (isset($u[5])){$zipcode = $u[5];print "$zipcode <ok>\n";} 
else{print "<error>";}

}

function  setOurCall($in){
global $file1,$call,$node,$path,$datum,$soundDbGsm;;
$action="";$file1=""; $datum = date('m-d-Y H:i:s');
include_once ("$path/sound_db.php");  
unset ($soundDbWav);// not using these
unset ($soundDbUlaw);
$test =  strtolower($call);
$oh=false;
$x = (string)$test;
for($i=0;$i<strlen($x);$i++)
{check_gsm_db ($x[$i]);$action = "$action $file1";} //print"$file1\n";

$file ="/var/lib/asterisk/sounds/rpt/nodenames/$node.ul"; 
exec ("sox $action $file",$output,$return_var);
print "$datum Creating soundfile $file\n";
unset ($soundDbGsm);// save memor clear

}

function setStartup($in){
global $hide,$startUp,$startUpNode,$search,$path,$fileEdit,$ok,$hide;

$displaystartUp ="false";if ($startUp){$displaystartUp ="true";} 

print "
 On start up connect to node:[$startUpNode]  $displaystartUp\n";
 
$line = readline("Enter Y or N: ");
if ($line=="y"){
$startUp=true;
$line = readline("Connect to Node:$startUpNode ");
if ($line<>""){$startUpNode=$line;}

//startup_macro = *731195
//				; Macro to run at startup (optional)
//startup_macro_delay=80
//				; Time in seconds to wait before executing
//				; the startup macro
 

print "Saving Connect to $startUpNode on start\n";
$rpi="/etc/asterisk/rpt.conf"; $hide=true;
$fileEdit=$rpi;$search="startup_macro_delay";edit_config("startup_macro_delay=90");  //  dns updates
$fileEdit=$rpi;$search="startup_macro";      edit_config("startup_macro = *73$startUpNode");
}

if ($line=="n"){
$startUp=false;
print "Saving Disable startup\n";
$rpi="/etc/asterisk/rpt.conf"; $hide=true;
$fileEdit=$rpi;$search="startup_macro_delay";edit_config(";startup_macro_delay=90");
$fileEdit=$rpi;$search="startup_macro";      edit_config(";startup_macro = *73$startUpNode");
}
editmenu();
}


function checkSimplex($in){
global $ok,$fileEdit,$search,$hide;
// install the custom macros but do it once

$rpi="/etc/asterisk/rpt.conf"; $hide=true;
$fileEdit=$rpi;$search="971=cop,21";search_config("null");

if($ok){print" Simplex Macros are already installed and active.\n";}

else{
print " Installing Simplex macros *971,*970,*973 
Must restart Asterisk server to activate them\n";

$hide=true;
$in="915=cop,55                ; Parrot once if Parrot mode is disabled
971=cop,21                ; enable Parrot Mode
970=cop,22                ; disable Parrot Mode
973=cop,23                ; Parrot cleanup/flush
";
$fileEdit=$rpi;$search="915=cop,55";edit_config($in);
if($ok){print " OK installed.\n";}
else{
print" I am sorry a error has prevented the install\n\n";
  }
 }
}

?>
