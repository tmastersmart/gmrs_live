<?php
//  ------------------------------------------------------------
//  (c) 2023 by WRXB288 lagmrs.com all rights reserved
//
// Setup program  
//    
// !shebang doesnt work on node so using direct loading
// php setup.php
// -------------------------------------------------------------

// PHP is in UTC Get in sync with the PI

$ver="v5.2"; $release="09-01-2023";

$line =	exec('timedatectl | grep "Time zone"'); //       Time zone: America/Chicago (CDT, -0500)
$line = str_replace(" ", "", $line);
$pos1 = strpos($line, ':');$pos2 = strpos($line, '(');
if ($pos1){  $zone   = substr($line, $pos1+1, $pos2-$pos1-1); }
else {$zone="America/Chicago";}
define('TIMEZONE', $zone);
date_default_timezone_set(TIMEZONE);
$phpzone = date_default_timezone_get(); // test it 
//if ($phpzone == $zone ){$phpzone="$phpzone set";}
//else{$phpzone="$phpzone ERROR";}

$phpVersion= phpversion();

$logRotate = 50000;// size to rotate at

$in="";
$iax          = "/etc/asterisk/iax.conf";
$rpi          = "/etc/asterisk/rpt.conf";
$manager      = "/etc/asterisk/manager.conf";

$tmpFile      = "/tmp/temp.dat";
$logger       = "/etc/asterisk/logger.conf";

$path  = "/etc/asterisk/local/mm-software";
$pathS = "/srv/http/supermon";
$pathG = "/srv/http/gmrs";
$pathGA= "/srv/http/gmrs/admin"; 
$pathGE= "/srv/http/gmrs/edit";

$supermonPath = $pathG;
$allmon       = "$pathGA/allmon.ini"; // new secure path  
$favorites    = "$pathG/favorites.ini";
$global       = "$pathG/global.inc";

// automatic node setup
$file=""; $in="check";
create_node ($file);// testing create it everytime 

$file= "$path/mm-node.txt"; 
if(file_exists($file)){
$line = file_get_contents($file);
$u= explode(",",$line);
$AutoNode=$u[0];$call=$u[1];$autotts=$u[2];
}

$file= "$path/node-name.txt";// imported from nodelist 
$name="";$city="";$state="";
if(file_exists($file)){
$line = file_get_contents($file);
$u= explode(",",$line);
$name=$u[1];$city=$u[2];$state=$u[3];//1=node 4=call
}



// make sure cron was installed
$file = "$path/cron-orginal.txt"; if (!file_exists($file)){setUpcron("cron");}

include ("$path/check_reg.php");

load($in); 

$file ="/var/lib/asterisk/sounds/rpt/nodenames/$node.ul"; 
if (!file_exists($file)){setOurCall($node);}

include ("$path/tagline.php");// $tagline="";tagline($tagline);print "$tagline (Have many nice days.)";
include ("$path/setup_install.php");// the functions

c64($in);
reg_check ($in);
check_bridge_installed ($in); // double check its installed.
$file="";

$stripe="============================================================";
start_menu($in);
start("start");

function start($in){
global $MuteNet1,$MuteNet2,$MuteNet3,$sleep,$call,$AutoNode,$stripe,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$search,$fileEdit,$ok;

$stdin = fopen('php://stdin', 'r');
$yes   = false;

while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Enter 1-2 E:_";
	$input = trim(fgets($stdin));
    if ($input == '1'){edit("edit");}
    if ($input == '2'){supermon("view");}
    if ($input == '3'){dvswitch("install");}
    
    if ($input == 'f'){reg_force("force");} 
    if ($input == 'a'){admin_sh_menu("reinstall");}
    if ($input == 'd'){doc("view");}     
   	if ($input == 'u'){install("I");}
    if ($input == 'x'){uninstall("x");}  
	if ($input == 'e'){quit('EXIT');}
    if ($input == ''){quit('EXIT');}
}
}



function reg_force($in){
global $counter,$watchdog,$NotReg,$datum;

print"
AT&T Fixed Wireless (UVERSE)routers may work for days but sudenly start blocking your port. 

Success rate for me is 100%. Your milage may vary. 
This is only for the following problem.
Your Router, Gateway, Modem or ISP Corrupts your open port so
it cant reach the reg server. 
I fix this by rotating the port# This forces a new path to the server.
Normaly registration is restored in a few seconds. 

After your back online the port will rotate back to default. On the next reboot.

Note: If you are using IAX client it wont be able to reconnect while on the alt port.

Watchdog can be set to run this fix automaticaly. 
";
reg_check ($in);
if($NotReg){reg_fix ("check");}
else {print"$datum This can only be run manualy if you are not registered.
"; }

start_menu($in);
}

function start_menu($in){
global $stripe,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll;
global $city,$state,$MuteNet1,$MuteNet2,$MuteNet3,$sleep;
global $phpVersion,$ver,$release, $phpzone,$call; 
print " 
$stripe
Setup Program  $ver  
(c) 2023 by WRXB288 LAGMRS.com all rights reserved 
PHP:$phpVersion Timezone: $phpzone  Release date:$release
$stripe
Welcome $call  Made in Louisiana
  
 Setup.php  program 
          
 1) Edit program Options
 2) Supermon Easy 1 Click Install
 3) DVSwitch Easy 1 Click Install
 
 A) Reinstall admin menu (fix menu)
 D) View the Docs
 F) Force Register Fix
 U) Upgrade (get the latest version)
 
 x) Uninstall This software. 
 E) Exit  
$stripe
";
} 
 

function editmenu(){
global $DisplayNodes,$city,$state,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$tts,$MuteNet1,$MuteNet2,$MuteNet3,$sleep,$debug,$IconBlock,$forcast,$beta,$AutoNode,$stripe,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate,$watchdog,$bridgeCheck;
global $burst,$phpVersion,$ver,$release, $phpzone,$call; 
$displayIconBlock="false";$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; 
$displayStatement="false";$displayReport="false";$displayForcast="false";$displaydebug="false"; $displaybridgeCheck= "false";
$displayMuteNet1="false";$displayMuteNet2="false"; $displayMuteNet3="false"; $displaySleep ="false";$displayNodes="No use Popup";
if ($sayWatch)    {$displayWatch =   "true";}
if ($sayWarn)     {$displayWarn     ="true";}
if ($sayAdvisory) {$displayAdvisory ="true";}
if ($sayStatement){$displayStatement="true";}
if ($forcast)     {$displayForcast  ="true";}
if ($reportAll)   {$displayReport   ="true";}
if ($IconBlock)   {$displayIconBlock="true";}
if ($debug)       {$displaydebug    ="true";}
if ($bridgeCheck) {$displaybridgeCheck= "true";}
if ($MuteNet1) {   $displayMuteNet1 ="true";}
if ($MuteNet2) {   $displayMuteNet2 ="true";}
if ($MuteNet3) {   $displayMuteNet3 ="true";}
if ($sleep)    {      $displaySleep ="true";}
if ($DisplayNodes){    $displayNodes ="YES";}
$burstDisplay="off";if($burst){$burstDisplay=$burst;}


print"
$stripe
(c) 2023 by WRXB288 LAGMRS.com all rights reserved 
PHP:$phpVersion  Installer:$ver  Release date:$release
Timezone: $phpzone
$stripe
Welcome $call  Made in Louisiana

 Setup editor.   Last write date:$saveDate

 1) Station [$station] Weather Station MADIS,APRSWXNET,Citizen Weather Observer Program (CWOP)
 2) Level Time [$level] 0=off 1=temp 2=cond 3=wind,hum,rain 4=Forcast (Levels to speak)
 3) Zipcode [$zipcode] for Acuweather conditions
 4) Location Lat:[$lat]/Lon:[$lon] needed for NWS API 
 5) SayWatch:$displayWatch SayAdvisory:$displayAdvisory SayStatement:$displayStatement 
 6) CPU Temp setup  HiTemp[$high]  Hot[$hot] Report normal temp[$displayReport]
 7) Node   Auto:[$AutoNode]  Node:[$node]
 9) Automatic Clock Muting  net1[$displayMuteNet1] net2[$displayMuteNet2] net3[$displayMuteNet3] sleep[$displaySleep]
 8) Display Node Scan on Supermon link page [$displayNodes] or in popup.
 0) Watchdog limit. will fix reg automaticaly after [$watchdog] falures 99=disable
 
 b) Bridging detection system [$displaybridgeCheck]
 c) Install into cron. (Done automaticaly. Manual reinstall)
 s) MDC-1200 burst [$burstDisplay] (for motorola guys)
 d) Debugging info [$displaydebug]
 u) Uninstall from cron. (Allows manual uninstall)
 W) Write to file.  (now automatic)
 M) Main menu
 E) Exit 
$stripe
";

// i) Forcast Icon block on supermon page [$displayIconBlock]

}

function supermonMenu(){
global $name,$city,$state,$forcast,$beta,$AutoNode,$stripe,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate,$search,$fileEdit,$ok;
print"
$stripe
This will set up GMRS Supermon for node:
$node $name $city $state

* One click automated install supermon. 
* Upgrade supermon to GMRS Supermon
* Add GMRS live index HUBS,Repeaters and nodes
* Add GMRS Logbook (soon)
* Remove Allstar branding and links. Add GMRS ones
* Add redirect from root to /supermon

 More later as updates come out. Use Update to install them.
 
----------------------------------------------------------------        
 Your existing supermon will be backed up. But as always make
 sure you have a backup of your card just in case.
 Use win32diskimager.org for card backups.       
---------------------------------------------------------------

 i) Setup supermon. 
  
 M) Main menu
 E) Exit  
$stripe
";
}






function quit($in){
global $phpVersion,$ver,$stripe,$phpzone,$release,$MuteNet1,$MuteNet2,$MuteNet3,$sleep,$forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$bridgeCheck;
save($in);
$path= "/etc/asterisk/local/mm-software";

print "
$stripe
(c) 2023 by WRXB288 LAGMRS.com all rights reserved 
PHP:$phpVersion  Installer:$ver  Release date:$release
Timezone: $phpzone
$stripe


Thank you for downloading.........Made in Louisiana


to test type

cd $path

php weather_pws.php
php temp.php
php cap_warn.php


this program is located in $path 
And can be run from the admin menu or by typing
php setup.php

$stripe
";

$tagline="";tagline($tagline);print "$tagline (Have many nice days.)";

c64("c64");

$file="$path/nodelist/clean.csv";
if (file_exists($file)){print "Nodelist exists\n";}
else{ print "Init Nodelist\n";exec("php $path/nodelist_process.php",$output,$return_var); }  


die;
}


function edit($in){
global $DisplayNodes,$city,$state,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$sleep,$forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$bridgeCheck;
editmenu();
$stdin = fopen('php://stdin', 'r');
$yes   = false;
while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Enter 1-9 M W E:_";
	$input = trim(fgets($stdin));
    if ($input == '1'){madis($station);}
    if ($input == '2'){level($level);}
    if ($input == '3'){zip($zipcode);}
    if ($input == '5'){warn($zipcode);}
    if ($input == '4'){location($lon);}
    if ($input == '6'){cpu($hot);}
    if ($input == '7'){setnode($node);}
    if ($input == '8'){lsnode("set");} 
    if ($input == '9'){muting("set");}
    if ($input == 'd'){debug("set");}
    if ($input == '0'){watchdog_set("set");}

    if ($input == 'b'){bridge("set");}
    if ($input == 'c'){setUpcron("set");}
    if ($input == 's'){setBurst("set");}
    if ($input == 'u'){unSetcron("set");}
    if ($input == 'm'){start_menu($in);start("start");}
    if ($input == 'w'){save("save");}
	if ($input == 'e'){quit('EXIT');}
}

}




function supermon($in){
global $name,$city,$state,$forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll;
supermonMenu();
$stdin = fopen('php://stdin', 'r');
$yes   = false;

while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Enter 1-7 M E:_";
	$input = trim(fgets($stdin));
    if ($input == 'i'){supermonGo("GO baby");}

    if ($input == 'm'){start_menu($in);start("start");}
	if ($input == 'e'){quit('EXIT');}
}

}


                                            

// -------------------------------------------------------------supermon ----------------------------------------------
function supermonGo($in){
global $name,$city,$state,$zipcode,$call,$password,$forcast,$beta,$AutoNode,$path,$node,$iax,$rpi,$manager,$supermonPath,$allmon,$favorites,$global,$tmpFile,$logger,$watchdog,$name,$location,$ip,$search,$fileEdit,$ok ;
print "
---------------------------------------------------------------
Name:$name City:$city State:$state

This will set up GMRS Supermon for node:$node

One click automated setup of GMRS supermon.
GMRS Supermon should already have been instaled but you may
wish to run update to get the latest version.

Use to setup Supermon after install. This does not touch existing
orginal supermon.
---------------------------------------------------------------        

  i) install   Any other key to abort!
  
";
  
$a = readline('Enter your command: ');

if ($a=="i"){
save_task_log ("Setting up GMRS Supermon");


$path  = "/etc/asterisk/local/mm-software";
$pathS = "/srv/http/supermon";
$pathG = "/srv/http/gmrs";
$pathGA= "/srv/http/gmrs/admin"; $path5 = $pathGA ;
$pathGE= "/srv/http/gmrs/edit";

$supermonPath = $pathG;
$allmon       = "$pathG/admin/allmon.ini"; // new secure path  
$favorites    = "$pathG/favorites.ini";
$global       = "$pathG/global.inc";


$line = readline("The Name for supermon page: $name ");if ($line){$name=$line;}
$location = readline("The Location for supermon page: $city $state");


$pass = getRandomString(9);

print "GMRS Supermon needs a password to access the manager
Random generated password [$pass] 

This is not the logon password its located in the manager file.
If you already have supermon setup changing the password will
log out the existing supermon. In this canse you should enter
the existing password.
\n";
$line = readline("Enter a password or just return for [$pass]");
if ($line){$password=$line;}
else {$password=$pass;}

$manager= "/etc/asterisk/manager.conf";// There is only 1 password in this file
$fileEdit=$manager;$search= "secret =";$hide=false;edit_config("secret =$password");
 
print "Password [$password] entered in $manager\n";

// $allmon       = "$pathGA/allmon.ini"; // new secure path  
buildAllmon($node);
if (file_exists($allmon)){print "Password entered in [$allmon] secured in the ADMIN directory.\n";}
else {print "error [$allmon] not found\n";die;}

//chdir($pathG);

chdir($pathGA);


// $file="$pathGA/.htpasswd";if (file_exists($file)){ unlink($file); }

print "
In order to secure GMRS Supermon a new ADMIN director was created that does not
use unsecure session keys. The new directory is secured by a web server password.
This requires you to enter a password now.   

$pathGA directory Username:admin \n";

exec ("htpasswd -c .htpasswd admin",$output,$return_var);


$out="#Protect Directory
AuthName \"GMRS Supermon\"
AuthType Basic
AuthUserFile $pathG/.htpasswd
Require valid-user

<FilesMatch \"\.(htaccess|htpasswd|ini|ini.php|log|sh|inc|bak|save)$\">
Order Allow,Deny
Deny from all
</FilesMatch>";

$file="$pathG/admin/.htaccess";print"Protecting admin\n";
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$out); flock ($fileOUT, LOCK_UN );fclose ($fileOUT);

//$file="$pathG/edit/.htaccess"; print"Protecting edit\n";
//$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$out); flock ($fileOUT, LOCK_UN );fclose ($fileOUT);



print "Building global.ini  $call \n"; buildGlobal($node);
print "Building fav  \n";buldFav("fav");

$rpi="/etc/asterisk/rpt.conf"; 
print "Insalling Connect and Disconnect logging into $rpi\n";
$fileEdit=$rpi;$search="connpgm=/usr/";$hide=false;edit_config("connpgm=/usr/local/sbin/supermon/smlogger 1");
$fileEdit=$rpi;$search="discpgm=/usr/";$hide=false;edit_config("discpgm=/usr/local/sbin/supermon/smlogger 0"); 

$fileEdit="$pathG/common.inc";
$search   = "TITLE_LOGGED";
$formated = "#TITLE_LOGGED = 'GMRS Supermon Node Manager 6.2+ Mod';";
$formated = str_replace('#', '$', $formated); $formated = str_replace("'", '"', $formated);
$hide=false;edit_config($formated); 

$fileEdit="$pathG/common.inc";
$search   = "TITLE_NOT_LOGGED";
$formated = "#TITLE_NOT_LOGGED = 'GMRS Supermon Node Manager';"; 
$formated = str_replace('#', '$', $formated); $formated = str_replace("'", '"', $formated);
$hide=false;edit_config($formated); 


$logger="/etc/asterisk/logger.conf";
print "Adjusting settings to messages in $logger\n";
$fileEdit=$logger;$search= "messages =>";$hide=false;edit_config("messages => notice,warning,error");


print "Upgrading root directory of web server to modern 2023 standards.\n";
$file="/srv/http/index.html";if (file_exists($file)) {unlink ($file);}
$file="/srv/http/index.php" ;if (file_exists($file)) {unlink ($file);}


// install redirect
$file="/srv/http/index.php" ;
$fileOUT = fopen($file, "w");
$out = "<?php
header('Location: /gmrs/link.php?nodes=$node');
die();
?>";// <?php
fwrite ($fileOUT, $out);fclose ($fileOUT);


print"-----------------------------------------------------------
Requesting ast restart......";
exec ("astres.sh",$output,$return_var);  // Run restart
print "ok\n";
print"Your supermon is setup visit the url with a web browser $ip
=================================================================
One click supermon install finished.";

}
start_menu($in);
start("start");
}

//$MuteNet1,$MuteNet2,$MuteNet3

function muting($in){
global $Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$sleep;

$displayMuteNet1="false";$displayMuteNet2="false"; $displayMuteNet3="false"; $displaySleep ="false";

if ($MuteNet1) {   $displayMuteNet1 ="true";}
if ($MuteNet2) {   $displayMuteNet2 ="true";}
if ($MuteNet3) {   $displayMuteNet3 ="true";}
if ($sleep)    {      $displaySleep ="true";}

print "
Automatic muting system for clock/alerts.
No more speaking during nets.
All times are your local time.

Roadkill TexasGMRS nets 
Wed net $Net1Start-$Net1Stop [$displayMuteNet1] Wind down wed
Sun net $Net2Start-$Net2Stop [$displayMuteNet2] Family fun night
Fri net $Net3Start-$Net3Stop [$displayMuteNet3] Bernies round table 

Mute at night 1-6am [$displaySleep] sleep mode.  

Just press return to keep the current values.
";
$line = readline("Mute net1 wed y/n: ");
if ($line=="y"){$MuteNet1=true;}
if ($line=="n"){$MuteNet1=false;}

if($MuteNet1){
$line = readline("Start time 24hr $Net1Start:");
if ($line){$Net1Start=$line;}
$line = readline("Stop time 24hr $Net1Stop:");
if ($line){$Net1Stop=$line;}
}

$line = readline("Mute net2 sun y/n: ");
if ($line=="y"){$MuteNet2=true;}
if ($line=="n"){$MuteNet2=false;}

if($MuteNet2){
$line = readline("Start time 24hr $Net2Start:");
if ($line){$Net2Start=$line;}
$line = readline("Stop time 24hr $Net2Stop:");
if ($line){$Net2Stop=$line;}
}
$line = readline("Mute net3 fri y/n: ");
if ($line=="y"){$MuteNet3=true;}
if ($line=="n"){$MuteNet3=false;}

if($MuteNet3){
$line = readline("Start time 24hr $Net3Start:");
if ($line){$Net3Start=$line;}
$line = readline("Stop time 24hr $Net3Stop:");
if ($line){$Net3Stop=$line;}
 }


$line = readline("Mute at Night 1-6am y/n: ");
if ($line=="y"){$sleep=true;}
if ($line=="n"){$sleep=false;}

editmenu();
}


function bridge($in){
global $bridgeCheck;

$displaybridgeCheck="false";
if ($bridgeCheck) {   $displaybridgeCheck ="true";}
print "
Automatic bridging detection/auto disconnect [$displaybridgeCheck]
If a bridge is detected it will be aborted.

This stops acidental bridging and stops someone from making a bridge from
DTMF tones. (Ongoing Beta) Please report any problems.
This is compatable with DV switch see comments in DV switch install. 
";
$line = readline("Set to t/f: ");
if ($line=="t"){$bridgeCheck=true;}
if ($line=="f"){$bridgeCheck=false;}
editmenu();
}



function debug($in){
global $debug,$forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayDebug="false";
if ($debug){        $displayDebug     ="true";}
print "
Debugging gives extra info..
Debug is set to [$displayDebug]
";
$line = readline("Set to t/f: ");
if ($line=="t"){$debug=true;}
if ($line=="f"){$debug=false;}
editmenu();
}

function setBurst($in){
global $burst,$call,$node;
$burstDisplay="off";if($burst){$burstDisplay=$burst;}
print "
MDC-1200 bursts can be sent on the local radio before the clock plays.
You can enter a node# call or something else. It does not transmit into the network.

Many MDC-1200 systems utilize the unit ID option. With each push-to-talk press,
the radio sends a data burst identifying the sending radio. Unit IDs are decoded
as unique hexadecimal four-digit numbers. Every radio would have a unique
four-digit ID.    [$burstDisplay]

 0) to turn off 
";
$line = readline("Change from $burstDisplay to: ");
if ($line <>0) {$burst=$line;}
else {$burst="";}

editmenu();
}



function setnode($station){
global $forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false";
print "
Node1 is auto detected on install if you need to change this you can do so here

AutoDetect node:$AutoNode Node set to $node:

";
$line = readline("Node $node: ");
if($line){$node=$line;}
editmenu();

}


function madis($station){
global $forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false";
print "
We need the code for you local weather station. 
Find your local MADIS station code at 
https://madis-data.ncep.noaa.gov/MadisSurface/

The Meteorolical Assimilation Data Ingest System
contains stations from APRSWXNET
CWOP(Citizen Weather Observer Program) 

The APRSWXNET/Citizen Weather Observer Program (CWOP) is a private-public partnership
with the goals of collecting weather data contributed by citizens and making these
data available for weather services and research activities. Upon integration into
the MADIS database, the observations become available to hundreds of users in the
meteorological community, including the majority of National Weather Service (NWS)
forecast offices, the National Climatic Data Center (NCDC), the National Operational
Hydrologic Remote Sensing Center (NOHRSC), and many universities and private companies.

";
$line = readline("Local Station $station: ");
$station = $line;
editmenu();
}


function level($level){
global $forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false";
print "
When the time and temp runs how much detal do you want?
0= off 1=temp,2=cond 3=wind,hum,rain 4=Forcast  (Levels to speak)

";
$line = readline("Level $level: ");
$level = $line;
editmenu();
}

function zip($level){
global $zipcode;
$line = readline("Enter your ZipCode $zipcode: ");
$zipcode = $line;
editmenu();
}

function zip2($level){
global $zipcode;
$line = readline("Enter your ZipCode $zipcode: ");
$zipcode = $line;
location($zipcode);
}


function cpu($level){
global $forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false";
if ($reportAll)   {$displayReport   ="true";}
print "
 CPU Temp setup
 
 HiTemp[$high] alarm.
 Hot   [$hot]  warning.
 Report Normal temps [$displayReport] for testing only
 generates a report every 15min.

";
$line = readline("HiTemp default 60: ");
if ($line>55){$high=$line;}

$line = readline("HotTemp default 50: ");
if ($line>49){$hot=$line;}

$line = readline("Report Normal temps y/n: ");
if ($line=="y"){$reportAll=true;}
else{$reportAll=false;}

editmenu();
}


function location($in){
global $city,$state,$forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
print "
Your LAT/LON is required for the National Weather Service new forcast alert system.
The more accurate your location is the better tornado/storm reports you will get.
Setup will build a default based on node city state but you need to check it.

Use your phone or go to http://gps-coordinates.org

 1) Enter Lat/Lon  :[$lat]/[$lon] 
 2) Enter Zipcode  :[$zipcode]
 3) Look up Lat/Lon by ZIP code [$zipcode]
 4) Look up Zip for your city:[$city] State:[$state]
 B) Back to edit menu

 E) Exit\n";
 
$stdin = fopen('php://stdin', 'r');
$yes   = false;
while (!$yes)
{
    $datum = date('m-d-Y-H:i:s');
	print "$datum Enter 1-2 B E:_";
	$input = trim(fgets($stdin));
    if ($input == '1'){locationEnter($station);}
    if ($input == '3'){lookupgps($zipcode);}
    if ($input == '2'){zip2($zipcode);}
    if ($input == '4'){lookupzip($city);location($in);}
    if ($input == 'b'){$yes= true;}
    if ($input == 'm'){$yes= true;}
    if ($input == 'q'){$yes= true;}
	if ($input == 'e'){quit('EXIT');}
}
editmenu();
}

function locationEnter($in){
global $lat,$lon;
$line = readline("Lat: ");
if($line){$lat=$line;}
$line = readline("Lon: ");
if($line){$lon=$line;}
location();
}

function lsnode($in){
global $DisplayNodes;
print "

Node Scan is my own version of lsnodes written from scratch in php with a better display
it finds all nodes connected to the HUB and finds all the nodes on other hubs connected
to that hub. 
So basicaly your seeing a static status page of all the nodes connected to the HUB.
It is static you have to reload it to update. Keeping cpu cycles low is important.

You have the choice of displaying this at the botom of the page.


\n";
$line = readline("Display nodes on supermon page y/n: ");
if ($line=="y"){$DisplayNodes=true;}
if ($line=="n"){$DisplayNodes=false;}
editmenu();
}
 



function watchdog_set($in){
global $watchdog;

print "
Watchdog timmer.  On this many falures [$watchdog] take action.

In case you get Not Registered abd it wont come back online it will rotate
the port to a random port and restart ast. This solves my ATT Fixed Wireless problem 

Which is designed to bypasses a port block on your modem, router or ISP.

3 or 4 recomended 

If you are having problems staying registered after a few days you can try this. 
If it doesnt work o well its something to try works for me....

Set to 99 to disable.   
";
$line = readline("Watchdog timmer $watchdog: ");
$watchdog = $line;
if($watchdog==""){$watchdog=2;}
editmenu();
}




function doc($in){
global $forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate,$stripe;
$i=0;
$file="$path/readme.txt";
print "
 Loading the readme.txt file
$stripe
";
$fileIN= file($file);
foreach($fileIN as $line){
print $line; $i++ ;
if ($i >42){$line = readline(" ");$i=0;}
}
print "$stripe
End of File
";
$line = readline("Hit Return for menu");
start_menu($in);start("start");
}

function warn($skywarn){
global $forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$testNewApi,$high,$hot,$nodeName,$reportAll,$saveDate;
$displayWatch="false"; $displayWarn="false";$displayAdvisory="false"; $displayStatement="false";$displayReport="false"; 
if ($sayWatch)    {$displayWatch =   "true";}
if ($sayWarn)     {$displayWarn     ="true";}
if ($sayAdvisory) {$displayAdvisory ="true";}
if ($sayStatement){$displayStatement="true";}

print "
Cap Warn uses Common Alerting Protocol (CAP) from the NWS
The new API needs your LAT/LON  [$lat/$lon]


Customise what reports you want
SayWarning   true <hard coded>
SayWatch     $displayWatch
SayAdvisory  $displayAdvisory
SayStatement $displayStatement 
 
";
$line = readline("Say Watches y/n: ");
if ($line=="y"){$sayWatch=true;}
if ($line=="n"){$sayWatch=false;}

$line = readline("Say Advisory y/n: ");
if ($line=="y"){$sayAdvisory=true;}
if ($line=="n"){$sayAdvisory=false;}

$line = readline("Say Statement y/n: ");
if ($line=="y"){$sayStatement=true;}
if ($line=="n"){$sayStatement=false;}
editmenu();
}




function load($in){
global $burst,$DisplayNodes,$name,$city,$state,$phpzone,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$bridgeCheck,$autotts,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$forcast,$beta,$saveDate,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog;
  $pathNull="";
  
if (is_readable("$path/setup.txt")) {
   $fileIN= file("$path/setup.txt");
   
   foreach($fileIN as $line){
    $u = explode(",",$line);
          $pathNull =  $u[0];// Just padding not really used 
             $node  =  $u[1];
          $station  =  $u[2];
             $level =  $u[3];
         $zipcode   =  $u[4];
         $IconBlock =  $u[5];
               $lat =  $u[6];
               $lon =  $u[7];
           $sayWarn =  $u[8];
          $sayWatch =  $u[9];
       $sayAdvisory = $u[10];
      $sayStatement = $u[11];
        $sleep      = $u[12];
              $high = $u[13]; 
               $hot = $u[14];
          $nodeName = $u[15];
         $reportAll = $u[16];
          $saveDate = $u[17];
           $forcast = $u[18]; // not used
              $beta = $u[19];
          $watchdog = $u[20];
             $debug = $u[21];
               $tts = $u[22]; // test t speach 
       $bridgeCheck = $u[23]; 
       $MuteNet1    = $u[24]; 
       $MuteNet2    = $u[25];
       $MuteNet3    = $u[26];
       $Net1Start   = $u[27];
       $Net1Stop    = $u[28];
       $Net2Start   = $u[29];
       $Net2Stop    = $u[30]; 
       $Net3Start   = $u[31];
       $Net3Stop    = $u[32];
       $DisplayNodes= $u[33];
       $burst       = $u[34];
    }
}
// If its missing create a defult
else {
// set default
$status ="Building default settings";save_task_log ($status);
print "$datum $status\n";

$reportAll = false;$nodeName = "server";$high=60;$hot=50;$in="";
// https://madis-data.ncep.noaa.gov/MadisSurface/
$station="KAEX";$level = 3 ;  // Alexandria International Airport (AEX)
$zipcode="";lookupzip ($in);// get a zip from city state

$IconBlock= true; $skywarn ="";
$lat ="31.3273"; $lon="-92.5485"; // Alexandria International Airport	31.3273717,-92.5485558
lookupgps($in); // make from zip or just use default

$sleep=true;$tts=$autotts; $DisplayNodes=false;
$sayWarn=true;$sayWatch=true;$sayAdvisory=true;$sayStatement =true;
$node = $AutoNode;$forcast= false;$beta = false; $debug=false;
$watchdog = 10; 

// set mute to off for default
$MuteNet1 = false; $MuteNet2 = false; $MuteNet3 = false;
$Net1Start= 19; $Net1Stop= 20;
$Net2Start= 18; $Net2Stop= 19;
$Net3Start= 20; $Net3Stop= 21;


if ($phpzone=="America/Chicago"){ // louisiana
$MuteNet1 = true; $MuteNet2 = true;
$Net1Start= 19; $Net1Stop= 20;
$Net2Start= 18; $Net2Stop= 19;
$Net3Start= 20; $Net3Stop= 21;
}

if ($phpzone=="America/Denver"){ // 
$Net1Start= 20; $Net1Stop= 21;
$Net2Start= 19; $Net2Stop= 20;
$Net3Start= 21; $Net3Stop= 22;
}
 
$bridgeCheck = true;$burst="";
save ("save");
 }
}

function save($in){
global $burst,$DisplayNodes,$Net1Start,$Net1Stop,$Net2Start, $Net2Stop,$Net3Start,$Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$tts,$debug,$datum,$forcast,$beta,$AutoNode,$path,$node,$station,$level,$zipcode,$IconBlock,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$sleep,$high,$hot,$nodeName,$reportAll,$watchdog,$bridgeCheck;

$path4 = "$path/backup";if(!is_dir($path4)){ mkdir($path4, 0755);}
$file = "$path/setup.txt";$dow = date('w');$fileBU = "$path4/setup.txt.$dow";
if (file_exists($file)){
if (file_exists($fileBU)){unlink($fileBU);}
copy($file, $fileBU); $status ="Backup settings to $fileBU";save_task_log ($status); 
print"$datum $status\n";
} 

$fileOUT = fopen("$path/setup.txt", "w");
$status ="Writing settings";save_task_log ($status);
print "$datum $status\n";

fwrite ($fileOUT, "$path,$node,$station,$level,$zipcode,$IconBlock,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$sleep,$high,$hot,$nodeName,$reportAll,$datum,$forcast,$beta,$watchdog,$debug,$tts,$bridgeCheck,$MuteNet1,$MuteNet2,$MuteNet3,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$DisplayNodes,$burst,,,,,,,,,,,");
fclose ($fileOUT);
}




function clean_repo($in){
chdir($in);
$files = glob($in.'/*'); 
foreach($files as $filed) {
   if($filed == '.' || $filed == '..') continue;
   if (is_file($filed)) { unlink($filed);print"del $filed\n";  }
 }
}




function create_node ($file){
global $file,$path;
// keep this file up to date
$file ="/usr/local/etc/allstar_node_info.conf"; $autotts=""; 
//copy($file, "$path/allstar_node_info.conf"); we no longer need this
$fileIN= file($file);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$line = str_replace('"', "", $line);
$pos = strpos("-$line", 'NODE1=');
if ($pos){$u= explode("=",$line);
$node=$u[1];}
$pos2 = strpos("-$line", 'STNCALL='); 
if ($pos2){$u= explode("=",$line);
$call=$u[1];}
}
// Get any tss key if exists   RESERVED for Future use
$file ="/usr/local/etc/tts.conf";
$fileIN= file($file);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$line = str_replace('"', "", $line);
$pos = strpos("-$line", 'tts_key=');
if ($pos){$u= explode("=",$line);
$autotts=$u[1];}
}
$file= "$path/mm-node.txt";// This will be the AutoNode varable
$fileOUT = fopen($file, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$node,$call,$autotts, , ,");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
}


// anti Bridging system Check installed.
function check_bridge_installed ($status){
global $search,$path,$fileEdit,$ok;
$fileEdit ="/usr/local/sbin/sm-support/smlogger_background.sh";
$fileBu = "$fileEdit-.bak"; 

if (!file_exists($fileBu)){
print"Installing anti Bridiging system\n";

$search='echo $LOGINFO'; 
$in="echo #LOGINFO |sed 's/ +/ /g' >> #LOGFILE

php /etc/asterisk/local/mm-software/connect.php #LOGINFO

";
$in = str_replace('#', '$', $in);
$hide=false;edit_config($in);// $search=search for line  $in=change to $fileEdit=file   out $ok=true


$search="";$path="";
} 
exec("sudo chmod +x /usr/local/sbin/sm-support/smlogger_background.sh",$output,$return_var); 
}

 //
// $status ="what to log ";save_task_log ($status);print "$datum $status
//";
//
function save_task_log ($status){
global $path,$error,$datum,$logRotate;

$datum  = date('m-d-Y H:i:s');
if(!is_dir("$path/logs/")){ mkdir("$path/logs/", 0755);}
chdir("$path/logs");
$log="$path/logs/log.txt";
$log2="$path/logs/log2.txt"; //if (file_exists($mmtaskTEMP)) {unlink ($mmtaskTEMP);} // Cleanup

// log rotation system
if (is_readable($log)) {
   $size= filesize($log);
   if ($size > $logRotate){
    if (file_exists($log2)) {unlink ($log2);}
    rename ($file, $log2);
    if (file_exists($log)) {print "error in log rotation";}
   }
}

$fileOUT = fopen($log, 'a+') ;
flock ($fileOUT, LOCK_EX );
fwrite ($fileOUT, "$datum,$status,,\r\n");
flock ($fileOUT, LOCK_UN );
fclose ($fileOUT);
}


function dvswitch($in){
global $node,$call;
print " DV Switch easy installer. 

This Installs DV Switch but you will still need to open a port
on your router. Recomend you test your phone on your LAN and get that working
first before you try remote connections.  

In order for this to work with the anti bridging system you must use your
ID [$call] as the caller ID so it will be ignored and not treated as a bridge.
Using a ID other than the one listed above will create a bridge alarm. 

Press (i) to install DV Switch
";

$a = readline('Enter your command: ');

if ($a == "i"){

$password = getRandomString(6);
print "Using random password of [$password] on IAX connection.\n";
edit_iax_DV($password);
edit_extensions($password);

$localIP = getHostByName(getHostName());

$sock = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
socket_connect($sock, "8.8.8.8", 53);
socket_getsockname($sock, $name); 
// This is the local machine's external IP address
$ip = $name;
$port = find_port ("port");

print " Thats it DV-Switch is installed.
Setup DV SWitch APP as listed here.

Protocol IAX2
Hostname $ip or on a LAN $localIP
Port     $port
Password $password
CallerID $call 
Node     $node

";
}
}

function admin_sh_menu(){
$file ="/usr/local/sbin/firsttime/adm01-shell.sh";
$file2="/usr/local/sbin/firsttime/mmsoftware.sh";
if (file_exists($file2)){unlink ($file2);}
copy($file, $file2);// copy existing to get correct permissions
$file= $file2;
$out='#/!bin/bash
#MENUFT%055%Time/Weather/Node Manager Setup

$SON
reset

php /etc/asterisk/local/mm-software/setup.php

exit 0
';
// overwrite with our menu.
$fileOUT = fopen($file, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, $out);flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
 exec("sudo chmod +x $file",$output,$return_var);
} 

function edit_extensions($in){ 
global $search,$path,$fileEdit,$ok,$node,$password;

$ok=false;$line=""; $search= "[dvswitch-iaxrpt]";
$fileEdit= "/etc/asterisk/extensions.conf";
if (file_exists($fileEdit)){
$fileBu = "$fileEdit-.bak"; if (!file_exists($fileBu)){copy($fileEdit,$fileBu);} // This creates a orginal backup
$tmpFile="$fileEdit-new.txt"; 

$fileIN= file($fileEdit);
$fileOUT = fopen($tmpFile, "w") or die ("Error $tmpFile Write falure");
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", $search); 
if ($pos>=1){
$formated="[dvswitch-iaxrpt]  
exten => $node,1,Answer
exten => $node,n,Playback,rpt/node
exten => $node,n,Playback,digits/1
exten => $node,n,Playback,digits/9
exten => $node,n,Playback,digits/9
exten => $node,n,Playback,digits/8
exten => $node,n,Set(CALLERID(num)=0)
exten => $node,n,Rpt,2955|P|#{CALLERID(name)} 
"; $formated = str_replace('#', '$', $formated);

$ok=true;fwrite ($fileOUT, "$formated\n"); break;
}  
fwrite ($fileOUT, "$line\n");
}

if (!$ok){ $formated="[dvswitch-iaxrpt] 
exten => $node,1,Answer
exten => $node,n,Playback,rpt/node
exten => $node,n,Playback,digits/1
exten => $node,n,Playback,digits/9
exten => $node,n,Playback,digits/9
exten => $node,n,Playback,digits/8
exten => $node,n,Set(CALLERID(num)=0)
exten => $node,n,Rpt,2955|P|#{CALLERID(name)}
"; 
fwrite ($fileOUT, "$formated\n");
}


fclose ($fileOUT);
// if ok then we found it
if ($ok){
if (file_exists($tmpFile)){ unlink($fileEdit);} 
rename ($tmpFile, $fileEdit); 

save_task_log ("Edit $fileEdit search:$search");

   } // rename
else{
print "error";}
}   


// try to prevent stray data
$fileEdit="";$search="";print"\n";
}


// THE Main IAX editor for DVSWITCH 
function edit_iax_DV($in){ 
global $search,$path,$fileEdit,$ok,$hide,$node,$password;

$ok=false;$line=""; 
$fileEdit= "/etc/asterisk/iax.conf";

if (file_exists($fileEdit)){
$fileBu = "$fileEdit-.bak"; if (!file_exists($fileBu)){copy($fileEdit,$fileBu);} // This creates a orginal backup
$tmpFile= "$fileEdit-new.txt"; 
$fileIN= file($fileEdit);
$fileOUT = fopen($tmpFile, "w") or die ("Error $tmpFile Write falure");

foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", "[DVSWITCH]"); if ($pos){$ok=true; break;}// if found stop...  
fwrite ($fileOUT, "$line\n");
}
// we are stoping here and adding our info. If it was already there we just rewrite it.
// This requires nothing be added under this or it will be erased.

$line="[DVSWITCH]
type=friend
context=dvswitch-iaxrpt
host=dynamic
auth=md5
secret=$password
disallow=all
allow=ulaw
transfer=no
calltokenoptional=0.0.0.0/0.0.0.0
requirecalltoken=no

";
fwrite ($fileOUT, "$line\n");
}
fclose ($fileOUT);

// now if we added we swap it in if it already existed we just stop.
// This needs to be changed so it can overwrite but not for now,.
if ($ok){
if (file_exists($tmpFile)){ unlink($fileEdit);} 
rename ($tmpFile, $fileEdit); 
save_task_log ("Edit $fileEdit search:$search");
} 
else{print "error";}
  


// try to prevent stray data It keeps showing up with left overs...
$fileEdit="";$search="";print"\n";
}



//this is my own editor to search and replace
// v2 7/28/2023
// $search=search for line  $in=change to $fileEdit=file   out $ok=true
function edit_config($in){ 
global $search,$path,$fileEdit,$ok,$hide;

if(!$hide){print "Search for $search in file:$fileEdit ";}
$ok=false;$line="";
if (file_exists($fileEdit)){

$fileBu = "$fileEdit-.bak"; if (!file_exists($fileBu)){copy($fileEdit,$fileBu);} // This creates a orginal backup

if(!file_exists($fileBu)and !$hide){ print "Unable to BackUP.";}

$tmpFile="$fileEdit-new.txt"; // keep in the same dir so we wont have to copy

$fileIN= file($fileEdit);
$fileOUT = fopen($tmpFile, "w") or die ("Error $tmpFile Write falure");
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", $search); 
if ($pos>=1){
$line=$in;$ok=true;
if(!$hide){print"$line Replacing with $in <ok>"; } // Replace the found line with a new one.
}  
fwrite ($fileOUT, "$line\n");
}

fclose ($fileOUT);
// if ok then we found it
if ($ok){
if (file_exists($tmpFile)){ unlink($fileEdit);} 
rename ($tmpFile, $fileEdit); 

save_task_log ("Edit $fileEdit search:$search");

   } // rename
else{
if(!$hide){print "not found";}
}   
  } //file exist

// try to prevent stray data
$fileEdit="";$search="";print"\n";
}





// global.inc'
function buildGlobal($in){
global $zipcode,$global,$path,$file,$tmpFile,$ok,$password,$node,$call,$name,$location,$pathG;
$file = $global;
$fileOUT = fopen($file, "w") or die ("Error $file Write falure\n");  // 
// 21600 = 6 hrs 3600 = 1 hr
$formated="
<?php
#CALL = '$call';
#NAME = '$name';
#LOCATION = '$location';
#TITLE2 = 'GMRS Live Node ';
#TITLE3 = 'System Node Manager';
#BACKGROUND = 'background.jpg';
#BACKGROUND_COLOR = 'blue';
#BACKGROUND_HEIGHT = '124px';
#REFRESH_DELAY = '3600';
#SHOW_COREDUMPS = 'yes';
#LOCALZIP = '$zipcode';
#MAINTAINER = '';
?>
";//  <?php
$formated = str_replace("'", '"', $formated);
$formated = str_replace('#', '$', $formated);
fwrite ($fileOUT, $formated);
fclose ($fileOUT);
print "saving $global \n";
save_task_log ("$file saved");
 }

 
function buldFav($in){
global $favorites,$path,$file,$tmpFile,$ok,$password,$node,$pathG;
//$favorites    = "$pathG/favorites.ini";
$file = $favorites;

// no backup needed we now install into our own directory
//if (file_exists($file)){
//$fileBu = "$file-.bak"; if (file_exists($fileBu)){ unlink($fileBu); }
//copy($file,$fileBu);if(!file_exists($fileBu)){ print "Unable to make a BackUP.";}

$fileOUT = fopen($file, "w") or die ("Error $file Write falure\n");  // 

$formated="
[general]

label[] = 'RoadKill 1195'
cmd[] = 'rpt cmd %node% ilink 3 1195'

label[] = 'RoadKill DV Switch 1167'
cmd[] = 'rpt cmd %node% ilink 3 1167'

label[] = 'Texas GMRS Network 2250'
cmd[] = 'rpt cmd %node% ilink 3 2250'

label[] = 'Nationwide Chat 700'
cmd[] = 'rpt cmd %node% ilink 3 700'

label[] = 'The Lone Wolf 1691'
cmd[] = 'rpt cmd %node% ilink 3 1691'

label[] = 'ALAMO CITY 1510'
cmd[] = 'rpt cmd %node% ilink 3 1510'

label[] = 'CENTRAL ILLINOIS 1915'
cmd[] = 'rpt cmd %node% ilink 3 1915'

label[] = 'Edit Favorties.ini to add content'
cmd[] = 'NONE'
";

$formated = str_replace("'", '"', $formated);
fwrite ($fileOUT, $formated);
fclose ($fileOUT);
print "saving $favorites  \n";
save_task_log ("$file saved");
}






//  This builds a secure allmon in the ADMIN area
function buildAllmon($in){
global $allmon,$path,$file,$tmpFile,$ok,$password,$node,$pathGA;

//$allmon       = "$pathG/admin/allmon.ini"; // new secure path  
$file = $allmon; // = "/srv/http/gmrs/admin";

if (file_exists($file)){
$fileBu = "$file-.bak"; 
 if (file_exists($fileBu)){ unlink($fileBu); } 
 copy($file,$fileBu);
 if(!file_exists($fileBu)){ print "Unable to make a BackUP.";}
}

$fileOUT = fopen($file, "w") or die ("Error $file Write falure\n");  // 

$formated="
[$node]
host=127.0.0.1:5038
user=admin
passwd=$password
menu=yes
system=Nodes
hideNodeURL=no

[All Nodes]
system=Display Groups
nodes=$node
menu=yes


[Directory]
url='/supermon/gmrs-node-index.php?type=hub&sort=live&code=08082023'
menu=yes

[List Nodes]
url='/supermon/lsnodes.php'
menu=yes

[Gmrs Live]
url='https://www.gmrslive.com/''
menu=yes
system= Bookmarks

[RoadKill Website]
url='http://roadkill.network'
menu=yes
system= Bookmarks

[Texas GMRS Website]
url='https://www.texasgmrs.net/''
menu=yes
system= Bookmarks

[Alamo City GMRS Community]
url='http://1510.node.gmrslive.com/supermon'
menu=yes
system= Network Status Pages

[Broadnet GMRS Repeater Systems]
url='https://status.broadnetgmrs.net/'
menu=yes
system= Network Status Pages

[Central Illinois GMRS Live Hub]
url='http://1915.node.gmrslive.com/supermon'
menu=yes
system= Network Status Pages

[GMRS Live Hub]
url='http://gmrslive.com/status/link.php?nodes=700,900'
menu=yes
system= Network Status Pages

[Hammond HUB]
url='http://1171.node.gmrslive.com/supermon/link.php?nodes=1171'
menu=yes
system= Network Status Pages

[Lone Wolf System]
url='http://www.lonewolfsystem.org/supermon/link.php?nodes=1691'
menu=yes
system= Network Status Pages

[Ottawa Lake MI]
url='http://1171.node.gmrslive.com/supermon/link.php?nodes=1114'
menu=yes
system= Network Status Pages

[South Dade GMRS Club]
url='http://1806.node.gmrslive.com/supermon'
menu=yes
system= Network Status Pages

[Southeast Mishigami Hub - Ottawa Lake, MI]
url='http://1114.node.gmrslive.com/supermon/link.php?nodes=1114'
menu=yes
system= Network Status Pages

[Southwest Michigan HUB]
url='http://1082.node.gmrslive.com/supermon/link.php?nodes=1082'
menu=yes
system= Network Status Pages

[Texas GMRS Network]
url='https://link.texasgmrs.net/link.php?nodes=2250,2251,2252,2253,2254,1000,922'
menu=yes
system= Network Status Pages

[The RoadKill !! Repeater System]
url='http://roadkill.network/''
menu=yes
system= Network Status Pages


";
$formated = str_replace("'", '"', $formated);

fwrite ($fileOUT, $formated);
fclose ($fileOUT);
print "saving $allmon \n";
save_task_log ("$file saved");
}


// build a password
function getRandomString($n){
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';

    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }
    save_task_log ("IAX password $randomString");
    return $randomString;
}



// remove from chron
function unSetcron($in){
global $search,$node1,$path;
print"restoring cron ";
 
// install the backup

$file = "$path/cron-orginal.txt";
if (file_exists($file)){exec ("crontab $file",$output,$return_var);print"from backup";}
else{
print"from default archive";
$replace="# Do not remove the following line
# required for lsnodes and allmon
15 03 * * * cd /usr/local/sbin; ./astdb.php cron
00 * * * * (source /usr/local/etc/allstar.env ; /usr/bin/nice -19 /usr/bin/perl /usr/local/sbin/saytime.pl \$NODE1 > /dev/null)
";

$fileOUT = fopen($file, "w");fwrite ($fileOUT, $replace);fclose ($fileOUT);
exec ("crontab $file",$output,$return_var);
}
print "ok\n";
$tmpFile = "$path/cron-new.txt"; if (file_exists($tmpFile)){ unlink($tmpFile); }
$file = "$path/cron-orginal.txt";if (file_exists($file)){ unlink($file); }  // this may fail if permissions are wrong.
}

// sets up cron and removes old scripts.
function setUpcron($in){
global $fileEdit,$search,$path;
print "Installing Cron ";
// make a backup for uninstall
$file = "$path/cron-orginal.txt"; if (!file_exists($file)){exec ("crontab -l > $file",$output,$return_var);print"[made backup]";}
$file = "$path/cron.txt";

if (file_exists($file)){exec ("crontab $file",$output,$return_var);print" using[cron.txt] ";}
else{
$out="# GMRS Node Manager
# nodelist processor replaces astdb.php
2 2-4 * * * php /etc/asterisk/local/mm-software/nodelist_process.php cron >/dev/null
00 * * * * php /etc/asterisk/local/mm-software/hourly.php >/dev/null
*/13 * * * * php /etc/asterisk/local/mm-software/odd_min.php >/dev/null
59 * * * * /usr/local/sbin/trimlog.sh /var/log/asterisk/messages 1000
";
$file = "$path/cron.txt"; 
$fileOUT = fopen($file, "w");fwrite ($fileOUT, $out);fclose ($fileOUT);
print" using [memory] repo was missing ";
exec ("crontab $file",$output,$return_var);
}
print " <OK>\n";

//stop the looping script from being in memory
$fileEdit="/etc/rc.local"; $search="AutoSky";$hide=true;edit_config("#");



 
}
 
function c64($in){
print"






        **** COMODORE 64 BASIC V2 **** 
    64K RAM SYSTEM  38911 BASIC BYTES FREE
READY.
";
}

function lookupgps($in){
global $lat,$lon,$zipcode,$city,$state;
// This key is licensed to me do not reuse in anything else.
// Get your own.
$api="d8e8c050-2d0c-11ee-86e8-a9d406a2a91b";
$domain ="app.zipcodebase.com";
$datum   = date('m-d-Y H:i:s');
print "$datum Polling $domain $zipcode WAIT!>--";
$mtime = microtime(); $mtime = explode(" ",$mtime); $mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;

$attime = gmdate('YmdHi');
$url = "api/v1/search?apikey=$api&codes=$zipcode&country=US";

$options = array(
    'http'=>array(
        'timeout' => 30,  
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Content-Type: application/json\r\n".
                  "User-Agent: Allstar Node lagmrs.com \r\n" 
));
$context = stream_context_create($options);
$html = @file_get_contents("http://$domain/$url"); 
$file ="/tmp/zip-to-geo.xml";
if(file_exists($file)){unlink($file);}
//$json = json_decode($html);
$html = str_replace('"', "", $html);
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"https://$domain/$url\n $html ");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
$mtime = microtime(); $mtime = explode(" ",$mtime); $mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);



$u = explode(",",$html);  // latitude:31.74500000,longitude:-92.39520000
$uLat = explode(":",$u[4]) ; $uLon = explode(":",$u[5]);
$uCity = explode(":",$u[6]); $uState = explode(":",$u[7]);

$city="";$state="";
if ($uCity[0]=="city"){$city=$uCity[1];print"ok $poll_time sec ($city "; }
if ($uState[0]=="state"){$state=$uState[1];print"$state)\n"; }

if ($uLat[0]=="latitude"){print"$datum";$uLat[1]=round($uLat[1],4);print " [$uLat[1]/";$lat=$uLat[1];}
if ($uLon[0]=="longitude"){$uLon[1]=round($uLon[1],4);print "$uLon[1]]\n";$lon=$uLon[1];}
else{print"ERROR\n";}

}


function lookupzip ($in){
global $lat,$lon,$zipcode,$city,$state,$path;

if (!$state){return;}

$stateName="";
$input= file("$path/states.csv");
//$state= trim($state) ; $state  = str_replace("\n","",$state);
foreach($input as $line){ 
$line  = str_replace("\n","",$line);
$u = explode(",",$line);
$u[1] = str_replace(" ","",$u[1]);
//$test1 = strtoupper($u[1]);
if ($u[1]==$state){print"*";$stateName=$u[0];break;}
 
}
if(!$stateName){print "error in database $state";$stateName=$state;}



// This key is licensed to me do not reuse in anything else.
// Get your own.
$api="d8e8c050-2d0c-11ee-86e8-a9d406a2a91b";
$domain ="app.zipcodebase.com";
$datum   = date('m-d-Y H:i:s');
print "$datum Polling $domain $stateName WAIT!>-- ";
$mtime = microtime(); $mtime = explode(" ",$mtime); $mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
//https://app.zipcodebase.com/api/v1/code/city?apikey=d8e8c050-2d0c-11ee-86e8-a9d406a2a91b&city=Amsterdam&state_name=Noord-Holland&country=nl
$attime = gmdate('YmdHi');
$url = "api/v1/code/city?apikey=$api&city=$city&state_name=$stateName&country=US";

$options = array(
    'http'=>array(
        'timeout' => 30,  
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Content-Type: application/json\r\n".
                  "User-Agent: Allstar Node lagmrs.com \r\n" 
));
$context = stream_context_create($options);
$html = @file_get_contents("http://$domain/$url"); 
$file ="/tmp/city-to-zip.xml";
if(file_exists($file)){unlink($file);}
//$json = json_decode($html);
$html = str_replace('"', "", $html);$html = str_replace('[', "", $html); $html = str_replace(']', "", $html); $html = str_replace('}', "", $html); $html = str_replace('{', "", $html);
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"https://$domain/$url\n $html ");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
$mtime = microtime(); $mtime = explode(" ",$mtime); $mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
$u  = explode(":",$html);  
if (isset($u[5])){$zipcode = $u[5];print "$zipcode <ok>\n";} 
else{print "<error>";}

}

function  setOurCall($in){
global $file1,$call,$node,$path,$datum,$soundDbGsm;;
$action="";$file1=""; $datum = date('m-d-Y H:i:s');
include_once ("$path/sound_db.php");  
unset ($soundDbWav);// not using these
unset ($soundDbUlaw);
$test =  strtolower($call);
$oh=false;
$x = (string)$test;
for($i=0;$i<strlen($x);$i++)
{check_gsm_db ($x[$i]);$action = "$action $file1";} //print"$file1\n";

$file ="/var/lib/asterisk/sounds/rpt/nodenames/$node.ul"; 
exec ("sox $action $file",$output,$return_var);
print "$datum Creating soundfile $file\n";
unset ($soundDbGsm);// save memor clear

}



?>
