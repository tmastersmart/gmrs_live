<?php
// (c)2023  lagmrs.com
//
// version check.... 

$path   = "/etc/asterisk/local/mm-software";
$repoURL= "https://raw.githubusercontent.com/tmastersmart/gmrs_live/main";
$fileVersion="$path/version.txt"; 
$update=false;

if (!file_exists($fileVersion)){ $update=true;}

if (file_exists($fileVersion)){ 
 $ft = time()-filemtime($fileVersion);
 if ($ft > 336 * 3600){  // 336 = 2 weeks.  Change later
 $update=true; 
// $fth=round($ft /3600);
 }
}



if ($update){
chdir($path);
print "Updating version.txt \n";
if (file_exists($fileVersion)){unlink($fileVersion);}
exec("sudo wget $repoURL/version.txt",$output,$return_var);
}

?>
