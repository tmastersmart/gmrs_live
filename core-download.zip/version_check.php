<?php
// (c)2023  lagmrs.com
//
// version check.... 
// v1b    09/30/23    Checks for version file from dist server and downloads it.

$path   = "/etc/asterisk/local/mm-software";
$fileVersion="$path/version.txt"; 

$update=true;
if (file_exists($fileVersion)){
 $ft = time()-filemtime($fileVersion);
 if ($ft < 120 * 3600){$update=false; } // about 5 days
 $fth=round($ft /3600);
}

if ($update ){

$domain ="raw.githubusercontent.com"; $url = "/tmastersmart/gmrs_live/main/version.txt"; 
$datum  = date('m-d-Y H:i:s');
print "$datum Getting Update Info $domain >";
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-Encoding: gzip\r\n" 
));
$context = stream_context_create($options);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$html = @file_get_contents("https://$domain/$url",false,$context);
$html = gzinflate( substr($html,10,-8) ); 
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
print"$html\n"; $out="checking for update";save_task_log ($out);print"$datum $out\n";
$fileOUT = fopen($fileVersion,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$html\r\n"); flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
}
else{print "$datum Version.txt does not need update ($fth hrs old)\n";}

if (is_readable($fileVersion)) {
 $fileIN= file($fileVersion);
 foreach($fileIN as $line){
 $u = explode(",",$line);   
  if($coreVersion < $u[0]){
  $out="Update needed";save_task_log ($out);print"$datum $out\n";
//   Auto upgrade. TEST
//   include_once ("$path/setup_install.php");
//   install("U");
   } 
 }
}





?>
