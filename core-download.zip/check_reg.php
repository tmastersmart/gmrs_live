<?php
// (c)2015/2023 by The Master lagmrs.com

//  "Auth. Sent" at Server
//  "Registered" at Server
//
//  Module is not to be loaded direct
//
// check if the node is reg     

// v2 07/22/2023

function reg_check ($in){
global $debug,$counter,$datum,$node,$node1,$registered,$ip,$file,$path,$NotReg,$debug,$watchdog;

//Host::::::::::::::::::dnsmgr::Username:::::::::::::::Perceived:::::::::::::Refresh::State
//0.0.0.0:4569::::::::::Y:::::::2955:::::::::::::::::::<Unregistered>:::::::::::::60::Unregistered

//07-18-2023 11:15:07 Network Error we are offline
//PHP Notice:  Undefined offset: 11 in /etc/asterisk/local/mm-software/check_reg.php on line 60
//PHP Notice:  Undefined offset: 30 in /etc/asterisk/local/mm-software/check_reg.php on line 60
//PHP Notice:  Undefined offset: 31 in /etc/asterisk/local/mm-software/check_reg.php on line 60
//PHP Notice:  Undefined offset: 39 in /etc/asterisk/local/mm-software/check_reg.php on line 60
//PHP Notice:  Undefined offset: 41 in /etc/asterisk/local/mm-software/check_reg.php on line 60
//node:2955 node1:
//PHP Notice:  Undefined offset: 41 in /etc/asterisk/local/mm-software/check_reg.php on line 72

//  "Auth. Sent"  "Registered"    rejected: 'Registration Refused' // Request,Auth.,

$file   = "/tmp/registered_check.txt"; if(file_exists($file)){unlink($file);}
//semaphore
$fileYes= "/tmp/registered_flag.txt";
$fileNo = "/tmp/not_registered_flag.txt";
$status= exec("/bin/asterisk -rx 'iax2 show registry' > $file",$output,$return_var);
$fileIN= file($file);
$node1="";$node2="";$registered="";
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$line = str_replace(" ", ":", $line);
//$u = explode(":",$line);  
if (!$node1){//$host=$u[0];$port=$u[1];$dnsmge=$u[4];$node1=$u[11]; $ip=$u[30];$port2=$u[31]; $refRate=$u[39]; $registered=$u[41];}
$pos = strpos("-$line", "Unregistered"); if($pos){$registered="Unregistered";}
$pos = strpos("-$line", "Registration Refused"); if($pos){$registered="Registration Refused";}
$pos = strpos("-$line", "Request"); if($pos){$registered="Request";}
$pos = strpos("-$line", "Auth"); if($pos){$registered="Auth";}
$pos = strpos("-$line", "Sent"); if($pos){$registered="Sent";}
$pos = strpos("-$line", "Registered"); if($pos){$registered="Registered";}
$pos = strpos("-$line", $node); if($pos){$node1=$node;$status=$line;}
}
}
// We scan for the status of our node ignore all other. 
// this is only for a one 1 node hub.......

if($debug){print "node:$node $registered\n";}



$datum   = date('m-d-Y H:i:s');
if($debug){$out=$registered;save_task_log ($out);print"$datum DEBUG $out\n";}
print "$datum Node:$node is $registered";   
if ($registered=="Registered"){
print "<OK!>\n"; 
$file= $fileNo; if(file_exists($file)){unlink($file);}
$file= $fileYes;
}
else {
print "Error!\n"; 
save_task_log ("node:$node Detect $registered");
$file= $fileYes; if(file_exists($file)){unlink($file);}
$file= $fileNo;
}
$out= $registered;
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$out);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);  
//save_task_log ($out);// unneeded
}

// Take action to fix reg
function reg_fix ($in){
global $counter,$datum,$node1,$registered,$ip,$node,$file,$path,$NotReg,$watchdog,$debug,$newPort;
// Watchdog -----> restart AST asterisk (MMregister fix)
$newPort= rand(4500,4600); rotate_port("rotate");
sleep(10);
$datum   = date('m-d-Y H:i:s');
$eastBoundAndDown="'We gonna do what they say can't be done'"; 
$out="Trying to fix it.. $eastBoundAndDown";
save_task_log ($out);print "$datum $out
"; 
sleep(60);// give time for playing to finish 
$status= shell_exec("sudo /usr/local/sbin/astres.sh");
$datum   = date('m-d-Y H:i:s');
print"$datum Requesting a AST restart
";
sleep (60); // Give time to register
reg_check ("recheck");
}


//
// we check which port is in use
//
function find_port ($in){
global $port,$debug,$datum;
$port="";
$iax     =  "/etc/asterisk/iax.conf";
$fileIN= file($iax);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", "bindport="); 
if ($pos == 1){
if($debug){print"$datum DEBUG $line\n";}
$u= explode("=",$line);
$port = $u[1]; $port= trim($port," ");
return $port;
  }
 }
} 

// rotate the port to this number
// use extra level error checking
function rotate_port($in){  //$random = rand(4500,4600);   // rand(min,max); 
global $path,$newPort,$debug;

if(!$newPort){$newPort= rand(4500,4600);}
$datum = date('m-d-Y-H:i:s');
$cur   = date('mdyhis');
srand(time());

$savever = true ;
$iax     =  "/etc/asterisk/iax.conf";
$iaxbk   =  "/tmp/iax-$cur.conf";
$iaxtmp  =  "/etc/asterisk/iax-tmp.conf";
$status = "";
chdir("/etc/asterisk");
copy($iax,$iaxbk);
if (file_exists($iaxbk )){ // work from the backup
$fileOUT = fopen($iaxtmp, "w");
$fileIN= file($iaxbk);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", "bindport="); 
if ($pos == 1){$status = "$status $line changed to bindport=$newPort";$line="bindport=$newPort";

}
$pos = strpos("-$line", ";rotate_port"); if ($pos == 1){$line=";rotate_port $datum port:$newPort";$savever=false;}
fwrite ($fileOUT, "$line\n");
}
if($savever){ fwrite ($fileOUT, ";rotate_port $datum port:$newPort\n"); } 
fclose ($fileOUT);
 
if (file_exists($iaxbk)){ 
 unlink($iax); 
 if (!file_exists($iax)){ rename ($iaxtmp, $iax); }
 else{ $status="$status Unable to unlink file $iax for replacement";}
}
}
else {$status="$status Unable to make working backup $iaxbk";}

$datum = date('m-d-Y-H:i:s');
print "$datum $status 
";
save_task_log ($status);


}





?>

