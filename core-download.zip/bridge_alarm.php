<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
//
// Automated bridging detection module no direct load.
//
// v1.2 09/08/2023     
$path          = "/etc/asterisk/local/mm-software";
$nodelistClean = "$path/nodelist/clean.csv";// nodelist

include_once ("$path/load.php");
include_once ("$path/sound_db.php");

$datum = date('m-d-Y-H:i:s');
print "$datum Scanning for network bridge\n";

// you can adjust this (for GMRS LIVE)
// none of these should ever bridge to each other
$BridgeAlarm1=1195;$BridgeDetect1=false;
//$BridgeAlarm2=1000;$BridgeDetect1=false; // test node
$BridgeAlarm2=700; $BridgeDetect2=false;
$BridgeAlarm3=611; $BridgeDetect3=false;
$BridgeAlarm4=900; $BridgeDetect4=false;
$BridgeDetect=0;
$NUMLINKS=0; $v="";$vv="";  

// detection for proper net Bridging. if one exist the other should also.
$TexasGmrs=2250;$RoadKill=1195;$Texas=false;$Rkill=false;$BrokenBridge=0;
//
$action="";
$datum   = date('m-d-Y H:i:s');$gmdatum = gmdate('m-d-Y H:i:s');
$nodes=0; $array1=false;
$lxnodes ="/tmp/xnodes.txt"; if(file_exists($lxnodes)){unlink($lxnodes);}

$status= exec("sudo /bin/asterisk -rx \"rpt xnode $node\" ",$output,$return_var);


//$file=$lxnodes;
//$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );
//$fileIN= $output;
//foreach($fileIN as $line){fwrite ($fileOUT,"$line\n");}
//flock ($fileOUT, LOCK_UN );fclose ($fileOUT);

//RPT_NUMALINKS=1
//RPT_ALINKS=1,1195TK
$fileIN= $output;  // use from memory
foreach($fileIN as $line){ 

$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line); 
$line = str_replace(" ", "", $line); // print "<! -----$line----->\n";
// get the network name
$pos2 = strpos("-$line", ",");if($pos2 and !$array1){$v = explode(",",$line);$array1=true;} // first array
$pos3 = strpos("-$line", "RPT_NUMLINKS"); if ($pos3){ $vv = explode("=",$line);$NUMLINKS=$vv[1];}
$pos1 = strpos("-$line", "RPT_ALINKS"); // RPT_ALINKS=1,1195TU   RPT_NUMLINKS=35 
if ($pos1){
$u = explode("=",$line);// get the value
$u3 = explode(",",$u[1]);
$line =$u3[1];// this is the node# of the network
//$line = substr($line, 1); 
$networkNode  = substr($line, 0,strlen($line-2));
//$networkNode=$line; // network node number less the text

}

// print "RPT_ALINKS $line";
// links
$pos = strpos("-$line", "RPT_LINKS");
if ($pos){
$u = explode("=",$line);// get the value
$u2 = explode(",",$u[1]);// break up the fields
$nodes=$u2[0]; 
}

}

// In some cases no data is returned on u2 but v always has data
// we use u2 if its provided and v as a backup.
// This is expermental not sure which one is best to use.
$nodes1=count($v); $nodes2=count($u2);
if ($nodes1 > $nodes2){ $u2=$v; $nodes=count($v);}


if ($nodes>1){

foreach ($u2 as $line){ 
$line = str_replace(" ", "", $line);
$line = str_replace("T", "", $line);
$line = str_replace("R", "", $line);
$line = str_replace("C", "", $line);
if (is_numeric($line)) {
 if($line==$BridgeAlarm1){$BridgeDetect1=true;$BridgeDetect++;print "$datum $BridgeAlarm1 detected\n";}
 if($line==$BridgeAlarm2){$BridgeDetect2=true;$BridgeDetect++;print "$datum $BridgeAlarm2 detected\n";}
 if($line==$BridgeAlarm3){$BridgeDetect3=true;$BridgeDetect++;print "$datum $BridgeAlarm3 detected\n";}
 if($line==$BridgeAlarm4){$BridgeDetect4=true;$BridgeDetect++;print "$datum $BridgeAlarm4 detected\n";}
 
 // detect a broken bridge 

 if($line==$TexasGmrs){$Texas=true;$BrokenBridge++;print "$datum $TexasGmrs ok\n";}
 if($line==$RoadKill) {$Rkill=true;$BrokenBridge++;print "$datum $RoadKill ok\n";} 
 }
}

if ($BridgeDetect>=2){
$status="";
if ($BridgeDetect1){$status="$BridgeAlarm1";}
if ($BridgeDetect2){$status="$status $BridgeAlarm2";}
if ($BridgeDetect3){$status="$status $BridgeAlarm3";}
if ($BridgeDetect4){$status="$status $BridgeAlarm4";}
print "$datum BRIDGE  detected  $status\n";
print "$datum Connected to node: $networkNode \n";
print "$datum Nodecount1: $nodes1 Nodecount2: $nodes2 \n";
save_task_log ("Bridge detected $status");


if($burst){
print "$datum BA1 MDC-1200 bursts $burst\n";
exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);
} 
sleep(2);

//  emergency  warning  terminating  sorry2  removed repair
// alllinksdisconnected 
$action="";
check_wav_db ("strong click"); if($file1){$action = "$action $file1";}
check_gsm_db ("warning");if($file1){$action = "$action $file1";} 
check_ulaw_db ("bridged_bot");if($file1){$action = "$action $file1";} 

if ($BridgeDetect1 and $BridgeDetect2){  
$oh=false;$x = (string)$BridgeAlarm1;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
check_gsm_db ("connected");if($file1){$action = "$action $file1";} 
check_gsm_db ("to");if($file1){$action = "$action $file1";} 
$oh=false;$x = (string)$BridgeAlarm2;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
}

if ($BridgeDetect1 and $BridgeDetect3){
$oh=false;$x = (string)$BridgeAlarm1;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
check_gsm_db ("connected");if($file1){$action = "$action $file1";} check_gsm_db ("to");if($file1){$action = "$action $file1";} 
$oh=false;$x = (string)$BridgeAlarm3;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
}

if ($BridgeDetect1 and $BridgeDetect4){
$oh=false;$x = (string)$BridgeAlarm1;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
check_gsm_db ("connected");if($file1){$action = "$action $file1";} 
check_gsm_db ("to");if($file1){$action = "$action $file1";} 
$oh=false;$x = (string)$BridgeAlarm4;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
}

if ($BridgeDetect2 and $BridgeDetect3){
$oh=false;$x = (string)$BridgeAlarm2;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
check_gsm_db ("connected");if($file1){$action = "$action $file1";}  
check_gsm_db ("to");if($file1){$action = "$action $file1";} 
$oh=false;$x = (string)$BridgeAlarm3;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
}

if ($BridgeDetect2 and $BridgeDetect4){
$oh=false;$x = (string)$BridgeAlarm2;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
check_gsm_db ("connected");if($file1){$action = "$action $file1";} 
check_gsm_db ("to");if($file1){$action = "$action $file1";} 
$oh=false;$x = (string)$BridgeAlarm4;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
}

if ($BridgeDetect3 and $BridgeDetect4){
$oh=false;$x = (string)$BridgeAlarm3;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
check_gsm_db ("connected");if($file1){$action = "$action $file1";} 
check_gsm_db ("to");if($file1){$action = "$action $file1";} 
$oh=false;$x = (string)$BridgeAlarm4;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
}

//$test =  strtolower($call);
//$oh=false;
//$x = (string)$test;
//for($i=0;$i<strlen($x);$i++){
//check_gsm_db ($x[$i]);$action = "$action $file1";
//} 


check_gsm_db ("silence1");if($file1){$action = "$action $file1";}

$file = "/tmp/bridged.gsm";if(file_exists($file)){unlink($file);}

exec("sox $action $file",$output,$return_var); if($debug){print "DEBUG:$action";}
exec("sudo asterisk -rx 'rpt localplay $node /tmp/bridged'",$output,$return_var);

 } // end if bridged


// Check for a broken bridge
if ($BrokenBridge <2 ){ // One of them is here but not both so ALARM
 // $TexasGmrs=2250;$RoadKill=1195;$Texas=false;$Roadkill=false;
print "$datum Broken Bridge $BrokenBridge\n"; 
 
if($burst){
print "$datum BA2 MDC-1200 bursts $burst\n";
exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);
} 
$action="";

if (!$Texas){
print "$datum Broken bridge $TexasGmrs missing\n";
save_task_log ("Broken Bridge $TexasGmrs missing");
check_wav_db ("strong click"); if($file1){$action = "$action $file1";}
check_gsm_db ("warning");if($file1){$action = "$action $file1";} 
check_gsm_db ("texas");if($file1){$action = "$action $file1";}
check_gsm_db ("node");if($file1){$action = "$action $file1";}  
$oh=false;$x = (string)$TexasGmrs;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
check_gsm_db ("is");if($file1){$action = "$action $file1";} 
check_gsm_db ("not-yet-connected");if($file1){$action = "$action $file1";} 
}

if (!$Rkill){
print "$datum Broken bridge $RoadKill missing\n";
save_task_log ("Broken Bridge $RoadKill missing");
check_wav_db ("strong click"); if($file1){$action = "$action $file1";}
check_gsm_db ("warning");if($file1){$action = "$action $file1";} 
check_gsm_db ("louisiana");if($file1){$action = "$action $file1";} 
check_gsm_db ("node");if($file1){$action = "$action $file1";}  
$oh=false;$x = (string)$RoadKill;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
check_gsm_db ("is");if($file1){$action = "$action $file1";} 
check_gsm_db ("not-yet-connected");if($file1){$action = "$action $file1";} 
}


check_gsm_db ("silence1");if($file1){$action = "$action $file1";}

$file = "/tmp/bridgedown.gsm";if(file_exists($file)){unlink($file);}

exec("sox $action $file",$output,$return_var); if($debug){print "DEBUG:$action";}
exec("sudo asterisk -rx 'rpt localplay $node /tmp/bridgedown'",$output,$return_var);
} // end broken bridge check

} // end if nodes >1 


