<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
//
// Automated bridging detection module no direct load.
//
// v1.3 09/16/2023  
// v1.4 09/20/2023  Changes to mesage  
// v1.5 09/23/2023  Changed routines to only rep the bridged node.
// v1.6 09/27/2023  Fixed a major syntax error 
// v1.7 10/01/2023  Removed the word TO sounded like 2
// v1.8 10/11/2023  Duplicate word is removed
// v1.9 10/29/2023  Tweeks.
// v2   11/07/2023  prevent duplicate burst
// v2.1
// v2.2 12/15/23  Bridge on/off setting not being checked for- fixed.
// v2.3 12/17/23  Second briging setting added. Clash detection. Skip bridge alarm added
// 

$clash         = "/tmp/mmweather-task.txt";
$path          = "/etc/asterisk/local/mm-software";
$nodelistClean = "$path/nodelist/clean.csv";// nodelist

include_once ("$path/load.php");
include_once ("$path/sound_db.php");

$datum = date('m-d-Y-H:i:s');
print "$datum Scanning for network bridge\n";

if(file_exists($clash)){
 $out="Waiting for other thread. "; save_task_log($out);print"$datum $out\n";
 sleep(20);
}



// detection for proper net Bridging. if one exist the other should also.

$RoadKill =1195;
$TexasGmrs=2250;
$Texas=false;
$Rkill=false;
$BrokenBridge=0;


// you can adjust this (for GMRS LIVE)
// none of these should ever bridge to each other
$BridgeAlarm1=$RoadKill ;$BridgeDetect1=false;$BridgeName1="louisiana";
$BridgeAlarm2=700       ;$BridgeDetect2=false;$BridgeName2="florida";
$BridgeAlarm3=611       ;$BridgeDetect3=false;$BridgeName3="florida"; 
$BridgeAlarm4=922       ;$BridgeDetect4=false;$BridgeName4=""; // spare 
$BridgeAlarm5=$TexasGmrs;$BridgeDetect5=false;$BridgeName5="texas";
$BridgeDetect=0;
$NUMLINKS=0; $v="";$vv="";  


//
$action="";
$datum   = date('m-d-Y H:i:s');$gmdatum = gmdate('m-d-Y H:i:s');
$nodes=0; $array1=false;
$lxnodes ="/tmp/xnodes.txt"; if(file_exists($lxnodes)){unlink($lxnodes);}

$status= exec("sudo /bin/asterisk -rx \"rpt xnode $node\" ",$output,$return_var);


//$file=$lxnodes;
//$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );
//$fileIN= $output;
//foreach($fileIN as $line){fwrite ($fileOUT,"$line\n");}
//flock ($fileOUT, LOCK_UN );fclose ($fileOUT);

//RPT_NUMALINKS=1
//RPT_ALINKS=1,1195TK
$fileIN= $output;  // use from memory
foreach($fileIN as $line){ 

$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line); 
$line = str_replace(" ", "", $line); // print "<! -----$line----->\n";
// get the network name
$pos2 = strpos("-$line", ",");if($pos2 and !$array1){$v = explode(",",$line);$array1=true;} // first array
$pos3 = strpos("-$line", "RPT_NUMLINKS"); if ($pos3){ $vv = explode("=",$line);$NUMLINKS=$vv[1];}
$pos1 = strpos("-$line", "RPT_ALINKS"); // RPT_ALINKS=1,1195TU   RPT_NUMLINKS=35 
if ($pos1){
$u = explode("=",$line);// get the value
$u3 = explode(",",$u[1]);
$line =$u3[1];// this is the node# of the network
//$line = substr($line, 1); 
$networkNode  = substr($line, 0,strlen($line-2));
//$networkNode=$line; // network node number less the text

}

// print "RPT_ALINKS $line";
// links
$pos = strpos("-$line", "RPT_LINKS");
if ($pos){
$u = explode("=",$line);// get the value
$u2 = explode(",",$u[1]);// break up the fields
$nodes=$u2[0]; 
}

}

// In some cases no data is returned on u2 but v always has data
// we use u2 if its provided and v as a backup.
// This is expermental not sure which one is best to use.
$nodes1=count($v); $nodes2=count($u2); $ST=false;
if ($nodes1 > $nodes2){ $u2=$v; $nodes=count($v);}


if ($nodes>1){

foreach ($u2 as $line){ 
$pos  = strpos("-$line", "R");if($pos){$ST=true;}
//$pos  = strpos("-$line", "T");if($pos){$ST=false;} 
$line = str_replace(" ", "", $line);
$line = str_replace("T", "", $line);
$line = str_replace("R", "", $line);
$line = str_replace("C", "", $line);
if (is_numeric($line)) {

 if($networkNode==$RoadKill or $networkNode==$TexasGmrs) {
 if($line==$BridgeAlarm2){$BridgeDetect2=true;$BridgeDetect=3;print "$datum $BridgeAlarm2 detected\n";}  //700 bridge
 if($line==$BridgeAlarm3){$BridgeDetect3=true;$BridgeDetect=3;print "$datum $BridgeAlarm3 detected\n";}  //611 bridge 
 if($line==$BridgeAlarm4){$BridgeDetect4=true;$BridgeDetect=4;print "$datum $BridgeAlarm4 detected\n";}  //900 bridge 
 }

 if($networkNode==700 or $networkNode==611) {
 if($line==$BridgeAlarm1){$BridgeDetect1=true;$BridgeDetect=3;print "$datum $BridgeAlarm1 detected\n";} //1195 bridge
 if($line==$BridgeAlarm5){$BridgeDetect5=true;$BridgeDetect=3;print "$datum $BridgeAlarm5 detected\n";}  //2250 bridge 
 }
// extra bridging support to be added here 
 
 
}
 
 // detect a broken bridge 

 if($line==$TexasGmrs){$Texas=true;$BrokenBridge++;print "$datum $TexasGmrs ok\n";}
 if($line==$RoadKill) {$Rkill=true;$BrokenBridge++;print "$datum $RoadKill ok\n";} 
 }
}

if ($BridgeDetect>=2 and $bridgeMonitor){
$status="";
if ($BridgeDetect1){$status="$BridgeAlarm1";}
if ($BridgeDetect2){$status="$status $BridgeAlarm2";}
if ($BridgeDetect3){$status="$status $BridgeAlarm3";}
if ($BridgeDetect4){$status="$status $BridgeAlarm4";}
print "$datum BRIDGE  detected  $status\n";
print "$datum Connected to node: $networkNode \n";
print "$datum Nodecount1: $nodes1 Nodecount2: $nodes2 \n";
save_task_log ("Bridge detected $status");

// we need to prevent this from repeating serveral times 
if (!isset($bursted)) { $bursted =false;}
if(!$bursted) {
if($burst){
   print "$datum MDC-1200 bursts for ID $burst\n";
   exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);
   $bursted=true;
 } 
} 

sleep(2);

//  emergency  warning  terminating  sorry2  removed repair
// alllinksdisconnected   $soundPath="/var/lib/asterisk/sounds/rpt/nodenames"; 
$action="";
check_wav_db ("strong click");if($file1){$action = "$action $file1";}
check_gsm_db ("warning");     if($file1){$action = "$action $file1";} 
check_gsm_db ("bridged_bot"); if($file1){$action = "$action $file1";} 
check_gsm_db ("node");        if($file1){$action = "$action $file1";}
//check_gsm_db ("to");          if($file1){$action = "$action $file1";} 

if ($BridgeDetect1){ $oh=false;$x = (string)$BridgeAlarm1;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";}} 
if ($BridgeDetect2){ $oh=false;$x = (string)$BridgeAlarm2;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} } 
if ($BridgeDetect3){ $oh=false;$x = (string)$BridgeAlarm3;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} } 
if ($BridgeDetect4){ $oh=false;$x = (string)$BridgeAlarm4;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} }
if ($BridgeDetect5){ $oh=false;$x = (string)$BridgeAlarm5;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} } 

//if ($ST){check_gsm_db ("r"); if($file1){$action = "$action $file1";}}

check_gsm_db ("connected"); if($file1){$action = "$action $file1";}

//check_gsm_db ("warning_bridged");if($file1){$action = "$action $file1";} 


$file = "/tmp/bridged.gsm";if(file_exists($file)){unlink($file);}

exec("sox $action $file",$output,$return_var); if($debug){print "DEBUG:$action";}
exec("sudo asterisk -rx 'rpt localplay $node /tmp/bridged'",$output,$return_var);

 } // end if bridged


// Check for a broken bridge
if ($Texas or $Rkill){
if ($BrokenBridge <2  and $bridgeMonitor){ // One of them is here but not both so ALARM

$min  = date('i');$skip=false;
if ($LinkCheck ==2){$skip=true; if($min >=20 and $min <=40){$skip=false;} }
// if link is on 2 then report only on the 30 min mark 
if (!$skip){  
 // $TexasGmrs=2250;$RoadKill=1195;$Texas=false;$Roadkill=false;
print "$datum Broken Bridge $BrokenBridge\n"; 
 
if($burst){
print "$datum BA2 MDC-1200 bursts $burst\n";
exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);
} 
$action="";

if (!$Texas){
print "$datum Broken bridge $TexasGmrs missing\n";
save_task_log ("Broken Bridge $TexasGmrs missing");
check_wav_db ("strong click"); if($file1){$action = "$action $file1";}
check_gsm_db ("warning");if($file1){$action = "$action $file1";} 
check_gsm_db ("texas");if($file1){$action = "$action $file1";}
check_gsm_db ("node");if($file1){$action = "$action $file1";}  
$oh=false;$x = (string)$TexasGmrs;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
//check_gsm_db ("is");if($file1){$action = "$action $file1";} 
check_gsm_db ("not-yet-connected");if($file1){$action = "$action $file1";} 
}

if (!$Rkill){
print "$datum Broken bridge $RoadKill missing\n";
save_task_log ("Broken Bridge $RoadKill missing");
check_wav_db ("strong click"); if($file1){$action = "$action $file1";}
check_gsm_db ("warning");if($file1){$action = "$action $file1";} 
check_gsm_db ("louisiana");if($file1){$action = "$action $file1";} 
check_gsm_db ("node");if($file1){$action = "$action $file1";}  
$oh=false;$x = (string)$RoadKill;for($i=0;$i<strlen($x);$i++){make_number ($x[$i]);$action = "$action $actionOut";} //say the numbers one at a time not as a set 
//check_gsm_db ("is");if($file1){$action = "$action $file1";} 
check_gsm_db ("not-yet-connected");if($file1){$action = "$action $file1";} 
}


check_gsm_db ("silence1");if($file1){$action = "$action $file1";}

$file = "/tmp/bridgedown.gsm";if(file_exists($file)){unlink($file);}

exec("sox $action $file",$output,$return_var); if($debug){print "DEBUG:$action";}
exec("sudo asterisk -rx 'rpt localplay $node /tmp/bridgedown'",$output,$return_var);
} // end skip
} // end broken bridge check
}
 // end if nodes >1 


