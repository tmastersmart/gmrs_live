<?php
// (c)2015/2023 by The Master lagmrs.com  by pws.winnfreenet.com
// This script uses some code my weather programs. Member CWOP since 2015 
// This is the new api for the NWS. 
//
// Weather caching system. to stop all weather pulls on the hr.
// 
// The purpose is to randomise calls and cach. so all nodes dont pull at the same time.
// 2nd some calls for temp have resulted in NULL This allows a cach to be used until the temp updates. 
//
// version
// v1.0  10/04/2023   First version created to stop overloads on the API
// v1.6  10/11/2023  Added ambent weather 

if (!isset($ver)){ $ver="1.6";}

//$apiDebug=true;
//if($debug){$apiDebug=true;}


//if($apiDebug){
$path="/etc/asterisk/local/mm-software";
include_once ("$path/load.php");      // settings .. Functions

$forcastxml  ="/tmp/geocode.xml";
$forcastxml2 ="/tmp/forcast.xml";
$alertxml    ="/tmp/skywarn.xml";
$currentxml  ="/tmp/current.xml";$currentxmlBAD  ="/tmp/current-bad.xml";
$acuwxml     ="/tmp/accuweather.xml";
$femaCSV     ="/tmp/fema.csv";
$ambientxml  ="/tmp/ambient.xml";


$datum  = date('m-d-Y H:i:s');
$ambientApiKey         = "02eeb9b99218497184d1f6b2f66a239a6a4595e3778c4055ac0af98f94a282f4"; // Your station
// If ambent API
if($ambientApiKey){
$update=true; $ft=0;
$randomMin = mt_rand(40, 60);// age of the file.
$file= $ambientxml;
if (file_exists($file)){
 $ft = time()-filemtime($file);
 $ft = round(($ft)/60);                             
 if ($ft < $randomMin){$update=false; print "$datum using cache for current ambient ($ft mins old).Target $randomMin Min\n";}
 if ($ft >65){unlink($ambientxml); print "$datum current cache is stale ($ft mins old). Purging it\n";save_task_log ("Purging $ambientxml");} 
}

if ($update){
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$ambientApplicationKey = "63edf3218001424093bed2167262f769f87b1ff4aa024a85a91af1f149e78283"; // Get your own its free DONT COPY

$domain ="rt.ambientweather.net"; 
$url = "v1/devices/?apiKey=$ambientApiKey&applicationKey=$ambientApplicationKey";
// https://rt.ambientweather.net/v1/devices/?apiKey=02eeb9b99218497184d1f6b2f66a239a6a4595e3778c4055ac0af98f94a282f4&applicationKey=63edf3218001424093bed2167262f769f87b1ff4aa024a85a91af1f149e78283


$datum  = date('m-d-Y H:i:s'); print "$datum Polling $domain for your station ($ft mins old)>";

$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Accept: application/cap+xml" .
                  "Cookie: foo=bar\r\n" .
                  "User-Agent: lagmrs.com $ver weather software\r\n" 
));
$context = stream_context_create($options);
$html = @file_get_contents("https://$domain/$url",false,$context);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);

if(!$html){
$status="Received $html ";if($poll_time>=10){$status="$status timeout";}
save_task_log ("ambient API Station error $status $poll_time Sec.");
print "$status $poll_time Sec.\n";
watchdog ("net"); $data_good=false;
}

else{  
//read_ambient_api_temp ($file);
$file=$ambientxml;$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$html);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
watchdog ("oknet");
print "OK $poll_time Sec.\n";
}

 }

} // and ambient key







// THE NWS station pull 
if($station){
$update=true; $ft=0;
$randomMin = mt_rand(40, 60);// age of the file.
$file= $currentxml;
if (file_exists($file)){
 $ft = time()-filemtime($file);
 $ft = round(($ft)/60);                             
 if ($ft < $randomMin){$update=false; print "$datum using cache for current NWS ($ft mins old).Target $randomMin Min\n";}
 if ($ft >65){unlink($currentxml); print "$datum current cache is stale ($ft mins old). Purging it\n";save_task_log ("Purging $currentxml");} 
}

if ($update){
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$domain ="api.weather.gov"; 
$url = "stations/$station/observations/latest";// latest only
//$url = "stations/$station/observations";// get several readings 5000 lines

$datum  = date('m-d-Y H:i:s'); print "$datum Polling $domain for $station latest only ($ft mins old)>";

$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Accept: application/cap+xml" .
                  "Cookie: foo=bar\r\n" .
                  "User-Agent: lagmrs.com $ver weather software\r\n" // Tell the NWS who we are
));
$context = stream_context_create($options);
$html = @file_get_contents("https://$domain/$url",false,$context);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
 
if(!$html){
$status="Received $html ";if($poll_time>=10){$status="$status timeout";}
save_task_log ("weather API Station error $status $poll_time Sec.");
print "$status $poll_time Sec.\n";
watchdog ("net"); $data_good=false;
}
else{
$file=$currentxmlBAD;$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$html);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
read_api_temp ($file);

if ($data_good){
if (file_exists($currentxml)){unlink($currentxml);} 
if (file_exists($currentxmlBAD)){rename ($currentxmlBAD,$currentxml);}
watchdog ("oknet");
print "OK $poll_time Sec.\n";
}

else{
$status="Bad Temp Data! ignoring";if($poll_time>=10){$status="$status timeout";}
save_task_log ("weather API Station error $status $poll_time Sec. https://$domain/$url");
print "$status $poll_time Sec.\n";
if (file_exists($currentxmlBAD)){
 if (file_exists($acuwxml)){unlink ($acuwxml);}// Force a acuweather pool to get the temp
  }
 }
 } // end else 
 }// end update
}// end of NWS station id



// Get the forcast from acuweather
$update=true;
$randomMin = mt_rand(120, 250);// age of the file. 
$file= $acuwxml;
if (file_exists($file)){
 $ft = time()-filemtime($file);
 $ft = round(($ft)/60);                             
 if ($ft < $randomMin){$update=false; print "$datum using cache for conditions ($ft mins old).Target $randomMin Min\n";} 
}


if ($update){
// Poll acuweather for the current conditions. 
$file=$acuwxml;
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;  
$datum   = date('m-d-Y H:i:s');print "$datum Polling Accuweather Conditions $zipcode >";
$options = array(
    'http'=>array(
        'timeout' => 10,  
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Cookie: foo=bar\r\n" .
                  "User-Agent: lagmrs.com $ver weather software \r\n" 
));
$context = stream_context_create($options);

$html = @file_get_contents("http://rss.accuweather.com/rss/liveweather_rss.asp?metric=F&locCode=$zipcode");
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);

if(!$html){
$status="Received $html ";if($poll_time>=10){$status="$status timeout";}
save_task_log ("Acuweather API Station error $status $poll_time Sec.");
print "$status $poll_time Sec.\n";
watchdog ("net");
 }
else{
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$html");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
watchdog ("oknet");
print "OK $poll_time Sec.\n";
 }
}


if (!file_exists($forcastxml2)){ 
 if (file_exists($forcastxml)){unlink($forcastxml);}
}
// force update if 2nd file is missing by erasing the first one..

// Test the age of the geocoded file
$update=true;
$randomMin = mt_rand(19, 49);// age of the file. mins
$file= $forcastxml;
if (file_exists($file)){
 $ft = time()-filemtime($file);
 $ft = round(($ft)/60);                              
 if ($ft < $randomMin){$update=false; print "$datum using cache for forcast ($ft mins old).Target $randomMin Min\n";} 
}



if ($update){
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$domain ="api.weather.gov"; $url = "/points/$lat,$lon"; 
$datum  = date('m-d-Y H:i:s');print "$datum Polling $domain for location $lat/$lon>";
$file=$forcastxml;
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Accept: application/cap+xml" .
                  "Cookie: foo=bar\r\n" .
                  "User-Agent: lagmrs.com $ver weather software\r\n" // Tell the NWS who we are
));
$context = stream_context_create($options);
$html = @file_get_contents("https://$domain/$url",false,$context);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
 
if(!$html){
$status="<error1>";if($poll_time>=10){$status="$status timeout";}
save_task_log ("weather API GeoCode error $status $poll_time Sec.");
print "$status $poll_time Sec.\n";
watchdog ("net");
}
else{
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$html);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
watchdog ("oknet");
print "OK $poll_time Sec.\n";
read_api_url ($file); // the URL is pulled from above file.
// now we have a URL to get a forcast 

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
print "$datum Polling $domain for Geocoded Forcast>";
$file=$forcastxml2;
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Accept: application/cap+xml" .
                  "Cookie: foo=bar\r\n" .
                  "User-Agent: lagmrs.com $ver weather software\r\n" // Tell the NWS who we are
));
$context = stream_context_create($options);
$html = @file_get_contents("$url",false,$context);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
 
if(!$html){
$status="<error2>";if($poll_time>=10){$status="$status timeout";}
save_task_log ("weather API forcast error $status $poll_time Sec.");
print "$status $poll_time Sec.\n";
watchdog ("net");
}

else {
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$html);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
watchdog ("oknet");
print "OK $poll_time Sec.\n";
  }
  
 }// end else good gps
}// end update

// Test the age of the $alertxml file
$update=true;
$randomMin = mt_rand(10, 39);// age of the file. mins
$file= $alertxml;
if (file_exists($file)){
 $ft = time()-filemtime($file);
 $ft = round(($ft)/60);                             
 if ($ft < $randomMin){$update=false; print "$datum using cache for CapWarn ($ft mins old).Target $randomMin Min\n";} 
}

if ($update){
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$domain ="api.weather.gov"; $url = "/alerts/active?point=$lat,$lon"; 
$datum  = date('m-d-Y H:i:s');
print "$datum Polling $domain for Gecoded Alerts >";
$file=$alertxml;
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Accept: application/cap+xml" .
                  "Cookie: foo=bar\r\n" .
                  "User-Agent: lagmrs.com $ver weather software\r\n" // Tell the NWS who we are
));
$context = stream_context_create($options);
$html = @file_get_contents("https://$domain/$url",false,$context);

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
 
if(!$html){
$status="<error3>";if($poll_time>=10){$status="$status timeout";}
save_task_log ("weather API CAP Warn error $status $poll_time Sec.");
print "$status  $poll_time Sec.\n";
watchdog ("net");
}

else{
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$html);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
print "<ok> $poll_time Sec.\n";
watchdog ("oknet");
 }
}// end update




// fema https://www.fema.gov/api/open/v2/DisasterDeclarationsSummaries?$filter=declarationDate%20ge%20%272023-10-01T00:00:00.000z%27%20and%20state%20eq%20%27LA%27&$format=csv
// Test the age of the geocoded file 

$file= $femaCSV;
if ($parishCounty and $fema){    // both must be set to even update
$update=true;
$randomMin = mt_rand(1200, 1440);// age of the file. mins   1200 1440 mns in a day

if (file_exists($file)){
 $ft = time()-filemtime($file);
 $ft = round(($ft)/60);                             
 if ($ft < $randomMin){$update=false; print "$datum using cache for FEMA ($ft mins old).Target $randomMin Min\n";} 
}
if ($update){
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
// $parishCounty,$fema,
$date=date('Y-m-d'); $date=$date."T00:00:00.000z";
$domain ="www.fema.gov"; $url = "/api/open/v2/DisasterDeclarationsSummaries?\$filter=declarationDate%20ge%20%27$date%27%20and%20state%20eq%20%27$fema%27&\$format=csv"; 
$datum  = date('m-d-Y H:i:s');  //10-04-2023
print "$datum Polling $domain for Declared Emergencys >";
$file=$femaCSV;
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Accept: application/cap+xml" .
                  "Cookie: foo=bar\r\n" .
                  "User-Agent: $ver 2way radio software\r\n" 
));
$context = stream_context_create($options);
$html = @file_get_contents("https://$domain/$url",false,$context);

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
 
if(!$html){
$status="<error3>";if($poll_time>=10){$status="$status timeout";}
save_task_log ("FEMA error $status $poll_time Sec.");
print "$status  $poll_time Sec.\n";
watchdog ("net");
}

else{
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$html);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
print "<ok> $poll_time Sec.\n";
watchdog ("oknet");
 }
}// end update
}
else {
if (file_exists($file)){unlink($file);}
}



function read_api_temp ($file){
global $outCtemp,$data_good,$file;
$temp=false; $data_good=false;
if (file_exists($file)){
$html= file($file); 
foreach($html as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);

$line = str_replace('"', "", $line);
 
//"temperature": {
//            "unitCode": "wmoUnit:degC",
//            "value": 22.300000000000001, 
//print "--$line\n";
$pos = strpos($line, 'temperature:');      if ($pos) {$temp=true;}
   
$pos = strpos($line, 'value'); 
if ($pos) {
     $test = $line; 
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ','); // "value": null,
     $value2 = substr($test, $Lpos+2,($Rpos-$Lpos)-2);
     $value2 = str_replace(',', "", $value2);
     $value2 = trim($value2," ");
    
     if ($value2=="null"){$value2="";}
//     print "$value2\n";
     
// which one to put it in  $avgwind,$gustspeed
if($temp) {
if ($value2){
$outCtemp=$value2;$data_good = true;}

$temp=false;
   }
  }
 }
}

}



function read_api_url ($file){
global $url,$data_good,$file;
$data_good=false;
if (file_exists($file)){
$html= file($file); 
foreach($html as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$len= strlen($line);
$line = str_replace('"', "", $line);     
$pos = strpos($line, 'forecast:');  //forecast": "https://api.weather.gov/gridpoints/SHV/128,37/forecast",
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, 'http');$Rpos = strpos($test, 'cast,');
     $url  = substr($test, $Lpos,($Rpos-$Lpos)+4);
     break;
     }
}
}

}

