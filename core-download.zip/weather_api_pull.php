<?php
// (c)2015/2023 by The Master lagmrs.com  by pws.winnfreenet.com
// This script uses some code my weather programs. Member CWOP since 2015 
// This is the new api for the NWS. 
//
// Weather caching system. to stop all weather pulls on the hr.
// 
// The purpose is to randomise calls and cach. so all nodes dont pull at the same time.
// 2nd some calls for temp have resulted in NULL This allows a cach to be used until the temp updates. 
//
// version
// v1.0  10/04/2023   First version created to stop overloads on the API
// v1.6  10/11/2023  Added ambent weather
// v1.7  11/02/2023  Extra purge logging removed 
// v1.8  11/17/2023  Tweek cleanup
// v1.9  11/19/2023  FEMA is down. Extra code to kill out of date file if we get bad data.
// v2.0  11/20/2023  Adjustments to cach
// v2.1  12/23/2023  Extra debugging  // Purge old weather files if API goes down
// v2.2  12/25/23    Prevent repeat loading of GEO location file when TWS forcast goes down. 
// v2.3  12/31/23    Error log changes for NWS going down. File not found Protection to ambent read. 
// v2.4  1/25/24    bug fix 
// v2.5  1/29/24    Functions moved to external file. Now saves currect data for webserver from here
// v2.8  2/9        IMprovements to weather
// v2,9  7/7        cyclone added

if (!isset($ver)){ $ver="2.9";}

$path="/etc/asterisk/local/mm-software";
include_once ("$path/load.php"); 
$forcastxml  ="/tmp/geocode.xml";
$forcastxml2 ="/tmp/forcast.xml";
$forcastTxt  ="/tmp/forcast.txt";
$alertxml    ="/tmp/skywarn.xml";
$currentxml  ="/tmp/current.xml";
$currentxmlBAD ="/tmp/current-bad.xml";
$acuwxml     ="/tmp/accuweather.xml";
$femaCSV     ="/tmp/fema.csv";
$ambientxml  ="/tmp/ambient.xml";
$forcastIcons    ="/tmp/forcast_icons.txt";
$forcastWeekFile ="/tmp/forcast_week.txt";
$nameWeekFile    ="/tmp/forcast_name.txt";
$cyclone         ="/tmp/cyclone.xml";
$cycloneTxt      ="/tmp/cyclone.txt";

$cycloneURL = "/gis-at.xml"; // set from ones listed at cyclone update ///https://www.nhc.noaa.gov/aboutrss.shtml

include_once ("$path/weather_functions.php"); 


$outtemp="";$data_good=false;$type="?";$the_temp="";
$datum  = date('m-d-Y H:i:s');
$file= $cyclone ;
if (file_exists($file)){
 $ft = time()-filemtime($file);
 if ($ft > 1 * 3600){ // if its older 1 hr
 $fth=round($ft /3600);
 $out="Purging $file ($fth hrs) old.";save_task_log ($out);print"$datum $out\n";
 unlink ($file);unlink ($cycloneTxt );
 } 
}

$file= $forcastTxt;
if (file_exists($file)){
 $ft = time()-filemtime($file);
 if ($ft > 20 * 3600){ // if its older than a day get rid of it
 $fth=round($ft /3600);
 $out="Purging $file ($fth hrs) old.";save_task_log ($out);print"$datum $out\n";
 unlink ($file);
 } 
}
$file= $forcastIcons;
if (file_exists($file)){
 $ft = time()-filemtime($file);
 if ($ft > 20 * 3600){ 
 $fth=round($ft /3600);
 $out="Purging $file ($fth hrs) old.";save_task_log ($out);print"$datum $out\n";
 unlink ($file);
 }
// else {$fth=round($ft /3600); $out="$file ($fth hrs) old.";print"$datum $out\n";} 
}
$file= $forcastWeekFile;
if (file_exists($file)){
 $ft = time()-filemtime($file);
 if ($ft > 20 * 3600){ 
 $fth=round($ft /3600);
 $out="Purging $file ($fth hrs) old.";save_task_log ($out);print"$datum $out\n";
 unlink ($file);
 unlink ($nameWeekFile);
 } 
}

$file= $nameWeekFile;
if (file_exists($file)){
 $ft = time()-filemtime($file);
 if ($ft > 20 * 3600){ 
 $fth=round($ft /3600);
 $out="Purging $file ($fth hrs) old.";save_task_log ($out);print"$datum $out\n";
 unlink ($file);
 } 
}




//$ambientApiKey         = ""; // Your station
// If ambent API
if($ambientApiKey){
$update=true; $ft=0;
$randomMin = mt_rand(40, 60);// age of the file.
$file= $ambientxml;
if (file_exists($file)){
// print "$datum cache $file exists\n";
 $ft = time()-filemtime($file);
 $ft = round(($ft)/60);                             
 if ($ft < $randomMin){$update=false; print "$datum using cache for current ambient ($ft mins old).Target $randomMin Min\n";}
 if ($ft >65){unlink($ambientxml);$update=true; print "$datum current cache is stale ($ft mins old). Target $randomMin Purging it\n";} // save_task_log ("Purging $ambientxml");
}
//else{ print "$datum $file does not exists\n";}

if ($update){
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$ambientApplicationKey = "63edf3218001424093bed2167262f769f87b1ff4aa024a85a91af1f149e78283"; // Get your own its free DONT COPY

$domain ="rt.ambientweather.net"; 
$url = "v1/devices/?apiKey=$ambientApiKey&applicationKey=$ambientApplicationKey";


$datum  = date('m-d-Y H:i:s'); print "$datum Polling $domain for your station ($ft mins old)>";

$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Accept: application/cap+xml" .
                  "Cookie: foo=bar\r\n" .
                  "User-Agent: lagmrs.com $ver weather software\r\n" 
));
$context = stream_context_create($options);
$html = @file_get_contents("https://$domain/$url",false,$context);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);

if(!$html){
$status="<ERROR> ";if($poll_time>=20){$status="$status timeout";}
save_task_log ("ambient API Station error $status $poll_time Sec.");
print "$status $poll_time Sec.\n";
if (file_exists($file)){ unlink($file);}
watchdog ("net"); $data_good=false;
print "$datum Atempting to use backup feed\n";
}

else{  
$file=$ambientxml;
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$html);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
watchdog ("oknet");
print "OK $poll_time Sec.\n";
if (!file_exists($file)){print "$datum ERROR unable to Create: $file\n";}
  }
 }

//read_ambient_api_temp ($file);
read_ambient($file); // Decode all the data and save it as current for the webserver
if($data_good){$the_temp=$outtemp;$type="AMB";save_curent($data_good);}// ---------------------save------------------------------
else{  if (file_exists($file)){unlink ($file);print "$datum Erase bad data: $file\n";}}
$file="";
} // end ambient key





//if ($data_good){print "$datum data_good=true $outtemp\n";}
//if (!$data_good){print "$datum data_good=false $outtemp\n ";}

// Only get the NWS data if the above was not done. 
if($data_good){$file= $currentxml;if (file_exists($file)){unlink ($file);}$update=false;}
// THE NWS station pull 
if($station and !$data_good){
$update=true; $ft=0;
$randomMin = mt_rand(40, 60);// age of the file.
$file= $currentxml;
if (file_exists($file)){
 $ft = time()-filemtime($file);
 $ft = round(($ft)/60);                             
 if ($ft < $randomMin){$update=false; print "$datum using cache for current NWS ($ft mins old).Target $randomMin Min\n";}
 if ($ft >65){unlink($currentxml); print "$datum current cache is stale ($ft mins old). Purging it\n";} //  save_task_log ("Purging $currentxml");
}

if ($update){
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$domain ="api.weather.gov"; $html="";
//$url = "stations/$station/observations/latest";// latest only  (will have nulls at random times problems-)
//$url = "stations/$station/observations";// get several readings Huge 1.2 meg file
$limitReports=12;
$url = "stations/$station/observations?limit=$limitReports";// get the last x reports  



$datum  = date('m-d-Y H:i:s'); print "$datum Polling $domain for $station last $limitReports reports ($ft mins old)>";

$options = array(
    'http'=>array(
        'timeout' => 30,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Accept: application/cap+xml" .
                  "Cookie: foo=bar\r\n" .
                  "User-Agent: lagmrs.com $ver weather software\r\n" // Tell the NWS who we are
));
$context = stream_context_create($options);
$html = @file_get_contents("https://$domain/$url",false,$context);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
//print "\n https://$domain/$url\n$html \n"; 
if(!$html){
$status="Received NULL ";if($poll_time>=10){$status="$status timeout";}
save_task_log ("weather API Station error $status $poll_time Sec."); 
print "$status $poll_time Sec.\n"; 
watchdog ("net");
print "$datum ";
$data_good=false; 
}
else{
$file=$currentxmlBAD;$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$html);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
//read_api_temp ($file);
read_NWS ($file); // Read all the data from the file.
}

if ($data_good){
if (file_exists($currentxml)){unlink($currentxml);} 
if (file_exists($currentxmlBAD)){rename ($currentxmlBAD,$currentxml);}
$the_temp=$outtemp;$type="NWS";save_curent($data_good);// ---------------------save------------------------------
watchdog ("oknet");
print "OK $poll_time Sec.\n";
}
else{
$status="NO Temp Data!";if($poll_time>=10){$status="$status timeout";}
save_task_log ("weather API Station error $status $poll_time Sec. https://$domain/$url");
print "$status $poll_time Sec.\n";
if (file_exists($currentxmlBAD)){ if (file_exists($acuwxml)){unlink ($acuwxml);}}// force a update
  } // else bad
 }// end update
}// end of NWS station id



// Get the forcast from acuweather
$update=true;
$randomMin = mt_rand(59, 250);// random age of the file. 
$file= $acuwxml;
if (file_exists($file)){
 $ft = time()-filemtime($file);
 $ft = round(($ft)/60);                             
 if ($ft < $randomMin){$update=false; print "$datum using cache for conditions ($ft mins old).Target $randomMin Min\n";} 
}

if ($update){
// Poll acuweather for the current conditions. 
$file=$acuwxml;
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;  
$datum   = date('m-d-Y H:i:s');print "$datum Polling Accuweather Conditions $zipcode >";
$options = array(
    'http'=>array(
        'timeout' => 10,  
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Cookie: foo=bar\r\n" .
                  "User-Agent: lagmrs.com $ver weather software \r\n" 
));
$context = stream_context_create($options);
$url="http://rss.accuweather.com/rss/liveweather_rss.asp?metric=F&locCode=$zipcode";
$html = @file_get_contents("$url");
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);

if(!$html){
$status="Received $html ";if($poll_time>=10){$status="$status timeout";}
save_task_log ("Acuweather API Station error $status $poll_time Sec.");
print "$status $poll_time Sec.\n";
if (file_exists($file)){ unlink($file);}
watchdog ("net");
 }
 
else{
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$url\n$html");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
read_acuweather($file);
watchdog ("oknet");
if($cond1){print " [$cond1]";}
if($temp) {print " Temp:[$temp]";}
print "OK $poll_time Sec.\n";
if(!$the_temp and $temp){
$the_temp=$temp;
$condWX="$temp $cond1";

// build current file for webserver from just the temp.
//$WindChill="";$heatIndex="";$outtemp="";$outtempC="";$feelsLike="";$dewpoint=""; 
//$outhumi="";$barometricPressure="";$barometricPressureABS="";$uv="";$solarradiation="";
//$rainofdaily="";$rainofmonthly="";$rainofyearly=""; $winddir="";
//$avgwind="";$gustspeed="";$maxdailygust="";$textDescription=""; $station="Acuweather";
//save_curent($data_good); (dont save into charts this is corrupting the graphs.)
// off dont for now

 
  }// only use the temp if we dont have one.
 } // good data
} // update acuweather



// Test the age of the geocoded file
$update=true; 
$forcastxml  ="/tmp/geocode.xml";
$forcastxml2 ="/tmp/forcast.xml"; 
$randomMin = mt_rand(39, 59);// age of the file. mins random
$file= $forcastxml;
if (file_exists($file)){
 $ft = time()-filemtime($file);
 $ft = round(($ft)/60);                              
 if ($ft < $randomMin){
 $update=false; 
 print "$datum using cache for NWS Gecode ($ft mins old).Target $randomMin Min\n";
 if (!file_exists($forcastxml2)){print "$datum NWS Server is down no forcast data [Error] \n";save_task_log ("NWS Server Forcast Down");} 
}
}


if ($update){
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$domain ="api.weather.gov"; $url = "/points/$lat,$lon"; 
$datum  = date('m-d-Y H:i:s');print "$datum Polling $domain for location $lat/$lon>";
$file=$forcastxml;
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Accept: application/cap+xml" .
                  "Cookie: foo=bar\r\n" .
                  "User-Agent: lagmrs.com $ver weather software\r\n" // Tell the NWS who we are
));
$context = stream_context_create($options);
$html = @file_get_contents("https://$domain/$url",false,$context);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);


if(!$html){
if($debug){print"https://$domain/$url\n";} 
$status="<error1> empty";if($poll_time>=10){$status="$status timeout";}
save_task_log ("weather API GeoCode error $status $poll_time Sec.");
print "$status $poll_time Sec.\n";
if (file_exists($file)){ unlink($file);}
watchdog ("net");
}
else{

$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$html);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
watchdog ("oknet");
print "OK $poll_time Sec.\n";
if($debug){print"https://$domain/$url\n";} 
read_api_url ($file); // the URL is pulled from above file.
// now we have a URL to get a forcast 

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
print "$datum Polling $domain for Geocoded Forcast>";
$file=$forcastxml2;
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Accept: application/cap+xml" .
                  "Cookie: foo=bar\r\n" .
                  "User-Agent: lagmrs.com $ver weather software\r\n" // Tell the NWS who we are
));
$context = stream_context_create($options);
$html = @file_get_contents("$url",false,$context);
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
 
if(!$html){
$status="<error2> empty";if($poll_time>=10){$status="$status timeout";}
save_task_log ("weather API forcast error $status $poll_time Sec.");
print "$status $poll_time Sec.\n";
if (file_exists($file)){ unlink($file);}
watchdog ("net");
}

else {
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$html);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
watchdog ("oknet");
print "OK $poll_time Sec.\n";
  }
if($debug){print"$url\n";}   
 }// end else good gps
}// end update

// Test the age of the $alertxml file
$update=true;
$randomMin = mt_rand(10, 29);// age of the file. mins
$file= $alertxml;
if (file_exists($file)){
 $ft = time()-filemtime($file);
 $ft = round(($ft)/60);                             
 if ($ft < $randomMin){$update=false; print "$datum using cache for CapWarn ($ft mins old).Target $randomMin Min\n";} 
}

if ($update){
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$domain ="api.weather.gov"; $url = "/alerts/active?point=$lat,$lon"; 
$datum  = date('m-d-Y H:i:s');
print "$datum Polling $domain for Gecoded Alerts >";
$file=$alertxml;
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Accept: application/cap+xml" .
                  "Cookie: foo=bar\r\n" .
                  "User-Agent: lagmrs.com $ver weather software\r\n" // Tell the NWS who we are
));
$context = stream_context_create($options);
$html = @file_get_contents("https://$domain/$url",false,$context);

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
 
if(!$html){
$status="<error3>";if($poll_time>=10){$status="$status timeout";}
save_task_log ("weather API CAP Warn error $status $poll_time Sec.");
print "$status  $poll_time Sec.\n";
if (file_exists($file)){ unlink($file);}
watchdog ("net");
}

else{
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$html);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
print "<ok> $poll_time Sec.\n";
watchdog ("oknet");
 }
}// end update




// fema https://www.fema.gov/api/open/v2/DisasterDeclarationsSummaries?$filter=declarationDate%20ge%20%272023-10-01T00:00:00.000z%27%20and%20state%20eq%20%27LA%27&$format=csv
// Test the age of the geocoded file 

$file= $femaCSV;
if ($parishCounty and $fema){    // both must be set to even update
$update=true;
$randomMin = mt_rand(1200, 1440);// age of the file. mins   1200 1440 mns in a day

if (file_exists($file)){
 $ft = time()-filemtime($file);
 $ft = round(($ft)/60);                             
 if ($ft < $randomMin){$update=false; print "$datum using cache for FEMA ($ft mins old).Target $randomMin Min\n";} 
}
if ($update){
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
// $parishCounty,$fema,
$date=date('Y-m-d'); $date=$date."T00:00:00.000z";
$domain ="www.fema.gov"; 
$url = "/api/open/v2/DisasterDeclarationsSummaries?\$filter=declarationDate%20ge%20%27$date%27%20and%20state%20eq%20%27$fema%27&\$format=csv"; 
//$url = "/api/open/v2/DisasterDeclarationsSummaries?\$filter=state%20eq%20%27$fema%27&\$format=csv"; 
$datum  = date('m-d-Y H:i:s');  //10-04-2023
print "$datum Polling $domain for Declared Emergencys >";
$file=$femaCSV;
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Accept: application/cap+xml" .
                  "Cookie: foo=bar\r\n" .
                  "User-Agent: $ver 2way radio software\r\n" 
));
$context = stream_context_create($options);
$html = @file_get_contents("https://$domain/$url",false,$context);

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
 
if(!$html){
$status="<error3>";if($poll_time>=10){$status="$status timeout";}
save_task_log ("FEMA error $status $poll_time Sec.");
print "$status  $poll_time Sec.\n";
if (file_exists($file)){ unlink($file);}
// watchdog ("net"); dont count fema as a net down error
}

else{
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$html);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
print "<ok> $poll_time Sec.\n";
watchdog ("oknet");
 }
}// end update
}
else {
if (file_exists($file)){unlink($file);}
}


// 
// cyclone https://www.nhc.noaa.gov/gis-at.xml
// Test the age of the geocoded file 
$cyclone         ="/tmp/cyclone.xml";
$cycloneTxt      ="/tmp/cyclone.txt";
$cycloneURL = "/gis-at.xml"; // set from ones listed at cyclone update ///https://www.nhc.noaa.gov/aboutrss.shtml

$file= $cyclone;
if ($cycloneURL){    
$update=true;
$randomMin = mt_rand(39, 59);// age of the file. mins random

if (file_exists($file)){
 $ft = time()-filemtime($file);
 $ft = round(($ft)/60);                             
 if ($ft < $randomMin){$update=false; print "$datum using cache for Cyclone ($ft mins old).Target $randomMin Min\n";} 
}
if ($update){
if (file_exists($file)){unlink($file);}
if (file_exists($cycloneTxt)){unlink($cycloneTxt);}
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;

$date=date('Y-m-d'); $date=$date."T00:00:00.000z";
$domain ="www.nhc.noaa.gov"; //https://www.nhc.noaa.gov/gis-at.xml
$url = $cycloneURL;

$datum  = date('m-d-Y H:i:s');  //10-04-2023
print "$datum Polling $domain for Cyclones >";

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$options = array(
    'http'=>array(
        'timeout' => 20,  //if it takes this long somethings wrong
        'method'=>"GET",
        'header'=>"Accept-language: en\r\n" .
                  "Accept: application/cap+xml" .
                  "Cookie: foo=bar\r\n" .
                  "User-Agent: $ver 2way radio software\r\n" 
));
$context = stream_context_create($options);
$html = @file_get_contents("https://$domain/$url",false,$context);

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_end = $mtime;
$poll_time = ($poll_end - $poll_start);$poll_time = round($poll_time,2);
 
if(!$html){
$status="<error3>";if($poll_time>=10){$status="$status timeout";}
save_task_log ("Noaa error $status $poll_time Sec.");
print "$status  $poll_time Sec.\n";
if (file_exists($file)){ unlink($file);}
// watchdog ("net"); dont count fema as a net down error
}

else{
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$html);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
print "<ok> $cyclone $poll_time Sec.\n";
if (file_exists($file)){ read_cyclone($file);}

watchdog ("oknet");
 }
}// end update
}





