<?php
// (c)2023 by WXRB288 lagmrs.com  by pws.winnfreenet.com
// all rights reserved
//
// This is not opensource
// v1.1 8/22/2023 
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_start = $mtime;
$copyright="\n<!-- copyright 2023 lagmrs.com all rights reserved -->\n";
//print"<html><head>
//<title>GMRS Live Node Indexing System</title> 
//<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">
//<link type=\"text/css\" rel=\"stylesheet\" href=\"supermon.css\"></head></body>";
//<body style=\"background-color:powderblue;\"> 

print $copyright;

$path       = "/etc/asterisk/local/mm-software";
include_once ("$path/load.php");
include_once ("$path/supermon_input.php");
$type="";$sort="all";$code="";
for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'type')    {  $type = $fieldValues[$i]; }
if ($fieldNames[$i] == 'sort')    {  $sort = $fieldValues[$i]; }
if ($fieldNames[$i] == 'code')    {  $code = $fieldValues[$i]; }
}

             
$nodelist  =  "/var/log/asterisk/astdb.txt"; 
//if(!file_exists($filename)){include_once "$path/nodelist_process.php";}
$Webpath = "/srv/http/gmrs/admin"; 
$dns = "/tmp/rpt_extnodes";
$clean     ="$path/nodelist/clean.csv";// nodelist
$hubs      ="$path/nodelist/hubs.csv";
$repeaters ="$path/nodelist/repeaters.csv";
$callList  ="$path/nodelist/nodes.csv";// non duped calls
$version = phpversion();
$datum = date('m-d-Y-H:i:s');     
$filename="";$desc="All GMRS " ;$city="";
if ($type=="nod"){ $filename =  $clean;$desc="Nodes";$city="City,State";}
if ($type=="rep"){ $filename =  $repeaters;$desc="Repeaters";$city="Info";}
if ($type=="hub"){ $filename =  $hubs;$desc="Hubs";$city="Info";}
if ($sort=="live"){ $sort = "live";$desc="$desc are currently Online";}
if ($sort=="all"){  $sort = "all";$desc="$desc are currently Online & Offline";}
$codeOut= date('mdY');//if ($code<>$codeOut){$filename="";}
print "<p>GMRS Live Node Directory <small>(This is a Live Index showing which $desc)</small><p>";


$title="Online Only 
[<a href=\"/gmrs/gmrs-node-index.php?type=hub&sort=live&code=$codeOut\"> Hubs</a> ]  
[<a href=\"/gmrs/gmrs-node-index.php?type=rep&sort=live&code=$codeOut\"> Repeaters</a> ]  
[<a href=\"/gmrs/gmrs-node-index.php?type=nod&sort=live&code=$codeOut\"> Nodes</a> ]  
 Online & Offline
[<a href=\"/gmrs/gmrs-node-index.php?type=hub&sort=all&code=$codeOut\"> Hubs</a> ]  
[<a href=\"/gmrs/gmrs-node-index.php?type=rep&sort=all&code=$codeOut\"> Repeaters</a> ]  
[<a href=\"/gmrs/gmrs-node-index.php?type=nod&sort=all&code=$codeOut\"> Nodes</a> ]";
//    rColor=darkblue cColor=red bColor=palegreen gColor=lightgray tColor=lemonchiffon lColor=powderblue  <tr class="gColor">    
if ($filename){
// load into memory then print. 
$fileINdns= file($dns);
$i=0;$action=""; // load to memory
$fileIN= file($filename);
foreach($fileIN as $line){
$u = explode("|",$line);
$live=false;
foreach($fileINdns as $lineDns){
 $lineDns = str_replace(" ", "", $lineDns);
 $uu = explode("=",$lineDns);
 if ($uu[0]==$u[0]){
  $live=true;break;}
}
// Allows listing nodes only
if ($type=="nod"){
 if(trim($u[4])=="H"){continue;}
 if(trim($u[4])=="R"){continue;}
 if(trim($u[4])=="Z"){continue;}
 }

if($sort=="live" and !$live){continue;}
$count++;
if (!$live) {$action="$action<tr class=\"gColor\">";$st="*";}
if ($live){ 
$i++;$st="";
if ($i == 1){$action="$action<tr class=\"tColor\">";}
if ($i == 2){$action="$action<tr class=\"wColor\">";$i=0;}
}
$action = "$action<td class=\"nodeNum\">$u[0]$st</td><td>$u[1]</td><td>$u[2]</td><td>$u[3]</td></tr><!--- $u[4] --->\n";
}

print "<table border=0 class=gridtable id=AutoNumber1 '>\n";
print "<tr class=\"lColor\"><td colspan=8 >$title Total nodes:$count</td></tr>\n";
print "<tr class=\"rColor\"><td>NODE</td><td style='text-align: center; vertical-align: middle;'>$desc</td><td>location</td><td>call</td></tr>\n";
print "$action\n";

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_end = $mtime;$script_time = ($script_end - $script_start);$script_time = round($script_time,2);


print"<tr class=\"gColor\"><td colspan=8 align=center>*=Unregistered  (c)2023 by WRXB288 $fdate (Total Time to process $script_time Sec)</td></tr>";  
print"</table>";  

}
else {print "<p>Please select from the above menu!</P>";}
print $copyright;
print"</body></html>";

?>
