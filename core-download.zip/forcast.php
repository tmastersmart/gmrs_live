<?php
// (c)2023 by WRXB288 and LAgmrs.com 
 
//
//
//https://api.weather.gov  module not to be called direct 
//
//   v2.0 7/31/2023
//   v2.1 9/27/2023  Day names file added.
//   v2.2 10/05/2023 Polling moved to polling routine. 
//   v2.3 10/14/2023 fema added
//   v2.4 12/25/23 Debuging added API version
//   v2.5 1/22/24 added watch flags
//   v2.6 1/26   Minor cleanup
//================================test=================
//
//

$shortForcast="";$url=""; $apiVer="?"; $headline="";$event="";

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$forcastxml  ="/tmp/geocode.xml";
$forcastxml2 ="/tmp/forcast.xml";
$forcastTxt  ="/tmp/forcast.txt";
$femaCSV     ="/tmp/fema.csv";
$forcastIcons    ="/tmp/forcast_icons.txt";
$forcastWeekFile ="/tmp/forcast_week.txt";
$nameWeekFile    ="/tmp/forcast_name.txt";
$alertxml    ="/tmp/skywarn.xml";
include_once ("$path/weather_functions.php"); 

// https://api.weather.gov/stations/KIER/observations/latest
if($lat and $lon){
 
//$file=$forcastxml;
$file=$forcastxml2;
if (file_exists($file)){
read_api ($file);   // $apiVer 
if ($shortForcast){print "$datum NWS Forcast: [$shortForcast]\n";}
if ($debug){if ($detailedForecast){print "$datum DEBUG API:$apiVer Detailed: $detailedForecast\n";}}
}                                                        

$file=$alertxml;
if (file_exists($file)){
read_api ($alertxml);
$datum   = date('m-d-Y H:i:s');
//
// CAP Warn is processed by cap_warn.php only
// Weather_pws.php displays but does not process.
//  Filter the alearts. Remove unwanted and dupes

$clean="";$clean2="";$watchWa=false;$watchW=false;$watchA=false;$watchS=false;
$d= explode(",",$headline);
$u= explode(",",$event); $i=-1;
foreach($u as $line){
$i++;
//print "$line\n";
$pos = strpos("-$line", "Warning");  if ($pos){ $watchWa=true;}
if (!$sayWarn and $pos){ continue;}
$pos = strpos("-$line", "Watch");    if ($pos){ $watchW=true;}   
if (!$sayWatch and $pos){ continue;}
$pos = strpos("-$line", "Advisory"); if ($pos){ $watchA=true;}
if (!$sayAdvisory and $pos){ continue;}
$pos = strpos("-$line", "Statement");if ($pos){ $watchS=true;}
if (!$sayStatement and $pos){continue;}

if ($clean){$pos = strpos("-$clean", $line); if ($pos){continue;}}// Get rid of the dupes. 

if($clean){
$clean="$clean,$line";
$clean2="$clean2,$d[$i]";
}
else {$clean=$line;$clean2=$d[$i];}


}

$watchSTATUS="Alert";
if ($event){ 
$event=$clean;$headline=$clean2;
if ($watchS) { $watchSTATUS="Statement";}
if ($watchA) { $watchSTATUS="Advisory";}
if ($watchW) { $watchSTATUS="Watch";}
if ($watchWa){ $watchSTATUS="Warning";}
print "$datum Raw Event(s): [$watchSTATUS] $event \n";
print "$datum Cleaned Event(s): $clean\n";
}
if(!$event){$event="clear";}







if ($debug){
 if ($description){print "$datum DEBUG Description:$description\n";}
 if ($headline){   print "$datum DEBUG Headline:$headline\n";}
}


//if ($shortForcast){print "$datum Forcast: $shortForcast\n";}

//if ($debug){if ($detailedForecast){print "$datum DEBUG Detailed: $detailedForecast\n";}}
if ($description or $shortForcast){$file=$forcastTxt;$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$shortForcast|$detailedForecast|$icon");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);}

if (file_exists($forcastxml2)) {
build_week ($forcastxml2);  
$file=$forcastIcons   ;$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$iconWeek)   ;flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
$file=$forcastWeekFile;$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$forcastWeek);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
$file=$nameWeekFile   ;$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$nameWeek)   ;flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
  }
 }
}
else{$out="ERROR lat/lon not set"; save_task_log ($out);print "$datum $out \n";}

$file=$femaCSV;
if (file_exists($file)){
read_fema($file);
//$parishCounty,$file,$femaY,$femaType,$femaDesc,$femaArea;
//$fema_good
if($femaType){

print "$datum $femaType | $femaDesc\n";
 if ($clean){$clean="$clean,$femaType";}
 else {$clean= $femaType;}

 if ($event){$event="$event,$femaType";}
 else {$event=$femaType;}

 if ($headline){$headline="$headline,$femaType";}
 else {$headline= $femaType;}
 }
}






