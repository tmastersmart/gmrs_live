<?php
// (c)2023 by WRXB288 and LAgmrs.com 
 
//
//
//https://api.weather.gov  module not to be called direct 
//
//   v2.0 7/31/2023
//   v2.1 9/27/2023  Day names file added.
//   v2.2 10/05/2023 Polling moved to polling routine. 
//   v2.3 10/14/2023 fema added
//================================test=================
//
//

$shortForcast="";$url=""; $apiVer="?"; $headline="";$event="";

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$poll_start = $mtime;
$forcastxml  ="/tmp/geocode.xml";
$forcastxml2 ="/tmp/forcast.xml";
$forcastTxt  ="/tmp/forcast.txt";
$femaCSV     ="/tmp/fema.csv";

$forcastIcons    ="/tmp/forcast_icons.txt";
$forcastWeekFile ="/tmp/forcast_week.txt";
$nameWeekFile    ="/tmp/forcast_name.txt";

$alertxml    ="/tmp/skywarn.xml";
$clean="";$clean2="";
// https://api.weather.gov/stations/KIER/observations/latest
if($lat and $lon){
 
//$file=$forcastxml;
$file=$forcastxml2;
if (file_exists($file)){
read_api ($file);
if ($shortForcast){print "$datum Forcast: $shortForcast\n";}
if ($debug){if ($detailedForecast){print "$datum DEBUG Detailed: $detailedForecast\n";}}
}

$file=$alertxml;
if (file_exists($file)){
read_api ($alertxml);
$datum   = date('m-d-Y H:i:s');
//
// CAP Warn is processed by cap_warn.php only
// Weather_pws.php displays but does not process.
//  Filter the alearts. Remove unwanted and dupes

$d= explode(",",$headline);
$u= explode(",",$event); $i=-1;
foreach($u as $line){
$i++;
//$pos = strpos("-$line", "Warning");  if (!$sayWarn and $pos){ continue;} 
$pos = strpos("-$line", "Watch");    if (!$sayWatch and $pos){ continue;}
$pos = strpos("-$line", "Advisory"); if (!$sayAdvisory and $pos){ continue;}
$pos = strpos("-$line", "Statement");if (!$sayStatement and $pos){continue;} 

if ($clean){$pos = strpos("-$clean", $line);     if ($pos){continue;}}// Get rid of the dupes. 

if($clean){
$clean="$clean,$line";
$clean2="$clean2,$d[$i]";
}
else {$clean=$line;$clean2=$d[$i];}


}


if ($event){
print "$datum Raw Event(s): $event\n";
print "$datum Cleaned Event(s): $clean\n";

$event=$clean;$headline=$clean2;
}
if(!$event){$event="clear";}







if ($debug){
 if ($description){print "$datum DEBUG Description:$description\n";}
 if ($headline){   print "$datum DEBUG Headline:$headline\n";}
}


//if ($shortForcast){print "$datum Forcast: $shortForcast\n";}

//if ($debug){if ($detailedForecast){print "$datum DEBUG Detailed: $detailedForecast\n";}}


if($shortForcast){$file=$forcastTxt;$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$shortForcast|$detailedForecast|$icon");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);}

if (file_exists($forcastxml2)) {
build_week ($forcastxml2);  
$file=$forcastIcons   ;$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$iconWeek)   ;flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
$file=$forcastWeekFile;$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$forcastWeek);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
$file=$nameWeekFile   ;$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$nameWeek)   ;flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
  }
 }
}
else{$out="ERROR lat/lon not set"; save_task_log ($out);print "$datum $out \n";}

$file=$femaCSV;
if (file_exists($file)){
read_fema($file);
//$parishCounty,$file,$femaY,$femaType,$femaDesc,$femaArea;
//$fema_good
if($femaType){

print "$datum $femaType | $femaDesc\n";
 if ($clean){$clean="$clean,$femaType";}
 else {$clean= $femaType;}

 if ($event){$event="$event,$femaType";}
 else {$event=$femaType;}

 if ($headline){$headline="$headline,$femaType";}
 else {$headline= $femaType;}
 }
}



function read_fema($file){
global $parishCounty,$file,$femaY,$femaType,$femaDesc,$femaArea;
$html= file($file);$i=0; 
// line 0 is the header we dont need that
//femaDeclarationString,disasterNumber,state,declarationType,declarationDate,fyDeclared,incidentType,declarationTitle,ihProgramDeclared,iaProgramDeclared,paProgramDeclared,hmProgramDeclared,incidentBeginDate,incidentEndDate,disasterCloseoutDate,tribalRequest,fipsStateCode,fipsCountyCode,placeCode,designatedArea,declarationRequestNumber,lastIAFilingDate,lastRefresh,hash,id

//DR-4611-LA,4611,LA,DR,2021-08-29T00:00:00.000Z,2021,Hurricane,HURRICANE IDA,0,0,1,1,2021-08-26T00:00:00.000Z,2021-09-03T00:00:00.000Z,,0,22,001,99001,Acadia (Parish),21091,2021-11-29T00:00:00.000Z,2023-05-22T03:41:22.800Z,ff1a3e46c0e4a3fa2ea3b679f89e9dba67784b28,04d7e3d8-af93-497e-9d4b-ecdcdf057f80
$fema_good=false;  //Acadia (Parish)
$parishCounty=strtolower($parishCounty);
foreach($html as $line){
if($i>=1){
$u = explode(",",$line); 
 $line=strtolower($line);

 $pos = strpos($line, $parishCounty);
 if($pos){  
  //print "\n-$u[19]-$parishCounty-$femaArea $u[6] $u[7]\n";
  $femaY=$u[5];
  $femaType=$u[6];$femaType=strtolower($femaType);
  $femaDesc=$u[7];
  $femaArea=$u[19];
  $fema_good=true;break;
  }
 }
$i++;
 }
}


function read_api ($file){
global $head,$headline,$apiVer,$description,$event,$icon,$shortForcast,$detailedForecast,$url,$data_good,$title,$clear,$file,$out;
// New API   
// headline description 
$html= file($file); $apiVer="?";
foreach($html as $line){


$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$len= strlen($line);

//  "icon": "https://api.weather.gov/icons/land/night/tsra_hi,30/sct?size=medium",   might contain a comma
$pos = strpos($line, 'icon":');  // "icon": "https://api.weather.gov/icons/land/day/tsra_hi,20?size=medium",
if ($pos) {
     $test = trim($line," "); 
     $Lpos = strpos($test, ':');;$Rpos = strpos($test, '",');
     $icon  = substr($test, $Lpos+3, ($Rpos-$Lpos)-3);
     $icon  = str_replace('size=medium', 'size=small', $icon);// Redirect to the smaller icons  small medium and large avalable
//   print "$icon";
}


$pos = strpos($line, '"headline":'); // "headline": "Heat Advisory issued June 25 at 4:22AM CDT until June 25 at 7:00PM CDT by NWS Shreveport LA",
if ($pos) {
     $test = $line; 
     $Lpos = strpos($test, ':');$Rpos = strpos($test, '",');
     $headline2 = substr($test, $Lpos+3,($Rpos-$Lpos)-3);
     $headline2 = str_replace(',', "", $headline2);// just in case TWS breaks things with ,
     $headline2 = trim($headline2," ");
     if($headline2 and $headline){
     $headline ="$headline,$headline2";
     $headline2="";
     }
     else {$headline=$headline2;}
     }    


          
$line = str_replace('"', "", $line);     
     
  
     
     
$pos = strpos($line, 'event:'); //  "event": "Heat Advisory",
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ',');
     $event2 = substr($test, $Lpos+2,($Rpos-$Lpos)-2);
     if($event2 and $event){
     $event ="$event,$event2";// stacks events
     $event2="";
     }
     else {$event=$event2;}
     }
$pos = strpos($line, 'forecast:');  //forecast": "https://api.weather.gov/gridpoints/SHV/128,37/forecast",
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, 'http');$Rpos = strpos($test, 'cast,');
     $url  = substr($test, $Lpos,($Rpos-$Lpos)+4);
     }
$pos = strpos($line, 'shortForecast:');  
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ',');
     $shortForcast  = substr($test, $Lpos+2,($Rpos-$Lpos)-2);
     $shortForcast = str_replace(',', "", $shortForcast);// just in case TWS breaks things with ,
     $shortForcast = trim($shortForcast," ");
     }
     

$pos = strpos($line, 'version:'); //"@version": "1.1",   API still shows 1.1 but may change to 1.2
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ',');
     $apiVer  = substr($test, $Lpos+2, $len-2);
     $apiVer = str_replace(',', "", $apiVer); // just in case TWS breaks things with ,
     }     
$pos = strpos($line, 'detailedForecast:'); // "detailedForecast": "Mostly sunny, with a high near 94. Northeast wind 0 to 10 mph."
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ',');
     $detailedForecast = substr($test,$Lpos+2, $len-2);
     $detailedForecast = str_replace(',', "", $detailedForecast);// just in case TWS breaks things with ,
     $detailedForecast = trim($detailedForecast," ");
     }    

$pos = strpos($line, 'description:');  // "description": "* WHAT...Heat index 
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ',');
     $description2 = substr($test, $Lpos+2,($Rpos-$Lpos)-2);
     $description2 = str_replace(',', "", $description2);// just in case TWS breaks things with ,
     $description2 = trim($description2," ");
     // stack into an array
     if($description2 and $description){
      $description ="$description,$description2";
      $description2="";
     }
     else {$description=$description2;}
     }   







$pos = strpos($line, 'number: 2,');if ($pos) { return;} 
// stop here dont read past today 
 
  }
}


// Day names added since this is fluid and changes Its not always the next 7 days
function build_week ($file){
global $debug,$iconWeek,$forcastWeek,$nameWeek;
$forcastWeek="";$nameWeek="";$iconWeek="";$testI="";
$testI= file($file); 
foreach($testI as $line){

$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);




$pos = strpos($line, 'name":');  //"name": "Tonight",
if ($pos) {
     $test = trim($line," "); $len= strlen($test);
     $Lpos = strpos($test, ':');;$Rpos = strpos($test, '",');
     $nameIt  = substr($test, $Lpos+3, ($Rpos-$Lpos)-3);
     if($nameIt and $nameWeek){
     $nameWeek ="$nameWeek|$nameIt";// stacks a week 
     $nameIt="";
     }
     else {$nameWeek=$nameIt;}
     }




//  "icon": "https://api.weather.gov/icons/land/night/tsra_hi,30/sct?size=medium",   might contain a comma
$pos = strpos($line, 'icon":');  // "icon": "https://api.weather.gov/icons/land/day/tsra_hi,20?size=medium",
if ($pos) {
     $test = trim($line," "); $len= strlen($test);
     $Lpos = strpos($test, ':');;$Rpos = strpos($test, '",');
     $icon2  = substr($test, $Lpos+3, ($Rpos-$Lpos)-3);
     $icon2  = str_replace('size=medium', 'size=small', $icon2);// Redirect to the smaller icons  small medium and large avalable
//     print "$icon2|";
     if($icon2 and $iconWeek){
     $iconWeek ="$iconWeek|$icon2";// stacks a week of icons into array use | not ,
     $icon2="";
     }
     else {$iconWeek=$icon2;}
     }
$line = str_replace('"', "", $line);        
     
//"detailedForecast": "Mostly clear, with a low around 76. South wind 5 to 10 mph."
$pos = strpos($line, 'detailedForecast:');   
if ($pos) {
     $test = $line;   $len=strlen($test); // print "$test\n";
     $Lpos = strpos($test, ':');$Rpos = strpos($test, '}');
     $forcast = substr($test, $Lpos+2,$len); if($debug){print "$forcast\n";}
     $forcast = str_replace(',', "", $forcast);// just in case TWS breaks things with ,
     $forcast = trim($forcast," ");
      if($forcastWeek and $forcast){
     $forcastWeek ="$forcastWeek|$forcast";// stacks a week into array use | not ,
     $forcast="";
     }
     else {$forcastWeek=$forcast;}
     }
     
 
     
     
     
     
  }
}


