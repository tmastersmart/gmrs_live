<?php
//  ------------------------------------------------------------
//  (c) 2023 by WRXB288 lagmrs.com all rights reserved
//
// do not run this  install("I");  // I gives install prompt
// -------------------------------------------------------------
// 1.9 09/18/23 added cleanup of license files and linefeeds
// 2.0 09/29/23 Changes to allow for promptless updates later
// 2.1 10/02/23 Stop backing up the log

function install($in){
global $datum,$file,$path; 

$verInstaller= "2.1"; $verRt="10-02-2023";
$path  = "/etc/asterisk/local/mm-software";
$pathG = "/srv/http/gmrs";
print "
---------------------------------------------------------------
Module: Updater $verInstaller Release Date:$verRt
(c) 2023 by WRXB288 lagmrs.com all rights reserved 

This will download then update the GMRS Node Controler software

It will not touch any existing orginal supermon system.
GMRS supermon is located in: $pathG
Main software is located in: $path

";

// I=prompt A= autoinstall.

if ($in=="I"){print " U) Update/install  any other key to abort!\n";
$a = readline('Enter your command: ');if ($a <> "u"){return;}
}
print "--------------------------------------------------------\n";

$path  = "/etc/asterisk/local/mm-software";        
$repoURL= "https://raw.githubusercontent.com/tmastersmart/gmrs_live/main";
$pathS = "$path/sounds";if(!is_dir($pathS)){ mkdir($pathS, 0755);}
$pathR = "$path/repo";  if(!is_dir($pathR)){ mkdir($pathR, 0755);}
$pathB = "$path/backup";if(!is_dir($pathB)){ mkdir($pathB, 0755);}
$pathG = "/srv/http/gmrs";if(!is_dir($pathG)){ mkdir($pathG, 0755);}
$pathGA= "/srv/http/gmrs/admin";if(!is_dir($pathGA)){ mkdir($pathGA, 0755);}
$pathGE= "/srv/http/gmrs/edit";if(!is_dir($pathGE)){ mkdir($pathGE, 0755);}
$pathI = "/srv/http/gmrs/images";if(!is_dir($pathI)){ mkdir($pathI, 0755);}
$pathN = "/var/lib/asterisk/sounds/rpt/nodenames";
 
print"Cleaning any existing repos......\n";
chdir($pathR);

          
$file = "$pathR/core-download.zip"; if (file_exists($file)){unlink ($file);}
$file = "$pathR/sounds.zip"; if (file_exists($file)){unlink ($file);}
$file = "$pathR/supermon.zip";if (file_exists($file)){unlink ($file);}
$file = "$pathR/nodenames.zip";if (file_exists($file)){unlink ($file);}
$file = "$pathR/gmrs.zip"; if (file_exists($file)){unlink ($file);}
$file = "$pathR/admin.zip";if (file_exists($file)){unlink ($file);}
$file = "$pathR/images.zip"; if (file_exists($file)){unlink ($file);}
$file = "$pathR/file_id.diz"; if (file_exists($file)){unlink ($file);}


 chdir($pathR);
 print "Downloading new repos ...........\n";
  exec("sudo wget $repoURL/core-download.zip",$output,$return_var);
  exec("sudo wget $repoURL/sounds.zip",$output,$return_var);
//exec("sudo wget $repo/supermon.zip",$output,$return_var);
  exec("sudo wget $repoURL/nodenames.zip",$output,$return_var); 
  exec("sudo wget $repoURL/gmrs.zip",$output,$return_var);
  exec("sudo wget $repoURL/admin.zip",$output,$return_var);
  exec("sudo wget $repoURL/images.zip",$output,$return_var);

 print "Downloading finished...........\n";
 chdir($pathR);
  
 exec("unzip $pathR/core-download.zip",$output,$return_var);
  
     
   foreach (glob("*.php") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing php file:$path/$file "; 
    if (file_exists("$path/$file")){unlink("$path/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){
    rename ("$pathR/$file", "$path/$file");
     exec("sudo chmod +x $path/$file",$output,$return_var); 
    } 
    print"ok\n";
    }
  }
  
   foreach (glob("*.csv") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing csv file:$path/$file "; 
    if (file_exists("$path/$file")){unlink("$path/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$path/$file"); } 
    print"ok\n";
    }
  }  
 
   foreach (glob("*.txt") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing txt file:$path/$file "; 
    if (file_exists("$path/$file")){unlink("$path/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$path/$file"); } 
    print"ok\n";
    }
  }  
 
 

if (file_exists("$path/taglines.txt")){
exec("touch -d 19910101 $path/taglines.txt",$output,$return_var);// Just being funny taglines are very old.
}




exec("unzip $pathR/sounds.zip",$output,$return_var);
//$path2 = "$path/sounds";$path3 = "$path/repo";$path4 = "$path/backup"; // just for debugging
chdir($pathR);   
 foreach (glob("*.wav") as $file) {
  if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing wav file:$pathS/$file "; 
    if (file_exists("$pathS/$file")){unlink("$pathS/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathS/$file");} // Move it into the SOUNDS
    print"ok\n";
    }
  }

 foreach (glob("*.ul") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing ul file:$pathS/$file "; 
    if (file_exists("$pathS/$file")){unlink("$pathS/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathS/$file");} // Move it into the SOUNDS
    print"ok\n";
    }
  }

 foreach (glob("*.gsm") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing gsm file:$pathS/$file "; 
    if (file_exists("$pathS/$file")){unlink("$pathS/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathS/$file");} // Move it into the SOUNDS
    print"ok\n";
    }
  }
  

// new install GMRS Supermon

exec("unzip $pathR/gmrs.zip",$output,$return_var); 

chdir($pathR);   
 foreach (glob("*.php") as $file) {
  if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing php file:$pathG/$file "; 
    if (file_exists("$pathG/$file")){unlink("$pathG/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathG/$file");} 
    print"ok\n";
    }
  }
  
 foreach (glob("*.css") as $file) {
  if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing css file:$pathG/$file "; 
    if (file_exists("$pathG/$file")){unlink("$pathG/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathG/$file");} 
    print"ok\n";
    }
  }  
  
 foreach (glob("*.js") as $file) {
  if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing js file:$pathG/$file "; 
    if (file_exists("$pathG/$file")){unlink("$pathG/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathG/$file");} 
    print"ok\n";
    }
  } 
 foreach (glob("*.inc") as $file) {
  if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing inc file:$pathG/$file "; 
    if (file_exists("$pathG/$file")){unlink("$pathG/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathG/$file");} 
    print"ok\n";
    }
  } 
 foreach (glob("*.ini") as $file) {
  if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing ini file:$pathG/$file "; 
    if (file_exists("$pathG/$file")){unlink("$pathG/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathG/$file");} 
    print"ok\n";
    }
  }            
  foreach (glob("*.ico") as $file) {
  if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing ico file:$pathG/$file "; 
    if (file_exists("$pathG/$file")){unlink("$pathG/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathG/$file");} 
    print"ok\n";
    }
  } 
  
exec("unzip $pathR/admin.zip",$output,$return_var); 
//$pathGA = "$pathG/admin";

chdir($pathR);   
 foreach (glob("*.php") as $file) {
  if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing php file:$pathGA/$file "; 
    if (file_exists("$pathGA/$file")){unlink("$pathGA/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathGA/$file");} 
    print"ok\n";
    }
  }
  
 foreach (glob("*.css") as $file) {
  if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing css file:$pathGE/$file "; 
    if (file_exists("$pathGA/$file")){unlink("$pathGA/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathGA/$file");} 
    print"ok\n";
    }
  }  
  
 foreach (glob("*.js") as $file) {
  if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing js file:$pathGE/$file "; 
    if (file_exists("$pathGA/$file")){unlink("$pathGA/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathGA/$file");} 
    print"ok\n";
    }
  } 
 foreach (glob("*.inc") as $file) {
  if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing inc file:$pathGA/$file "; 
    if (file_exists("$pathGA/$file")){unlink("$pathGA/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathGA/$file");} 
    print"ok\n";
    }
  } 
 foreach (glob("*.ini") as $file) {
  if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing ini file:$pathGA/$file "; 
    if (file_exists("$pathGA/$file")){unlink("$pathGA/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathGA/$file");} 
    print"ok\n";
    }
  }            
  foreach (glob("*.ico") as $file) {
  if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing ico file:$pathGA/$file "; 
    if (file_exists("$pathGA/$file")){unlink("$pathGA/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathGA/$file");} 
    print"ok\n";
    }
  } 

exec("unzip $pathR/images.zip",$output,$return_var); 
//$pathI = "$pathG/images";

chdir($pathR);   
 foreach (glob("*.gif") as $file) {
  if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing gif file:$pathI/$file "; 
    if (file_exists("$pathI/$file")){unlink("$pathI/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathI/$file");} 
    print"ok\n";
    }
  }
 foreach (glob("*.jpg") as $file) {
  if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing jpg file:$pathI/$file "; 
    if (file_exists("$pathI/$file")){unlink("$pathI/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathI/$file");} 
    print"ok\n";
    }
  }

//======================================


// "/var/lib/asterisk/sounds/rpt/nodenames";    $pathN 

exec("unzip $pathR/nodenames.zip",$output,$return_var);


 foreach (glob("*.ul") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing ul file:$pathN/$file "; 
    if (file_exists("$pathN/$file")){unlink("$pathN/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathN/$file");print"--";} // Move it into the SOUNDS
    print"ok\n";
    }
  }
$pathB = "$path/backup";

//$cur   = date('mdyhis');

// make backups, erase the old ones to save space
$file = "$path/setup.txt";   $file2= "$pathB/setup.txt";  if (file_exists($file2)){unlink($file2);} 
copy($file, $file2);print "Backup $file2\n";

$file = "$path/mm-node.txt"; $file2= "$pathB/mm-node.txt";if (file_exists($file2)){unlink($file2);}
copy($file, $file2);print "Backup $file2\n";

$file = "$path/logs/log.txt";$file2= "$pathB/log.txt";    if (file_exists($file2)){unlink($file2);}
copy($file, $file2);print "Backup $file2\n";

// clean_repo($path3);



// Update Bridging link.
$fileEdit ="/usr/local/sbin/sm-support/smlogger_background.sh"; $fileBu = "$fileEdit-.bak"; 
if (file_exists($fileBu)){ unlink ($fileEdit);copy ($fileBu,$fileEdit);}

// reinstall the bridge link
check_bridge_installed ("check");

// cleanup
$file="license-sounds.txt";if (file_exists("$path/$file")){unlink("$path/$file");}
$file="license-core.txt";  if (file_exists("$path/$file")){unlink("$path/$file");}
$file="license-web.txt";   if (file_exists("$path/$file")){unlink("$path/$file");}

print "----\n";


}


// Uninstaller 
function uninstall($in){
global $datum,$file,$path;
$verInstaller= "1.5"; $verRt="08-28-2023";
print "
===============================================================
Module: Uninstaller $verInstaller Release Date:$verRt
(c) 2023 by WRXB288 lagmrs.com all rights reserved

This will remove all the software and set back to orginal
be sure this is what you want to do.
If you have major problems you should try update first.
===============================================================

-----> UNINSTALLER <-------
  
  u) uninstall 

 Any other key to abort 
";
$a = readline('Enter your command: ');

if ($a == "u"){

$path  = "/etc/asterisk/local/mm-software"; 
$repo = "https://raw.githubusercontent.com/tmastersmart/gmrs_live/main";
$pathS = "$path/sounds";
$pathR = "$path/repo"; 
$pathB = "$path/backup";
$pathCt = "$path/charts";
$pathG = "/srv/http/gmrs";
$pathGA= "/srv/http/gmrs/admin";
$pathGE= "/srv/http/gmrs/edit";
$nodesounds="/var/lib/asterisk/sounds/rpt/nodenames"; 

$datum = date('m-d-Y-H:i:s');

print "$datum Uninstalling ";
// reinstall orginal cron
unSetcron($in);

$file ="/usr/local/sbin/firsttime/mmsoftware.sh";if (file_exists($file)){unlink ($file);}
$file ="/etc/asterisk/local/mm-software/install.php";if (file_exists($file)){unlink ($file);}
$file ="/tmp/install.php";if (file_exists($file)){unlink ($file);}                 

$fileEdit ="/usr/local/sbin/sm-support/smlogger_background.sh";
$fileBu = "$fileEdit-.bak"; 
if (file_exists($fileBu)){
unlink ($fileEdit); 
copy ($fileBu,$fileEdit); 
exec("sudo chmod +x /usr/local/sbin/sm-support/smlogger_background.sh",$output,$return_var); 
}

// make backups in this version backups are not removed. Will be later
$cur   = date('mdyhis');
$file = "$path/setup.txt";    if (file_exists($file)){$file2="$pathB/setup-$cur.txt"  ;rename($file, $file2);} 
$file = "$path/mm-node.txt";  if (file_exists($file)){$file2="$pathB/mm-node-$cur.txt";rename($file, $file2);} 
$file = "$path/logs/log.txt"; if (file_exists($file)){$file2="$pathB/log-$cur.txt"    ;rename($file, $file2);} 
$file = "$path/logs/log2.txt";if (file_exists($file)){$file2="$pathB/log2-$cur.txt"   ;rename($file, $file2);} 

$path  = "/etc/asterisk/local/mm-software"; 
chdir($path);
clean_repo($pathR);     rmdir($pathR);
clean_repo($pathS);     rmdir($pathS);
clean_repo($pathCt);     rmdir($pathCt);
//clean_repo($pathB);     rmdir($pathB);   // skiping so we can keep backups
clean_repo("$path/nodelist"); rmdir("$path/nodelist");
clean_repo("$path/logs");     rmdir("$path/logs");  

clean_repo($pathGA);   rmdir($pathGA); 
clean_repo($pathGE);   rmdir($pathGE); 
clean_repo($pathG);    rmdir($pathG);  
clean_repo($nodesounds);
clean_repo($pathR);
// remove dir will fail if not empty
clean_repo($path);

print "[OK]

$datum Node Manager Uninstalled. 
In this early version backups will be kept in [$pathB]
for debugging. 

If the install.php file was located in  /etc/asterisk/local or /tmp
it was removed. 
Please report any problems you may have had to www.lagmrs.com

To reinstall type
cd /etc/asterisk/local
wget https://raw.githubusercontent.com/tmastersmart/gmrs_live/main/install.php
php install.php

";

} 
quit('EXIT');
}






?>
