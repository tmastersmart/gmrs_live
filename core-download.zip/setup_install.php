<?php
//  ------------------------------------------------------------
//  (c) 2023 by WRXB288 lagmrs.com all rights reserved
//
// do not run this
// load setup
// function moved to its own file
// $ver="v4.8"; $release="08-20-2023";
// -------------------------------------------------------------
$verInstaller= "1.4.9"; $verRt="08-28-2023";

function install($in){
global $datum,$file,$path; 


$path  = "/etc/asterisk/local/mm-software";
$pathG = "/srv/http/gmrs";
print "
---------------------------------------------------------------
Module: Updater $verInstaller Release Date:$verRt
(c) 2023 by WRXB288 lagmrs.com all rights reserved

This will download then update the GMRS Node Controler software

It will not touch any existing orginal supermon system.
GMRS supermon is located in: $pathG
Main software is located in: $path

U) Update/install  any other key to abort!
---------------------------------------------------------------
";
$a = readline('Enter your command: ');

if ($a == "u"){
        
$repo = "https://raw.githubusercontent.com/tmastersmart/gmrs_live/main";
$pathS = "$path/sounds";if(!is_dir($pathS)){ mkdir($pathS, 0755);}
$pathR = "$path/repo";  if(!is_dir($pathR)){ mkdir($pathR, 0755);}
$pathB = "$path/backup";if(!is_dir($pathB)){ mkdir($pathB, 0755);}
$pathG = "/srv/http/gmrs";if(!is_dir($pathG)){ mkdir($pathG, 0755);}
$pathGA= "/srv/http/gmrs/admin";if(!is_dir($pathGA)){ mkdir($pathGA, 0755);}
$pathGE= "/srv/http/gmrs/edit";if(!is_dir($pathGE)){ mkdir($pathGE, 0755);}
 
$filesP = "supermon_lnodes.php,tagline.php,setup.php,setup_install.php,supermon_weather.php,load.php,forcast.php,temp.php,cap_warn.php,weather_pws.php,sound_db.php,check_reg.php,nodelist_process.php,check_gmrs.sh,connect.php";
$filesD = "sound_gsm_db.csv,sound_wav_db.csv,sound_ulaw_db.csv,states.csv,cron.txt,readme.txt,taglines.txt";   
$filesG = "favicon.ico,supermon.css,link.php,lsnodes.php,gmrs-node-index.php,server.php,controlserver.php,gmrs-chart.php,connect.php,controlpanel.php,index.php";
$filesGE = "dtmf.php,controlserver.php,controlpanel.php";
$filesGA = "log.php";

print"Cleaning any existing repos......\n";
chdir($pathR);
clean_repo($pathR);         
$file = "$repo/core-download.zip"; 
if (file_exists($file)){unlink ($file);}
if (file_exists($file)){print"Error removing old file $file\n";}
$file = "$repo/sounds.zip";        
if (file_exists($file)){unlink ($file);}
if (file_exists($file)){print"Error removing old file $file\n";}
$file = "$repo/supermon.zip";      
if (file_exists($file)){unlink ($file);}
if (file_exists($file)){print"Error removing old file $file\n";}
$file = "$repo/nodenames.zip";     
if (file_exists($file)){unlink ($file);}
if (file_exists($file)){print"Error removing old file $file\n";}


 print "Downloading new repos ...........\n";
  exec("sudo wget $repo/core-download.zip",$output,$return_var);
  exec("sudo wget $repo/sounds.zip",$output,$return_var);
  exec("sudo wget $repo/supermon.zip",$output,$return_var);
  exec("sudo wget $repo/nodenames.zip",$output,$return_var);  
  exec("unzip $pathR/core-download.zip",$output,$return_var);
  
 print "Downloading finished...........
 
 
 
 ----------------------------------------------------------------\n";
 
$u = explode(",",$filesP);// ------------------------------------
foreach($u as $file) {
  print "Installing -PHP $path/$file ";
  if (!file_exists("$pathR/$file")){print"error file missing\n";}
  else{
  if (file_exists("$path/$file")){unlink("$path/$file");}
  rename ("$pathR/$file", "$path/$file");
  exec("sudo chmod +x $path/$file",$output,$return_var); 
  print"ok\n";
  }
  } 
 
$u = explode(",",$filesD);// ---------------------------------------
foreach($u as $file) {
  print "Installing -database $path/$file ";
    if (!file_exists("$pathR/$file")){print"error file missing\n";}
  else{
  if (file_exists("$path/$file")){unlink("$path/$file");}
  if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$path/$file");}
  print"ok\n";
  } 
  }
if (file_exists("$path/taglines.txt")){
exec("touch -d 19910101 $path/taglines.txt",$output,$return_var);// Just being funny taglines are very old.
}

exec("unzip $pathR/sounds.zip",$output,$return_var);
//$path2 = "$path/sounds";$path3 = "$path/repo";$path4 = "$path/backup"; // just for debugging
chdir($pathR);   
 foreach (glob("*.wav") as $file) {
  if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing sound file:$pathS/$file "; 
    if (file_exists("$pathS/$file")){unlink("$pathS/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathS/$file");print"--";} // Move it into the SOUNDS
    print"ok\n";
    }
  }

 foreach (glob("*.ul") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing sound file:$pathS/$file "; 
    if (file_exists("$pathS/$file")){unlink("$pathS/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathS/$file");print"--";} // Move it into the SOUNDS
    print"ok\n";
    }
  }

 foreach (glob("*.gsm") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing sound file:$pathS/$file "; 
    if (file_exists("$pathS/$file")){unlink("$pathS/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathS/$file");print"--";} // Move it into the SOUNDS
    print"ok\n";
    }
  }
  


//   $pathG     = "/srv/http/gmrs";
exec("unzip $pathR/supermon.zip",$output,$return_var); 
$u = explode(",",$filesG); 
foreach($u as $file) {
  print "Installing -Supermon root $filesG/$file ";
  if (!file_exists("$pathR/$file")){print"error file missing\n";}
  else{
  if (file_exists("$pathG/$file")){unlink("$pathG/$file");}
  rename ("$pathR/$file", "$pathG/$file");
  exec("sudo chmod +x $pathG/$file",$output,$return_var); 
  print"ok\n";
  }
}
 
$pathGE = "$pathG/edit";

$u = explode(",",$filesGE); 
foreach($u as $file) {
  print "Installing -Supermon edit $pathGE/$file ";
  if (!file_exists("$pathR/$file")){print"error file missing\n";}
  else{
  if (file_exists("$pathGE/$file")){unlink("$pathGE/$file");}
  rename ("$pathR/$file", "$pathGE/$file");
  exec("sudo chmod +x $pathGE/$file",$output,$return_var); 
  print"ok\n";
  }

}



$u = explode(",",$filesGA);
foreach($u as $file) {
  print "Installing -Supermon admin $pathGA/$file ";
  if (!file_exists("$pathR/$file")){print"error file missing\n";}
  else{
  if (file_exists("$pathGA/$file")){unlink("$pathGA/$file");}
  rename ("$pathR/$file", "$pathGA/$file");
  print"ok\n";
  }
  }
$nodesounds="/var/lib/asterisk/sounds/rpt/nodenames";

 foreach (glob("*.ul") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { unlink($file);print"del $file\n";  }
    }

exec("unzip $pathR/nodenames.zip",$output,$return_var);


 foreach (glob("*.ul") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing sound file:$pathS/$file "; 
    if (file_exists("$pathS/$file")){unlink("$pathS/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathS/$file");print"--";} // Move it into the SOUNDS
    print"ok\n";
    }
  }

// make backups
$cur   = date('mdyhis');
$file = "$path/setup.txt";   $file2= "$path4/setup-$cur.txt";  copy($file, $file2);
$file = "$path/mm-node.txt"; $file2= "$path4/mm-node-$cur.txt";copy($file, $file2);
$file = "$path/logs/log.txt";$file2= "$path4/log-$cur.txt"   ; copy($file, $file2);

// clean_repo($path3);



// Update Bridging link.
// uninstall the bridging link. 
$fileEdit ="/usr/local/sbin/sm-support/smlogger_background.sh";
$fileBu = "$fileEdit-.bak"; 
if (file_exists($fileBu)){
unlink ($fileEdit); 
copy ($fileBu,$fileEdit); 
}

// reinstall the bridge link
check_bridge_installed ("check");

}// end og U

start_menu("start");start("start");
}


// Uninstaller 
function uninstall($in){
global $datum,$file,$path;
print "
===============================================================
Module: Uninstaller $verInstaller Release Date:$verRt
(c) 2023 by WRXB288 lagmrs.com all rights reserved

This will remove all the software and set back to orginal
be sure this is what you want to do.
If you have major problems you should try update first.
===============================================================

-----> UNINSTALLER <-------
  
  u) uninstall 

 Any other key to abort 
";
$a = readline('Enter your command: ');

if ($a == "u"){

$path  = "/etc/asterisk/local/mm-software"; 
$repo = "https://raw.githubusercontent.com/tmastersmart/gmrs_live/main";
$pathS = "$path/sounds";
$pathR = "$path/repo"; 
$pathB = "$path/backup";
$pathG = "/srv/http/gmrs";
$pathGA= "/srv/http/gmrs/admin";
$pathGE= "/srv/http/gmrs/edit";
$nodesounds="/var/lib/asterisk/sounds/rpt/nodenames"; 

$datum = date('m-d-Y-H:i:s');

print "$datum Uninstalling ";
// reinstall orginal cron
unSetcron($in);

$file ="/usr/local/sbin/firsttime/mmsoftware.sh";if (file_exists($file)){unlink ($file);print"-";}
$file ="/etc/asterisk/local/mm-software/install.php";if (file_exists($file)){unlink ($file);print"-";}
$file ="/tmp/install.php";if (file_exists($file)){unlink ($file);print"-";}


$fileEdit ="/usr/local/sbin/sm-support/smlogger_background.sh";
$fileBu = "$fileEdit-.bak"; 
if (file_exists($fileBu)){
unlink ($fileEdit);print"-"; 
copy ($fileBu,$fileEdit);print"-"; 
exec("sudo chmod +x /usr/local/sbin/sm-support/smlogger_background.sh",$output,$return_var); 
}

// make backups in this version backups are not removed. Will be later
$cur   = date('mdyhis');
$file = "$path/setup.txt";   if (file_exists($file)){$file2= "$path4/setup-$cur.txt";  rename($file, $file2);print"-";} 
$file = "$path/mm-node.txt"; if (file_exists($file)){$file2= "$path4/mm-node-$cur.txt";rename($file, $file2);print"-";} 
$file = "$path/logs/log.txt";if (file_exists($file)){$file2= "$path4/log-$cur.txt"   ; rename($file, $file2);print"-";} 
$file = "$path/logs/log2.txt";if (file_exists($file)){$file2= "$path4/log2-$cur.txt"   ; rename($file, $file2);print"-";} 

chdir($path);
clean_repo($pathR);     rmdir($pathR);print"-";
clean_repo($pathS);     rmdir($pathS);print"-";
//clean_repo($pathB);     rmdir($pathB);   // skiping so we can keep backups
clean_repo("$path/nodelist/"); rmdir("$path/nodelist/");print"-";
clean_repo("$path/logs/");     rmdir("$path/logs/"); print"-"; 
// erase custom supermon directories
clean_repo($pathGA);   rmdir($pathGA); print"-";
clean_repo($pathGE);   rmdir($pathGE); print"-";
clean_repo($pathG);    rmdir($pathG);  print"-";
clean_repo($nodesounds);print"-";
clean_repo($pathR);print"-";
// remove dir will fail if not empty
clean_repo($path);print"-";

print "[OK]

$datum Node Manager Uninstalled. 
In this early version backups will be kept in [$pathB]
for debugging. 

If the install.php file was located in  /etc/asterisk/local or /tmp
it was removed. 
Please report any problems you may have had to www.lagmrs.com

To reinstall type
cd /etc/asterisk/local
wget https://raw.githubusercontent.com/tmastersmart/gmrs_live/main/install.php
php install.php

";

} 
quit('EXIT');
}






?>
