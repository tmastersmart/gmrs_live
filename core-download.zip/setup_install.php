<?php
//  ------------------------------------------------------------
//  (c) 2023 by WRXB288 lagmrs.com all rights reserved
//
// do not run this
// load setup
// function moved to its own file
// $ver="v4.8"; $release="08-20-2023";
// -------------------------------------------------------------
function install($in){
global $datum,$file,$path; 

$verInstaller= "1.4.8"; $verRt="08-20-2023";
$path  = "/etc/asterisk/local/mm-software";
$pathG = "/srv/http/gmrs";
print "
---------------------------------------------------------------
Module: Updater $verInstaller Release Date:$verRt
(c) 2023 by WRXB288 lagmrs.com all rights reserved

This will download then update the GMRS Node Controler software

It will not touch any existing orginal supermon system.
GMRS supermon is located in: $pathG
Main software is located in: $path

U) Update/install  any other key to abort!
---------------------------------------------------------------";
$a = readline('Enter your command: ');

if ($a == "u"){
        
$repo = "https://raw.githubusercontent.com/tmastersmart/gmrs_live/main";
//$pathS = "/srv/http/supermon";
$pathS = "$path/sounds";if(!is_dir($pathS)){ mkdir($pathS, 0755);}
$pathR = "$path/repo";  if(!is_dir($pathR)){ mkdir($pathR, 0755);}
$pathB = "$path/backup";if(!is_dir($pathB)){ mkdir($pathB, 0755);}
$pathG = "/srv/http/gmrs";if(!is_dir($pathG)){ mkdir($pathG, 0755);}
$pathGA= "/srv/http/gmrs/admin";if(!is_dir($pathGA)){ mkdir($pathGA, 0755);}
$pathGE= "/srv/http/gmrs/edit";if(!is_dir($pathGE)){ mkdir($pathGE, 0755);}


// programs  
$filesP = "supermon_lnodes.php,tagline.php,setup.php,setup_install.php,supermon_weather.php,load.php,forcast.php,temp.php,cap_warn.php,weather_pws.php,sound_db.php,check_reg.php,nodelist_process.php,check_gmrs.sh,connect.php";
// Text and database files 
$filesD = "sound_gsm_db.csv,sound_wav_db.csv,sound_ulaw_db.csv,states.csv,cron.txt,readme.txt,taglines.txt,version.txt";   
// gmrs Supermon directory
$filesG = "favicon.ico,supermon.css,link.php,lsnodes.php,gmrs-node-index.php,server.php,controlserver.php,gmrs-chart.php,connect.php,controlpanel.php,index.php";
// files in the edit directory
$filesGE = "dtmf.php,controlserver.php,controlpanel.php";
// This is the new GMRS Supermon admin area
$filesGA = "log.php";

print"Cleaning any existing repos......\n";
chdir($pathR);
clean_repo($pathR);         
$file = "$repo/core-download.zip"; 
if (file_exists($file)){unlink ($file);}
if (file_exists($file)){print"Error removing old file $file\n";}
$file = "$repo/sounds.zip";        
if (file_exists($file)){unlink ($file);}
if (file_exists($file)){print"Error removing old file $file\n";}
$file = "$repo/supermon.zip";      
if (file_exists($file)){unlink ($file);}
if (file_exists($file)){print"Error removing old file $file\n";}
$file = "$repo/nodenames.zip";     
if (file_exists($file)){unlink ($file);}
if (file_exists($file)){print"Error removing old file $file\n";}


 print "Downloading new repos ...........\n";
  exec("sudo wget $repo/core-download.zip",$output,$return_var);
  exec("sudo wget $repo/sounds.zip",$output,$return_var);
  exec("sudo wget $repo/supermon.zip",$output,$return_var);
  exec("sudo wget $repo/nodenames.zip",$output,$return_var);  
  exec("unzip $pathR/core-download.zip",$output,$return_var);
  
 print "Downloading finished...........
 
 
 
 ----------------------------------------------------------------\n";
 
$u = explode(",",$filesP);// ------------------------------------
foreach($u as $file) {
  print "Installing -PHP $path/$file ";
  if (!file_exists("$pathR/$file")){print"error file missing\n";}
  else{
  if (file_exists("$path/$file")){unlink("$path/$file");}
  rename ("$pathR/$file", "$path/$file");
  exec("sudo chmod +x $path/$file",$output,$return_var); 
  print"ok\n";
  }
  } 
 
$u = explode(",",$filesD);// ---------------------------------------
foreach($u as $file) {
  print "Installing -database $path/$file ";
    if (!file_exists("$pathR/$file")){print"error file missing\n";}
  else{
  if (file_exists("$path/$file")){unlink("$path/$file");}
  if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$path/$file");}
  print"ok\n";
  } 
  }
if (file_exists("$path/taglines.txt")){
exec("touch -d 19910101 $path/taglines.txt",$output,$return_var);// Just being funny taglines are very old.
}

exec("unzip $pathR/sounds.zip",$output,$return_var);
//$path2 = "$path/sounds";$path3 = "$path/repo";$path4 = "$path/backup"; // just for debugging
chdir($pathR);   
 foreach (glob("*.wav") as $file) {
  if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing sound file:$pathS/$file "; 
    if (file_exists("$pathS/$file")){unlink("$pathS/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathS/$file");print"--";} // Move it into the SOUNDS
    print"ok\n";
    }
  }

 foreach (glob("*.ul") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing sound file:$pathS/$file "; 
    if (file_exists("$pathS/$file")){unlink("$pathS/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathS/$file");print"--";} // Move it into the SOUNDS
    print"ok\n";
    }
  }

 foreach (glob("*.gsm") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing sound file:$pathS/$file "; 
    if (file_exists("$pathS/$file")){unlink("$pathS/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathS/$file");print"--";} // Move it into the SOUNDS
    print"ok\n";
    }
  }
  


//   $pathG     = "/srv/http/gmrs";
exec("unzip $pathR/supermon.zip",$output,$return_var); 
$u = explode(",",$filesG); // ----------------------------------------------
foreach($u as $file) {
  print "Installing -Supermon root $path1/$file ";
  if (!file_exists("$pathR/$file")){print"error file missing\n";}
  else{
  if (file_exists("$pathG/$file")){unlink("$pathG/$file");}
  rename ("$pathR/$file", "$pathG/$file");
  exec("sudo chmod +x $patG/$file",$output,$return_var); 
  print"ok\n";
  }
}
 
$pathGE = "$pathG/edit";

$u = explode(",",$filesGE); // ------------------------------------------------
foreach($u as $file) {
  print "Installing -Supermon edit $path6/$file ";
  if (!file_exists("$pathR/$file")){print"error file missing\n";}
  else{
  if (file_exists("$pathGE/$file")){unlink("$pathGE/$file");}
  rename ("$pathR/$file", "$pathGE/$file");
  exec("sudo chmod +x $patgGE/$file",$output,$return_var); 
  print"ok\n";
  }

}



// delete these files from the supermon directory. They are not needed or can be hacked 
//$files = "astlookup.php,voter.php,irlplog.php,bubblechart.php,astnodes.php,extnodes.php,voterserver.php,connectlog.php,webacclog.php,astlog.php,rptstats.php,linuxlog.php,weberrlog.php,allmon.ini";
//$u = explode(",",$files);
//foreach($u as $file) {
//  print "Removing Supermon root $path1/$file ";
// // if (file_exists("$path1/$file")){unlink("$path1/$file");}
//  print"ok\n";
//  }
 


$u = explode(",",$filesGA);// -------------------------------------------------
foreach($u as $file) {
  print "Installing -Supermon admin $pathGA/$file ";
  if (!file_exists("$pathR/$file")){print"error file missing\n";}
  else{
  if (file_exists("$pathGA/$file")){unlink("$pathGA/$file");}
  rename ("$pathR/$file", "$pathGA/$file");
  print"ok\n";
  }
  }
$nodesounds="/var/lib/asterisk/sounds/rpt/nodenames";

 foreach (glob("*.ul") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { unlink($file);print"del $file\n";  }
    }

exec("unzip $pathR/nodenames.zip",$output,$return_var);


 foreach (glob("*.ul") as $file) {
    if($file == '.' || $file == '..') continue;
    if (is_file($file)) { 
    print"Installing sound file:$pathS/$file "; 
    if (file_exists("$pathS/$file")){unlink("$pathS/$file");print"Replacing ";}// kill existing file
    if (file_exists("$pathR/$file")){rename ("$pathR/$file", "$pathS/$file");print"--";} // Move it into the SOUNDS
    print"ok\n";
    }
  }

// make backups
$cur   = date('mdyhis');
$file = "$path/setup.txt";   $file2= "$path4/setup-$cur.txt";  copy($file, $file2);
$file = "$path/mm-node.txt"; $file2= "$path4/mm-node-$cur.txt";copy($file, $file2);
$file = "$path/logs/log.txt";$file2= "$path4/log-$cur.txt"   ; copy($file, $file2);

// clean_repo($path3);



// Update Bridging link.
// uninstall the bridging link. 
$fileEdit ="/usr/local/sbin/sm-support/smlogger_background.sh";
$fileBu = "$fileEdit-.bak"; 
if (file_exists($fileBu)){
unlink ($fileEdit); 
copy ($fileBu,$fileEdit); 
}

// reinstall the bridge link
check_bridge_installed ("check");

}// end og U

start_menu("start");start("start");
}

?>
