<?php
// (c)2015/2023 by The Master lagmrs.com  by pws.winnfreenet.com
// This script uses some code my weather programs. Member CWOP since 2015 

// I license you to use this on your copy of this software only.
// Not for use on anything but GMRS.  GMRS ONLY! 

// No part of this code is opensource 
//
// _______ _                 __          __        _   _                  _____             
//|__   __(_)                \ \        / /       | | | |                / ____|            
//   | |   _ _ __ ___   ___   \ \  /\  / /__  __ _| |_| |__   ___ _ __  | |     _ __  _   _ 
//   | |  | | '_ ` _ \ / _ \   \ \/  \/ / _ \/ _` | __| '_ \ / _ \ '__| | |    | '_ \| | | |
//   | |  | | | | | | |  __/    \  /\  /  __/ (_| | |_| | | |  __/ |    | |____| |_) | |_| |
//   |_|  |_|_| |_| |_|\___|     \/  \/ \___|\__,_|\__|_| |_|\___|_|     \_____| .__/ \__,_|
//                                                                             | |          
//                                                                             |_|          
// 
// Swapped datafeed from mesowest to NWS API. We were overloading  mesowest and they wanted me to go paid. 

// You need to get weather from your local airport. Some other mesowest stations may also work.
// v5.8 10/06/23  Added ambent weather
// v5.9 10/17/23  Winchill adjustments
// v6.0 10/22/23  Port number not reset to default. Moving to setup
// v6.1 10/24/23  Dont check the port#
// v6.3 11/07/23  Dont Burst adjustments ( Fixed level 0 should have been mute)
// v6.4 11/17/23  Acuweather problems. Receiving 0f with no conditions
// v6.5 11/20/23  Minor thunderstorm warnings adjustments
// v6.6 11/23/23  Ambent weather adjustments
// v6.7 12/31/23  Tagline changes
// v6.8 1/6/24    using GM time for muting
// v7   1/15/24   Saving raw temp readings for later processing
// v7.1 1/16      New database for temp data ,dewpoint added
// v7.2 1/21      cpu log moved to new chart
// v7.4 1/29      Changes in pm detection and lunch time. Change in alerts. New sounds. Cleanup recomment code.
//                Was not polling weather when in mute. Now polling for weather charts.
// v7.5 2/8       Supports NWS not sending both press types and now reads wind gust if selected 

$ver= "v7.5";$release="2/8/2024";  

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_start = $mtime;
$path="/etc/asterisk/local/mm-software";
include_once ("$path/load.php");      // settings .. Functions
include_once ("$path/sound_db.php");  // functions
include_once ("$path/check_reg.php"); 
include_once ("$path/weather_functions.php"); 
$file= "$path/mm-node.txt"; 
if(file_exists($file)){
$line = file_get_contents($file);
$u= explode(",",$line);
$AutoNode=$u[0];$call=$u[1];$autotts=$u[2];
}
srand (time (0));
$currentTime = "/tmp/current-time.gsm";if(file_exists($currentTime)){unlink($currentTime);}
$clash="/tmp/mmweather-task.txt";
$error="";$action="";$condWX=""; $the_temp="";$moo="";$cond1="";$data_good=false;$WindChill="";$temp=""; $feelsLike=""; $uv="";  $dewpoint=""; 
$condWX=""; $the_temp="";$heatIndex="";$outhumi="";$avgwind=""; $rainofdaily="";$barometricPressure="";$stationID="";$solarradiation=""; 
$phpVersion= phpversion();
$time= date('H:i');
$date =  date('m-d-Y');
// Token generated for this script. owned by LAGMRS.com
// I license you to use this on your copy of this software only.
$datum   = date('m-d-Y H:i:s');$gmdatum = gmdate('m-d-Y H:i:s');
print "
===================================================
Time Temp Weather $coreVersion $ver
mesowest, madis, APRSWXNET(CWOP)
(c)2013/2023 WRXB288 LAGMRS.com all rights reserved
$phpzone PHP v$phpVersion  Release date:$release
===================================================
$datum Model: $piVersion
$datum Node:$node UTC:$gmdatum 
";

// test for clash (only 1 thread allowed)
if(file_exists($clash)){
 $out="Waiting for other thread. "; save_task_log($out);print"$datum $out\n";
 sleep(90);
 // safety clear abandoned flags
 $ft = time()-filemtime($clash);
 $ft = round(($ft)/60); 
 if ($ft > 10){unlink($clash);}  // 10 mins
}

$fileOUT = fopen($clash,'w');fwrite ($fileOUT,$datum);fclose ($fileOUT);

// test for mute move to start
$hour=date('H');$day=date('D');// $hour=gmdate('H');$day=gmdate('D');
$mute=false;
if($MuteNet1){ if($hour>=$Net1Start and $hour <=$Net1Stop and $day=="Wed"){ $mute=true;$out="Net1 $day $hour Muted";}}
if($MuteNet2){ if($hour>=$Net2Start and $hour <=$Net2Stop and $day=="Sun"){ $mute=true;$out="Net2 $day $hour Muted";}}
if($MuteNet3){ if($hour>=$Net3Start and $hour <=$Net3Stop and $day=="Fri"){ $mute=true;$out="Net3 $day $hour Muted";}}
if($sleep)   { if($hour>=1 and $hour <=6){ $mute=true;$out="Sleep Mute $day $hour am ";}}
if($mute){save_task_log ($out);print "$datum $out\n";}
if($level == "0"){$mute=true;} // new settings 0=mute 1= talk

$forcastxml  ="/tmp/geocode.xml";
$forcastxml2 ="/tmp/forcast.xml";
$alertxml    ="/tmp/skywarn.xml";
$currentxml  ="/tmp/current.xml"; $currentTxt  ="/tmp/current.txt";
$acuwxml     ="/tmp/accuweather.xml"; $conditionsTxt  ="/tmp/conditions.txt";
$ambientxml  ="/tmp/ambient.xml";
$weatherLogs ="$path/logs/weather.csv";
$log         ="$path/logs/cpu_temp_log.txt";

watchdog ("oknet");// default to good network

include_once ("$path/weather_api_pull.php"); 



// ---------------------------------ambient read----------------------------
if (file_exists($ambientxml)){
 read_ambient($ambientxml); 
$status="";
$datum = date('m-d-Y H:i:s');
if ($data_good){ 
$validTemp = true;
$action = watchdog ("oknet");
$the_temp=$outtemp; $status="$stationID Temp:$the_temp";
// ambent only provides feelslike 
if($dewpoint){ $status ="$status Dew:$dewpoint";}
if($heatIndex){$status ="$status HeatIndex:$heatIndex";}
if($WindChill){$status ="$status WindChill:$WindChill";}
//if($feelsLike <> $the_temp){$status ="$status FeelsLike:$feelsLike";}
if($outhumi){$status ="$status hum:$outhumi%";}
if($avgwind    >0){$status ="$status Wind:$avgwind";}
if($gustspeed and $avgwind){if($gustspeed > $avgwind){$status ="$status Gust:$gustspeed";}}
if($rainofdaily>0){$status ="$status Rain:$rainofdaily";}
if($barometricPressure>0){$status ="$status Pres:$barometricPressure ";}
if($barometricPressureABS>0){$status ="$status PresABS:$barometricPressureABS ";}
if($uv>0){$status ="$status UV Index:$uv";}
if($solarradiation>0){$status ="$status Solar:$solarradiation";}
$condWX=$status;save_task_log ($condWX);
print "$datum Ambient $condWX \n";
}
else{
$datum   = date('m-d-Y H:i:s');
$status="<error>";save_task_log ("AMB $status ");
print "$datum Abient $status bad data.\n";
$file=$ambientxml; if (file_exists($file)){ unlink($file);}// remove the file so it can be reloaded
$validTemp = false;$condWX=""; $the_temp="";$heatIndex="";$outhumi="";$avgwind=""; $rainofdaily="";$gustspeed="";
}

}// end AMB




// -----------------------------------------NWS read -----------------------------------------
if (file_exists($currentxml) and !$data_good){
read_NWS($currentxml);
$status="";$datum   = date('m-d-Y H:i:s');
if ($data_good){ 
$validTemp = true;$action = watchdog ("oknet");
$the_temp=$outtemp;
$status="$station Temp:$the_temp"; 
if($dewpoint){ $status ="$status Dew:$dewpoint";}
if($heatIndex){$status ="$status HeatIndex:$heatIndex";}
if($WindChill){$status ="$status WindChill:$WindChill";}
if($outhumi){  $status ="$status Hum:$outhumi%";}
if($avgwind>0){$status ="$status Wind:$avgwind";}  
if($gustspeed and $avgwind){if($gustspeed > $avgwind){$status ="$status Gust:$gustspeed";}}
if($rainofdaily>0){$status ="$status Rain:$rainofdaily";}
if($barometricPressure>0){$status ="$status Pres:$barometricPressure ";}
if($barometricPressureABS>0){$status ="$status PresABS:$barometricPressureABS ";}
if($textDescription){$cond1=strtolower($textDescription);} // pull out cond from the station
$condWX=$status;save_task_log ($condWX);
print "$datum NWS: $condWX\n"; 

}// end data good
else{
$status="<error>";save_task_log ("NWS $status");
print "$datum NWS $status bad data.\n";
$file=$currentxml; if (file_exists($file)){ unlink($file);}// remove the file so it can be reloaded
$validTemp = false;$condWX=""; $the_temp="";$heatIndex="";$outhumi="";$avgwind=""; $rainofdaily="";$gustspeed="";
}
// end NWS
}







if ($cond1){print "$datum NWS Conditions: $cond1\n";} 

// -----------------------------Acuweather Backup system ------------------------------ 
if (!$cond1 or !$the_temp) { 
$file=$acuwxml; read_acuweather($file);
print "$datum Acuweather";
if($cond1){print " [$cond1]";}
if($temp) {print " Temp:[$temp]";}
else{print" <ERROR>";unlink($acuwxml);}
print "\n";
if(!$the_temp and $temp){$the_temp=$temp;$condWX="$temp $cond1";}// only use the temp if we dont have one.
} // end acuweather


// ----------------------- forcast-----------------------------------
include_once ("$path/forcast.php");// mandatory to get alerts
if ($event=="clear"){$event="";} // Skip if clear

// This has been moved into the API so it saves the data after polls and not on the hr.
//$in="";save_curent($in);// -------------------------------save------------------------------

if (!$mute){

// ------------------------------Start sounds--------------------------
$hour=date('H');$day=date('l');$hr=date('h');$min=date('i');$cmd="";
check_gsm_db ("silence1");if($file1){$action = "$action $file1";}
$randomS = mt_rand(1, 4);
if ($randomS==1){check_wav_db("star dull");if($file1){$action = "$action $file1";}}
if ($randomS==2){check_wav_db("light click");if($file1){$action = "$action $file1";}}
if ($randomS==3){check_gsm_db("beep");if($file1){$action = "$action $file1";}}  
if ($randomS==4){check_wav_db("strong click");if($file1){$action = "$action $file1";}} 
//good,good-afternoon,good-evening,good-morning, (need good night)
$status ="";
if ($hour < 12)                {check_gsm_db("good-morning");  if($file1){$action="$action $file1";}}
if ($hour >=12 and $hour <=18) {check_gsm_db("good-afternoon");if($file1){$action="$action $file1";}}
if ($hour >=19)                {check_gsm_db("good-evening");  if($file1){$action="$action $file1";}}
// channel-insecure-warn,    currently  current-time-is     is-currently
$datum   = date('m-d-Y H:i:s');

$random = mt_rand(1, 3);
if ($random == 1){check_gsm_db  ("the time is");     if($file1){$action = "$action $file1";} }
if ($random == 2){check_gsm_db  ("current-time-is"); if($file1){$action = "$action $file1";} }
if ($random == 3){check_gsm_db  ("currently");       if($file1){$action = "$action $file1";} check_gsm_db  ("the time is"); if($file1){$action = "$action $file1";}}

$oh=false;make_number ($hr); $action = "$action $actionOut";
//if ($min == 0 ){check_gsm_db ("oclock");if($file1){$action = "$action $file1";}}  // this just doesnt sound right with am/pm after it
if ($min<>0){$oh=true;make_number ($min); $action = "$action $actionOut";}

$timestamp = time();$pm = date('a', $timestamp);
if ($pm=="am"){check_gsm_db ("a-m");if($file1){$action = "$action $file1";}} 
if ($pm=="pm"){check_gsm_db ("p-m");if($file1){$action = "$action $file1";}} 
if ($hour == 12 and $min<=6){check_gsm_db("lunch_time");if($file1){$action="$action $file1";}}

$datum   = date('m-d-Y H:i:s');print "$datum The time is $hr:$min $pm\n";
check_gsm_db ("silence1");if($file1){$action = "$action $file1";}
//check_gsm_db ("silence2");if($file1){$action = "$action $file1";}

// -----------------Conditions ----------------------
if ($levelCond){
$datum   = date('m-d-Y H:i:s');
check_gsm_db ("weather"); if($file1){$action = "$action $file1";}
check_gsm_db ("conditions");if($file1){$action = "$action $file1";}   
$cond1 = str_replace('thunderstorms', "thunderstorm", $cond1);   // thunderstorms
$cond1 = str_replace('rain', "rain2", $cond1); // play sound2
$u = explode(" ",$cond1);
foreach ($u as $word) { if($word){ check_gsm_db ($word);if($file1){$action = "$action $file1";}}}
} // end cond


// -----------------------forcast --------------------
if ($levelForcast and $shortForcast){
 $status = "today";
 if ($hour >= 12 and $hour <=19) {$status = "evening";}  
 if ($hour >= 19 and $hour <=21) {$status = "tonight";} 
 check_gsm_db ($status);if($file1){$action = "$action $file1";}
 $test = strtolower($shortForcast); 
// reformat for better sound
$test = str_replace('thunderstorms', "thunderstorm", $test);   // thunderstorms
$test = str_replace('chance', "chance-of", $test);
$test = str_replace('slight chance-of', "slight_chance", $test);
$test = str_replace('rain showers', "rain_showers", $test);
$test = str_replace('showers and thunderstorms', "showers_and_thunderstorms", $test);
$test = str_replace('areas of fog', "areas_of_fog", $test);
//$test = str_replace('showers', "rain", $test);  // we need a showers file
//$test = str_replace('nws', "national weather service", $test);
// likely needs to be reencoded
$test = str_replace('then', "later", $test);
//$test = str_replace('slight', "low", $test);
$test = str_replace('fog/mist', "fog misty", $test);// we also have fog,foggy,misty and in wav Dense Fog Advisory 
$u = explode(" ",$test);
foreach ($u as $word) { if($word){check_gsm_db ($word);if($file1){$action = "$action $file1";} }}
} // end forcast


 

// CAP 1.2 --------------alerts --------------------
if (!$mute and $clean){ 
check_wav_db  ("strong click");if($file1){$action = "$action $file1";}
$watchSTATUS="alert";
if ($watchS) {$watchSTATUS="Special Weather Statement";check_wav_db ($watchSTATUS);if($file1){$action = "$action $file1";$watchSTATUS="";} }
if ($watchA) {$watchSTATUS="advisory";}
if ($watchW) {$watchSTATUS="watch";   }
if ($watchWa){$watchSTATUS="warning"; }
print "$datum Alert(s) Detected $watchSTATUS\n";
//print "DEBUG $event";
if ($watchSTATUS){ 
//check_gsm_db ("a");if($file1){$action = "$action $file1";}
check_gsm_db ($watchSTATUS);if($file1){$action = "$action $file1";}
//check_wav_db ("weather service");if($file1){$action = "$action $file1";}
} 
check_wav_db  ("strong click");if($file1){$action = "$action $file1";}
$u = explode(",",$clean);
foreach ($u as $line) {
if($line){ check_wav_db($line); if($file1){$action = "$action $file1";} }
 
// check for major warrnings.
// persons in path of 
if($line=="Tornado Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("tornado");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Severe Thunderstorm Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("thunderstorm");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Hurricane Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("hurricane");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
if($line=="Blizzard Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("blizzard");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
// Fire Weather Watch,Red Flag Warning, sets a burn ban flag
//if($line=="Red Flag Warning" or $line=="Fire Weather Watch" ){
// check_wav_db ("Burn Ban");if($file1){$action = "$action $file1";}
//}

// Hydrologic Outlook  ( this is a statement about flooding. Unsure if we should honor)
check_wav_db ("weather service");if($file1){$action = "$action $file1";}
check_wav_db ("light click"); if($file1){$action = "$action $file1";}

 } // end for
} // end alerts
 

$datum   = date('m-d-Y H:i:s');

// --------------------------TEMP ----------------------------
if($levelTemp and $the_temp) {
check_gsm_db ("temperature");if($file1){$action = "$action $file1";}
$the_temp=number_format((float)$the_temp, 2, '.', '');  // fixes a php error
list($whole, $decimal) = explode('.', $the_temp);
$oh=false;make_number ($whole);$action = "$action $actionOut";
if($decimal>=1){
 check_gsm_db ("point");if($file1){$action = "$action $file1";} 
 $oh=true;make_number ($decimal);$action = "$action $actionOut";
}
check_gsm_db ("degrees");if($file1){$action = "$action $file1";} 
$moo=false; // make a comment on the temp    cool
$random = mt_rand(1, 4);
//$random = rand(1,3);
if ($the_temp >90 or $the_temp <20){ 
 if ($random == 1 or $random == 4){check_gsm_db ("moo1");  if($file1){$action = "$action $file1";$moo=true;}}
 if ($random == 2){check_gsm_db ("we-apologize");   if($file1){$action = "$action $file1";}} 
 if ($random == 3){check_gsm_db ("groovy");if($file1){$action = "$action $file1";}} 
 }
}// end temp



if($levelTemp and $heatIndex) {
$test=$the_temp+15;//if ($heatIndex >=100){$test=$the_temp;}    // when to read it
if($heatIndex >$test) {
check_gsm_db ("heat index");if($file1){$action = "$action $file1";}
$heatIndex= number_format((float)$heatIndex, 2, '.', '');
list($whole, $decimal) = explode('.', $heatIndex);
$oh=false;make_number ($whole); $action = "$action $actionOut";
check_gsm_db ("degrees");if($file1){$action = "$action $file1";}
if(!$moo){ if ($heatIndex >90 ){ check_gsm_db ("moo1"); if($file1){$action = "$action $file1";}  } } 
 }
}


if($levelTemp and $WindChill){
$test=$the_temp-15;//if ($WindChill <=35){$test=$the_temp;}
if($WindChill <$test) {
check_gsm_db ("wind chill");if($file1){$action = "$action $file1";}
$WindChill= number_format((float)$WindChill, 2, '.', '');
list($whole, $decimal) = explode('.', $WindChill);
$oh=false;make_number ($whole); $action = "$action $actionOut";
check_gsm_db ("degrees");if($file1){$action = "$action $file1";} 
if ($WindChill <20 ){check_gsm_db ("moo1");if($file1){$action = "$action $file1";}} 
 }
}



// ----------------------------DewPoint----------------------------------
if($levelDew and $dewpoint){
check_gsm_db ("dew point");if($file1){$action = "$action $file1";}
$dewpoint= number_format((float)$dewpoint, 2, '.', '');
list($whole, $decimal) = explode('.', $dewpoint);
$oh=false;make_number ($whole); $action = "$action $actionOut";
if($decimal>=1){
 check_gsm_db ("point");if($file1){$action = "$action $file1";} 
 $oh=true;make_number ($decimal);$action = "$action $actionOut";
}
check_gsm_db ("degrees");if($file1){$action = "$action $file1";} 
} // end dewpoint



// ----------------------------Hum------------------------------
if($levelHum and $outhumi){
check_gsm_db ("humidity");if($file1){$action = "$action $file1";}
$oh=false;make_number ($outhumi);$action = "$action $actionOut";
check_gsm_db ("percent");if($file1){$action = "$action $file1";}
} // end hum


//-----------------------------Wind---------------------------------
if($levelWind){
 if ($avgwind>0){
check_gsm_db ("wind");if($file1){$action = "$action $file1";} 
$avgwind= number_format((float)$avgwind, 2, '.', '');
list($whole, $decimal) = explode('.', $avgwind);
$oh=false;make_number ($whole);$action = "$action $actionOut";
if($decimal>=1){
 check_gsm_db ("point");if($file1){$action = "$action $file1";} 
$oh=false;make_number ($decimal); $action = "$action $actionOut";
}
check_gsm_db ("miles-per-hour");if($file1){$action = "$action $file1";}
// GUST  if over 3 mph
if ($gustspeed){
 if($gustspeed > $avgwind+3){
check_gsm_db ("gusting-to");if($file1){$action = "$action $file1";} 
$whole= number_format((float)$gustspeed, 0, '.', '');
$oh=false;make_number ($whole);$action = "$action $actionOut";
check_gsm_db ("miles-per-hour");if($file1){$action = "$action $file1";}
   } // if gust >
  } // if gust
 } // wind
// if no wind to report check for gust and if over X 
if($avgwind<1){
 if($gustspeed){
  if($gustspeed > 2){
   check_gsm_db ("wind");if($file1){$action = "$action $file1";} 
   check_gsm_db ("gust");if($file1){$action = "$action $file1";}
   $gustspeed= number_format((float)$gustspeed, 2, '.', '');
   list($whole, $decimal) = explode('.', $gustspeed);
   $oh=false;make_number ($whole);$action = "$action $actionOut";
    if($decimal>=1){
    check_gsm_db ("point");if($file1){$action = "$action $file1";} 
    $oh=false;make_number ($decimal); $action = "$action $actionOut";
    }
   check_gsm_db ("miles-per-hour");if($file1){$action = "$action $file1";} 
   } // gust
  } // if gust
 } // if no wind read the gust
 
} // end lvl







// $level,$levelForcast,$levelDew,$levelRain,$levelPress,$levelUvi,$levelTemp,$levelCond,$levelHum;

// -----------------------------------rain-------------------------------
if ($levelRain and $rainofdaily>0){
check_gsm_db ("rainfall");if($file1){$action = "$action $file1";} 
$rainofdaily= number_format((float)$rainofdaily, 2, '.', '');
list($whole, $decimal) = explode('.', $rainofdaily);
$oh=false;make_number ($whole); $action = "$action $actionOut";

if($decimal>=1){
 check_gsm_db ("point");if($file1){$action = "$action $file1";} 
 $oh=true;make_number ($decimal); $action = "$action $actionOut";
 }
check_gsm_db ("inches");if($file1){$action = "$action $file1";}  
}// end rain 
 

//-----------------------------------press-----------------------------------
if ($levelPress){
  $Press=""; // Some stations dont send both so use in order
  if ($barometricPressureABS>0){$Press= number_format((float)$barometricPressureABS, 2, '.', '');}
  if ($barometricPressure>0){   $Press= number_format((float)$barometricPressure, 2, '.', '');}
  if ($Press){
$random = mt_rand(1, 2);
if ($random==1){check_gsm_db ("pressure");if($file1){$action = "$action $file1";} }   
if ($random==2){check_gsm_db ("barometer");if($file1){$action = "$action $file1";} }   
list($whole, $decimal) = explode('.', $Press);
$oh=false;make_number ($whole); $action = "$action $actionOut";
if($decimal>=1){
 check_gsm_db ("point");if($file1){$action = "$action $file1";} 
 $oh=true;make_number ($decimal); $action = "$action $actionOut";
   }
  }// end press 
} // level check

 
// $level,$levelForcast,$levelDew,$levelRain,$levelPress,$levelUvi,$levelTemp,$levelCond,$levelHum; 
 
//-----------------------------------UVI----------------------------------- 
if ($levelUvi and $uv>=1){
check_gsm_db ("ultraviolet_index");if($file1){$action = "$action $file1";}
$oh=false;make_number ($uv); $action = "$action $actionOut";
}// uvi 

// Start the CPU temp warnings here.
//$log="/tmp/cpu_temp_log.txt";
$datum = date('m-d-Y H:i:s');
$line= exec("/opt/vc/bin/vcgencmd measure_temp",$output,$return_var);// SoC BCM2711 temp
$line = str_replace("'", "", $line);
$line = str_replace("C", "", $line);
$u= explode("=",$line);
$temp=$u[1];
$tempf = (float)(($temp * 9 / 5) + 32);
print "$datum $nodeName Temp is $tempf F $temp C\n";

$line= exec("/opt/vc/bin/vcgencmd get_throttled",$output,$return_var);
//throttled=0x0
$u= explode("x",$line); 
$throttled = "";
if($u[1]== "0"){$throttled = "";}
if($u[1]== "1"){$throttled = "under-voltage-detected";}
if($u[1]== "2"){$throttled = "arm-frequency-capped";}
if($u[1]== "4"){$throttled = "currently-throttled";}
if($u[1]== "8"){$throttled = "soft-temp-limit-active";}
if($u[1]== "10000"){$throttled = "under-voltage-detected";}
if($u[1]== "20000"){$throttled = "arm-frequency-capping";}
if($u[1]== "80000"){$throttled = "throttling-has-occurred";}
if($u[1]== "80000"){$throttled = "soft-temp-limit-occurred";}

if($throttled){$status ="$nodeName $throttled code:$u[1]";save_task_log ($status);print "$datum $status\n";}
$fileOUT = fopen($log, "a") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,$temp, \n");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);

if ($reportAll or $temp >=$hot){
//$vpath ="/var/lib/asterisk/sounds";
$cmd="";
check_gsm_db ("silence1");if($file1){$action = "$action $file1";}
check_gsm_db ($nodeName);if($file1){$action = "$action $file1";} 
list($whole, $decimal) = explode('.', $temp);
$oh=false;make_number ($whole);$action = "$action $actionOut";
if($decimal>=1){
check_gsm_db ("point");if($file1){$action = "$action $file1";} 
$oh=false;make_number ($decimal); $action = "$action $actionOut";
}
check_gsm_db ("degrees");if($file1){$action = "$action $file1";} 
check_gsm_db ("celsius");if($file1){$action = "$action $file1";} 

if ($temp >=$hot){
   $status ="CPU HOT $temp";save_task_log ($status);
 if ($temp >=$high){check_gsm_db ("warning");if($file1){$action = "$action $file1";}} 
 else{check_gsm_db ("high");if($file1){$action = "$action $file1";}}
}
if ($throttled){check_ulaw_db ($throttled);if($file1){$action = "$action $file1";}  }
} // end cpu temp

// ---------------------------------registery---------------------------
if ($counterNet ==0){
// Check the reg
reg_check ("check");// $node1 $ip $port2 $registered
if($registered !="Registered" and $registered != 'Sent'){
 $status="Register Status:$registered";save_task_log ($status);
 watchdog ("reg");// add to counter ,an-error-has-occurred
 check_gsm_db ("an-error-has-occurred");if($file1){$action = "$action $file1";}
 check_gsm_db ("node");if($file1){$action = "$action $file1";} 
 $oh=false;$x=(string)$node;
for($i=0;$i<strlen($x);$i++){ 
make_number ($x[$i]);$action = "$action $actionOut"; //say the numbers one at a time not as a set 
}
//  "Auth. Sent"  "Registered"    rejected: 'Registration Refused' // Request,Auth.,
$pos1 = strpos("-$registered", 'Unregistered');if($pos1){check_gsm_db ("is-not-registered");if($file1){$action = "$action $file1";}}
$pos1 = strpos("-$registered", 'Refused');     if($pos1){check_gsm_db ("is-rejected");      if($file1){$action = "$action $file1";}}
$pos1 = strpos("-$registered", 'Auth');        if($pos1){check_gsm_db ("connecting");       if($file1){$action = "$action $file1";}}
$pos1 = strpos("-$registered", 'Sent');        if($pos1){check_gsm_db ("connecting");       if($file1){$action = "$action $file1";}}
$pos1 = strpos("-$registered", 'Request');     if($pos1){check_gsm_db ("not-yet-connected");if($file1){$action = "$action $file1";}}
}
if ($registered =="Registered"){watchdog ("okreg");}
} // end if net up

if ($counterNet >=1){
$out="Network Error we are offline"; 
save_task_log ($out);print "$datum $out\n";
check_wav_db ("strong click"); if($file1){$action = "$action $file1";}
check_gsm_db ("net down");if($file1){$action = "$action $file1";} 
//check_gsm_db ("sorry2");if($file1){$action = "$action $file1";} 
}


 
// ------------------------------Burst-----------------------------------
$datum   = date('m-d-Y H:i:s'); 
// we need to prevent this from repeating serveral times 
if(!isset($bursted)){$bursted =false;}
if($burst and !$bursted) {
   print "$datum MDC-1200 bursts for ID $burst\n";
   exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);
   $bursted=true;
} 

// ---------------------------------play the file---------------------
print "$datum Playing file $currentTime\n";
//check_gsm_db ("silence1");if($file1){$action = "$action $file1";}
$randomE = mt_rand(1, 5);
//print "$datum $randomS / $randomE\n";
if ($randomE==1){check_wav_db("star dull");if($file1){$action = "$action $file1";}}
if ($randomE==2){check_wav_db("light click");if($file1){$action = "$action $file1";}}
if ($randomE==3){check_gsm_db("beep");if($file1){$action = "$action $file1";}} 
if ($randomE==4){check_wav_db("strong click");if($file1){$action = "$action $file1";}} 
//if ($randomE==5){check_wav_db("silence1");if($file1){$action = "$action $file1";}}
// if 5 do nothing
exec("sox $action $currentTime",$output,$return_var);if($debug){print "DEBUG $action";}
exec("sudo asterisk -rx 'rpt localplay $node /tmp/current-time'",$output,$return_var);
}// end play

// ----------------------------------reg fix -----------------------------
if($counter >$watchdog and $NotReg and $counterNet <1 ){
reg_fix ("check");
if(!$NotReg){$out="We are back online"; save_task_log ($out);print "$datum $out\n";}
}// end reg fix

if(file_exists($clash)){unlink($clash);}
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_end = $mtime;$script_time = ($script_end - $script_start);$script_time = round($script_time,2);
$datum  = date('m-d-Y H:i:s');
$memory = memory_get_usage() ;$memory =formatBytes($memory);
print "$datum  [Line end] Used:$memory $script_time Sec\n";
$tagline="";tagline($tagline);print "\n";
print"===================================================\n";
// end of line
//
// Do you want to play a game?









?>
