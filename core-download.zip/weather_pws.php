<?php
// (c)2015/2023 by The Master lagmrs.com  by pws.winnfreenet.com
// This script uses some code my weather programs. Member CWOP since 2015 

// I license you to use this on your copy of this software only.
// Not for use on anything but GMRS.  GMRS ONLY! 

// No part of this code is opensource 
//
// _______ _                 __          __        _   _                  _____             
//|__   __(_)                \ \        / /       | | | |                / ____|            
//   | |   _ _ __ ___   ___   \ \  /\  / /__  __ _| |_| |__   ___ _ __  | |     _ __  _   _ 
//   | |  | | '_ ` _ \ / _ \   \ \/  \/ / _ \/ _` | __| '_ \ / _ \ '__| | |    | '_ \| | | |
//   | |  | | | | | | |  __/    \  /\  /  __/ (_| | |_| | | |  __/ |    | |____| |_) | |_| |
//   |_|  |_|_| |_| |_|\___|     \/  \/ \___|\__,_|\__|_| |_|\___|_|     \_____| .__/ \__,_|
//                                                                             | |          
//                                                                             |_|          
// 
// Swapped datafeed from mesowest to NWS API. We were overloading  mesowest and they wanted me to go paid. 

// You need to get weather from your local airport. Some other mesowest stations may also work.
// v5.8 10/06/23  Added ambent weather
// v5.9 10/17/23  Winchill adjustments

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_start = $mtime;
$path="/etc/asterisk/local/mm-software";
include_once ("$path/load.php");      // settings .. Functions
include_once ("$path/sound_db.php");  // functions
include_once ("$path/check_reg.php"); 

$file= "$path/mm-node.txt"; 
if(file_exists($file)){
$line = file_get_contents($file);
$u= explode(",",$line);
$AutoNode=$u[0];$call=$u[1];$autotts=$u[2];
}

$ver= "v5.9.1";$release="10/17/2023";  

srand (time (0));

$currentTime = "/tmp/current-time.gsm";if(file_exists($currentTime)){unlink($currentTime);}
$clash="/tmp/mmweather-task.txt";
$error="";$action="";$condWX=""; $the_temp="";$moo="";$cond1="";$data_good=false;$WindChill="";$temp=""; $feelsLike="";
$condWX=""; $the_temp="";$heatIndex="";$outhumi="";$avgwind=""; $rainofdaily="";$barometricPressure="";$stationID="";
$phpVersion= phpversion();

$time= date('H:i');
$date =  date('m-d-Y');
// Token generated for this script. owned by LAGMRS.com
// I license you to use this on your copy of this software only.
// Not for use on anything but GMRS.  GMRS ONLY! 
// Do not copy get your own.

$datum   = date('m-d-Y H:i:s');$gmdatum = gmdate('m-d-Y H:i:s');
print "
===================================================
Time Temp Weather $coreVersion $ver
mesowest, madis, APRSWXNET(CWOP)
(c)2013/2023 WRXB288 LAGMRS.com all rights reserved
$phpzone PHP v$phpVersion  Release date:$release
===================================================
$datum Model: $piVersion
$datum Node:$node UTC:$gmdatum Level:$level
";

// test for clash (only 1 thread allowed)
if(file_exists($clash)){
// unlink($clash);
 $out="Waiting for other thread. "; save_task_log($out);print"$datum $out\n";
 sleep(35);
}

$fileOUT = fopen($clash,'w');fwrite ($fileOUT,$datum);fclose ($fileOUT);

// test for mute move to start
$hour=date('H');$day=date('D');
$mute=false;
if($MuteNet1){ if($hour>=$Net1Start and $hour <=$Net1Stop and $day=="Wed"){ $mute=true;$out="Net1 $day $hour Muted";}}
if($MuteNet2){ if($hour>=$Net2Start and $hour <=$Net2Stop and $day=="Sun"){ $mute=true;$out="Net2 $day $hour Muted";}}
if($MuteNet3){ if($hour>=$Net3Start and $hour <=$Net3Stop and $day=="Fri"){ $mute=true;$out="Net3 $day $hour Muted";}}
if($sleep)   { if($hour>=1 and $hour <=6){ $mute=true;$out="Sleep Mute $day $hour am ";}}
if($mute){save_task_log ($out);print "$datum $out\n";}

$forcastxml  ="/tmp/geocode.xml";
$forcastxml2 ="/tmp/forcast.xml";
$alertxml    ="/tmp/skywarn.xml";
$currentxml  ="/tmp/current.xml"; $currentTxt  ="/tmp/current.txt";
$acuwxml     ="/tmp/accuweather.xml"; $conditionsTxt  ="/tmp/conditions.txt";
$ambientxml  ="/tmp/ambient.xml";

watchdog ("oknet");// default to good network
if (!$mute){
include_once ("$path/weather_api_pull.php"); 

$file=$ambientxml;
if (file_exists($file)){
read_ambient($file);
$datum = date('[H:i:s]');$status="";

if ($data_good){ 
$validTemp = true;
//print "<ok> $poll_time Sec.\n";
$action = watchdog ("oknet");
$the_temp=$outtemp;


$datum   = date('m-d-Y H:i:s');$status="$stationID Temp:$the_temp";
if($heatIndex){$status ="$status HeatIndex:$heatIndex";}
if($WindChill){$status ="$status WindChill:$WindChill";}
//if($feelsLike){$status ="$status FeelsLike:$feelsLike";}

if($outhumi){$status ="$status hum:$outhumi%";}
if($avgwind    >0){$status ="$status Wind:$avgwind";}
if($rainofdaily>0){$status ="$status Rain:$rainofdaily";}
if($barometricPressure>0){$status ="$status Preasure:$barometricPressure in";}
if($uv>0){$status ="$status UV Index:$uv";}

}

// No cond provided
//if($textDescription){$cond1=strtolower($textDescription);}

$condWX=$status;save_task_log ($condWX);print "$datum $condWX $cond1 \n";


if(!$data_good){
$datum   = date('m-d-Y H:i:s');
$status="<error>";
save_task_log ("Ambient error $status ");
print "$datum $status bad weather data.\n";
$file=$ambientxml; if (file_exists($file)){ unlink($file);}// remove the file so it can be reloaded
$validTemp = false;
$condWX=""; $the_temp="";$heatIndex="";$outhumi="";$avgwind=""; $rainofdaily="";
} // bad data
}// END AMBENT




$file=$currentxml;
if (file_exists($file) and !$data_good){
read_NWS($file);
$datum = date('[H:i:s]');$status="";

if ($data_good){ 
$validTemp = true;
//print "<ok> $poll_time Sec.\n";
$action = watchdog ("oknet");
$the_temp=$outtemp;


$datum   = date('m-d-Y H:i:s');$status="$station Temp:$the_temp";
if($heatIndex){$status ="$status HeatIndex:$heatIndex";}
if($WindChill){$status ="$status WindChill:$WindChill";}
if($outhumi){$status ="$status hum:$outhumi%";}
if($avgwind    >0){$status ="$status Wind:$avgwind";}
if($rainofdaily>0){$status ="$status Rain:$rainofdaily";}
if($barometricPressure>0){$status ="$status Preasure:$barometricPressure in";}
}


if($textDescription){$cond1=strtolower($textDescription);}
$condWX=$status;save_task_log ($condWX);print "$datum $condWX $cond1 \n";// $outtempC C


if(!$data_good){
$datum   = date('m-d-Y H:i:s');
$status="<error>";
save_task_log ("NWS error $status ");
print "$datum $status bad weather data.\n";
$file=$currentxml; if (file_exists($file)){ unlink($file);}// remove the file so it can be reloaded
$validTemp = false;
$condWX=""; $the_temp="";$heatIndex="";$outhumi="";$avgwind=""; $rainofdaily="";
} // bad data
}// END WX



// 1 temp 2=cond 3=wind humi rain 4=forcast
if ($level >1 or !$cond1){  // If the api didnt get the cond fetch it from acuweather
// Poll acuweather for the current conditions. Ignore the temp
$file=$acuwxml; //  "/tmp/accuweather.xml";
if (file_exists($file)){
 $fileIN= file($file);
 foreach($fileIN as $line){
 $line = str_replace("\r", "", $line);
 $line = str_replace("\n", "", $line);
 $pos1 = strpos($line, 'Currently');  //<title>Currently: Partly Sunny: 90F</title> 
 
 $len = strlen($line);
 if (!$cond1){
  if ($pos1){
   $u = explode(":",$line);
   $cond1=strtolower($u[1]);

   $pos2 = strpos($u[2], '<');
   $temp = substr($u[2], 0, $pos2);
   print "$datum Acuweather Temp: $temp\n";}
   
  }
 }
}

} // end if exists


if ($cond1){print "$datum Conditions: $cond1\n";}
if(!$the_temp and $temp){$the_temp=$temp;$condWX="$temp $cond1";}

// run the forcast

include_once ("$path/forcast.php");// mandatory to get alerts
if ($event="clear"){$event="";} // Skip if clear

if ($shortForcast ){$out ="$cond1 | $shortForcast";}
else {$out=$cond1;}
//   save_task_log ($out);  stop logging
 // end level 2

// $condWX=weather data cond1=current cond 
$conditionsTxt  ="/tmp/conditions.txt";

if ($condWX){$file=$conditionsTxt;$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$condWX $cond1");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);}

// ------------------------------------------------------------------------
$hour = date('H');$day  = date('l');$hr =   date('h');$min  = date('i');
$cmd="";
check_gsm_db ("silence1");if($file1){$action = "$action $file1";}
$randomS = mt_rand(1, 4);
if ($randomS==1){check_wav_db("star dull");if($file1){$action = "$action $file1";}}
if ($randomS==2){check_wav_db("light click");if($file1){$action = "$action $file1";}}
if ($randomS==3){check_gsm_db("beep");if($file1){$action = "$action $file1";}}  
if ($randomS==4){check_wav_db("strong click");if($file1){$action = "$action $file1";}} 

//good,good-afternoon,good-evening,good-morning, (need good night)
$status ="";
if ($hour < 12)                {check_gsm_db("good-morning");  if($file1){$action="$action $file1";}}
if ($hour >=12 and $hour <=18) {check_gsm_db("good-afternoon");if($file1){$action="$action $file1";}}
if ($hour >=19)                {check_gsm_db("good-evening");  if($file1){$action="$action $file1";}}


// channel-insecure-warn,    currently  current-time-is     is-currently
$datum   = date('m-d-Y H:i:s');

//$random= rand(1,3);   
$random = mt_rand(1, 3);
if ($random == 1){check_gsm_db  ("the time is");     if($file1){$action = "$action $file1";} }
if ($random == 2){check_gsm_db  ("current-time-is"); if($file1){$action = "$action $file1";} }
if ($random == 3){check_gsm_db  ("currently");       if($file1){$action = "$action $file1";} check_gsm_db  ("the time is"); if($file1){$action = "$action $file1";}}

//save_word ("the-time-is");
$oh=false;make_number ($hr); $action = "$action $actionOut";



//if ($min == 0 ){check_gsm_db ("oclock");if($file1){$action = "$action $file1";}}  // this just doesnt sound right with am/pm after it

if ($min<>0){$oh=true;make_number ($min); $action = "$action $actionOut";}


if ($hour < 12 ){$pm="am";check_gsm_db ("a-m");if($file1){$action = "$action $file1";}} 
if ($hour >= 12){$pm="pm";check_gsm_db ("p-m");if($file1){$action = "$action $file1";}} 

$datum   = date('m-d-Y H:i:s');
print "$datum The time is $hr:$min $pm   
";
check_gsm_db ("silence2");if($file1){$action = "$action $file1";}





// 1 temp 2=cond 3=wind humi rain 4=forcast 
if ($level >1){
$datum   = date('m-d-Y H:i:s');
//print "$datum Conditions: $cond1";
check_gsm_db ("weather"); if($file1){$action = "$action $file1";}
check_gsm_db ("conditions");if($file1){$action = "$action $file1";}   

$u = explode(" ",$cond1);
foreach ($u as $word) {
 if($word){check_gsm_db ($word);if($file1){$action = "$action $file1";} }
}
} // level 1 end


// -----------------------forcast --------------------
// 1 temp 2=cond 3=wind humi rain 4=forcast
if ($level >=4){

  if ($shortForcast) {
$status = "today";
if ($hour >= 12 and $hour <=19) {$status = "evening";}  
if ($hour >= 19 and $hour <=21) {$status = "tonight";} 

check_gsm_db ($status);if($file1){$action = "$action $file1";}
$test = strtolower($shortForcast); 
$test = str_replace('thunderstorms', "thunderstorm", $test);
$test = str_replace('chance', "chance-of", $test);
//$test = str_replace('showers', "rain", $test);  // we need a showers file
$test = str_replace('nws', "national weather service", $test);
$test = str_replace('then', "later", $test);
$test = str_replace('slight', "low", $test);
$test = str_replace('fog/mist', "misty", $test);// we also have fog,foggy,misty and in wav Dense Fog Advisory 
$u = explode(" ",$test);
foreach ($u as $word) {
 if($word){check_gsm_db ($word);if($file1){$action = "$action $file1";} }
    }
   }

 } // level 4 end


 

// The cap_warn.php system in in charge of all this
// We bypass that and just report current event. Duplicate
// This may change but it verifies all events are current at the hr
if ($level>=2 and $clean){
// Events are in a diffrent database
print "$datum Alert(s) Detected\n";
//print "DEBUG $event";
check_gsm_db ("alert");if($file1){$action = "$action $file1";} 
check_wav_db  ("strong click");if($file1){$action = "$action $file1";}
$u = explode(",",$clean);
foreach ($u as $line) {
//$word = strtolower($word);// This database has upercase and lowercase
//if($line){ check_wav_db($line);if($file1){$action = "$action $file1";} } // star dull

if($line){ check_wav_db($line); if($file1){$action = "$action $file1";} }
 
// check for major warrnings.
// persons in path of 
if($line=="Tornado Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("tornado");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Severe Thunderstorm Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("thunderstorm");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Hurricane Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("hurricane");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
if($line=="Blizzard Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("blizzard");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
// Fire Weather Watch,Red Flag Warning, sets a burn ban flag
//if($line=="Red Flag Warning" or $line=="Fire Weather Watch" ){
// check_wav_db ("Burn Ban");if($file1){$action = "$action $file1";}
//}
check_wav_db ("light click"); if($file1){$action = "$action $file1";}

 } // end for
} // lvl2
 



if($the_temp) {
$datum   = date('m-d-Y H:i:s');
//print "$datum $condWX"; 
check_gsm_db ("temperature");if($file1){$action = "$action $file1";}

$the_temp=number_format((float)$the_temp, 2, '.', '');  // fixes a php error

list($whole, $decimal) = explode('.', $the_temp);
$oh=false;make_number ($whole);$action = "$action $actionOut";

if($decimal>=1){
 check_gsm_db ("point");if($file1){$action = "$action $file1";} 
 $oh=true;make_number ($decimal);$action = "$action $actionOut";

}
check_gsm_db ("degrees");if($file1){$action = "$action $file1";} 

// make a comment on the temp    cool
$moo=false;
$random = mt_rand(1, 3);
//$random = rand(1,3);
if ($the_temp >90 or $the_temp <20){ 
 if ($random == 1){check_gsm_db ("moo1");  if($file1){$action = "$action $file1";$moo=true;}} 
 if ($random == 2){check_gsm_db ("we-apologize");   if($file1){$action = "$action $file1";}} 
 if ($random == 3){check_gsm_db ("groovy");if($file1){$action = "$action $file1";}} 
}
}
if($heatIndex) {
// when to read it
$test=$the_temp+15;if ($heatIndex >=100){$test=$the_temp;}

if($heatIndex >$test) {
check_gsm_db ("heat index");if($file1){$action = "$action $file1";}
list($whole, $decimal) = explode('.', $heatIndex);
$oh=false;make_number ($whole); $action = "$action $actionOut";

check_gsm_db ("degrees");if($file1){$action = "$action $file1";}
if(!$moo){ if ($heatIndex >90 ){ check_gsm_db ("moo1"); if($file1){$action = "$action $file1";}  } } 
 }
}

if($WindChill){
// when to read it
$test=$the_temp-15;if ($WindChill <=35){$test=$the_temp;}

if($WindChill <$test) {
check_gsm_db ("wind chill");if($file1){$action = "$action $file1";}
list($whole, $decimal) = explode('.', $WindChill);
$oh=false;make_number ($whole); $action = "$action $actionOut";


check_gsm_db ("degrees");if($file1){$action = "$action $file1";} 
// make a comment on the temp
if ($WindChill <20 ){check_gsm_db ("moo1");if($file1){$action = "$action $file1";}} 
}
}

if($level>2){ // 1 temp only 2=temp,cond 3= temp,cond,wind humi rain 
 if($outhumi){
check_gsm_db ("humidity");if($file1){$action = "$action $file1";}
$oh=false;make_number ($outhumi);$action = "$action $actionOut";
check_gsm_db ("percent");if($file1){$action = "$action $file1";}
}

if($avgwind>0){
check_gsm_db ("wind");if($file1){$action = "$action $file1";} 

list($whole, $decimal) = explode('.', $avgwind);
$oh=false;make_number ($whole);$action = "$action $actionOut";

if($decimal>=1){
 check_gsm_db ("point");if($file1){$action = "$action $file1";} 
$oh=false;make_number ($decimal); $action = "$action $actionOut";

}
check_gsm_db ("miles-per-hour");if($file1){$action = "$action $file1";} 
}

if ($rainofdaily>0){
check_gsm_db ("rainfall");if($file1){$action = "$action $file1";} 
list($whole, $decimal) = explode('.', $rainofdaily);
$oh=false;make_number ($whole); $action = "$action $actionOut";

if($decimal>=1){
 check_gsm_db ("point");if($file1){$action = "$action $file1";} 
 $oh=true;make_number ($decimal); $action = "$action $actionOut";

  }
 check_gsm_db ("inches");if($file1){$action = "$action $file1";}  
 } 
 
 
if ($barometricPressure>0){

$random = mt_rand(1, 2);
if ($random==1){check_gsm_db ("pressure");if($file1){$action = "$action $file1";} }   
if ($random==2){check_gsm_db ("barometer");if($file1){$action = "$action $file1";} }   
list($whole, $decimal) = explode('.', $barometricPressure);
$oh=false;make_number ($whole); $action = "$action $actionOut";

if($decimal>=1){
 check_gsm_db ("point");if($file1){$action = "$action $file1";} 
 $oh=true;make_number ($decimal); $action = "$action $actionOut";

  }
// check_gsm_db ("inches");if($file1){$action = "$action $file1";}  
 } 
  
 
 
 
} // end of level2

// Start the CPU temp warnings here.
$log="/tmp/cpu_temp_log.txt";
$datum = date('m-d-Y H:i:s');
$line= exec("/opt/vc/bin/vcgencmd measure_temp",$output,$return_var);// SoC BCM2711 temp
$line = str_replace("'", "", $line);
$line = str_replace("C", "", $line);
$u= explode("=",$line);
$temp=$u[1];
$tempf = (float)(($temp * 9 / 5) + 32);
print "$datum $nodeName Temp is $tempf F $temp C
";

$line= exec("/opt/vc/bin/vcgencmd get_throttled",$output,$return_var);
//throttled=0x0
$u= explode("x",$line); 
$throttled = "";
if($u[1]== "0"){$throttled = "";}
if($u[1]== "1"){$throttled = "under-voltage-detected";}
if($u[1]== "2"){$throttled = "arm-frequency-capped";}
if($u[1]== "4"){$throttled = "currently-throttled";}
if($u[1]== "8"){$throttled = "soft-temp-limit-active";}
if($u[1]== "10000"){$throttled = "under-voltage-detected";}
if($u[1]== "20000"){$throttled = "arm-frequency-capping";}
if($u[1]== "80000"){$throttled = "throttling-has-occurred";}
if($u[1]== "80000"){$throttled = "soft-temp-limit-occurred";}

if($throttled){
$status ="$nodeName $throttled code:$u[1]";save_task_log ($status);print "$datum $status
";

}
$fileOUT = fopen($log, "a") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,$temp, \n");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);

if ($reportAll or $temp >=$hot){
//$vpath ="/var/lib/asterisk/sounds";
$cmd="";
check_gsm_db ("silence1");if($file1){$action = "$action $file1";}
check_gsm_db ($nodeName);if($file1){$action = "$action $file1";} 

list($whole, $decimal) = explode('.', $temp);
$oh=false;make_number ($whole);$action = "$action $actionOut";

if($decimal>=1){
check_gsm_db ("point");if($file1){$action = "$action $file1";} 
$oh=false;make_number ($decimal); $action = "$action $actionOut";

}
check_gsm_db ("degrees");if($file1){$action = "$action $file1";} 
check_gsm_db ("celsius");if($file1){$action = "$action $file1";} 

if ($temp >=$hot){
   $status ="CPU HOT $temp";save_task_log ($status);
 if ($temp >=$high){check_gsm_db ("warning");if($file1){$action = "$action $file1";}} 
 else{check_gsm_db ("high");if($file1){$action = "$action $file1";}}
}
if ($throttled){check_ulaw_db ($throttled);if($file1){$action = "$action $file1";}  }
} // end temp

if ($counterNet ==0){
// Check the reg
reg_check ("check");// $node1 $ip $port2 $registered
if($registered !="Registered"){
watchdog ("reg");// add to counter ,an-error-has-occurred
check_gsm_db ("an-error-has-occurred");if($file1){$action = "$action $file1";}
check_gsm_db ("node");if($file1){$action = "$action $file1";} 
$oh=false;
$x = (string)$node;
for($i=0;$i<strlen($x);$i++)
{ 
make_number ($x[$i]);$action = "$action $actionOut"; //say the numbers one at a time not as a set 
}

//  "Auth. Sent"  "Registered"    rejected: 'Registration Refused' // Request,Auth.,
$pos1 = strpos("-$registered", 'Unregistered');if($pos1){check_gsm_db ("is-not-registered");if($file1){$action = "$action $file1";}}
$pos1 = strpos("-$registered", 'Refused');     if($pos1){check_gsm_db ("is-rejected");      if($file1){$action = "$action $file1";}}
$pos1 = strpos("-$registered", 'Auth');        if($pos1){check_gsm_db ("connecting");       if($file1){$action = "$action $file1";}}
$pos1 = strpos("-$registered", 'Sent');        if($pos1){check_gsm_db ("connecting");       if($file1){$action = "$action $file1";}}
$pos1 = strpos("-$registered", 'Request');     if($pos1){check_gsm_db ("not-yet-connected");if($file1){$action = "$action $file1";}}
}
if ($registered =="Registered"){watchdog ("okreg");}


} // end if net up

if ($counterNet >=1){
$out="Network Error we are offline"; 
save_task_log ($out);print "$datum $out\n";
check_wav_db ("strong click"); if($file1){$action = "$action $file1";}
check_gsm_db ("net down");if($file1){$action = "$action $file1";} 
//check_gsm_db ("sorry2");if($file1){$action = "$action $file1";} 
}


 
// ---------------------------------------------------play the file---------------------
$datum   = date('m-d-Y H:i:s'); 


if($burst){
print "$datum MDC-1200 bursts $burst\n";
exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);
} 



print "$datum Playing file $currentTime\n";
check_gsm_db ("silence1");if($file1){$action = "$action $file1";}
$randomE = mt_rand(1, 4);
//print "$datum $randomS / $randomE\n";
if ($randomE==1){check_wav_db("star dull");if($file1){$action = "$action $file1";}}
if ($randomE==2){check_wav_db("light click");if($file1){$action = "$action $file1";}}
if ($randomE==3){check_gsm_db("beep");if($file1){$action = "$action $file1";}} 
if ($randomE==4){check_wav_db("strong click");if($file1){$action = "$action $file1";}} 

exec("sox $action $currentTime",$output,$return_var);if($debug){print "DEBUG $action";}
exec("sudo asterisk -rx 'rpt localplay $node /tmp/current-time'",$output,$return_var);

 }






// check the working port -- Put it back to default on next reboot
if (!$NotReg){
$port = find_port ("find");
if ($port != "4569"){
$out="Port $port in use"; save_task_log ($out);print "$datum $out
";
 $newPort=4569;
 rotate_port("rotate");
 }
}

if($counter >$watchdog and $NotReg and $counterNet <1 ){
reg_fix ("check");
if(!$NotReg){
$out="We are back online"; // Yep I fixed it.
save_task_log ($out);print "$datum $out
"; 
 }
}




if(file_exists($clash)){unlink($clash);}
$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_end = $mtime;$script_time = ($script_end - $script_start);$script_time = round($script_time,2);
$datum  = date('m-d-Y H:i:s');
$memory = memory_get_usage() ;$memory =formatBytes($memory);

print "$datum ";$tagline="";tagline($tagline);print "\n";

print "$datum  [Line end] Used:$memory $script_time Sec\n";


print"===================================================\n";


function read_ambient($file){
global $barometricPressure,$textDescription,$f,$WindChill,$heatIndex,$dateReading,$timeReading,$sitename,$data_good ;
global $CurrTimeHr,$CurrTime,$CurrTimeD,$CurrTimeM,$CurrTimeY,$html,$outtemp,$outtempC,$outhumi,$avgwind,$gustspeed ;
global $rainofdaily,$rainofyearly,$stationID,$feelsLike,$uv,$dewPoint,$solarradiation;
$data_good = false;
$WindChill="";$heatIndex=""; $outtemp=""; $dewpoint="";
$temp=false;$dew=false;$speed=false;$gust=false;$hum=false;$chill=false;$heat=false;$rain1=false;$rain3=false; $rain6=false;$press=false;
$textDescription=""; $i=0;
//$len= strlen($line);
$html= file($file); 
foreach($html as $line){
$line = str_replace('"', "", $line);
$u = explode(",",$line);
}

while($i < count($u)){

$u2 = explode(":",$u[$i]);	
if($u2[0]=="tempf"){       $outtemp=$u2[1];$data_good=true;}    
if($u2[0]=="humidity"){    $outhumi=$u2[1];} 
if($u2[0]=="windspeedmph"){$avgwind=$u2[1];}  
if($u2[0]=="windgustmph"){ $gustspeed=$u2[1];}

if($u2[0]=="dailyrainin"){ $rainofdaily=$u2[1];}    
if($u2[0]=="yearlyrainin"){$rainofyearly=$u2[1];} 

if($u2[0]=="feelsLike"){
$feelsLike=$u2[1]; // create the heatindex
if ($feelsLike>89) { $heatIndex=$u2[1]; }
if ($feelsLike<50) { $WindChill=$u2[1]; }
}

//if($u2[0]=="baromabsin"){$barometricPressure=$u2[1];}   
if($u2[0]=="baromrelin"){ $barometricPressure=$u2[1];}   
if($u2[0]=="dewPoint"){   $dewPoint=$u2[1];} 
if($u2[0]=="solarradiation"){$solarradiation=$u2[1];}
if($u2[0]=="uv"){         $uv=$u2[1];}

if($u2[0]=="date"){  //lastData:{dateutc:1697088540000 date:2023-10-12T05:29:00.000Z
$CurrTime=$u2[1];
$u3 = explode("-",$u2[1]);
$CurrTimeY = $u3[0];
$CurrTimeM = $u3[1];
$CurrTimeD = substr($u3[2], 0, 2);
$CurrTimeHr= substr($u3[2], 3, 2);
$CurrTimeM = $u[2];
}  

if($u2[0]=="location"){ // its in there more than once get the first one.
if(!$stationID){$stationID=$u2[1];}
}   
    
    
$i++;
}

// ambent will return 80.1  with no ending 0s 
if($outtemp){$data_good=true;} // verify



}

// copyright by lagmrs.com  
// New weather by NWS API
function read_NWS ($file) {
global $barometricPressure,$textDescription,$f,$WindChill,$heatIndex, $dateReading, $timeReading,$sitename,$data_good,$CurrTimeR,$CurrTimeMi,$CurrTimeHr,$CurrTime,$CurrTimeD,$CurrTimeM,$CurrTimeY,$html,$outtemp,$outtempC,$outhumi,$avgwind,$gustspeed,$rainofdaily,$rainofyearly;
$data_good = false;
$WindChill="";$heatIndex=""; $outtemp=""; $dewpoint="";
$temp=false;$dew=false;$speed=false;$gust=false;$hum=false;$chill=false;$heat=false;$rain1=false;$rain3=false; $rain6=false;$press=false;
$textDescription="";

$html= file($file); 
foreach($html as $line){


$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$len= strlen($line);

//"temperature": {
//"dewpoint": {
//"windDirection": {
//"windSpeed": {
//"windGust": {
//"barometricPressure": {
//"seaLevelPressure": {
//"visibility": {
//"maxTemperatureLast24Hours": {
//"minTemperatureLast24Hours": {
//"precipitationLastHour": {
//"precipitationLast3Hours": {
//"precipitationLast6Hours": {
//"relativeHumidity": {
//"windChill": {
//"heatIndex": {
//"textDescription": "Clear",

$pos = strpos($line, 'textDescription":'); 
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ','); 
     $value2 = substr($test, $Lpos+2,($Rpos-$Lpos)-2);
     $value2 = str_replace(',', "", $value2);
     $value2 = str_replace('"', "", $value2);
     $value2 = trim($value2," ");
     $textDescription=$value2;
}



$pos = strpos($line, 'temperature":');      if ($pos) {$temp=true;}
$pos = strpos($line, 'dewpoint":');         if ($pos) {$dew=true;}
$pos = strpos($line, 'windSpeed":');        if ($pos) {$speed=true;}
$pos = strpos($line, 'windGust":');         if ($pos) {$gust=true;}
$pos = strpos($line, 'relativeHumidity":'); if ($pos) {$hum=true;}
$pos = strpos($line, 'windChill":');        if ($pos) {$chill=true;}
$pos = strpos($line, 'heatIndex":');        if ($pos) {$heat=true;}
$pos = strpos($line, 'precipitationLastHour":');      if ($pos) {$rain1=true;}  // $rainofdaily,$rainofyearly
$pos = strpos($line, 'precipitationLastHour3Hours":');if ($pos) {$rain3=true;}
$pos = strpos($line, 'precipitationLastHour6Hours":');if ($pos) {$rain6=true;}
$pos = strpos($line, 'barometricPressure":');if ($pos) {$press=true;}

$pos = strpos($line, 'value":'); 
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ','); // "value": null,
     $value2 = substr($test, $Lpos+2,($Rpos-$Lpos)-2);
     $value2 = str_replace(',', "", $value2);
     $value2 = trim($value2," ");
    
     if ($value2=="null"){$value2="";}
     
$f="";
 
// which one to put it in  $avgwind,$gustspeed
if($temp) {
if ($value2){
if (!$outtemp) {celsius_to_fahrenheit($value2);$outtemp=$f;$outtempC=number_format($value2, 2);$data_good = true;}
}
$temp=false;}
if($dew)  {
if ($value2){
if (!$dewpoint) {celsius_to_fahrenheit($value2);$dewpoint=$f; }
}
$dew=false;
}
if($speed){
if ($value2){
if (!$avgwind) {$avgwind=number_format($value2, 2);}
}
$speed=false;}
if($gust) {
if ($value2){
if (!$gustspeed) {$gustspeed=number_format($value2, 2);}
}
$gust=false;}
if($hum)  {
if ($value2){
if (!$outhumi) {$outhumi=number_format($value2, 2);}
}
$hum=false;}
if($chill){
if ($value2){
if (!$WindChill) {celsius_to_fahrenheit($value2);$WindChill=$f;}
}
$chill=false;}

if($heat) {
if ($value2){
if (!$heatIndex) {celsius_to_fahrenheit($value2);$heatIndex=$f;}
}
$heat=false;}

if($rain1) {
if ($value2){
if (!$rainofDaily) {$rainofdaily=$value2;}
}
$rain1=false;}

if($rain3) {
if ($value2){
 if (!$rainofDaily) {$rainofdaily=$value2;}
 }
$rain3=false;}

if($rain6) {
if ($value2){
 if (!$rainofDaily) {$rainofdaily=$value2;}
 }
$rain6=false;}


if($press) {
if ($value2){
 if (!$barometricPressure) { $mb = $value2 * 0.00029529980164712; $barometricPressure=number_format($mb, 2); }
 }
$press=false;}


  }
 }   
}

function celsius_to_fahrenheit($in){ 
global $f;
    $f=$in*9/5+32; 
    $f=number_format($f, 2);
}




?>
