<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
// */13 * * * * php /etc/asterisk/local/mm-software/odd_min.php >/dev/null
//
// Chron system calls this to run odd min events  

// v2.2   09/17/2023
// v2.3   09/18/2023

$path="/etc/asterisk/local/mm-software";
print"
===================================================
Odd Min cron loader 
(c)2023 WRXB288 LAGMRS.com all rights reserved
===================================================
"; 
include_once ("$path/load.php");      // settings .. Functions
include_once ("$path/sound_db.php");  // functions
include_once ("$path/bridge_alarm.php"); 
include_once ("$path/temp.php"); // CPU alarm



$datum   = date('m-d-Y H:i:s'); 
$hour=date('H');$day=date('D');
$mute=false; $sleeping=false;
if($MuteNet1){ if($hour>=$Net1Start and $hour <=$Net1Stop and $day=="Wed"){ $mute=true;$out="Net1 $day $hour Muted";}}
if($MuteNet2){ if($hour>=$Net2Start and $hour <=$Net2Stop and $day=="Sun"){ $mute=true;$out="Net2 $day $hour Muted";}}
if($MuteNet3){ if($hour>=$Net3Start and $hour <=$Net3Stop and $day=="Fri"){ $mute=true;$out="Net3 $day $hour Muted";}}
if($sleep)   { if($hour>=1 and $hour <=6){ $mute=true;$sleeping=true;}}




// disconnected alarm ($NUMLINKS shoule not be 0)
if (!$sleeping){ 
if ($LinkCheck<>0 and $NUMLINKS <1){
 if ($LinkCheck ==2){
  $min  = date('i'); 
  if($min >=20 and $min <=40){
   if(!$mute){include_once ("$path/link_check.php");} 
   }
  }  
 else { include_once ("$path/link_check.php");}
 }
}

if(!$mute){ sleep(10);include_once ("$path/cap_warn.php");} // weather alert

include_once ("$path/watchdog.php");// Net down alarm 
unset ($soundDbWav);
unset ($soundDbGsm);
unset ($soundDbUlaw);
// endof file
?>

