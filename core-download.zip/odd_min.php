<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
// */13 * * * * php /etc/asterisk/local/mm-software/odd_min.php >/dev/null
//
// Chron system calls this to run odd min events  

// v2.2   09/17/2023
// v2.3   09/18/2023  fix for temp module clearing sound database. Now intergrated
//                    version update added
// v2.4   10/06/1023  Online test added.
// quick check if we are online  
// v2.5   11/08/23 Check if the webserver is requesting a nodelist update
// v2.6   11/11/23 bug fix 

$path="/etc/asterisk/local/mm-software"; 
print"
===================================================
Odd Min cron loader 
(c)2023 WRXB288 LAGMRS.com all rights reserved
===================================================
"; 
include_once ("$path/load.php");      // settings .. Functions
include_once ("$path/sound_db.php");  // functions

$datum   = date('m-d-Y H:i:s');
$url = 'https://google.com';
$url = gethostbyname(str_replace(['https://','http://'],NULL,$url));
if(filter_var($url,FILTER_VALIDATE_IP)) { $counterNet=0;print "$datum We are Online\n";}
else {$counterNet=1;print "$datum We are Offline\n";}

$bursted=false;
if ($idType=="4"){
 if($burst){
   print "$datum MDC-1200 bursts for ID $burst\n";
   exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);
   $bursted=true;
 } 
}

include_once ("$path/bridge_alarm.php"); 
include_once ("$path/temp.php"); // CPU alarm



$datum   = date('m-d-Y H:i:s'); 
$hour=date('H');$day=date('D');
$mute=false; $sleeping=false;
if($MuteNet1){ if($hour>=$Net1Start and $hour <=$Net1Stop and $day=="Wed"){ $mute=true;$out="Net1 $day $hour Muted";}}
if($MuteNet2){ if($hour>=$Net2Start and $hour <=$Net2Stop and $day=="Sun"){ $mute=true;$out="Net2 $day $hour Muted";}}
if($MuteNet3){ if($hour>=$Net3Start and $hour <=$Net3Stop and $day=="Fri"){ $mute=true;$out="Net3 $day $hour Muted";}}
if($sleep)   { if($hour>=1 and $hour <=6){ $mute=true;$sleeping=true;}}




// disconnected alarm ($NUMLINKS shoule not be 0)
if (!$sleeping){ 
if ($LinkCheck<>0 and $NUMLINKS <1){
 if ($LinkCheck ==2){
  $min  = date('i'); 
  if($min >=20 and $min <=40){
   if(!$mute){include_once ("$path/link_check.php");} 
   }
  }  
 else { include_once ("$path/link_check.php");}
 }
}

if(!$mute){ sleep(10);include_once ("$path/cap_warn.php");} // weather alert

include_once ("$path/watchdog.php");// Net down alarm 
include_once ("$path/ip_monitor.php");// Updates our external ip logs

// The webserver found a new user but does not have permissions to run update
// Preform update outside the webserver space. But dont loop only do it once
$flag="/tmp/nodelist_needs_update.txt"; $flag2="/tmp/nodelist_updated.txt";
if(file_exists($flag) and !file_exists ($flag2)) {
    unlink($flag); $fileOUT = fopen($flag2,'a+');fwrite ($fileOUT,"$datum updated once today not again\n");fclose ($fileOUT);
    include_once ("$path/nodelist_process.php");
    }
    
// Age out the files.
if(file_exists($flag2)){ 
 $ft = time()-filemtime($flag2);
 if ($ft < 20 * 3600){unlink($flag2);}
}

if(file_exists($flag)){ 
 $ft = time()-filemtime($flag);
 if ($ft < 20 * 3600){unlink($flag);}
}

     
unset ($soundDbWav);
unset ($soundDbGsm);
unset ($soundDbUlaw);
// endof file
?>

