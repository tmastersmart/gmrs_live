<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
// */13 * * * * php /etc/asterisk/local/mm-software/odd_min.php >/dev/null
//
// Chron system calls this to run odd min events  
// v2.2   09/17/2023
// v2.3   09/18/2023  fix for temp module clearing sound database. Now intergrated
//                    version update added  
// v2.4   10/06/1023  Online test added.
// quick check if we are online  
// v2.5   11/08/23 Check if the webserver is requesting a nodelist update
// v2.6   11/11/23 bug fix 
// v2.7   11/12/23 bug fix in net test
// v2.8   11/13/23 clash added
// v2.8.1 11/18/2023 Clash adjusted.
// v2.9   11/22/23 Bug in semore aging out
// v3.0   12/03/23 Changed clash routine to stop overlap with time
// v3.1   12/17/23 Notify weather we are running to stop clash
// v3.2   12/23   debugging  / bug fix
// v3.3   01/14/24 Bug in the nightime mute fixed
// v3.4   2/9 jingle added
// v3.6   

$ver= "v3.6";$release="2/11/2024"; 
srand (time (0)); 

$path="/etc/asterisk/local/mm-software"; 
$clash="/tmp/mmweather-task.txt"; // Prevents more than one program from running at the same time
include_once ("$path/load.php");      // settings .. Functions
include_once ("$path/sound_db.php");  // functions

$file= "$path/mm-node.txt"; 
if(file_exists($file)){
$line = file_get_contents($file);
$u= explode(",",$line);
$AutoNode=$u[0];$call=$u[1];$autotts=$u[2];
}
$phpVersion= phpversion();
$datum   = date('m-d-Y H:i:s');$gmdatum = gmdate('m-d-Y H:i:s');

print"
===================================================
Odd Min cron loader $coreVersion $ver
(c)2023 WRXB288 LAGMRS.com all rights reserved
$phpzone PHP v$phpVersion  Release date:$release
===================================================
"; 

$fileWEB="/tmp/setup.txt";if (file_exists($fileWEB)) {
print"$datum Running: Merge Setup\n";include_once ("$path/merge_setup.php");} 

// Test if the DNS is working  If so we assume the net is up
$datum   = date('m-d-Y H:i:s'); $randomS = mt_rand(1, 6);
if ($randomS==1){ $url = 'http://google.com';}
if ($randomS==2){ $url = 'http://gmrslive.com';}
if ($randomS==3){ $url = 'http://texasgmrs.net';}
if ($randomS==4){ $url = 'http://yahoo.com';}
if ($randomS==5){ $url = 'http://verizon.com';}
if ($randomS==6){ $url = 'http://att.com';}
print "$datum DNS Lookup [$url] :";
$url = gethostbyname(str_replace(['https://','http://'],NULL,$url));
if(filter_var($url,FILTER_VALIDATE_IP)) { print "OK $url \n";watchdog ("oknet");}  
else {watchdog ("net");print " We are Offline\n";}


// test for clash (only 1 thread allowed)
if(file_exists($clash)){
 $out="Waiting for other thread. "; save_task_log($out);print"$datum $out\n";
 sleep(90);
 // safety clear abandoned flags
 $ft = time()-filemtime($clash);
 $ft = round(($ft)/60); 
 if ($ft > 10){unlink($clash);}  // 10 mins
}

//if(file_exists($clash)){unlink($clash);}
//$fileOUT = fopen($clash,'w');fwrite ($fileOUT,"$datum cron");fclose ($fileOUT);// Notify weather that we are running


$datum   = date('m-d-Y H:i:s'); 
$hour=date('H');$day=date('D');
$mute=false; $sleeping=false;
if($MuteNet1){ if($hour>=$Net1Start and $hour <=$Net1Stop and $day=="Wed"){ $mute=true;$out="Net1 $day $hour Muted";}}
if($MuteNet2){ if($hour>=$Net2Start and $hour <=$Net2Stop and $day=="Sun"){ $mute=true;$out="Net2 $day $hour Muted";}}
if($MuteNet3){ if($hour>=$Net3Start and $hour <=$Net3Stop and $day=="Fri"){ $mute=true;$out="Net3 $day $hour Muted";}}
if($sleep)   { if($hour>=1 and $hour <=6){ $mute=true;}}
if($mute){print "$datum Sleep Mute $day $hour am\n";}

$bursted=false;
if ($idType=="4" and $burst){print "$datum MDC-1200 bursts for ID $burst\n";   exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$burst'",$output,$return_var);   $bursted=true; } 

print"$datum Running: CPU Temp\n";     include_once ("$path/temp.php"); // CPU alarm
print"$datum Running: Bridge Alarm\n"; include_once ("$path/bridge_alarm.php"); // sets $NUMLINKS must run before link check
if ($LinkCheck ==2 and !$mute and $NUMLINKS <1){
  $min  = date('i'); if($min >=20 and $min <=40){  
print"$datum Running: link check\n";   include_once ("$path/link_check.php");  }
 } 

    
if(!$mute){ 
$seconds = mt_rand(7, 20); //$min= round(($seconds / 60),0);
print"$datum Unsyncing Multi Node systems. $seconds second(s) delay\n";
sleep($seconds);include_once ("$path/cap_warn.php");
print"$datum Running: BlipVerts\n"; include_once ("$path/blipverts.php");
} 
print"$datum Running: Watchdog\n";  include_once ("$path/watchdog.php");// Net down alarm 
print"$datum Running: IP Monitor\n";include_once ("$path/ip_monitor.php");// Updates our external ip logs

// The webserver found a new user but does not have permissions to run update
// Preform update outside the webserver space. But dont loop only do it once
$flag  ="/tmp/nodelist_needs_update.txt";
$flag2 ="/tmp/nodelist_updated.txt";// set by processor 
if(file_exists($flag)){   $ft = time()-filemtime($flag); if ($ft > 20 * 3600){unlink($flag);}} // 20 hrs
if(file_exists($flag2)){ $ft = time()-filemtime($flag2); if ($ft > 20 * 3600){unlink($flag2);}} // 20hrs

if(file_exists($flag) and !file_exists ($flag2)) {$out="Webserver Request a nodelist update";save_task_log ($out);
print"$datum Running: Nodelist Process\n";include_once ("$path/nodelist_process.php");
}

tagline($out);
unset ($soundDbWav);
unset ($soundDbGsm);
unset ($soundDbUlaw);
if(file_exists($clash)){unlink($clash);}  // safety clear abandoned flags
?>

