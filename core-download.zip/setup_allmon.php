<?php
//  ------------------------------------------------------------
//  (c) 2023 by WRXB288 lagmrs.com all rights reserved
//
// Setup program  $ver="v7.5"; $release="11-4-2023";  

//  This builds a allmon file
//


function buildAllmon($in){
global $allmon,$path,$file,$tmpFile,$ok,$password,$node,$pathG,$pathGA;

$pathSUPERMON="gmrs";$allmon="/srv/http/gmrs/admin/allmon.ini"; // new secure path

if ($in=="gmrs"){    $allmon="/srv/http/gmrs/admin/allmon.ini";$pathSUPERMON="gmrs";} 
if ($in=="supermon"){$allmon="/srv/http/supermon/allmon.ini";  $pathSUPERMON="supermon";} 

$file= $allmon;

if (file_exists($file)){ unlink($file);}
$fileOUT = fopen($file, "w") or die ("Error $file Write falure\n"); 

$formated="
[$node]
host=127.0.0.1:5038
user=admin
passwd=$password
menu=yes
system=Nodes
hideNodeURL=no

[All Nodes]
system=Display Groups
nodes=$node
menu=yes

[Status]
system=Display Groups
url='/$pathSUPERMON/link.php?nodes=$node'
menu=yes



[Directory]
system=Node Manager
url='/gmrs/gmrs-node-index.php?type=hub&sort=live&code=08082023'
menu=yes

[List Nodes]
system=Node Manager
url='/gmrs/lsnodes.php'
menu=yes

[Freq Chart]
system=Node Manager
url='/gmrs/gmrs-chart.php'
menu=yes

[System Map]
system=Node Manager
url='/gmrs/map.php'
menu=yes

[Status]
system=Node Manager
url='/gmrs/link.php?nodes=$node'
menu=yes

[Admin]
system=Node Manager
url='/gmrs/admin/link.php?nodes=$node'
menu=yes

[Logs]
system=Node Manager
url='/gmrs/admin/log.php?log=mmsoftware'
menu=yes


 

[RoadKill Website]
url='http://roadkill.network'
menu=yes
system= Bookmarks

[Texas GMRS Website]
url='https://www.texasgmrs.net/'
menu=yes
system= Bookmarks

[GmrsLive Website]
url='https://www.gmrslive.com/'
menu=yes
system= Bookmarks

[HamVoip Website]
url='https://hamvoip.org/'
menu=yes
system= Bookmarks

[GMRS Node Map]
url='https://gmrsnodes.com/'
menu=yes
system= Bookmarks

[mygmrs Map]
url='https://mygmrs.com/map'
menu=yes
system= Bookmarks

[Propagation Map]
url='https://vhf.dxview.org/'
menu=yes
system= Bookmarks


[FCC Lookup]
url='https://fjallfoss.fcc.gov/General_Menu_Reports/callsign.cfm'
menu=yes
system= Bookmarks

[Alamo City GMRS Community]
url='http://1510.node.gmrslive.com/supermon'
menu=yes
system= Network Status Pages

[Broadnet GMRS Repeater Systems]
url='https://status.broadnetgmrs.net/'
menu=yes
system= Network Status Pages

[Central Illinois GMRS Live Hub]
url='http://1915.node.gmrslive.com/supermon'
menu=yes
system= Network Status Pages

[GMRS Live Hub]
url='http://gmrslive.com/status/link.php?nodes=700,900'
menu=yes
system= Network Status Pages

[Hammond HUB]
url='http://1171.node.gmrslive.com/supermon/link.php?nodes=1171'
menu=yes
system= Network Status Pages

[Lone Wolf System]
url='http://www.lonewolfsystem.org/supermon/link.php?nodes=1691'
menu=yes
system= Network Status Pages

[Ottawa Lake MI]
url='http://1171.node.gmrslive.com/supermon/link.php?nodes=1114'
menu=yes
system= Network Status Pages

[South Dade GMRS Club]
url='http://1806.node.gmrslive.com/supermon'
menu=yes
system= Network Status Pages

[Southeast Mishigami Hub - Ottawa Lake, MI]
url='http://1114.node.gmrslive.com/supermon/link.php?nodes=1114'
menu=yes
system= Network Status Pages

[Southwest Michigan HUB]
url='http://1082.node.gmrslive.com/supermon/link.php?nodes=1082'
menu=yes
system= Network Status Pages

[Texas GMRS Network]
url='https://link.texasgmrs.net/link.php?nodes=2250,2251,2252,2253,2254,1000,922'
menu=yes
system= Network Status Pages

[The RoadKill !! Repeater System]
url='http://1195.node.gmrslive.com/link.php?nodes=1195,1196,1167,50132'
menu=yes
system= Network Status Pages
";
$formated = str_replace("'", '"', $formated);

fwrite ($fileOUT, $formated);
fclose ($fileOUT);
print "saving $allmon \n";
save_task_log ("$file saved");
}

?>

