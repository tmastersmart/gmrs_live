<?php
//  ------------------------------------------------------------
//  (c) 2023 by WRXB288 lagmrs.com all rights reserved
//
// Setup program  $ver="v7.5"; $release="11-4-2023";  
//  v7.6 12/28/23 update bookmarks
//  This builds a allmon file
//
// v7.7  1/5/24 This version works with the new menu system that reads from a database.
//              GMRS Supermon will edit this file,

function buildAllmon($in){
global $allmon,$path,$file,$tmpFile,$ok,$password,$node,$pathG,$pathGA;

$pathSUPERMON="gmrs";$allmon="/srv/http/gmrs/admin/allmon.ini"; // new secure path

if ($in=="gmrs"){    $allmon="/srv/http/gmrs/admin/allmon.ini";$pathSUPERMON="gmrs";} 
if ($in=="supermon"){$allmon="/srv/http/supermon/allmon.ini";  $pathSUPERMON="supermon";} 

$file= $allmon;
if (file_exists($file)){ unlink($file);}
$fileOUT = fopen($file, "w") or die ("Error $file Write falure\n"); 

$formated="
[$node]
host=127.0.0.1:5038
user=admin
passwd=$password
menu=yes
system=Nodes
hideNodeURL=no

[All Nodes]
system=Nodes
nodes=$node
menu=yes
";

$formated = str_replace("'", '"', $formated);

fwrite ($fileOUT, $formated);
fclose ($fileOUT);
print "saving $allmon \n";
save_task_log ("$file saved");
}

?>

