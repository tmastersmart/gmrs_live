<?php
//  ------------------------------------------------------------
//  (c) 2023 by WRXB288 lagmrs.com all rights reserved
//
// Setup program  $ver="v7.5"; $release="11-4-2023";  
//  v7.6 12/28/23 update bookmarks
//  This builds a allmon file
//


function buildAllmon($in){
global $allmon,$path,$file,$tmpFile,$ok,$password,$node,$pathG,$pathGA;

$pathSUPERMON="gmrs";$allmon="/srv/http/gmrs/admin/allmon.ini"; // new secure path

if ($in=="gmrs"){    $allmon="/srv/http/gmrs/admin/allmon.ini";$pathSUPERMON="gmrs";} 
if ($in=="supermon"){$allmon="/srv/http/supermon/allmon.ini";  $pathSUPERMON="supermon";} 

$webDB="$path/web_database.csv"; $action="";
if (is_readable($webDB)) {
   $fileIN= file($webDB);
   foreach($fileIN as $line){
    $u = explode(",",$line);
    $action="$action [$u[1]]\nurl='$u[2]'\nmenu=yes\nsystem=Network Status Pages\n";
   }
}
    

$file= $allmon;

if (file_exists($file)){ unlink($file);}
$fileOUT = fopen($file, "w") or die ("Error $file Write falure\n"); 

$formated="
[$node]
host=127.0.0.1:5038
user=admin
passwd=$password
menu=yes
system=Nodes
hideNodeURL=no

[All Nodes]
system=Display Groups
nodes=$node
menu=yes

[Status]
system=Display Groups
url='/$pathSUPERMON/link.php?nodes=$node'
menu=yes



[Directory]
system=Node Manager
url='/gmrs/gmrs-node-index.php?type=hub&sort=live&code=08082023'
menu=yes

[List Nodes]
system=Node Manager
url='/gmrs/lsnodes.php'
menu=yes

[Freq Chart]
system=Node Manager
url='/gmrs/gmrs-chart.php'
menu=yes

[System Map]
system=Node Manager
url='/gmrs/map.php'
menu=yes

[Status]
system=Node Manager
url='/gmrs/link.php?nodes=$node'
menu=yes

[Admin]
system=Node Manager
url='/gmrs/admin/link.php?nodes=$node'
menu=yes

[Logs]
system=Node Manager
url='/gmrs/admin/log.php?log=mmsoftware'
menu=yes


 

[RoadKill Website]
url='http://roadkill.network'
menu=yes
system= Bookmarks

[Texas GMRS Website]
url='https://www.texasgmrs.net/'
menu=yes
system= Bookmarks

[TX-LA GMRS Policies]
url='https://www.texasgmrs.net/wp-content/uploads/2023/11/GMRS-Policies-2023-11-12.pdf'
menu=yes
system= Bookmarks

[GmrsLive Website]
url='https://www.gmrslive.com/'
menu=yes
system= Bookmarks

[HamVoip Website]
url='https://hamvoip.org/'
menu=yes
system= Bookmarks

[GMRS Node Map]
url='https://gmrsnodes.com/'
menu=yes
system= Bookmarks

[mygmrs Map]
url='https://mygmrs.com/map'
menu=yes
system= Bookmarks

[Propagation Map]
url='https://vhf.dxview.org/'
menu=yes
system= Bookmarks

[FCC Part95E]
url='https://www.ecfr.gov/current/title-47/chapter-I/subchapter-D/part-95/subpart-E'
menu=yes
system= Bookmarks

[FCC Lookup]
url='https://fjallfoss.fcc.gov/General_Menu_Reports/callsign.cfm'
menu=yes
system= Bookmarks

$action

";
$formated = str_replace("'", '"', $formated);

fwrite ($fileOUT, $formated);
fclose ($fileOUT);
print "saving $allmon \n";
save_task_log ("$file saved");
}

?>

