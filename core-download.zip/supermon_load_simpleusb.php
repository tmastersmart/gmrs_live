<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
// lsnodes replacement for simpleusb editor.. 
 

$basename=basename($_SERVER['PHP_SELF']);
$piVersion = file_get_contents ("/proc/device-tree/model");
$phpzone = date_default_timezone_get();
$status="Error";
$path  = "/etc/asterisk/local/mm-software"; 
$fileWEB="/tmp/setup.txt";  // We have write permission
$fileSET="$path/setup.txt"; // We have read only permissions



print"<!-- Reading simpleUSB settings -->\n";

$datum   = date('m-d-Y H:i:s');$gmdatum = gmdate('m-d-Y H:i:s');
$output="";$line="";$out="";

print"<!-- sudo /bin/asterisk -rx \"susb tune menu-support 4\" -->\n";   // command 4 reads the settiings
$status= exec("sudo /bin/asterisk -rx \"susb tune menu-support 4\" ",$output,$return_var);


$j = json_decode($output, true); 
if ( json_last_error() != JSON_ERROR_NONE ) {
		Print " Read Error - Try again";
		exit;
	}

$device_cur  =device('state'('name'));
$deemphasis  =state('deemphasis');
$preemphasis =state('preemphasis');
$plfilter    =state('plfilter');
$dcsfilter   =state('dcsfilter');
$txtestkeyed =state('rxtestkeyed');
$rxboostset  =state('rxboostset');
$invertppt   =state('invertptt');
$rxcdtype    =state('rxcdtype');
$rxsdyype    =state('rxsdtype');
$echomode    =state('echomode');
$rxmisetset  =state('rxmixerset');
$rxondelay   =state('rxondelay');
$rxaudiodelay=state('rxaudiodelay');
$txmixaset   =state('txmixaset');
$txmixbset   =state('txmixbset');
$txsplevl    =state('txdsplevel');
$pttstatus   =state('pttstatus');
$coscomposite=state('coscomposite');
$tx_audio_level_method=state('tx_audio_level_method');


print"<!-- $output -->\n";




?>
