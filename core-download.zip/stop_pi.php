#!/usr/bin/php
<?php
// (c)2025 by The Master lagmrs.com 
// Not for use on anything but GMRS ONLY! 
// No part of this code is opensource 
// Created to provide voice prompts in a stop

// v1.2 added power falure flag

$ver= "v1.2";$release="3/8/2025"; 
$action ="";
$path="/etc/asterisk/local/mm-software";
include_once ("$path/load.php");      // settings .. Functions
include_once ("$path/sound_db.php");  // functions
include_once ("$path/check_reg.php"); 

$file= "$path/mm-node.txt"; 

if(file_exists($file)){
$line = file_get_contents($file);
$u= explode(",",$line);
$AutoNode=$u[0];$call=$u[1];$autotts=$u[2];
}
$phpVersion= phpversion();
$datum   = date('m-d-Y H:i:s');$gmdatum = gmdate('m-d-Y H:i:s');

$piSystem=false;if (is_readable("/proc/device-tree/model")) {$piVersion = file_get_contents ("/proc/device-tree/model");$piSystem=true;}
else {$piVersion =	exec('uname -m -p');}

print "
===================================================
Node Restart $coreVersion $ver
(c)2025 WRXB288 LAGMRS.com all rights reserved
$phpzone PHP v$phpVersion  Release date:$release
===================================================
$datum Model: $piVersion
$datum Node:$node UTC:$gmdatum Level:$level
";

$line= exec("/opt/vc/bin/vcgencmd measure_temp",$output,$return_var);// SoC BCM2711 temp

$line = str_replace("'", "", $line);
$line = str_replace("C", "", $line);
$u= explode("=",$line);
$temp=$u[1];
$tempf = (float)(($temp * 9 / 5) + 32);
print "$datum Temp is $tempf F $temp C \n";


$action="";

check_gsm_db ($nodeName);if($file1){$action = "$action $file1";} // Name (server,repeater,node,tower,temperature) or any name in the database.");
list($whole, $decimal) = explode('.', $temp);
$oh=false;make_number ($whole);$action = "$action $actionOut";

if($decimal>=1){
check_gsm_db ("point");if($file1){$action = "$action $file1";} 
$oh=false;make_number ($decimal); $action = "$action $actionOut";

}
check_gsm_db ("degrees");if($file1){$action = "$action $file1";} 
check_gsm_db ("celsius");if($file1){$action = "$action $file1";} 





// /sbin/asterisk -rx 
// /sbin/killall safe_asterisk
// /sbin/killall asterisk
// /bin/rm -f /var/run/asterisk.ctl /var/run/asterisk.pid
// /usr/sbin/safe_asterisk

check_wav_db("wait-moment"); if($file1){$action = "$action $file1";}
check_gsm_db("yeah");   if($file1){$action = "$action $file1";}

print"talking \n";$file ="/tmp/jingle.ul";  if (file_exists($file)){unlink($file);} 
  exec("sox $action $file",$output,$return_var);  
  exec("sudo asterisk -rx 'rpt localplay $node /tmp/jingle'",$output,$return_var);
  sleep(11);


// move flag to support through reboots
$pathFlag="/etc/asterisk/local";
$flag = "$pathFlag/clean-shutdown.txt"; 
$fileOUT = fopen($flag,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$datum);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);




print"Rebooting system
Your terminal connection will now disconnect.....
\n";

exec("/usr/local/sbin/halt.sh $node",$output,$return_var);die; 

///usr/local/sbin/halt.sh



