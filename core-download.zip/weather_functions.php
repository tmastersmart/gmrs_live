<?php
// (c)2015/2023 by The Master lagmrs.com  by pws.winnfreenet.com
// This script uses some code my weather programs. Member CWOP since 2015 

// I license you to use this on your copy of this software only.
// Not for use on anything but GMRS.  GMRS ONLY! 

// No part of this code is opensource 
//
// Functons for weather. Shared 
// v1 1/29/24  All functions moved into this file so they can be shared. Cleanup on some functions
// v1.1 2/2/24  Debugging corupted data
// v1.2 2/6 Bug fix in NWS decoding
// v1.3 NWS now reads older reports to find one thats not NULL 
// v1.4 Error checking for file not found

function save_curent($in){

global $data_good,$in;
global $CurrTimeHr,$CurrTime,$CurrTimeD,$CurrTimeM,$CurrTimeY,$html;
global $outhumi,$barometricPressure,$barometricPressureABS;
global $uv,$solarradiation,$type;
global $the_temp,$outtemp,$outtempC,$heatIndex,$WindChill,$feelsLike,$dewpoint;
global $rainofdaily,$rainofmonthly,$rainofyearly;
global $avgwind,$gustspeed,$maxdailygust,$winddir;
global $currentTxt,$weatherLogs,$path,$datum,$cond1,$condWX,$station,$Station,$stationID;
// -------------------------------save------------------------------
// $condWX=weather data cond1=current cond $shortForcast
$datum = date('m-d-Y-H:i:s');   
if (!$the_temp){$the_temp=$outtemp;}

if($station){$Station=$station;}   // from ambient or NWS
if($stationID){$Station=$stationID;}
if(!$Station){$Station="-";}

//if (!$heatIndex) {$heatIndex =$the_temp;}
//if (!$WindChill) {$WindChill =$the_temp;}
if (!$dewpoint)  {$dewpoint  =$the_temp;}
//if (!$feelsLike){$feelsLike=$the_temp;}



$currentTxt    = "/tmp/current.txt";$file=$currentTxt; //if (file_exists($file)){unlink($file);}
$weatherLogs   = "$path/logs/weather.csv"; 
                     $fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$datum,$the_temp,$heatIndex,$WindChill,$feelsLike,$dewpoint,$outhumi,$avgwind,$rainofdaily,$barometricPressure,$rainofyearly,$uv,$solarradiation,$cond1,$gustspeed,$rainofmonthly,$maxdailygust,$condWX,$Station,,,,\n");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);// Save the raw data
$file=$weatherLogs  ;$fileOUT = fopen($file,'a');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$datum,$the_temp,$heatIndex,$WindChill,$feelsLike,$dewpoint,$outhumi,$avgwind,$rainofdaily,$barometricPressure,$rainofyearly,$uv,$solarradiation,$gustspeed,$rainofmonthly,$maxdailygust,$barometricPressureABS,$winddir,$Station,$type,,,,,,,,,\n");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);// save to the new weather database for charts
//print "$datum Saving current report [$Station]\n";
}


function read_acuweather($file){
global $cond1,$temp,$data_good;
$data_good = false;$temp="";
if (file_exists($file)){ //  "/tmp/accuweather.xml"; 
 $fileIN= file($file);
 foreach($fileIN as $line){
 $line = str_replace("\r", "", $line);
 $line = str_replace("\n", "", $line);
 $pos1 = strpos($line, 'Currently');  //<title>Currently: Partly Sunny: 90F</title> 
 $len = strlen($line);
 if (!$cond1 and $pos1){
   $u = explode(":",$line); 
   $cond1=strtolower($u[1]);       
   $pos2 = strpos($u[2], 'F<');
   $temp = substr($u[2], 0, $pos2);
   }
  }
 }// end
if($temp){$data_good=true;}   
}



function read_ambient($file){
global $textDescription,$f,$dateReading,$timeReading,$sitename,$data_good ;
global $CurrTimeHr,$CurrTime,$CurrTimeD,$CurrTimeM,$CurrTimeY,$html;
global $outhumi,$barometricPressure,$barometricPressureABS;
global $stationID,$uv,$solarradiation;
global $outtemp,$outtempC,$heatIndex,$WindChill,$feelsLike,$dewpoint;
global $rainofdaily,$rainofmonthly,$rainofyearly;
global $avgwind,$gustspeed,$maxdailygust,$winddir;

$data_good = false;
$WindChill="";$heatIndex="";$outtemp="";$outtempC="";$feelsLike="";$dewpoint=""; 
$outhumi="";$barometricPressure="";$barometricPressureABS="";$uv="";$solarradiation="";
$rainofdaily="";$rainofmonthly="";$rainofyearly=""; $winddir="";
$avgwind="";$gustspeed="";$maxdailygust="";
$textDescription=""; $i=0; $CurrTime="";

if (file_exists($file)){ 
//Just one line,
//[{"macAddress":"00:0","lastData":{"dateutc":1706460660000,"winddir":0,"windspeedmph":3.36,"windgustmph":4.92,"maxdailygust":14.99,"tempf":43.9,"battout":1,"humidity":86,"hourlyrainin":0,"eventrainin":0,"dailyrainin":0,"weeklyrainin":0,"monthlyrainin":9.65,"yearlyrainin":9.65,"totalrainin":9.65,"tempinf":66,"battin":1,"humidityin":42,"baromrelin":30.31,"baromabsin":30.23,"uv":3,"solarradiation":134.5,"temp1f":45.68,"humidity1":80,"batt1":0,"batt2":1,"batt3":1,"batt4":1,"batt5":1,"batt6":1,"batt7":1,"batt8":1,"feelsLike":42.41,"dewPoint":39.99,"feelsLike1":45.7,"dewPoint1":39.9,"feelsLikein":66,"dewPointin":42.2,"lastRain":"2024-01-27T10:40:00.000Z","tz":"America/Chicago","date":"2024-01-28T16:51:00.000Z"},"info":{"name":"xxx","location":"xxx","coords":{"coords":{"lat":xxx},"lon":xxx},"address":"","location":"xxx","elevation":49"geo":{"type":"Point","coordinates":[-x,x]}}}}]
$html= file($file);foreach($html as $line){$line = str_replace('"', "", $line);$u = explode(",",$line);}

while($i < count($u)){
$u2 = explode(":",$u[$i]);
if($u2[0]=="winddir"){     $winddir=$u2[1];} 
if($u2[0]=="tempf"){       $outtemp=$u2[1];$data_good=true;} 
if($u2[0]=="feelsLike"){   $feelsLike=$u2[1];} 
if($u2[0]=="dewPoint"){   $dewpoint=$u2[1];}  //"dewPoint":12.31, 
if($u2[0]=="humidity"){    $outhumi=$u2[1];} 
if($u2[0]=="windspeedmph"){$avgwind=$u2[1];}  
if($u2[0]=="windgustmph"){ $gustspeed=$u2[1];}
if($u2[0]=="maxdailygust"){$maxdailygust=$u2[1];} 
if($u2[0]=="dailyrainin"){ $rainofdaily=$u2[1];} 
if($u2[0]=="monthlyrainin"){$rainofmonthly=$u2[1];}    
if($u2[0]=="yearlyrainin"){$rainofyearly=$u2[1];} 
if($u2[0]=="baromabsin"){ $barometricPressureABS=$u2[1];}  
if($u2[0]=="baromrelin"){ $barometricPressure=$u2[1];}   
if($u2[0]=="solarradiation"){$solarradiation=$u2[1];}
if($u2[0]=="uv"){         $uv=$u2[1];} 
if($u2[0]=="location"){if(!$stationID){$stationID=$u2[1];}}// also has name
if($u2[0]=="date"){
$CurrTime =$u2[1]; 
$u3 = explode("-",$u2[1]);
$CurrTimeY = $u3[0];
$CurrTimeM = $u3[1];
$CurrTimeD = substr($u3[2], 0, 2);
$CurrTimeHr= substr($u3[2], 3, 2);
$CurrTimeM = $u[2];
} 
$i++;
}
// ambent may return 80.1  with no ending 0s 
if($outtemp){$data_good=true;} // verify
 if($outtemp and $feelsLike){
  if ($feelsLike > $outtemp+10) { $heatIndex=$feelsLike; }
  if ($feelsLike < $outtemp-10) { $WindChill=$feelsLike; }
  }
 } 
}






function read_fema($file){
global $parishCounty,$file,$femaY,$femaType,$femaDesc,$femaArea;
$html= file($file);$i=0; 
// line 0 is the header we dont need that
//femaDeclarationString,disasterNumber,state,declarationType,declarationDate,fyDeclared,incidentType,declarationTitle,ihProgramDeclared,iaProgramDeclared,paProgramDeclared,hmProgramDeclared,incidentBeginDate,incidentEndDate,disasterCloseoutDate,tribalRequest,fipsStateCode,fipsCountyCode,placeCode,designatedArea,declarationRequestNumber,lastIAFilingDate,lastRefresh,hash,id

//DR-4611-LA,4611,LA,DR,2021-08-29T00:00:00.000Z,2021,Hurricane,HURRICANE IDA,0,0,1,1,2021-08-26T00:00:00.000Z,2021-09-03T00:00:00.000Z,,0,22,001,99001,Acadia (Parish),21091,2021-11-29T00:00:00.000Z,2023-05-22T03:41:22.800Z,ff1a3e46c0e4a3fa2ea3b679f89e9dba67784b28,04d7e3d8-af93-497e-9d4b-ecdcdf057f80
$fema_good=false;  //Acadia (Parish)
$parishCounty=strtolower($parishCounty);
foreach($html as $line){
if($i>=1){
$u = explode(",",$line); 
 $line=strtolower($line);

 $pos = strpos($line, $parishCounty);
 if($pos){  
  //print "\n-$u[19]-$parishCounty-$femaArea $u[6] $u[7]\n";
  $femaY=$u[5];
  $femaType=$u[6];$femaType=strtolower($femaType);
  $femaDesc=$u[7];
  $femaArea=$u[19];
  $fema_good=true;break;
  }
 }
$i++;
 }
}

// NWS Read forcast API ------------------------------------------------
function read_api ($file){
global $head,$headline,$apiVer,$description,$event,$icon,$shortForcast,$detailedForecast,$url,$data_good,$title,$clear,$file,$out;

$html= file($file); $apiVer="?";$d1=0;
foreach($html as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$len= strlen($line);
//  "icon": "https://api.weather.gov/icons/land/night/tsra_hi,30/sct?size=medium",   might contain a comma
$pos = strpos($line, 'icon":');  // "icon": "https://api.weather.gov/icons/land/day/tsra_hi,20?size=medium",
if ($pos) {
     $test = trim($line," "); 
     $Lpos = strpos($test, ':');;$Rpos = strpos($test, '",');
     $icon  = substr($test, $Lpos+3, ($Rpos-$Lpos)-3);
     $icon  = str_replace('size=medium', 'size=small', $icon);// Redirect to the smaller icons  small medium and large avalable
//   print "$icon";
}

$pos = strpos($line, '"headline":'); // "headline": "Heat Advisory issued June 25 at 4:22AM CDT until June 25 at 7:00PM CDT by NWS Shreveport LA",
if ($pos) {
     $test = $line; 
     $Lpos = strpos($test, ':');$Rpos = strpos($test, '",');
     $headline2 = substr($test, $Lpos+3,($Rpos-$Lpos)-3);
     $headline2 = str_replace(',', "", $headline2);// just in case TWS breaks things with ,
     $headline2 = trim($headline2," ");
     if($headline2 and $headline){
     $headline ="$headline,$headline2";
     $headline2="";
     }
     else {$headline=$headline2;}
     }    
   
$line = str_replace('"', "", $line);     
    
$pos = strpos($line, 'event:'); //  "event": "Heat Advisory",
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ',');
     $event2 = substr($test, $Lpos+2,($Rpos-$Lpos)-2);
     if($event2 and $event){
     $event ="$event,$event2";// stacks events
     $event2="";
     }
     else {$event=$event2;}
     }
$pos = strpos($line, 'forecast:');  //forecast": "https://api.weather.gov/gridpoints/SHV/128,37/forecast",
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, 'http');$Rpos = strpos($test, 'cast,');
     $url  = substr($test, $Lpos,($Rpos-$Lpos)+4);
     }
$pos = strpos($line, 'shortForecast:');  
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ',');
     $shortForcast  = substr($test, $Lpos+2,($Rpos-$Lpos)-2);
     $shortForcast = str_replace(',', "", $shortForcast);// just in case TWS breaks things with ,
     $shortForcast = trim($shortForcast," ");
     }

$pos = strpos($line, 'version:'); //"@version": "1.1",   API still shows 1.1 but may change to 1.2
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ',');
     $apiVer  = substr($test, $Lpos+2, $len-2);
     $apiVer = str_replace(',', "", $apiVer); // just in case TWS breaks things with ,
     }     
$pos = strpos($line, 'detailedForecast:'); // "detailedForecast": "Mostly sunny, with a high near 94. Northeast wind 0 to 10 mph."
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ',');
     $detailedForecast = substr($test,$Lpos+2, $len-2);
     $detailedForecast = str_replace(',', "", $detailedForecast);// just in case TWS breaks things with ,
     $detailedForecast = trim($detailedForecast," ");
     }    

$pos = strpos($line, 'description:');  // "description": "* WHAT...Heat index 
if ($pos) {
     $test = $line;$d1++;
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ',');
     $description2 = substr($test, $Lpos+2,($Rpos-$Lpos)-2);
     $description2 = str_replace(',', "", $description2);// just in case TWS breaks things with ,
     $description2 = trim($description2," ");
     // stack into an array
     if($description2 and $description){
      $description ="$description<BR>$d1. [$description2 ]";
      $description2="";
     }
     else {$description="$d1. [$description2 ]";}
     } 
       
// stop here dont read past today 
$pos = strpos($line, 'number: 2,');if ($pos) { break;} 
 }
 

 
}

// NWS forcast next x events
// Day names added since this is fluid and changes Its not always the next 7 days
function build_week ($file){
global $debug,$iconWeek,$forcastWeek,$nameWeek;
$forcastWeek="";$nameWeek="";$iconWeek="";$testI="";
$testI= file($file); 
foreach($testI as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);

$pos = strpos($line, 'name":');  //"name": "Tonight",
if ($pos) {
     $test = trim($line," "); $len= strlen($test);
     $Lpos = strpos($test, ':');;$Rpos = strpos($test, '",');
     $nameIt  = substr($test, $Lpos+3, ($Rpos-$Lpos)-3);
     if($nameIt and $nameWeek){
     $nameWeek ="$nameWeek|$nameIt";// stacks a week 
     $nameIt="";
     }
     else {$nameWeek=$nameIt;}
     }

//  "icon": "https://api.weather.gov/icons/land/night/tsra_hi,30/sct?size=medium",   might contain a comma
$pos = strpos($line, 'icon":');  // "icon": "https://api.weather.gov/icons/land/day/tsra_hi,20?size=medium",
if ($pos) {
     $test = trim($line," "); $len= strlen($test);
     $Lpos = strpos($test, ':');;$Rpos = strpos($test, '",');
     $icon2  = substr($test, $Lpos+3, ($Rpos-$Lpos)-3);
     $icon2  = str_replace('size=medium', 'size=small', $icon2);// Redirect to the smaller icons  small medium and large avalable
//     print "$icon2|";
     if($icon2 and $iconWeek){
     $iconWeek ="$iconWeek|$icon2";// stacks a week of icons into array use | not ,
     $icon2="";
     }
     else {$iconWeek=$icon2;}
     }
$line = str_replace('"', "", $line);        
     
//"detailedForecast": "Mostly clear, with a low around 76. South wind 5 to 10 mph."
$pos = strpos($line, 'detailedForecast:');   
if ($pos) {
     $test = $line;   $len=strlen($test); // print "$test\n";
     $Lpos = strpos($test, ':');$Rpos = strpos($test, '}');
     $forcast = substr($test, $Lpos+2,$len); if($debug){print "$forcast\n";}
     $forcast = str_replace(',', "", $forcast);// just in case TWS breaks things with ,
     $forcast = trim($forcast," ");
      if($forcastWeek and $forcast){
     $forcastWeek ="$forcastWeek|$forcast";// stacks a week into array use | not ,
     $forcast="";
     }
     else {$forcastWeek=$forcast;}
     }
  }
}





//   Pull the Forcast URL from the NWS geocoded report ------------------------
function read_api_url ($file){
global $url,$data_good,$file;
$data_good=false;
if (file_exists($file)){
$html= file($file); 
foreach($html as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$len= strlen($line);
$line = str_replace('"', "", $line);     
$pos = strpos($line, 'forecast:');  //forecast": "https://api.weather.gov/gridpoints/SHV/128,37/forecast",
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, 'http');$Rpos = strpos($test, 'cast,');
     $url  = substr($test, $Lpos,($Rpos-$Lpos)+4);
     break;
     }
  }
 }
}



// NWS Read the new API current weather -----v2---------------------------------------------------------
function read_NWS ($file) {
global $CurrTimeR,$CurrTimeMi,$CurrTimeHr,$CurrTime,$CurrTimeD,$CurrTimeM,$CurrTimeY;
global $textDescription,$f,$dateReading,$timeReading,$sitename,$data_good ;
global $CurrTimeHr,$CurrTime,$CurrTimeD,$CurrTimeM,$CurrTimeY,$html;
global $outhumi,$barometricPressure,$barometricPressureABS;
global $stationID,$uv,$solarradiation;
global $outtemp,$outtempC,$heatIndex,$WindChill,$feelsLike,$dewpoint;
global $rainofdaily,$rainofmonthly,$rainofyearly;
global $avgwind,$gustspeed,$maxdailygust,$winddir;

$WindChill="";$heatIndex="";$outtemp="";$outtempC="";$feelsLike="";$dewpoint=""; 
$outhumi="";$barometricPressure="";$uv="";$solarradiation=""; $barometricPressureABS="";
$rainofdaily="";$rainofmonthly="";$rainofyearly="";
$avgwind="";$gustspeed="";$maxdailygust="";
$textDescription=""; $i=0;
$data_good = false;
$temp=false;$dew=false;$speed=false;$gust=false;$hum=false;$chill=false;$heat=false;$rain1=false;$rain3=false; $rain6=false;$press=false;$pressSEA=false;$dir=true;
$html= file($file); 
foreach($html as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$len= strlen($line);// $value2="";
//"textDescription": "Clear",
$pos = strpos($line, 'textDescription":'); 
if ($pos) {
     $test = $line; 
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ','); 
     $value2 = substr($test, $Lpos+2,($Rpos-$Lpos)-2);
     $value2 = str_replace(',', "", $value2);
     $value2 = str_replace('"', "", $value2);
     $value2 = trim($value2," ");
     $textDescription=$value2; 
} 

$pos = strpos($line, 'temperature":');                if($pos){$temp    =true;continue;}
$pos = strpos($line, 'dewpoint":');                   if($pos){$dew     =true;continue;}
$pos = strpos($line, 'windSpeed":');                  if($pos){$speed   =true;continue;}
$pos = strpos($line, 'windGust":');                   if($pos){$gust    =true;continue;}
$pos = strpos($line, 'relativeHumidity":');           if($pos){$hum     =true;continue;}
$pos = strpos($line, 'windChill":');                  if($pos){$chill   =true;continue;}
$pos = strpos($line, 'heatIndex":');                  if($pos){$heat    =true;continue;}
$pos = strpos($line, 'precipitationLastHour":');      if($pos){$rain1   =true;continue;} 
$pos = strpos($line, 'precipitationLastHour3Hours":');if($pos){$rain3   =true;continue;}
$pos = strpos($line, 'precipitationLastHour6Hours":');if($pos){$rain6   =true;continue;}
$pos = strpos($line, 'barometricPressure":')         ;if($pos){$press   =true;continue;}
$pos = strpos($line, 'seaLevelPressure":')           ;if($pos){$pressSEA=true;continue;}
$pos = strpos($line, 'windDirection":');              if($pos){$dir     =true;continue;}

$pos = strpos($line, 'value":'); 
if ($pos) {
     $test = $line; 
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ','); // "value": null,
     $value2 = substr($test, $Lpos+2,($Rpos-$Lpos)-2);
     $value2 = str_replace(',', "", $value2);
     $value2 = trim($value2," ");
  if ($value2=="null"){// its null start over
  $value2="";
  $temp=false;$dew=false;$speed=false;$gust=false;$hum=false;$chill=false;$heat=false;$rain1=false;$rain3=false; $rain6=false;$press=false;$pressSEA=false;$dir=true;
  continue;
  }

$f="";
if($temp and !$outtemp){celsius_to_fahrenheit($value2);$outtemp=$f;$outtempC=number_format($value2, 2);$data_good = true;$temp=false;continue;}
if($dew  and !$dewpoint){celsius_to_fahrenheit($value2);$dewpoint=$f;$dew=false;continue;}
if($chill and !$WindChill){celsius_to_fahrenheit($value2);$WindChill=$f;$chill=false;continue;} 
if($heat and !$heatIndex){celsius_to_fahrenheit($value2);$heatIndex=$f;$heat=false;continue;}


if($speed and !$avgwind ){$avgwind=number_format($value2, 2);$speed=false;continue;}
if($gust and !$gustspeed ){$gustspeed=number_format($value2, 2);$gust=false;continue;} 
if($dir and !$winddir ){$winddir=$value2;$dir=false;continue;} 

if($hum and !$outhumi ){$outhumi=number_format($value2, 2);$hum=false;continue;}
if($rain1 and !$rainofdaily ){$rainofdaily=$value2;$rain1=false;continue;}
if($rain3 and !$rainofdaily ){$rainofdaily=$value2;$rain3=false;continue;}
if($rain6 and !$rainofdaily ){$rainofdaily=$value2;continue;}
if($press and !$barometricPressureABS ){$mb = $value2 * 0.00029529980164712; $barometricPressureABS=number_format($mb, 2);$press=false;continue; }
if($pressSEA and !$barometricPressure  ){$mb = $value2 * 0.00029529980164712; $barometricPressure=number_format($mb, 2);$pressSEA=false;continue; }
}
 } // end for
 
if (!$outtemp){$data_good = true;}

// fix the heat index values 
if (!$heatIndex > $outtemp+10) { $heatIndex=""; }
if (!$WindChill < $outtemp-10) { $WindChill=""; }

       
}

function celsius_to_fahrenheit($in){ 
global $f;
    $f=$in*9/5+32; 
    $f=number_format($f, 2);
}

// OLD code to be removed as soon as im sure its not still in core code
// Now reading the entire data not just the temp.

// OLD to be removed
function read_ambient_api_temp ($file){
global $outtemp,$data_good,$file,$html;
$data_good = false;$outtemp="";$temp=false;$i=0;
if (file_exists($file)){  // protection
$html= file($file); 
foreach($html as $line){$line = str_replace('"', "", $line);$u = explode(",",$line);}

while($i < count($u)){
$u2 = explode(":",$u[$i]);
if($u2[0]=="tempf"){$outtemp=$u2[1];$data_good=true;}    
$i++;
 }
if($outtemp){$data_good=true;}  
 }
}

// This is OLD and to be removed
// NWS Read the temp from API current weather-
function read_api_temp ($file){
global $outCtemp,$data_good,$file;
$temp=false; $data_good=false;
if (file_exists($file)){
$html= file($file); 
foreach($html as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);

$line = str_replace('"', "", $line);
 
//"temperature": {
//            "unitCode": "wmoUnit:degC",
//            "value": 22.300000000000001, 
//print "--$line\n";
$pos = strpos($line, 'temperature:');      if ($pos) {$temp=true;}
   
$pos = strpos($line, 'value'); 
if ($pos) {
     $test = $line; 
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ','); // "value": null,
     $value2 = substr($test, $Lpos+2,($Rpos-$Lpos)-2);
     $value2 = str_replace(',', "", $value2);
     $value2 = trim($value2," ");
    
     if ($value2=="null"){$value2="";}
//     print "$value2\n";
     
// which one to put it in  $avgwind,$gustspeed
if($temp) {
if ($value2){
$outCtemp=$value2;$data_good = true;}

$temp=false;
    }
   }
  }
 }
}


