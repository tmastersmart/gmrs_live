<?php
// (c)2015/2023 by The Master lagmrs.com  by pws.winnfreenet.com
// This script uses some code my weather programs. Member CWOP since 2015 

// I license you to use this on your copy of this software only.
// Not for use on anything but GMRS.  GMRS ONLY! 

// No part of this code is opensource 
//
// Functons for weather. Shared 
// v1 1/29/24  All functions moved into this file so they can be shared. Cleanup on some functions
// v1.1 2/2/24  Debugging corupted data
// v1.2 2/6 Bug fix in NWS decoding
// v1.3 NWS now reads older reports to find one thats not NULL 
// v1.4 Error checking for file not found
// v1.6 cyclone multi alert support added

// v1.7b talking version  for lagmrs.com
// v1.8  debugging for cyclone
// v1.9 added $instruction to alerts. 7/25  (fixed , in description stoping decode)
// v2   added the extra headlines,
// v2.2 reformat alerts into data fields (tweeks to the detection)
// v2.3  Huricane speaking adjusted
// v2.4  Adjusted the east c detection false trigers
// v2.5  Debugging added
// v2.6  VOICE to TSS moved from node image to the HUB image. 
function save_curent($in){

global $data_good,$in;
global $CurrTimeHr,$CurrTime,$CurrTimeD,$CurrTimeM,$CurrTimeY,$html;
global $outhumi,$barometricPressure,$barometricPressureABS;
global $uv,$solarradiation,$type;
global $the_temp,$outtemp,$outtempC,$heatIndex,$WindChill,$feelsLike,$dewpoint;
global $rainofdaily,$rainofmonthly,$rainofyearly;
global $avgwind,$gustspeed,$maxdailygust,$winddir;
global $currentTxt,$weatherLogs,$path,$datum,$cond1,$condWX,$station,$Station,$stationID;
// -------------------------------save------------------------------
// $condWX=weather data cond1=current cond $shortForcast
$datum = date('m-d-Y-H:i:s');   
if (!$the_temp){$the_temp=$outtemp;}

if($station){$Station=$station;}   // from ambient or NWS
if($stationID){$Station=$stationID;}
if(!$Station){$Station="-";}

//if (!$heatIndex) {$heatIndex =$the_temp;}
//if (!$WindChill) {$WindChill =$the_temp;}
if (!$dewpoint)  {$dewpoint  =$the_temp;}
//if (!$feelsLike){$feelsLike=$the_temp;}



$currentTxt    = "/tmp/current.txt";$file=$currentTxt; //if (file_exists($file)){unlink($file);}
$weatherLogs   = "$path/logs/weather.csv"; 
                     $fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$datum,$the_temp,$heatIndex,$WindChill,$feelsLike,$dewpoint,$outhumi,$avgwind,$rainofdaily,$barometricPressure,$rainofyearly,$uv,$solarradiation,$cond1,$gustspeed,$rainofmonthly,$maxdailygust,$condWX,$Station,,,,\n");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);// Save the raw data
$file=$weatherLogs  ;$fileOUT = fopen($file,'a');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$datum,$the_temp,$heatIndex,$WindChill,$feelsLike,$dewpoint,$outhumi,$avgwind,$rainofdaily,$barometricPressure,$rainofyearly,$uv,$solarradiation,$gustspeed,$rainofmonthly,$maxdailygust,$barometricPressureABS,$winddir,$Station,$type,,,,,,,,,\n");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);// save to the new weather database for charts
//print "$datum Saving current report [$Station]\n";
}


function read_acuweather($file){
global $cond1,$temp,$data_good;
$data_good = false;$temp="";
if (file_exists($file)){ //  "/tmp/accuweather.xml"; 
 $fileIN= file($file);
 foreach($fileIN as $line){
 $line = str_replace("\r", "", $line);
 $line = str_replace("\n", "", $line);
 $pos1 = strpos($line, 'Currently');  //<title>Currently: Partly Sunny: 90F</title> 
 $len = strlen($line);
 if (!$cond1 and $pos1){
   $u = explode(":",$line); 
   $cond1=strtolower($u[1]);       
   $pos2 = strpos($u[2], 'F<');
   $temp = substr($u[2], 0, $pos2);
   }
  }
 }// end
if($temp){$data_good=true;}   
}



function read_ambient($file){
global $textDescription,$f,$dateReading,$timeReading,$sitename,$data_good ;
global $CurrTimeHr,$CurrTime,$CurrTimeD,$CurrTimeM,$CurrTimeY,$html;
global $outhumi,$barometricPressure,$barometricPressureABS;
global $stationID,$uv,$solarradiation;
global $outtemp,$outtempC,$heatIndex,$WindChill,$feelsLike,$dewpoint;
global $rainofdaily,$rainofmonthly,$rainofyearly;
global $avgwind,$gustspeed,$maxdailygust,$winddir;

$data_good = false;
$WindChill="";$heatIndex="";$outtemp="";$outtempC="";$feelsLike="";$dewpoint=""; 
$outhumi="";$barometricPressure="";$barometricPressureABS="";$uv="";$solarradiation="";
$rainofdaily="";$rainofmonthly="";$rainofyearly=""; $winddir="";
$avgwind="";$gustspeed="";$maxdailygust="";
$textDescription=""; $i=0; $CurrTime="";

if (file_exists($file)){ 
//Just one line,
//[{"macAddress":"00:0","lastData":{"dateutc":1706460660000,"winddir":0,"windspeedmph":3.36,"windgustmph":4.92,"maxdailygust":14.99,"tempf":43.9,"battout":1,"humidity":86,"hourlyrainin":0,"eventrainin":0,"dailyrainin":0,"weeklyrainin":0,"monthlyrainin":9.65,"yearlyrainin":9.65,"totalrainin":9.65,"tempinf":66,"battin":1,"humidityin":42,"baromrelin":30.31,"baromabsin":30.23,"uv":3,"solarradiation":134.5,"temp1f":45.68,"humidity1":80,"batt1":0,"batt2":1,"batt3":1,"batt4":1,"batt5":1,"batt6":1,"batt7":1,"batt8":1,"feelsLike":42.41,"dewPoint":39.99,"feelsLike1":45.7,"dewPoint1":39.9,"feelsLikein":66,"dewPointin":42.2,"lastRain":"2024-01-27T10:40:00.000Z","tz":"America/Chicago","date":"2024-01-28T16:51:00.000Z"},"info":{"name":"xxx","location":"xxx","coords":{"coords":{"lat":xxx},"lon":xxx},"address":"","location":"xxx","elevation":49"geo":{"type":"Point","coordinates":[-x,x]}}}}]
$html= file($file);foreach($html as $line){$line = str_replace('"', "", $line);$u = explode(",",$line);}

while($i < count($u)){
$u2 = explode(":",$u[$i]);
if($u2[0]=="winddir"){     $winddir=$u2[1];} 
if($u2[0]=="tempf"){       $outtemp=$u2[1];$data_good=true;} 
if($u2[0]=="feelsLike"){   $feelsLike=$u2[1];} 
if($u2[0]=="dewPoint"){   $dewpoint=$u2[1];}  //"dewPoint":12.31, 
if($u2[0]=="humidity"){    $outhumi=$u2[1];} 
if($u2[0]=="windspeedmph"){$avgwind=$u2[1];}  
if($u2[0]=="windgustmph"){ $gustspeed=$u2[1];}
if($u2[0]=="maxdailygust"){$maxdailygust=$u2[1];} 
if($u2[0]=="dailyrainin"){ $rainofdaily=$u2[1];} 
if($u2[0]=="monthlyrainin"){$rainofmonthly=$u2[1];}    
if($u2[0]=="yearlyrainin"){$rainofyearly=$u2[1];} 
if($u2[0]=="baromabsin"){ $barometricPressureABS=$u2[1];}  
if($u2[0]=="baromrelin"){ $barometricPressure=$u2[1];}   
if($u2[0]=="solarradiation"){$solarradiation=$u2[1];}
if($u2[0]=="uv"){         $uv=$u2[1];} 
if($u2[0]=="location"){if(!$stationID){$stationID=$u2[1];}}// also has name
if($u2[0]=="date"){
$CurrTime =$u2[1]; 
$u3 = explode("-",$u2[1]);
$CurrTimeY = $u3[0];
$CurrTimeM = $u3[1];
$CurrTimeD = substr($u3[2], 0, 2);
$CurrTimeHr= substr($u3[2], 3, 2);
$CurrTimeM = $u[2];
} 
$i++;
}
// ambent may return 80.1  with no ending 0s 
if($outtemp){$data_good=true;} // verify
 if($outtemp and $feelsLike){
  if ($feelsLike > $outtemp+6) { $heatIndex=$feelsLike; }
  if ($feelsLike < $outtemp-5) { $WindChill=$feelsLike; }
  }
 } 
}

//<nhc:Cyclone>
//<nhc:center>25.9, -95.1</nhc:center>
//<nhc:type>TROPICAL STORM</nhc:type>
//<nhc:name>Beryl</nhc:name>
//<nhc:wallet>AT2</nhc:wallet>
//<nhc:atcf>AL022024</nhc:atcf>
//<nhc:datetime>10:00 AM CDT Sun Jul 7</nhc:datetime>
//<nhc:movement>NW at 10 mph</nhc:movement>
//<nhc:pressure>992 mb</nhc:pressure>
//<nhc:wind>65 mph</nhc:wind>
//<nhc:headline> ...BERYL BECOMING BETTER ORGANIZED AND FORECAST TO BECOME A HURRICANE BEFORE LANDFALL... ...PREPARATIONS SHOULD BE RUSHED TO COMPLETION...</nhc:headline>
//</nhc:Cyclone>

function read_cyclone($file){
global $tts,$path,$Ctype,$Ccenter,$Cname,$Cdate,$Cmovement,$Cwind,$Cheadline,$node,$datum,$file1;

$ttsDir = '/tmp/tts';
$dateTag = date("Ymd_His");  // Example: 20250730_151105
$ttsAudio        ="$ttsDir/audio.wav";// this is used elsewhere just kill it
$cyclone         ="/tmp/cyclone.xml";
$cycloneTxt      ="/tmp/cyclone.txt";
$cycloneGsm      ="/tmp/cyclone.gsm";
$cycloneWav      ="$ttsDir/cyclone_$dateTag.wav";// this keeps tts in the same dir
$cycloneFlag     ="/tmp/cyclone-flag.txt";
if ($tts){       print"$datum Voices Key=true [$tts]\n";}  
if (!is_dir($ttsDir)) {mkdir($ttsDir, 0777, true);} // 0777 permissions, true = recursive


$maxAge = 4 * 60 * 60; // 4 hours in seconds    hold off time

$action="";$vAction="";$talkFlag=false;
if (file_exists($cyclone)){ 
$html= file($cyclone);
if (file_exists($cycloneTxt)){unlink($cycloneTxt);}
$Ctype="";$Ccenter="";$Cname="";$Cdate="";$Cmovement="";$Cwind="";$Cheadline="";$Cdesc="";$CCdate="";$cyclone=false;
foreach($html as $line){
$u = explode(",",$line); 
$line = str_replace(',', "", $line); 
//$pos = strpos("-$line", "<description>"); if($pos){$xml = extract_xml($line);$Cdesc     = (string) $xml;}
//$pos = strpos("-$line", "<nhc:Cyclone>"); if($pos){$cyclone=true;}
//
//<description>Atlantic Basin GIS Data for Active Tropical Cyclones</description>GULF OF HONDURAS
//      <description>...ERIN BECOMING BETTER ORGANIZED AS IT MOVES NORTH-NORTHWESTWARD... ...LIFE-THREATENING RIP CURRENTS EXPECTED ALONG U.S. EAST COAST BEACHES... As of 11:00 PM EDT Tue Aug 19 the center of Erin was located near 27.7, -73.0 with movement NNW at 12 mph. The minimum central pressure was 959 mb with maximum sustained winds of about 100 mph.</description>
//      <nhc:Cyclone>
//        <nhc:center>27.7, -73.0</nhc:center>
//        <nhc:type>Hurricane</nhc:type>
//        <nhc:name>Erin</nhc:name>
//        <nhc:wallet>AT5</nhc:wallet>
//        <nhc:atcf>AL052025</nhc:atcf>
//        <nhc:datetime>11:00 PM EDT Tue Aug 19</nhc:datetime>
//        <nhc:movement>NNW at 12 mph</nhc:movement>
//        <nhc:pressure>959 mb</nhc:pressure>
//        <nhc:wind>100 mph</nhc:wind>
//        <nhc:headline>...ERIN BECOMING BETTER ORGANIZED AS IT MOVES NORTH-NORTHWESTWARD... ...LIFE-THREATENING RIP CURRENTS EXPECTED ALONG U.S. EAST COAST BEACHES...</nhc:headline>
//      </nhc:Cyclone>

$pos = strpos("-$line", "<description>"); if($pos and !$Cheadline){$xml = extract_xml($line);$Cdesc   = (string) $xml;}
$pos = strpos("-$line", "<nhc:center>");  if($pos){$xml = extract_xml($line);$Ccenter   = (string) $xml;}
$pos = strpos("-$line", "<nhc:type>");    if($pos){$xml = extract_xml($line);$Ctype     = (string) $xml;}
$pos = strpos("-$line", "<nhc:name>");    if($pos){$xml = extract_xml($line);$Cname     = (string) $xml;}
$pos = strpos("-$line", "<nhc:datetime"); if($pos){$xml = extract_xml($line);$Cdate     = (string) $xml;}
$pos = strpos("-$line", "<nhc:movement"); if($pos){$xml = extract_xml($line);$Cmovement = (string) $xml;}
$pos = strpos("-$line", "<nhc:wind>");    if($pos){$xml = extract_xml($line);$Cwind     = (string) $xml;}
$pos = strpos("-$line", "<nhc:headline>");if($pos){$xml = extract_xml($line);$Cheadline = (string) $xml;}
$pos = strpos("-$line", "</nhc:Cyclone>");
 if($pos){
print"$datum Testing this line $Cdesc\n";

//$Ccenter = "38.3, -50.8";
$out="Cyclone at $Ccenter";save_task_log($out);print"$datum $out \n"; 
//echo "East Coast: " . (checkEastCoastHurricaneLocation($Ccenter) ? "True" : "False") . "\n";
//echo "West Coast: " . (checkWestCoastHurricaneLocation($Ccenter) ? "True" : "False") . "\n";
//echo "Gulf Coast: " . (checkGulfCoastHurricaneLocation($Ccenter) ? "True" : "False") . "\n";

// note that a diffrent feed may be needed for the east cost.
// line 513 in weather_api_pull.php 
// $cycloneURL = "/gis-at.xml"; // set from ones listed at cyclone update ///https://www.nhc.noaa.gov/aboutrss.shtml
//  Atlantic Basin GIS Data:  gis-at.xml
//  Eastern Pacific Basin GIS gis-ep.xml
//  Central Pacific Basin GIS gis-cp.xml 

 
 
$gulfTest  = checkGulfCoastHurricaneLocation($Ccenter);
$eastTest  = checkEastCoastHurricaneLocation($Ccenter); 
$westTest  = checkGulfCoastHurricaneLocation($Ccenter);  
$caribbean = checkCaribbeanHurricaneLocation($Ccenter); 
 
 
//$gulfTest  = checkGulfStatesHurricaneWatch($Cdesc); 
//$eastTest  = checkEastCoastHurricaneWatch($Cdesc) ; 
//$westTest  = checkWestCoastHurricaneWatch($Cdesc) ; 
$gulfTrue  = checkGulfHurricaneWatch($Cdesc);
//$caribbean = checkCaribbeanHurricaneWatch($Cdesc);
$isHuricane= isHurricane($Ctype);
// debugging panel 
$out="";
if ($isHuricane){$out="$out Huricane=true";} 
if ($gulfTest ) {$out="$out GulfStates=true";}
if ($eastTest ) {$out="$out East=true";}
if ($westTest ) {$out="$out West=true";}
if ($gulfTrue ) {$out="$out Gulf=true";}
if ($caribbean ){$out="$out Caribbean=true";} 
if ($out="Cyclone match [$out]"){save_task_log($out);print"$datum $out \n";}
  
//if($gulfTest or $eastTest or $westTest or $gulfTrue){
if ($gulfTest || $eastTest || $westTest || $gulfTrue || $caribbean || $isHuricane ) {
  $action= "$action $Cdate,$Ccenter,$Ctype,$Cname,$Cmovement,$Cwind,$Cheadline,$Cdesc,,,,,\n";
// $vAction= "$vAction $Cdesc $Ctype $Cname Centered at $Ccenter Wind $Cwind $Cheadline ";
  $vAction= "$vAction $Ctype $Cname";
  if($Cwind){$vAction= "$vAction speed $Cwind";}
  $vAction= "$vAction $Cheadline";
  $talkFlag=true; $CCdate=$Cdate;
  }
 else{print"$datum Skipping [$Ctype $Cname]\n";}
 
 $Ctype="";$Ccenter="";$Cname="";$Cdate="";$Cmovement="";$Cwind="";$Cheadline="";$Cdesc="";
  }
}

// support for stacking alerts
if($action){
$fileOUT = fopen($cycloneTxt,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$action);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);

// only read it if set above----

if (file_exists($cycloneFlag)) {
    list($fileDate, $fileAction) = explode('|', trim(file_get_contents($cycloneFlag)));
    $lastModified = filemtime($cycloneFlag);
    $age = time() - $lastModified;
    // If too old, remove it and allow a new play
    if ($age > $maxAge) {        unlink($cycloneFlag);}    // If the bulletin date has changed, allow new play
    elseif ($fileDate !== $CCdate) {unlink($cycloneFlag);}
    // Otherwise, it’s too soon or same bulletin → block replay
    else { $talkFlag = false;}
}

// tts must be set if not we skip talking
// TSS was removed from the nodes will only be in the hubs

  }// end action 
else{ 
 if (file_exists($cycloneGsm ))  {unlink($cycloneGsm );} 
 if (file_exists($cycloneFlag )){unlink($cycloneFlag );}
 print"$datum Cyclone:All clear. Nothing in area.\n";


}// if not talking we dont need 


  }// end if cyclone file exists
}// end fnction

function checkGulfHurricaneWatch($text) {
    $text = str_replace('.', '', $text); // Remove periods
    $pattern = '/\b(Gulf(\s+of\s+(America|Mexico))?)\b/i';
    preg_match_all($pattern, $text, $matches);
    return !empty($matches[0]);
}


function checkGulfStatesHurricaneWatch($text) {
    $pattern = '/\b(Texas|Louisiana|Mississippi|Alabama|Florida|LA|MI|AL|TX|FL)\b/i';
    $matches = [];
    preg_match_all($pattern, $text, $matches);
    return !empty($matches[0]);
}

function checkEastCoastHurricaneWatch($text) {
    // Normalize text by removing periods that can break "U.S."
    $text = str_replace('.', '', $text);

    // East Coast states + abbreviations + US (drop NE trigered by north east)
 $pattern = '/\b(
    Maine|ME|
    NEW\s+ENGLAND|
    New\s+Hampshire|NH|
    Massachusetts|MA|
    Rhode\s+Island|RI|
    Connecticut|CT|
    New\s+York|NY|
    New\s+Jersey|NJ|
    Pennsylvania|PA|
    Delaware|DE|
    Maryland|MD|
    Virginia|VA|
    North\s+Carolina|NC|
    South\s+Carolina|SC|
    Georgia|GA|
    US
)\b/ix';

    preg_match_all($pattern, $text, $matches);
    return !empty($matches[0]);
}

function checkCaribbeanHurricaneWatch($text) {
    $text = str_replace('.', '', $text);

    // Territories & islands (with abbreviations)
    $pattern = '/\b(
        Puerto\s+Rico|PR|
        U\s*S\s*Virgin\s+Islands|Virgin\s+Islands|VI|
        Bahamas|Bermuda|Turks\s+and\s+Caicos|
        Cuba|Hispaniola|
        Haiti|Dominican\s+Republic|DR|
        Jamaica|Cayman\s+Islands|
        Barbados|Antigua|       
        St\s*Lucia|St\s*Croix|St\s*Thomas
    )\b/ix';

    preg_match_all($pattern, $text, $matches);
    return !empty($matches[0]);
}
// future expansion
function checkWestCoastHurricaneWatch($text) {
    // West Coast states including Hawaii and Alaska
    $pattern = '/\b(Washington|Oregon|California|Hawaii|Alaska|WA|OR|CA|HI|AK)\b/i';
    $matches = [];
    preg_match_all($pattern, $text, $matches);
    return !empty($matches[0]);
}



function isHurricane($type) {
    // Normalize to lowercase and trim whitespace
    $type = strtolower(trim($type));

    // Match only the word "hurricane"
    return $type === "hurricane";
}


// Helper function to parse coordinates from string like "38.3, -50.8"
function parseCoordinates($Ccenter) {
    if (is_string($Ccenter)) {
        $coords = explode(',', $Ccenter);
        if (count($coords) !== 2) {return [null, null]; }
        $lat = trim($coords[0]);
        $lon = trim($coords[1]);
        if (!is_numeric($lat) || !is_numeric($lon)) {return [null, null]; }
        return [(float)$lat, (float)$lon];
    }
    return [null, null];
}

// Check if hurricane is in East Coast USA region
function checkEastCoastHurricaneLocation($Ccenter) {
    list($lat, $lon) = parseCoordinates($Ccenter);
    if ($lat === null || $lon === null) {        return false;    }
    // East Coast boundaries: 25N to 45N, -81W to -65W
    $inEastCoast = ($lat >= 25 && $lat <= 45 && $lon >= -81 && $lon <= -65);
    return $inEastCoast;
}

// Check if hurricane is in West Coast USA region (including Hawaii)
function checkWestCoastHurricaneLocation($Ccenter) {
    list($lat, $lon) = parseCoordinates($Ccenter);
    if ($lat === null || $lon === null) {        return false;    }
    // West Coast boundaries: 30N to 50N, -125W to -115W
    // Hawaii boundaries: 18N to 23N, -161W to -154W
    $inWestCoast = ($lat >= 30 && $lat <= 50 && $lon >= -125 && $lon <= -115) ||
                   ($lat >= 18 && $lat <= 23 && $lon >= -161 && $lon <= -154);
    return $inWestCoast;
}

// Check if hurricane is in Gulf Coast USA region
function checkGulfCoastHurricaneLocation($Ccenter) {
    list($lat, $lon) = parseCoordinates($Ccenter);
    if ($lat === null || $lon === null) {        return false;    }
    // Gulf Coast boundaries: 24N to 31N, -98W to -80W
    $inGulfCoast = ($lat >= 24 && $lat <= 31 && $lon >= -98 && $lon <= -80);
    return $inGulfCoast;
}



// Check if hurricane is in Caribbean region
function checkCaribbeanHurricaneLocation($Ccenter) {
    list($lat, $lon) = parseCoordinates($Ccenter);
    if ($lat === null || $lon === null) { return false; }
    // Caribbean boundaries: 10N to 25N, -85W to -60W
    $inCaribbean = ($lat >= 10 && $lat <= 25 && $lon >= -85 && $lon <= -60);
    return $inCaribbean;
}




function avoidCriticalWindow() {
global $datum;
    while (true) {
        // Get the current minute of the hour
        $minute = (int)date('i');

        // Check if we are in the critical window between 55 minutes and 5 minutes past the hour
        if ($minute >= 55 || $minute <= 5) {
            // If we're in the avoid window, wait (sleep) for 30 seconds and check again
            print "$datum Current minute: $minute - Avoiding critical window, waiting...\n";
            sleep(30); // Sleep for 30 seconds and check again
        } else {
            // If we're outside the avoid window, break the loop and proceed
            print "$datum Current minute: $minute - It's safe to proceed!\n";
            break;
        }
    }
}


function extract_xml($xmlString){
$start_pos = strpos($xmlString, '>') + 1;
$end_pos = strrpos($xmlString, '<');
$xmlString = substr($xmlString, $start_pos, $end_pos - $start_pos);
return $xmlString;
}

function read_fema($file){
global $parishCounty,$file,$femaY,$femaType,$femaDesc,$femaArea;
$html= file($file);$i=0; 
// line 0 is the header we dont need that
//femaDeclarationString,disasterNumber,state,declarationType,declarationDate,fyDeclared,incidentType,declarationTitle,ihProgramDeclared,iaProgramDeclared,paProgramDeclared,hmProgramDeclared,incidentBeginDate,incidentEndDate,disasterCloseoutDate,tribalRequest,fipsStateCode,fipsCountyCode,placeCode,designatedArea,declarationRequestNumber,lastIAFilingDate,lastRefresh,hash,id

//DR-4611-LA,4611,LA,DR,2021-08-29T00:00:00.000Z,2021,Hurricane,HURRICANE IDA,0,0,1,1,2021-08-26T00:00:00.000Z,2021-09-03T00:00:00.000Z,,0,22,001,99001,Acadia (Parish),21091,2021-11-29T00:00:00.000Z,2023-05-22T03:41:22.800Z,ff1a3e46c0e4a3fa2ea3b679f89e9dba67784b28,04d7e3d8-af93-497e-9d4b-ecdcdf057f80
$fema_good=false;  //Acadia (Parish)
$parishCounty=strtolower($parishCounty);
foreach($html as $line){
if($i>=1){
$u = explode(",",$line); 
 $line=strtolower($line);

 $pos = strpos($line, $parishCounty);
 if($pos){  
  //print "\n-$u[19]-$parishCounty-$femaArea $u[6] $u[7]\n";
  $femaY=$u[5];
  $femaType=$u[6];$femaType=strtolower($femaType);
  $femaDesc=$u[7];
  $femaArea=$u[19];
  $fema_good=true;break;
  }
 }
$i++;
 }
}

// NWS Read forcast API ------------------------------------------------
function read_api ($file){
global  $NWheadline,$instruction,$head,$headline,$apiVer,$description,$event,$icon,$shortForcast,$detailedForecast,$url,$data_good,$title,$clear,$file,$out;

$html= file($file); $apiVer="?";$d1=0;$dd1=0;$ddd1=0;$dddd1=0;
$usenextline=false;$pos="";
// new varables make sure they get set
if(!isset($NWheadline)){   $NWheadline ="";}
if(!isset($instruction)){ $instruction ="";}

foreach($html as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$len= strlen($line);
//  "icon": "https://api.weather.gov/icons/land/night/tsra_hi,30/sct?size=medium",   might contain a comma
$pos = strpos($line, 'icon":');  // "icon": "https://api.weather.gov/icons/land/day/tsra_hi,20?size=medium",
if ($pos) {
     $test = trim($line," "); 
     $Lpos = strpos($test, ':');;$Rpos = strpos($test, '",');
     $icon  = substr($test, $Lpos+3, ($Rpos-$Lpos)-3);
     $icon  = str_replace('size=medium', 'size=small', $icon);// Redirect to the smaller icons  small medium and large avalable
//   print "$icon";
}

 //               "status": "Actual",
 //               "messageType": "Alert",
 //               "category": "Met",
 //               "severity": "Moderate",
 //               "certainty": "Likely",
 //               "urgency": "Expected",
 //               "event": "Heat Advisory",
 //               "sender": "w-nws.webmaster@noaa.gov",
 //               "senderName": "NWS New Orleans LA",
 //               "headline": "Heat Advisory issued July 21 at 10:22AM CDT until July 22 at 7:00PM CDT by NWS New Orleans LA",
 //               "description": "* WHAT...Heat index values up to 112 degrees expected.\n\n* WHERE...Portions of southeast Louisiana and southern Mississippi.\n\n* WHEN...Until 7 PM CDT this evening and again from 10 AM to 7 PM\nCDT Tuesday.\n\n* IMPACTS...Hot temperatures and high humidity may cause heat\nillnesses.",
 //               "instruction": "Drink plenty of fluids, stay in an air-conditioned room, stay out of\nthe sun, and check up on relatives and neighbors.\n\nTo reduce risk during outdoor work, the Occupational Safety and\nHealth Administration recommends scheduling frequent rest breaks in\nshaded or air conditioned environments. Anyone overcome by heat\nshould be moved to a cool and shaded location. Heat stroke is an\nemergency! Call 9 1 1.",
 //               "response": "Execute",
 //               "NWSheadline": [
 //               "HEAT ADVISORY REMAINS IN EFFECT UNTIL 7 PM CDT THIS EVENING... ...HEAT ADVISORY IN EFFECT FROM 10 AM TO 7 PM CDT TUESDAY"
 //               ],

$pos = strpos($line, '"NWSheadline":');
if($pos){$usenextline=true;continue;}
if($usenextline) {
     $NWheadline2 = $line; $dddd1++;
     $NWheadline2 = str_replace('"', "", $NWheadline2);
     $NWheadline2 = str_replace(',', "", $NWheadline2);// just in case TWS breaks things with ,
     $NWheadline2 = trim($NWheadline2," ");
     if($NWheadline2 and $NWheadline){
     $NWheadline ="$NWheadline|$NWheadline2";
     $NWheadline2="";
     }
     else {$NWheadline="$NWheadline2";}

    $usenextline=false;
    continue;
     }  




$pos = strpos($line, '"headline":'); // "headline": "Heat Advisory issued June 25 at 4:22AM CDT until June 25 at 7:00PM CDT by NWS Shreveport LA",
if ($pos) {
     $test = $line; $ddd1++;
     $Lpos = strpos($test, ':');$Rpos = strlen($test) ;// $Rpos = strpos($test, '",');
     $headline2 = substr($test, $Lpos+3,($Rpos-$Lpos)-1);
     $headline2 = str_replace(',', "", $headline2);// just in case TWS breaks things with ,
     $headline2 = trim($headline2," ");
     if($headline2 and $headline){
//     $headline ="$headline,$headline2";
     $headline ="$headline|$headline2";
     $headline2="";
     }
     else {$headline="$headline2";}
     }    
   
$line = str_replace('"', "", $line);     
    
$pos = strpos($line, 'event:'); //  "event": "Heat Advisory",
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ',');
     $event2 = substr($test, $Lpos+2,($Rpos-$Lpos)-2);
     if($event2 and $event){
     $event ="$event,$event2";// stacks events
     $event2="";
     }
     else {$event=$event2;}
     }
$pos = strpos($line, 'forecast:');  //forecast": "https://api.weather.gov/gridpoints/SHV/128,37/forecast",
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, 'http');$Rpos = strpos($test, 'cast,');
     $url  = substr($test, $Lpos,($Rpos-$Lpos)+4);
     }
$pos = strpos($line, 'shortForecast:');  
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ',');
     $shortForcast  = substr($test, $Lpos+2,($Rpos-$Lpos)-2);
     $shortForcast = str_replace(',', "", $shortForcast);// just in case TWS breaks things with ,
     $shortForcast = trim($shortForcast," ");
     }

$pos = strpos($line, 'version:'); //"@version": "1.1",   API still shows 1.1 but may change to 1.2
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ',');
     $apiVer  = substr($test, $Lpos+2, $len-2);
     $apiVer = str_replace(',', "", $apiVer); // just in case TWS breaks things with ,
     }     
$pos = strpos($line, 'detailedForecast:'); // "detailedForecast": "Mostly sunny, with a high near 94. Northeast wind 0 to 10 mph."
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ',');
     $detailedForecast = substr($test,$Lpos+2, $len-2);
     $detailedForecast = str_replace(',', "", $detailedForecast);// just in case TWS breaks things with ,
     $detailedForecast = trim($detailedForecast," ");
     }    

$pos = strpos($line, 'description:');  // "description": "* WHAT...Heat index 
if ($pos) {
     $test = $line;$dd1++;
     $Lpos = strpos($test, ':');$Rpos = strlen($test) ;// $Rpos = strpos($test, '",');
     $description2 = substr($test, $Lpos+2,($Rpos-$Lpos)-1);
     $description2 = str_replace(',', "", $description2);// just in case TWS breaks things with ,
     $description2 = trim($description2," ");
     // stack into an array
     if($description2 and $description){
      $description ="$description|$description2";
      $description2="";
     }
     else {$description="$description2";}
     } 
// instruction
// "instruction": "For your protection move to an interior room on the lowest floor of a\nbuilding.",
$pos = strpos($line, 'instruction:');  // "description": "* WHAT...Heat index 
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, ':');$Rpos = strlen($test) ;// $Rpos = strpos($test, '",');
     $instruction2 = substr($test, $Lpos+2,($Rpos-$Lpos)-1);
     $instruction2 = str_replace(',', "", $instruction2);// just in case TWS breaks things with ,
     $instruction2 = trim($instruction2," ");
     // stack into an array
     if($instruction2 and $instruction){
      $instruction ="$instruction|$instruction2";
      $instruction2="";
     }
     else {$instruction="$instruction2";}
     } 


// stop here dont read past today 
$pos = strpos($line, 'number: 2,');if ($pos) { break;} 
 }
 

 
}

// NWS forcast next x events
// Day names added since this is fluid and changes Its not always the next 7 days
function build_week ($file){
global $debug,$iconWeek,$forcastWeek,$nameWeek;
$forcastWeek="";$nameWeek="";$iconWeek="";$testI="";
$testI= file($file); 
foreach($testI as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);

$pos = strpos($line, 'name":');  //"name": "Tonight",
if ($pos) {
     $test = trim($line," "); $len= strlen($test);
     $Lpos = strpos($test, ':');;$Rpos = strpos($test, '",');
     $nameIt  = substr($test, $Lpos+3, ($Rpos-$Lpos)-3);
     if($nameIt and $nameWeek){
     $nameWeek ="$nameWeek|$nameIt";// stacks a week 
     $nameIt="";
     }
     else {$nameWeek=$nameIt;}
     }

//  "icon": "https://api.weather.gov/icons/land/night/tsra_hi,30/sct?size=medium",   might contain a comma
$pos = strpos($line, 'icon":');  // "icon": "https://api.weather.gov/icons/land/day/tsra_hi,20?size=medium",
if ($pos) {
     $test = trim($line," "); $len= strlen($test);
     $Lpos = strpos($test, ':');;$Rpos = strpos($test, '",');
     $icon2  = substr($test, $Lpos+3, ($Rpos-$Lpos)-3);
     $icon2  = str_replace('size=medium', 'size=small', $icon2);// Redirect to the smaller icons  small medium and large avalable
//     print "$icon2|";
     if($icon2 and $iconWeek){
     $iconWeek ="$iconWeek|$icon2";// stacks a week of icons into array use | not ,
     $icon2="";
     }
     else {$iconWeek=$icon2;}
     }
$line = str_replace('"', "", $line);        
     
//"detailedForecast": "Mostly clear, with a low around 76. South wind 5 to 10 mph."
$pos = strpos($line, 'detailedForecast:');   
if ($pos) {
     $test = $line;   $len=strlen($test); // print "$test\n";
     $Lpos = strpos($test, ':');$Rpos = strpos($test, '}');
     $forcast = substr($test, $Lpos+2,$len); if($debug){print "$forcast\n";}
     $forcast = str_replace(',', "", $forcast);// just in case TWS breaks things with ,
     $forcast = trim($forcast," ");
      if($forcastWeek and $forcast){
     $forcastWeek ="$forcastWeek|$forcast";// stacks a week into array use | not ,
     $forcast="";
     }
     else {$forcastWeek=$forcast;}
     }
  }
}





//   Pull the Forcast URL from the NWS geocoded report ------------------------
function read_api_url ($file){
global $url,$data_good,$file;
$data_good=false;
if (file_exists($file)){
$html= file($file); 
foreach($html as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$len= strlen($line);
$line = str_replace('"', "", $line);     
$pos = strpos($line, 'forecast:');  //forecast": "https://api.weather.gov/gridpoints/SHV/128,37/forecast",
if ($pos) {
     $test = $line;
     $Lpos = strpos($test, 'http');$Rpos = strpos($test, 'cast,');
     $url  = substr($test, $Lpos,($Rpos-$Lpos)+4);
     break;
     }
  }
 }
}



// NWS Read the new API current weather -----v2---------------------------------------------------------
function read_NWS ($file) {
global $CurrTimeR,$CurrTimeMi,$CurrTimeHr,$CurrTime,$CurrTimeD,$CurrTimeM,$CurrTimeY;
global $textDescription,$f,$dateReading,$timeReading,$sitename,$data_good ;
global $CurrTimeHr,$CurrTime,$CurrTimeD,$CurrTimeM,$CurrTimeY,$html;
global $outhumi,$barometricPressure,$barometricPressureABS;
global $stationID,$uv,$solarradiation;
global $outtemp,$outtempC,$heatIndex,$WindChill,$feelsLike,$dewpoint;
global $rainofdaily,$rainofmonthly,$rainofyearly;
global $avgwind,$gustspeed,$maxdailygust,$winddir;

$WindChill="";$heatIndex="";$outtemp="";$outtempC="";$feelsLike="";$dewpoint=""; 
$outhumi="";$barometricPressure="";$uv="";$solarradiation=""; $barometricPressureABS="";
$rainofdaily="";$rainofmonthly="";$rainofyearly="";
$avgwind="";$gustspeed="";$maxdailygust="";
$textDescription=""; $i=0;
$data_good = false;
$temp=false;$dew=false;$speed=false;$gust=false;$hum=false;$chill=false;$heat=false;$rain1=false;$rain3=false; $rain6=false;$press=false;$pressSEA=false;$dir=true;
$html= file($file); 
foreach($html as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$len= strlen($line);// $value2="";
//"textDescription": "Clear",
$pos = strpos($line, 'textDescription":'); 
if ($pos) {
     $test = $line; 
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ','); 
     $value2 = substr($test, $Lpos+2,($Rpos-$Lpos)-2);
     $value2 = str_replace(',', "", $value2);
     $value2 = str_replace('"', "", $value2);
     $value2 = trim($value2," ");
     $textDescription=$value2; 
} 

$pos = strpos($line, 'temperature":');                if($pos){$temp    =true;continue;}
$pos = strpos($line, 'dewpoint":');                   if($pos){$dew     =true;continue;}
$pos = strpos($line, 'windSpeed":');                  if($pos){$speed   =true;continue;}
$pos = strpos($line, 'windGust":');                   if($pos){$gust    =true;continue;}
$pos = strpos($line, 'relativeHumidity":');           if($pos){$hum     =true;continue;}
$pos = strpos($line, 'windChill":');                  if($pos){$chill   =true;continue;}
$pos = strpos($line, 'heatIndex":');                  if($pos){$heat    =true;continue;}
$pos = strpos($line, 'precipitationLastHour":');      if($pos){$rain1   =true;continue;} 
$pos = strpos($line, 'precipitationLastHour3Hours":');if($pos){$rain3   =true;continue;}
$pos = strpos($line, 'precipitationLastHour6Hours":');if($pos){$rain6   =true;continue;}
$pos = strpos($line, 'barometricPressure":')         ;if($pos){$press   =true;continue;}
$pos = strpos($line, 'seaLevelPressure":')           ;if($pos){$pressSEA=true;continue;}
$pos = strpos($line, 'windDirection":');              if($pos){$dir     =true;continue;}

$pos = strpos($line, 'value":'); 
if ($pos) {
     $test = $line; 
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ','); // "value": null,
     $value2 = substr($test, $Lpos+2,($Rpos-$Lpos)-2);
     $value2 = str_replace(',', "", $value2);
     $value2 = trim($value2," ");
  if ($value2=="null"){// its null start over
  $value2="";
  $temp=false;$dew=false;$speed=false;$gust=false;$hum=false;$chill=false;$heat=false;$rain1=false;$rain3=false; $rain6=false;$press=false;$pressSEA=false;$dir=true;
  continue;
  }

$f="";
if($temp and !$outtemp){celsius_to_fahrenheit($value2);$outtemp=$f;$outtempC=number_format($value2, 2);$data_good = true;$temp=false;continue;}
if($dew  and !$dewpoint){celsius_to_fahrenheit($value2);$dewpoint=$f;$dew=false;continue;}
if($chill and !$WindChill){celsius_to_fahrenheit($value2);$WindChill=$f;$chill=false;continue;} 
if($heat and !$heatIndex){celsius_to_fahrenheit($value2);$heatIndex=$f;$heat=false;continue;}


if($speed and !$avgwind ){$avgwind=number_format($value2, 2);$speed=false;continue;}
if($gust and !$gustspeed ){$gustspeed=number_format($value2, 2);$gust=false;continue;} 
if($dir and !$winddir ){$winddir=$value2;$dir=false;continue;} 

if($hum and !$outhumi ){$outhumi=number_format($value2, 2);$hum=false;continue;}
if($rain1 and !$rainofdaily ){$rainofdaily=$value2;$rain1=false;continue;}
if($rain3 and !$rainofdaily ){$rainofdaily=$value2;$rain3=false;continue;}
if($rain6 and !$rainofdaily ){$rainofdaily=$value2;continue;}
if($press and !$barometricPressureABS ){$mb = $value2 * 0.00029529980164712; $barometricPressureABS=number_format($mb, 2);$press=false;continue; }
if($pressSEA and !$barometricPressure  ){$mb = $value2 * 0.00029529980164712; $barometricPressure=number_format($mb, 2);$pressSEA=false;continue; }
}
 } // end for
 
if (!$outtemp){$data_good = true;}

// fix the heat index values 
if (!$heatIndex > $outtemp+10) { $heatIndex=""; }
if (!$WindChill < $outtemp-10) { $WindChill=""; }

       
}

function celsius_to_fahrenheit($in){ 
global $f;
    $f=$in*9/5+32; 
    $f=number_format($f, 2);
}

// OLD code to be removed as soon as im sure its not still in core code
// Now reading the entire data not just the temp.

// OLD to be removed
function read_ambient_api_temp ($file){
global $outtemp,$data_good,$file,$html;
$data_good = false;$outtemp="";$temp=false;$i=0;
if (file_exists($file)){  // protection
$html= file($file); 
foreach($html as $line){$line = str_replace('"', "", $line);$u = explode(",",$line);}

while($i < count($u)){
$u2 = explode(":",$u[$i]);
if($u2[0]=="tempf"){$outtemp=$u2[1];$data_good=true;}    
$i++;
 }
if($outtemp){$data_good=true;}  
 }
}

// This is OLD and to be removed
// NWS Read the temp from API current weather-
function read_api_temp ($file){
global $outCtemp,$data_good,$file;
$temp=false; $data_good=false;
if (file_exists($file)){
$html= file($file); 
foreach($html as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);

$line = str_replace('"', "", $line);
 
//"temperature": {
//            "unitCode": "wmoUnit:degC",
//            "value": 22.300000000000001, 
//print "--$line\n";
$pos = strpos($line, 'temperature:');      if ($pos) {$temp=true;}
   
$pos = strpos($line, 'value'); 
if ($pos) {
     $test = $line; 
     $Lpos = strpos($test, ':');$Rpos = strpos($test, ','); // "value": null,
     $value2 = substr($test, $Lpos+2,($Rpos-$Lpos)-2);
     $value2 = str_replace(',', "", $value2);
     $value2 = trim($value2," ");
    
     if ($value2=="null"){$value2="";}
//     print "$value2\n";
     
// which one to put it in  $avgwind,$gustspeed
if($temp) {
if ($value2){
$outCtemp=$value2;$data_good = true;}

$temp=false;
    }
   }
  }
 }
}



