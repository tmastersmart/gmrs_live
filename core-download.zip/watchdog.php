<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
// module can not be called direct
// v1 8/19/2023 
// v1.1 09/27/2023 run reg check even if net is down. 2nd temp file added to prevent cross.
// v1.2 10/02/2023 Added support for running offline and not getting alerts.
// v1.3 10/22/2023 Extra sleep added ... Removed code to set port back to defalt. Move to setup later
// v1.4 10/24/23 No longer check the port on run. 

//must be called after a read event to set network access flag.

include_once ("$path/check_reg.php");  // functions
$outTmp    ="/tmp/tmp-reg.wav";if (file_exists($outTmp)) {unlink($outTmp);}
$outTmp2   ="/tmp/tmp-net.wav";if (file_exists($outTmp2)){unlink($outTmp2);}
$datum   = date('m-d-Y H:i:s'); 
print "$datum Running Watchdog module:\n";

// We must have internet 
if ($counterNet <=2){ 
$action="";
// Check the reg
reg_check ("check");// $node1 $ip $port2 $registered
if($registered !="Registered"){
watchdog ("reg");// add to counter
check_gsm_db ("an-error-has-occured");if($file1){$action = "$action $file1";}
check_gsm_db ("node");if($file1){$action = "$action $file1";} 
$oh=false;
$x = (string)$node;
for($i=0;$i<strlen($x);$i++)
{ 
make_number ($x[$i]);$action = "$action $actionOut"; //say the numbers one at a time not as a set 
}

//  "Auth. Sent"  "Registered"    rejected: 'Registration Refused' // Request,Auth.,
$pos1 = strpos("-$registered", 'Unregistered');if($pos1){check_gsm_db ("is-not-registered");if($file1){$action = "$action $file1";}}
$pos1 = strpos("-$registered", 'Refused');     if($pos1){check_gsm_db ("is-rejected");      if($file1){$action = "$action $file1";}}
$pos1 = strpos("-$registered", 'Auth');        if($pos1){check_gsm_db ("connecting");       if($file1){$action = "$action $file1";}}
$pos1 = strpos("-$registered", 'Request');     if($pos1){check_gsm_db ("not-yet-connected");if($file1){$action = "$action $file1";}} 
$file = $outTmp;
exec ("sox $action $file",$output,$return_var);
$datum   = date('m-d-Y H:i:s');
print "$datum Playing file $file\n";
$status= exec("sudo asterisk -rx 'rpt localplay $node /tmp/tmp'",$output,$return_var);
sleep(3);
}

if ($registered =="Registered"){watchdog ("okreg");}






// counter is set by watchdog function in load.php file 
if($counter >$watchdog and $NotReg and $counterNet <1 ){reg_fix ("check");}


// if we are registered check which port we are on.
//if(!$NotReg){
//$port = find_port ("find");if ($port != "4569"){  $out="Port $port in use"; save_task_log ($out);print "$datum $out\n"; }
 // check the working port -- Put it back to default on next reboot
 // This is disabled for now. We will take care of this in setup later
 // Problem is the port can get blocked and stay blocked.
 //$newPort=4569; rotate_port("rotate");
// }
//$out="We are online"; save_task_log ($out);print "$datum $out\n";// Yep I fixed it. 
// }
 
}// end if net up

// If the net is down warn about it
// ($linkcheck allows running offline and not getting warnings)
if ($counterNet >=2 and $LinkCheck<>0){
$action="";
$out="Network Error we are offline"; 
save_task_log ($out);print "$datum $out\n";
check_wav_db ("strong click"); if($file1){$action = "$action $file1";}
check_gsm_db ("an-error-has-occured");if($file1){$action = "$action $file1";}
check_gsm_db ("net down");if($file1){$action = "$action $file1";} 
//check_gsm_db ("sorry2");if($file1){$action = "$action $file1";}

$file = $outTmp2;
exec ("sox $action $file",$output,$return_var);
$datum   = date('m-d-Y H:i:s');
print "$datum Playing file $file\n";
$status= exec("sudo asterisk -rx 'rpt localplay $node /tmp/tmp'",$output,$return_var);
sleep(3); 
}



















?>
