<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
// lsnodes replacement for GMRS... 

// Load nodelist for the onscreen display 
print"<!-- start nodelistCache -->\n";
$nodelistClean = "/etc/asterisk/local/mm-software/nodelist/clean.csv";// Cleaned up nodelist 
$OurNodeCache  = "/tmp/our-nodes-cache.csv";
if (file_exists($OurNodeCache)) {$file= $OurNodeCache;print"\n<!-- Using Nodelist Cache -->\n";}
else {$file=$nodelistClean;print"\n<!-- Using Full Nodelist -->\n";}

$astdb = array();  
if (file_exists($file)) {
 $fileIN= file($file); 
 foreach($fileIN as $line){
  $line = str_replace("\r", "", $line);
  $line = str_replace("\n", "", $line);
 $arr = preg_split("/\|/", trim($line)); print"<!-- $line -->\n";
 $astdb[$arr[0]] = $arr;
 } 
}


// Build a local cache  (This process saves 32mb of memory on every page load.) 
// A limited small Cache  is created on each bootup and used to display our nodenames on the status page.
//print"<!-- ";print_r($config);print "-->";

$count=count($nodes); $Cache=""; // $config[$node]
$OurNodeCache = "/tmp/our-nodes-cache.csv";
if (!file_exists($OurNodeCache)) {
print"\n<!-- building the nodelistCache -->\n";
//if ($count>0) {
   foreach ($nodes as $nodex) {
    if (isset($astdb[$nodex])){ 
     $Cache = "$Cache" . $astdb[$nodex][0] ."|". $astdb[$nodex][1]."|". $astdb[$nodex][2] ."|". $astdb[$nodex][3] ."|\n"; // Get from full nodelist
     }
  }  
 $fileOUT = fopen($OurNodeCache,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$Cache );flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
// }
}

?>

