<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
//
// Imports changes from the webserver into the cli program.
// v1 beta 12/17/23


$basename=basename($_SERVER['PHP_SELF']);


$path  = "/etc/asterisk/local/mm-software"; 
$fileWEB="/tmp/setup.txt";  // We have full permission
$fileSET="$path/setup.txt"; // We have full permissions
$path4 = "$path/backup";

if (is_readable($fileWEB)) { // We have a save to import
// First make a backup
$datum = date('m-d-Y-H:i:s');
if(!is_dir($path4)){ mkdir($path4, 0755);}
$file = $fileSET;$dow = date('w');$fileBU = "$path4/setup.txt.$dow";
if (file_exists($file)){
if (file_exists($fileBU)){unlink($fileBU);}
copy($file, $fileBU); $status ="Backup settings to $fileBU";save_task_log ($status); 
print"$datum $status\n";
}// end backup

// Now copy in the new settings
$datum = date('m-d-Y-H:i:s');
$file = $fileWEB;
$fileBU = $fileSET;
if (file_exists($file)){
if (file_exists($fileBU)){unlink($fileBU);}
copy($file, $fileBU); $status ="Merging in new settings";
if (file_exists($fileBU)){unlink($file);}
else {
$status="$status [error]";
// Something went wrong try to recover the setup from the backup
$fileBU = "$path4/setup.txt.$dow";
if (file_exists($fileBU)){
if (!file_exists($file)){copy($fileBU, $file); $status ="$setatus [Restoring]";}
 }
} // its bad atempt recover

save_task_log ($status); 
print"$datum $status\n";
 } // end import
}// end

?>

