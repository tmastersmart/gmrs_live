<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
//
// Imports changes from the webserver editor into the system
// Edits the config files. Some changes will requre a manual reboot
// 
// v1 beta 12/17/23
// v1.1 12/27/23  Import replace (imports setup.txt file but makes no changes to cong)
// v1.2 1/2/24  Total rewrite. Better import. editing of conf files added
// v1.3 1/5/24 Bug fix on ID not seeing CALL
// v1.4 1/6/24 Added  $brokenBridge
// v1.5 1/7/24 Fixed ID swapping
// v1,6 1/10  bug fix in short call.
// v1.7 1/13 Bug in using $ok varable. Fixed failed to import bug
// v1.8 1/21/24 doc route added
// v1.9 1/25 bug in $docRouteP save fixed. new var for global $levelForcast,$levelDew,$levelRain,$levelPress,$levelUvi;
// v2.0 2/4/24 Startup node number was not being merged unless was turned on or off 
// v2.1 2/4 timeout timmer added
// v2.2 2/6 bug in merge input

$basename=basename($_SERVER['PHP_SELF']);
$path  = "/etc/asterisk/local/mm-software"; 
$fileWEB="/tmp/setup.txt";  // We have full permission
$fileSET="$path/setup.txt"; // We have full permissions
$path4 = "$path/backup";
$in="";$out="";$call="";

include_once ("$path/load.php");      // settings .. Functions

$file= "$path/mm-node.txt"; 
if(file_exists($file)){
$line = file_get_contents($file);
$u= explode(",",$line);
$AutoNode=$u[0];$call=$u[1];$autotts=$u[2];
}

if (is_readable($fileWEB)) { // We have a save to import
 load_new($in);
 if($ok){save_new($in);}
 else { $status ="Failed to import changes";save_task_log ($status);print"$datum $status\n";}
}

if (file_exists($fileWEB)){unlink($fileWEB);}// make sure its gone



// No import exist so exit
//---------------------------------------end------------------------------

//this is my own editor to search and replace
// v2.0 7/28/2023
// v2.1 9/20/2023 Only save the first found line
// $search=search for line  $in=change to $fileEdit=file   out $ok=true 
// $hide=true; $changeall=true;
function edit_config($in){ 
global $search,$path,$fileEdit,$ok,$hide,$changeall,$call;



if(!$hide){print "Search for $search in file:$fileEdit ";}
$ok=false;$line="";
if (file_exists($fileEdit)){
$fileBu = "$fileEdit-.bak"; if (!file_exists($fileBu)){copy($fileEdit,$fileBu);} // This creates a orginal backup

// create a backup about once a day
$fileBu = "$fileEdit-1.bak"; 
if (file_exists($fileBu)){
 $ft = time()-filemtime($fileBu);
 if ($ft < 24 * 3600){  unlink ($fileBu);}
 } 
if (!file_exists($fileBu)){copy($fileEdit,$fileBu);} // working backup  $fileBu = "$fileEdit-1.bak"; 


if(!file_exists($fileBu)and !$hide){ print "Unable to BackUP.";}
$tmpFile="$fileEdit-new.txt"; // keep in the same dir so we wont have to copy

$fileIN= file($fileEdit);
$fileOUT = fopen($tmpFile, "w") or die ("Error $tmpFile Write falure");
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", $search); 
if ($pos>=1){ 


if (!$ok){
$line=$in;$ok=true;
if(!$hide){print"$line Replacing with $in <ok>"; } // Replace the found line with a new one.
 }// only change the first found line
 
if ($ok and $changeall) {
$line=$in;$ok=true; // replace all of the found lines
if(!$hide){print"$line Replacing with $in <ok>"; } // Replace the found line with a new one.
} 
 
 
}// pos  
fwrite ($fileOUT, "$line\n");
}

fclose ($fileOUT);
// if ok then we found it
if ($ok){
 if (file_exists($tmpFile)){ unlink($fileEdit);} 
 rename ($tmpFile, $fileEdit); 
 save_task_log ("Edit $fileEdit search:$search");
} // rename
else{if(!$hide){print "not found";} }
   
} //file exist
// try to prevent stray data
save_task_log ("Edit $fileEdit ($in)");
$fileEdit="";$search="";print"\n";
}


function search_config($out){ 
global $search,$path,$fileEdit,$ok,$out,$hide,$call;

if(!$hide){print "Search for $search in file:$fileEdit ";}
$ok=false;$line="";
if (file_exists($fileEdit)){
$fileIN= file($fileEdit);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
//print "$line\n";
$pos = strpos("-$line", $search);  
if ($pos>=1){
$out=$line;//print "$line - $search - $out\n"; 
$ok=true;if(!$hide){print"found $out\n";}
break;}
 }
}// end if exists
else {print"File Not Found $fileEdit\n";}

if(!$hide){
 if (!$ok){print"not found $search\n";}
 }
}



function load_new($in){
global $parishCounty,$fema,$startUp,$startUpNode,$burst,$DisplayNodes,$name,$city,$state,$phpzone,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start;
global $Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$bridgeCheck,$autotts,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$LinkCheck,$beta,$saveDate,$path,$hideIP;
global $idType,$ambientApiKey,$node,$station,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog;
global $inTone,$outToneL,$outToneU,$bridgeMonitor,$banner,$banner,$Fheader,$ok,$in;
global $search,$fileEdit,$hide,$call,$brokenBridge,$NodePassword,$docRouteP;
global $level,$levelForcast,$levelDew,$levelRain,$levelPress,$levelUvi,$levelTemp,$levelCond,$levelHum,$levelWind,$tot,$blipVerts ;   

$Fheader=""; $fileWEB="/tmp/setup.txt";$changeall=false; $ok=false;
  
if (is_readable($fileWEB)) {
   $fileIN= file($fileWEB);
   
   foreach($fileIN as $line){
    $u = explode(",",$line);
           $Fheader =  $u[0];
// now used as a protection header ="MMSOFTWARE"
// If it doesnt exist we dont import
   if($Fheader=="MMSOFTWARE"){
             $node  =  $u[1];
          $station  =  $u[2];
             $level =  $u[3];
         $zipcode   =  $u[4];
         $IconBlock =  $u[5];
               $lat =  $u[6];
               $lon =  $u[7];
           $sayWarn =  $u[8];
          $sayWatch =  $u[9];
       $sayAdvisory = $u[10];
      $sayStatement = $u[11];
        $sleep      = $u[12];
              $high = $u[13]; 
               $hot = $u[14];
          $nodeName = $u[15];
         $reportAll = $u[16];
//        $saveDate = $u[17];
         $LinkCheck = $u[18]; 
              $beta = $u[19];
          $watchdog = $u[20];
             $debug = $u[21];
               $tts = $u[22];  
       $bridgeCheck = $u[23]; 
       $MuteNet1    = $u[24]; 
       $MuteNet2    = $u[25];
       $MuteNet3    = $u[26];
       $Net1Start   = $u[27];
       $Net1Stop    = $u[28];
       $Net2Start   = $u[29];
       $Net2Stop    = $u[30]; 
       $Net3Start   = $u[31];
       $Net3Stop    = $u[32];
       $DisplayNodes= $u[33];
       $burst       = $u[34];
       
$rpi="/etc/asterisk/rpt.conf"; $hide=false;       
// phase 1 import changes
     if($startUp<>$u[35] or $startUpNode <> $u[36]){ // Changes must be made to rpt.conf
       $startUp     = $u[35];
       $startUpNode = $u[36];
       if($startUp){
        $fileEdit=$rpi;$search="startup_macro_delay";edit_config("startup_macro_delay=90");  //  dns updates
        $fileEdit=$rpi;$search="startup_macro";      edit_config("startup_macro = *73$startUpNode");
       }
       else{
        $fileEdit=$rpi;$search="startup_macro_delay";edit_config(";startup_macro_delay=90");
        $fileEdit=$rpi;$search="startup_macro";      edit_config(";startup_macro = *73$startUpNode");
       }
 
 }       
      $parishCounty = $u[37];
       $fema        = $u[38];
      $ambientApiKey= $u[39];
             $hideIP= $u[40];
            
// Phase 2 import

// 0) no id
// 1) Voice/Morse Voice ID fall back to morse [$call] 
// 2) Morse [$call]
// 3) Morse/ Short Morse  Morse [$call] fall back to short morse [$call3]
// 4) Short Morse [$call3]
// 5) MDC1200 burst 
// 6) Voice/Morse Voice ID fall back to short morse [$call3]  


if($idType<>$u[41]){
   $idType= $u[41];
   $call3 = substr($call, -3);  // creats the short ID last 3 digits
   if ($idType ==0 or $idType ==5){
   $in=";idtalkover =|iDE $call  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idtalkover";edit_config($in);
   $in=";idrecording=|iDE $call  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=|";edit_config($in);
   $in=";idrecording=/etc/asterisk/local/myid  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=/";edit_config($in);
   }
   if ($idType ==1){
   $in="idtalkover =|iDE $call  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idtalkover";edit_config($in);
   $in=";idrecording=|iDE $call  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=|";edit_config($in);
   $in="idrecording=/etc/asterisk/local/myid  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=/";edit_config($in);
   }
   if ($idType ==2){
   $in=";idtalkover =|iDE $call  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idtalkover";edit_config($in);
   $in="idrecording=|iDE $call  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=|";edit_config($in);
   $in=";idrecording=/etc/asterisk/local/myid  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=/";edit_config($in);
   }   
   if ($idType ==3){
   $in="idtalkover =|iDE $call3  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idtalkover";edit_config($in);
   $in="idrecording=|iDE $call   ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=|";edit_config($in);
   $in=";idrecording=/etc/asterisk/local/myid  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=/";edit_config($in);
   }

   if ($idType ==4){
   $in=";idtalkover =|iDE $call  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idtalkover";edit_config($in);
   $in="idrecording=|iDE $call3  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=|";edit_config($in);
   $in=";idrecording=/etc/asterisk/local/myid  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=/";edit_config($in);
  }
   if ($idType ==6){
   $in="idtalkover =|iDE $call3  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idtalkover";edit_config($in);
   $in=";idrecording=|iDE $call  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=|";edit_config($in);
   $in="idrecording=/etc/asterisk/local/myid  ; installed by node manager option $idType";   $fileEdit=$rpi;$search="idrecording=/";edit_config($in);
   }
}

$toneChange=false;
// Phase 3 import
if($inTone <> $u[42]){
   $inTone= $u[42]; $toneChange=true;
   if ($inTone){
    $in=";linkunkeyct=ct8 ; sent when a network user unkeys - installed by node manager";    $fileEdit=$rpi;$search="linkunkeyct";edit_config($in);
   }             
   else{
   $in="linkunkeyct=ct8 ; sent when a network user unkeys - installed by node manager";   $fileEdit=$rpi;$search="linkunkeyct";edit_config($in);
   }
}
// Phase 4 import
if($outToneL <> $u[43]){
   $outToneL= $u[43];$toneChange=true;
   if ($inTone){
    $in=";remotect=ct3 ; Sent when remote base connected - installed by node manager";    $fileEdit=$rpi;$search="remotect";edit_config($in);
   }             
   else{
   $in="remotect=ct3 ; Sent when remote base connected - installed by node manager";   $fileEdit=$rpi;$search="remotect";edit_config($in);
   }
  }
  
// phase 5 import  
if($outToneU <> $u[44]){
   $outToneU= $u[44];$toneChange=true;  
$in=";unlinkedct=ct2 ; Sent when not connected to another node - installed by node manager";$fileEdit=$rpi;$search="unlinkedct";edit_config($in);
$in="unlinkedct=ct2 ; Sent when not connected to another node - installed by node manager"; $fileEdit=$rpi;$search="unlinkedct";edit_config($in);
}  
  


// if all tones disabled set the flag  
if ($toneChange){
 if (!$inTone and !$outToneL and !$outToneU){
  $fileEdit=$rpi;$search="nounkeyct=1";search_config("null");
 if(!$ok){$in="nounkeyct=1; Disable courtest tones (=1) - installed by node manager";$fileEdit=$rpi;$search="nounkeyct";edit_config($in);}
 }
 
 else { // make sure the flag is off
 $fileEdit=$rpi;$search="nounkeyct=0";search_config("null");
 if(!$ok){ $in="nounkeyct=0; Disable courtest tones (=1) - installed by node manager"; $fileEdit=$rpi;$search="nounkeyct";edit_config($in); }
 }  
}             
           

      $bridgeMonitor= $u[45];  
             $banner= $u[46];
      $brokenBridge = $u[47]; 
      $NodePassword = $u[48];
            
     if($docRouteP <> $u[49]){$docRouteP = $u[49];} // We may lock this...
       $levelForcast= $u[50];//new levels  
       $levelDew    = $u[51];
       $levelRain   = $u[52];
       $levelPress  = $u[53];                 
       $levelUvi    = $u[54];// new levels
       $levelTemp   = $u[55];                 
       $levelCond   = $u[56];// new levels 
       $levelHum    = $u[57];      
       $levelWind   = $u[58];

if(!isset($tot)){$tot=120000;} 
      
       if($tot <> $u[59]){
       $tot= $u[59];
       $fileEdit=$rpi;$search="rx_timeout=";edit_config("rx_timeout=$tot;  Set by node manager");  
       $fileEdit=$rpi;$search="tx_timeout=";edit_config("tx_timeout=$tot;  Set by node manager");
       }
       $blipVerts  = $u[60];       
        
       
       
       
     $ok=true;// This must be true if passes test   
             
    } // if header is ok
  } // foreach
 } // if readable
}
//------------------------------



function save_new($in){
global $parishCounty,$fema,$startUp,$startUpNode,$burst,$DisplayNodes,$name,$city,$state,$phpzone,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start;
global $Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$bridgeCheck,$autotts,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$LinkCheck,$beta,$saveDate,$path,$hideIP;
global $idType,$ambientApiKey,$node,$station,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog;
global $inTone,$outToneL,$outToneU,$bridgeMonitor,$banner,$Fheader,$brokenBridge,$NodePassword,$docRouteP;
global $level,$levelForcast,$levelDew,$levelRain,$levelPress,$levelUvi,$levelTemp,$levelCond,$levelHum,$levelWind,$tot,$blipVerts;

$datum = date('m-d-Y-H:i:s');
$path4 = "$path/backup";if(!is_dir($path4)){ mkdir($path4, 0755);}
$file = "$path/setup.txt";$dow = date('w');$fileBU = "$path4/setup.txt.$dow";
if (file_exists($file)){
if (file_exists($fileBU)){unlink($fileBU);}
copy($file, $fileBU); $status ="Backup settings to $fileBU";save_task_log ($status); 
print"$datum $status\n";
} 

$fileOUT = fopen("$path/setup.txt", "w");
$status ="Writing settings";save_task_log ($status);
print "$datum $status\n";

// fix varables problem true/false for the webserver (Get rid of blank varables)
if(!$IconBlock){$IconBlock=0;}//5
if(!$sayWarn){$sayWarn=0;}//8
if(!$sayWatch){$sayWatch=0;}//9
if(!$sayAdvisory){$sayAdvisory=0;}//10
if(!$sayStatement){$sayStatement=0;}//11
if(!$sleep){$sleep=0;}//12
if(!$reportAll){$reportAll=0;}//16 
if(!$LinkCheck){$LinkCheck=0;}//18 
if(!$beta){$beta=0;}  // 19
if(!$debug){$debug=0;} // 23
if(!$bridgeCheck){$bridgeCheck=0;} //24        
if(!$MuteNet1){$MuteNet1=0;} //24 
if(!$MuteNet2){$MuteNet2=0;} //25
if(!$MuteNet3){$MuteNet3=0;} //26
if(!$DisplayNodes){$DisplayNodes=0;} //33
if(!$startUp){$startUp=0;} //35
if(!$hideIP){$hideIP=0;} //40
if(!$idType){$idType=0;} //41
if(!$bridgeMonitor){$bridgeMonitor=0;} //45
if(!$brokenBridge){$brokenBridge=0;} //47
if(!$levelForcast){$levelForcast=0;} 
if(!$levelDew){    $levelDew=0;} 
if(!$levelRain){   $levelRain=0;} 
if(!$levelPress){  $levelPress=0;} 
if(!$levelUvi){    $levelUvi=0;} 
if(!$levelTemp){   $levelTemp=0;} 
if(!$levelCond){   $levelCond=0;}
if(!$levelHum){    $levelHum=0;} 
if(!$levelWind){   $levelWind=0;} 
if(!$tot){$tot=120000;} 
if(!$blipVerts){   $blipVerts=0;}
fwrite ($fileOUT, "MMSOFTWARE,$node,$station,$level,$zipcode,$IconBlock,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$sleep,$high,$hot,$nodeName,$reportAll,$datum,$LinkCheck,$beta,$watchdog,$debug,$tts,$bridgeCheck,$MuteNet1,$MuteNet2,$MuteNet3,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$DisplayNodes,$burst,$startUp,$startUpNode,$parishCounty,$fema,$ambientApiKey,$hideIP,$idType,$inTone,$outToneL,$outToneU,$bridgeMonitor,$banner,$brokenBridge,$NodePassword,$docRouteP,$levelForcast,$levelDew,$levelRain,$levelPress,$levelUvi,$levelTemp,$levelCond,$levelHum,$levelWind,$tot,$blipVerts,,,,,,,,");
fclose ($fileOUT);
}




?>

