<?php
// (c)2023 by WXRB288 lagmrs.com  by pws.winnfreenet.com
// data file loader module..

// v4.8 10/14/23  FEMA and abmbent updates.
// v4.8.1  Changes to log
// v4.9   Total system upgrade many changes
// v5.0   Hide ip at boot up added
// v5.1  11/05/23 Log file rotation and restart adjustments
// v5.2  11/08/23 ID type setting added
// v5.3  12/17/23 Bridging monitor setting added
// v5.5  12/23/23 Major update changes to cron loader required update
// v5.6  1/2/24  Minor changes for the new year
// v5.7  1/6/24  Option to turn of broken bridge detection for tx t la
// v6.1  1/25 new var for global $levelForcast,$levelDew,$levelRain,$levelPress,$levelUvi;
// v6.2   2/4 added timeout timer
include ("$path/tagline.php");
// $tagline="";tagline($tagline);print "$tagline (Have many nice days.)";
  
$coreVersion = "v6.2"; // This is our system version we compair against

$basename=basename($_SERVER['PHP_SELF']);

load("load");
$logRotate = 40000;// size to rotate at
$piVersion = file_get_contents ("/proc/device-tree/model");

// Get php timezone in sync with the PI
$phpzone = date_default_timezone_get(); 

$line =	exec('timedatectl | grep "Time zone"'); //       Time zone: America/Chicago (CDT, -0500)
$line = str_replace(" ", "", $line);
$pos1 = strpos($line, ':');$pos2 = strpos($line, '(');
if ($pos1){  $zone   = substr($line, $pos1+1, $pos2-$pos1-1); }
else {$zone="America/Chicago";}

if ($phpzone <> $zone){define('TIMEZONE', $zone);date_default_timezone_set(TIMEZONE);}

$phpzone = date_default_timezone_get(); // test it 
if ($phpzone == $zone ){$phpzone=$phpzone;}
else{$phpzone="$phpzone ERROR";}


function load($in){
global $parishCounty,$fema,$startUp,$startUpNode,$burst,$DisplayNodes,$name,$city,$state,$phpzone,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start;
global $Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$bridgeCheck,$autotts,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$LinkCheck,$beta,$saveDate,$path,$hideIP;
global $idType,$ambientApiKey,$node,$station,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog;
global $inTone,$outToneL,$outToneU,$bridgeMonitor,$banner,$Fheader,$brokenBridge,$NodePassword,$docRouteP;
global $level,$levelForcast,$levelDew,$levelRain,$levelPress,$levelUvi,$levelTemp,$levelCond,$levelHum,$levelWind,$tot;

if (is_readable("$path/setup.txt")) {
   $fileIN= file("$path/setup.txt");
   foreach($fileIN as $line){
    $u = explode(",",$line);
           $Fheader =  $u[0];// now used as a protection header ="MMSOFTWARE"
             $node  =  $u[1];
          $station  =  $u[2];
             $level =  $u[3];
         $zipcode   =  $u[4];
         $IconBlock =  $u[5];
               $lat =  $u[6];
               $lon =  $u[7];
           $sayWarn =  $u[8];
          $sayWatch =  $u[9];
       $sayAdvisory = $u[10];
      $sayStatement = $u[11];
             $sleep = $u[12];
              $high = $u[13]; 
               $hot = $u[14];
          $nodeName = $u[15];
         $reportAll = $u[16];
          $saveDate = $u[17];
         $LinkCheck = $u[18];
              $beta = $u[19];
          $watchdog = $u[20];
             $debug = $u[21];
               $tts = $u[22];   
       $bridgeCheck = $u[23];
       $MuteNet1    = $u[24]; 
       $MuteNet2    = $u[25];
       $MuteNet3    = $u[26];
       $Net1Start   = $u[27]; 
       $Net1Stop    = $u[28];
       $Net2Start   = $u[29];
       $Net2Stop    = $u[30]; 
       $Net3Start   = $u[31];
       $Net3Stop    = $u[32];
       $DisplayNodes= $u[33];
       $burst       = $u[34];
       $startUp     = $u[35];
       $startUpNode = $u[36];
       $parishCounty= $u[37];
       $fema        = $u[38];
      $ambientApiKey= $u[39]; 
            $hideIP = $u[40];
             $idType= $u[41];
             $inTone= $u[42];
           $outToneL= $u[43];
           $outToneU= $u[44];
      $bridgeMonitor= $u[45];
             $banner= $u[46];   
      $brokenBridge = $u[47];
      $NodePassword = $u[48]; 
         $docRouteP = $u[49];
// Auto upgrade from older versions
$levelForcast=true;if(isset($u[50])){$levelForcast= $u[50];}//new levels  
$levelDew=false;   if(isset($u[51])){$levelDew    = $u[51];}
$levelRain=true;   if(isset($u[52])){$levelRain   = $u[52];}
$levelPress=true;  if(isset($u[53])){$levelPress  = $u[53];}                 
$levelUvi=false;   if(isset($u[54])){$levelUvi    = $u[54];}
$levelTemp=true;   if(isset($u[55])){$levelTemp   = $u[55];}                 
$levelCond=true;   if(isset($u[56])){$levelCond   = $u[56];}         
$levelHum=true;    if(isset($u[57])){$levelHum    = $u[57];}
$levelWind=true;   if(isset($u[58])){$levelWind   = $u[58];} 
 
$tot=120000;if(isset($u[59])){$tot=$u[59];} // tx_timeout=180000 rx_timeout=120000                                             


}
    
    
// fix true/false conversion from webserver to console problems
// Thsi may not need this but the webserver saves as 0 bit blank.
if($IconBlock==0){    $IconBlock=false;}//5
if($sayWarn==0){      $sayWarn=false;}//8
if($sayWatch==0){     $sayWatch=false;}//9
if($sayAdvisory==0){  $sayAdvisory=false;}//10
if($sayStatement==0){ $sayStatement=false;}//11
if($sleep==0){        $sleep=false;}//12
if($reportAll==0){    $reportAll=false;}//16 
if($LinkCheck==0){    $LinkCheck=false;}//18 
if($beta==0){         $beta=false;}  // 19
if($debug==0){        $debug=false;} // 23
if($bridgeCheck==0){  $bridgeCheck=false;} //24        
if($MuteNet1==0){     $MuteNet1=false;} //24 
if($MuteNet2==0){     $MuteNet2=false;} //25
if($MuteNet3==0){     $MuteNet3=false;} //26
if($DisplayNodes==0){ $DisplayNodes=false;} //33
if($startUp==0){      $startUp=false;} //35
if($hideIP==0){       $hideIP=false;} //40
if($idType==0){       $idType=false;} //41
if($bridgeMonitor==0){$bridgeMonitor=false;} //45
if($brokenBridge==0){ $brokenBridge=false;} //47    
if($levelForcast==0){$levelForcast=false;} 
if($levelDew==0){    $levelDew=false;} 
if($levelRain==0){   $levelRain=false;} 
if($levelPress==0){  $levelPress=false;} 
if($levelUvi==0){    $levelUvi=false;} 
if($levelTemp==0){   $levelTemp=false;} 
if($levelCond==0){   $levelCond=false;} 
if($levelHum ==0){   $levelHum =false;} 
if($levelWind ==0){  $levelWind=false;}

}
else{
print "
==================================================================
Missing settings.txt file, load setup program to create one!
php setup.php
";die;}
}




function formatBytes($size, $precision = 2)
{
    $base = log($size, 1024);
    $suffixes = array('B', 'KB', 'MB', 'GB', 'TB');   

    return round(pow(1024, $base - floor($base)), $precision) . $suffixes[floor($base)];
}


// v2.1  dupe in setup.php 
function save_task_log ($status){
global $basename,$path,$error,$datum,$logRotate;

// $logRotate = 40000;// size to rotate at set at top

$datum  = date('m-d-Y H:i:s');
if(!is_dir("$path/logs/")){ mkdir("$path/logs/", 0755);}
chdir("$path/logs");
$log="$path/logs/log.txt";
$log2="$path/logs/log2.txt"; 


// log rotation system 
// To be replaced with daily logs....   
if (is_readable($log)) {
   $size= filesize($log);
   if ($size > $logRotate){
    if (file_exists($log2)) {unlink ($log2);}
    rename ($log, $log2);
    if (file_exists($log)) {print "error in log rotation";}
   }
}

if (!file_exists($log)) {$fileOUT = fopen($log, 'w') ;flock ($fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,Start log,$basename,,,\r\n");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);}

if (is_writeable($log)) {
 $fileOUT = fopen($log, 'a+') ;flock ($fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,$status,$basename,,,\r\n");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
}
else { 
$log="/tmp/log.txt";// fixes supermon permissions. This is a temp fix
$fileOUT = fopen($log, 'a+') ;flock ($fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,$status,$basename,,,\r\n");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
}

}

//  Watchdog system 
// 
function watchdog ($in){
global $file1,$datum,$soundDbGsm,$node,$datum,$netdown,$NotReg,$action,$status,$counter,$counterNet,$path,$watchdog;
$NotReg=false;$netdown=false;$status="";$counter=0;$counterNet=0;
//if (!isset($watchdog)) {$watchdog =5;}// error checking
// watch the internet okreg oknet net reg
$file= "/tmp/watchdog.txt"; if (file_exists($file)){
$line = file_get_contents($file);
$u= explode(",",$line);
if ($u[0]){$counter  = $u[0];}
if ($u[1]){$counterNet=$u[1];} 
}
if ($in == "okreg"){$counter=0;} // if reg then all is ok
if ($in == "oknet"){$counterNet=0;} // net can be ok and reg bad

if ($in == "net")  {
$counterNet++; $netdown =true;
$status ="WatchDog Counter [net down]: $counterNet $status";save_task_log ($status);print "$datum $status\n";
}
if ($in == "reg")  {
$counter++; $NotReg=true;
$status ="WatchDog Counter [not reg]: $counter $status";save_task_log ($status);print "$datum $status\n";
}
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$counter,$counterNet");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
}



?>
