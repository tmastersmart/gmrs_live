<?php
// (c)2023 by WXRB288 lagmrs.com  by pws.winnfreenet.com
// data file loader module..
// v4.8 10/14/23  FEMA and abmbent updates.
// v4.8.1  Changes to log

include ("$path/tagline.php");// $tagline="";tagline($tagline);print "$tagline (Have many nice days.)";
  
$coreVersion = "v4.8"; // This is our system version we compair against

$basename=basename($_SERVER['PHP_SELF']);

load("load");
$logRotate = 40000;// size to rotate at
$piVersion = file_get_contents ("/proc/device-tree/model");

// Get php timezone in sync with the PI
$phpzone = date_default_timezone_get(); 

$line =	exec('timedatectl | grep "Time zone"'); //       Time zone: America/Chicago (CDT, -0500)
$line = str_replace(" ", "", $line);
$pos1 = strpos($line, ':');$pos2 = strpos($line, '(');
if ($pos1){  $zone   = substr($line, $pos1+1, $pos2-$pos1-1); }
else {$zone="America/Chicago";}

if ($phpzone <> $zone){define('TIMEZONE', $zone);date_default_timezone_set(TIMEZONE);}

$phpzone = date_default_timezone_get(); // test it 
if ($phpzone == $zone ){$phpzone=$phpzone;}
else{$phpzone="$phpzone ERROR";}


function load($in){
global $ambientApiKey,$parishCounty,$fema,$startUp,$startUpNode,$coreVersion,$burst,$DisplayNodes,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$MuteNet1,$MuteNet2,$MuteNet3,$tts,$sleep,$IconBlock,$debug,$AutoNode,$datum,$LinkCheck,$beta,$saveDate,$path,$node,$station,$level,$zipcode,$skywarn,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$high,$hot,$nodeName,$reportAll,$watchdog,$bridgeCheck;

if (is_readable("$path/setup.txt")) {
   $fileIN= file("$path/setup.txt");
//$datum = date('m-d-Y-H:i:s');
//print "$datum Loading settings
//";
   foreach($fileIN as $line){
    $u = explode(",",$line);
//            $path =  $u[0];// basicaly a header
             $node  =  $u[1];
          $station  =  $u[2];
             $level =  $u[3];
         $zipcode   =  $u[4];
         $IconBlock =  $u[5];
               $lat =  $u[6];
               $lon =  $u[7];
           $sayWarn =  $u[8];
          $sayWatch =  $u[9];
       $sayAdvisory = $u[10];
      $sayStatement = $u[11];
             $sleep = $u[12];
              $high = $u[13]; 
               $hot = $u[14];
          $nodeName = $u[15];
         $reportAll = $u[16];
          $saveDate = $u[17];
         $LinkCheck = $u[18];
              $beta = $u[19];
          $watchdog = $u[20];
             $debug = $u[21];
               $tts = $u[22];   
       $bridgeCheck = $u[23];
       $MuteNet1    = $u[24]; 
       $MuteNet2    = $u[25];
       $MuteNet3    = $u[26];
       $Net1Start   = $u[27]; 
       $Net1Stop    = $u[28];
       $Net2Start   = $u[29];
       $Net2Stop    = $u[30]; 
       $Net3Start   = $u[31];
       $Net3Stop    = $u[32];
       $DisplayNodes= $u[33];
       $burst       = $u[34];
       $startUp     = $u[35];
       $startUpNode = $u[36];
       $parishCounty= $u[37];
       $fema        = $u[38];
      $ambientApiKey= $u[39];                 
    }
}



else 
{print "
==================================================================
Missing settings.txt file, load setup program to create one!

php setup.php
";
die;
 }
}




function formatBytes($size, $precision = 2)
{
    $base = log($size, 1024);
    $suffixes = array('B', 'KB', 'MB', 'GB', 'TB');   

    return round(pow(1024, $base - floor($base)), $precision) . $suffixes[floor($base)];
}


// v2 stop using $file confusion  
function save_task_log ($status){
global $basename,$path,$error,$datum,$logRotate;

// $logRotate = 40000;// size to rotate at set at top

$datum  = date('m-d-Y H:i:s');
if(!is_dir("$path/logs/")){ mkdir("$path/logs/", 0755);}
chdir("$path/logs");
$log="$path/logs/log.txt";
$log2="$path/logs/log2.txt"; 


// log rotation system 
// To be replaced with daily logs....   
if (is_readable($log)) {
   $size= filesize($log);
   if ($size > $logRotate){
    if (file_exists($log2)) {unlink ($log2);}
    rename ($log, $log2);
    if (file_exists($log)) {print "error in log rotation";}
   }
}

if (is_writeable($log)) {
 $fileOUT = fopen($log, 'a+') ;flock ($fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,$status,$basename,,,\r\n");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
}
else { 
unlink ($log);
$fileOUT = fopen($log, 'a+') ;flock ($fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,$status,$basename,,,\r\n");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
}

}

//  Watchdog system 
// 
function watchdog ($in){
global $file1,$datum,$soundDbGsm,$node,$datum,$netdown,$NotReg,$action,$status,$counter,$counterNet,$path,$watchdog;
$NotReg=false;$netdown=false;$status="";$counter=0;$counterNet=0;
if (!isset($watchdog)) {$watchdog =5;}// error checking
// watch the internet okreg oknet net reg
$file= "/tmp/watchdog.txt"; if (file_exists($file)){
$line = file_get_contents($file);
$u= explode(",",$line);
if ($u[0]){$counter  = $u[0];}
if ($u[1]){$counterNet=$u[1];} 
}
if ($in == "okreg"){$counter=0;} // if reg then all is ok
if ($in == "oknet"){$counterNet=0;} // net can be ok and reg bad

if ($in == "net")  {
$counterNet++; $netdown =true;
$status ="WatchDog [net down]: $counterNet $status";save_task_log ($status);print "$datum $status
";
}
if ($in == "reg")  {
$counter++; $NotReg=true;
$status ="WatchDog [not reg]: $counter $status";save_task_log ($status);print "$datum $status
";
}
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"$counter,$counterNet");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
}



?>
