<?php
// (c)2023  lagmrs.com
// Improved faster IP lookup and caching for supermon
// faster loading and no slow shell scripts
// v1 10/23/23
// v1.1 11/28/23
// v1.2 12/17/23    Port change to floating
// v1.3 1/1/24 Add error control to stop error if net down
// v1.3 1/24 Fixed Style problem and cach update bug
$update=true;$ip_cache="/tmp/external_ip.txt";
print "\n<!-- START IP lookup module and port ident -->\n";
$hostname = exec("$HOSTNAME |$AWK -F '.' '{print $1}'"); // "/bin/hostname";
$mylanip= $_SERVER['SERVER_ADDR'];
print "<small>
<span style='margin-top:0px;'>[$hostname][LAN:$mylanip]\n";
if (file_exists($ip_cache)){
$update=false;
 $ft = time()-filemtime($ip_cache); $fth=round($ft /3600); print "<!-- IP lookup $fth hrs ago -->\n";
 if ($ft > 8 * 3600){$update=true;} 
}
// $fth hrs old.

if($upate=true and file_exists($ip_cache)){ 
print "<!-- IP cached -->\n";
$fileIN= file($ip_cache);
foreach($fileIN as $line){
print $line; 
 }
}
else{ 
$myip = @file_get_contents("http://ipecho.net/plain");  // add error control
if($myip ){
 $domain = @gethostbyaddr($myip); 
 
 $out="[IP:$myip = $domain]"; print $out; print "\n<!-- IP lookup cach updated -->\n";
 if (is_writable($ip_cache)) {$fileOUT = fopen($ip_cache,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$out);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);}
}
}
$file="";$out="";// clear varables on exit

// we need to do this by php
$astport = exec("$CAT /etc/asterisk/iax.conf |$EGREP 'bindport' |$SED 's/bindport=//g'");
if($astport<>4569) {
print"</span>
[port:<span style=\"background-color: palegreen; color: black;\">$astport Floating</span>]
</small>";}

else{print"[port:$astport]
</span>
</small>";}
print "\n<!-- END IP lookup module and port ident -->\n\n";
?>
