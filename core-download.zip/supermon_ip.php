<?php
// (c)2023  lagmrs.com
// Improved faster IP lookup and caching for supermon
// faster loading and no slow shell scripts
// v1 10/23/23

print "<!-- IP lookup module -->\n";
$mylanip= $_SERVER['SERVER_ADDR'];
print "<small>[$hostname][LAN:$mylanip]";


$file="/tmp/external_ip.txt";

if (file_exists($file)){
 $ft = time()-filemtime($file); $fth=round($ft /3600); 
 print "<!-- IP lookup $fth hrs ago -->\n";
 if ($ft > 8 * 3600){unlink($file);} 
}
// $fth hrs old.

if(file_exists($file)){
$fileIN= file($file);
foreach($fileIN as $line){
print $line; 
print "<!-- IP lookup cached -->\n";
 }
}
else{ 
$myip = file_get_contents("http://ipecho.net/plain"); // better code
if($myip ){
 $domain = gethostbyaddr($myip); 
 print "<!-- IP lookup cach updated -->\n";
 $out="[IP:$myip = $domain]"; print $out;
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$out);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
 }
}

$file="";$out="";// clear varables on exit

$astport = exec("$CAT /etc/asterisk/iax.conf |$EGREP 'bindport' |$SED 's/bindport=//g'");
if($astport<>4569) {print"[port:<span style=\"background-color: green; color: black;\">$astport</span>]";}
else{print"[port:$astport]";}

?>
