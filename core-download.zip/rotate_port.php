 <?php
//  ------------------------------------------------------------
//  (c) 2023 by lagmrs.com all rights reserved
//  Permission granted to install and use with 
//  hubitat,gmrs,hamvoip.No modifications   
//  https://github.com/tmastersmart/
//
//  This fixes the register problem everyone is having. 
//  Being unable to explain this fix onair I just added it to my software.
//  If you want the fix you have to use my software
//
//  Call this the 'We gonna do what they say can't be done' fix 
//  ------------------------------------------------------------

$datum = date('m-d-Y-H:i:s');
$cur   = date('mdyhis');
srand(time());
$random = rand(4500,4600);   // rand(min,max); 
$savever = true ;

$iax     =  "/etc/asterisk/iax.conf";
$iaxbk   =  "/tmp/iax-$cur.conf";
$iaxtmp  =  "/etc/asterisk/iax-tmp.conf";

$status = "";
chdir("/etc/asterisk");
copy($iax,$iaxbk);if(!file_exists($iaxbk)){ $status="Unable to BackUP.";}


if (file_exists($iax )){
$fileOUT = fopen($iaxtmp, "w");
$fileIN= file($iax);
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$pos = strpos("-$line", "bindport="); 
if ($pos == 1){$status = "$status $line changed to bindport=$random";$line="bindport=$random";}
$pos = strpos("-$line", ";rotate_port"); if ($pos == 1){$line=";rotate_port $datum port:$random";$savever=false;}
fwrite ($fileOUT, "$line\n");
}
 
if($savever){ fwrite ($fileOUT, ";rotate_port $datum port:$random\n"); } 
fclose ($fileOUT);
 
if (file_exists($iaxbk)){ unlink($iax); if (!file_exists($iax)){ rename ($iaxtmp, $iax); }
 else{ $status="$status ERROR can not unlink file $iax";}
}
}
else {$status="Error Missing $iax";}

$datum = date('m-d-Y-H:i:s');
print "$datum $status 
";
save_task_log ($status);

?>
  
