#!/bin/bash
#
# Asterisk Node Configuration  system
#
# updated for 4 digit private nodes Louisiana image.  wrxb288
# Updated to setup the status page dvswitch and node manager 
# 
#
# Modified in acord with GPL (c)2025 by WRXB288
# By GPL for internal org use only not to be distributed.
#
#
# --------------------------------------------------------------------
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see http://www.gnu.org/licenses/.
# ---------------------------------------------------------------------
# Copyright (C)2015/2016 Christopher Kovacs, W0ANM


export SON="setterm --term linux --background blue --foreground white --clear all --cursor on"
export SOFF="setterm --term linux --background blue --foreground white --clear all --cursor off"
export D="dialog --clear "




 # Custom MM Software Version
MM_SOFTWARE_FILE="/etc/asterisk/local/mm-software/version.txt"
if [ -f "$MM_SOFTWARE_FILE" ]; then
    MM_SOFTWARE_VERSION=$(head -1 "$MM_SOFTWARE_FILE" | awk -F ',' '{print "Version: "$1"\nRelease Date: "$2}')
else
    MM_SOFTWARE_VERSION="MM Software Version File Not Found"
fi


# Variables
CONFIGFILE=/usr/local/etc/allstar_node_info.conf
SRCDIR=/usr/local/etc/asterisk_tpl
CONVDIR=/etc/asterisk
SOUNDS=/var/lib/asterisk/sounds
IDFILE=/etc/asterisk/local/node-id
DATE=$(date '+%Y.%m.%d.%H%M')

if [ -f $CONFIGFILE  ] ; then
   source $CONFIGFILE
   UPDATE=yes
else
   UPDATE=no
fi

if [ -f /usr/local/etc/allstar.env ] ; then
    source /usr/local/etc/allstar.env
else
	$SOFF
    $D --title "Error!" --msgbox "Error! Missing Environment file (/usr/local/etc/allstar.env), Aborting..." 10 60
	setterm --reset
    exit
fi

# change variables in file to there value
ConvertFile () {
  file_input=$1
  file_output=$2
  # echo "file_input=$file_input"
  # echo "file_output=$file_output"

  eval "echo \"$( < $file_input)\"" > $file_output
}


# ckyorn function with defaults

ckyorn () {
    return=0
    if [ "$1" = "y" ] ; then
        def="y"
        sec="n"
    else
        def="n"
        sec="y"
    fi
 
    while [ $return -eq 0 ]
    do
        read -e -p "([$def],$sec): ? " answer
        case "$answer" in
                "" )    # default
                        printf "$def"
                        return=1 ;;
        [Yy])   # yes
                        printf "y"
                        return=1
                        ;;
        [Nn] )   # no
                        printf "n"
                        return=1
                        ;;
                   *)   printf "    ERROR: Please enter y, n or return.  " >&2
                        printf ""
                        return=0 ;;
        esac
    done

}
####################################################
# Start
####################################################

# Custom backups / this stops multi backups
# The node manager will create its own backups to auto restore from
# These backups are only to store the last running system 
    cp /etc/asterisk/rpt.conf /etc/asterisk/rpt-old.conf
    cp /etc/asterisk/iax.conf /etc/asterisk/iax-old.conf
    cp /etc/asterisk/extensions.conf /etc/asterisk/extensions-old.conf
    cp /etc/asterisk/manager.conf /etc/asterisk/manager-old.conf
    cp /etc/asterisk/simple_tune_usb.conf /etc/asterisk/simple_tune_usb-old.conf
    cp /etc/asterisk/simpleusb.conf /etc/asterisk/simpleusb-old.conf
    cp /home/gmrs/poll_status.ini /home/gmrs/poll_status-old.ini
    cp /etc/asterisk/local/mm-software/setup.txt /etc/asterisk/local/mm-software/setup-old.txt
    
    
    
# Added tests for additional templates
# WA3DSP 3/2019

if [ -z $RPT_TEMPLATE_FILE ]
    then
      RPT_TXT="rpt.conf_tpl"
    else  
      RPT_TXT=$RPT_TEMPLATE_FILE
    
fi
if [ -z $IAX_TEMPLATE_FILE ]
    then
       IAX_TXT="iax.conf_tpl"
    else
       IAX_TXT=$IAX_TEMPLATE_FILE
fi
if [ -z $EXTENSIONS_TEMPLATE_FILE ]
    then
       EXTENSIONS_TXT="extensions.conf_tpl"
    else
       EXTENSIONS_TXT=$EXTENSIONS_TEMPLATE_FILE
fi

# Check if template files exist
if [ ! -f "$SRCDIR/$RPT_TXT" ]
    then
       TXT2="$SRCDIR/$RPT_TXT "
fi
if [ ! -f "$SRCDIR/$IAX_TXT" ]
    then
       TXT2="$TXT2 $SRCDIR/$IAX_TXT "
fi
if [ ! -f "$SRCDIR/$EXTENSIONS_TXT" ]
    then
       TXT2="$TXT2 $SRCDIR/$EXTENSIONS_TXT"
fi

if [ "$TXT2" != "" ]
     then
        $SOFF
        $D --msgbox "Missing Template file(s) - $TXT2 - cannot continue with setup." 8 78
        setterm --reset
        exit 0
fi

TXT1="{$RPT_TXT - $IAX_TXT - $EXTENSIONS_TXT}"

remain=$((78-${#TXT1}))
pad=$((remain / 2))
TXT1=$(printf "%*s%s" $pad '' "$TXT1")





   
$SOFF
if (! $D --colors --cr-wrap --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION " \
--title "Louisiana Image node setup" --defaultno --no-collapse --yesno \
"Welcome to the new improved node installer. This will set up the node, the status page and dvswitch all in one run.

Node numbers under 9999 are for private nodes. 

You must have your GMRS node number/password ready.
If not go to https://gmrshub.com/ and register.

Do you wish to continue?" 15 60 ) then
    #no
	setterm --reset
    exit 0
fi

return=0
while [ $return -eq 0 ]
do
    $SON
    ANS=$($D --title "Node Number" --nocancel --inputbox "Enter Node Number:"  8 40 "$NODE1" 3>&1 1>&2 2>&3 )
    
    # Debugging output
#    echo "ANS = $ANS"

    # Ensure the loop doesn't run forever
    return=1
done  # <-- This is necessary to close the loop
    
    
    # Validate the node number
    if [[ "$ANS" =~ ^9[0-9]{2}$ ]]; then
        $SOFF
        $D --title "Error" --msgbox "Error: '9xx' numbers are emergency only and not allowed. Please try again." 10 60
        continue
    fi

    
    
# upgraded to more modern code 2/25
#
# This honors the node number request from admin and sets private yes or no
PV_NODE=0
     
if [ "$ANS" = "$NODE1" ] ; then
    NODE1=$ANS
    if [ "$NODE1" -gt 9999 ] ; then  # Direct integer comparison with quotes
        PV_NODE=0
        $D --title "Public Node" --msgbox "This is a public node and will be registered at GMRSHUB." 10 60
    else
        PV_NODE=1
        $D --title "Private Node" --msgbox "This is a private node and will NOT be registered. Private numbers are not recomended since its easy to get a node number in seconds." 10 60
    fi  

    # Ensure PRIVATE_NODE exists in the env file before modifying it
    grep -q "^export PRIVATE_NODE=" /usr/local/etc/allstar.env || echo "export PRIVATE_NODE=" >> /usr/local/etc/allstar.env

    # Save PV_NODE setting
    sed -i "s/^export PRIVATE_NODE=.*/export PRIVATE_NODE=${PV_NODE}/" /usr/local/etc/allstar.env

    # Reload updated settings
    source /usr/local/etc/allstar.env
    break
fi    


DEFAULT_PORT=4569  # Default value
USER_INPUT=$($D --title "Bind Port" --nocancel --inputbox \
"Enter the IAX Bindport (default: $DEFAULT_PORT):" 8 40 "$DEFAULT_PORT" 3>&1 1>&2 2>&3)

# Ensure the variable is not empty
if [ -z "$USER_INPUT" ]; then
    SELECTED_PORT=$DEFAULT_PORT
else
    SELECTED_PORT="$USER_INPUT"
fi


BINDPORT=$SELECTED_PORT



       
STNCALL="GMRS"    
$SON
ANS=$($D --title "Your GMRS FCC Call" --nocancel --inputbox "Enter the node's GMRS FCC Call:" 8 50 "$STNCALL" 3>&1 1>&2 2>&3 )
# Convert input to uppercase
STNCALL="$(echo "$ANS" | tr '[:lower:]' '[:upper:]')"

# If left blank, set a default Morse code ID
if [ -z "$STNCALL" ]; then
    STNCALL="GMRS"  
fi


# Report status to stats.allstarlink.org
# description of report status
#DEFAULT = "--defaultno"
REPORTSTAT=n
# I assume this is handeled later or was removed we dont want stats


# This image will default to morse code for our network standard

VOICEID=n
IDREC="|iDE ${STNCALL}/L"
# this is adjusted by the WEB GUI



# Register (iax.conf)
# NODE1_PW
# NODE1
# BINDPORT
# DUPLEX
# duplex 
if [ -z "$DUPLEX" ] ; then
    DUPLEX=1
fi

$SOFF
ANS=$($D --title "Duplex Setting" --nocancel --default-item "$DUPLEX" --menu  \
"This setting setups up the different duplex modes for your gmrs node.

1 For normal nodes (simplex node).
2 3 or 4 For a repeater depending on conf.

Recomend just select [1].
 
Choose the desired duplex mode:" 22 78 5 \
"0" "half duplex (telemetry and courtesy tones do not transmit)" \
"1" "semi-half duplex (telemetry and courtesy tones transmit" \
"2" "normal full-duplex mode)" \
"3" "full-duplex mode, without repeated audio from main input source" \
"4" "Normal except no main repeat audio during autopatch only" 3>&1 1>&2 2>&3)

DUPLEX=$ANS

# Ensure PV_NODE is set; if not, default to 0
if [ -z "$PV_NODE" ]; then
    PV_NODE=0
fi

# if this is a private node, skip the password
if [ "$PV_NODE" -ne 1 ]; then

    # test password, 6-digit number
    PASSOK=false
     while  [ "$PASSOK" = "false" ] ; do

		$SON
         ANS=$($D --title "Node Password" --nocancel --inputbox \
"The node password is the password that is assigned 
with your node number. At GMRSHUB You must have this now!

Enter Node password for node $NODE1:" 14 60 "$NODE1_PW" 3>&1 1>&2 2>&3)

        # test, if null, use default else check answer
        if [ -z "${ANS}" ] ; then
            break
        elif  [[ ! ${ANS} =~ ^[0-9a-zA-Z]+$ ]] || [ ${#ANS} >= 16 ] ; then
		$SOFF
		$D --title "Password Error" --infobox "Password format is invalid.." 3 34 ; sleep 2
		PASSOK=false
        else
            PASSOK=true
        fi
    done

    if [ -z "$ANS" ] ; then
        NODE1_PW=$NODE1_PW
    else
        NODE1_PW=$ANS
    fi

fi ; # end node password

#iax rpt user info
if [ "$UPDATE" = "yes" ] ; then
   if [ -z "$IAXRPT_PW" ] ; then
       DEFAULT="--defaultno"
   else
       DEFAULT=""
   fi
else
   DEFAULT="--defaultno"
fi


#removed confusing IAX windows client question 2/25
$SOFF
$D --title "Ready to build" --msgbox  "We have enough info to build your node. Lets go." 10 35
IAXRPT=n
IAXRPT_PW=""
# if bindport is null set it to 4569
if [ -z "$BINDPORT" ] ; then
    BINDPORT=4569
fi

echo "NODE1=\"$NODE1\"" > $CONFIGFILE
echo "STNCALL=\"$STNCALL\"" >> $CONFIGFILE
echo "REPORTSTAT=\"$REPORTSTAT\"" >> $CONFIGFILE
echo "BINDPORT=\"$BINDPORT\"" >> $CONFIGFILE
echo "NODE1_PW=\"$NODE1_PW\"" >> $CONFIGFILE
echo "IAXRPT_PW=\"$IAXRPT_PW\"" >> $CONFIGFILE
echo "VOICEID=\"$VOICEID\""  >> $CONFIGFILE
echo "TTS_ID=\"$TTS_ID\""  >> $CONFIGFILE
echo "DUPLEX=\"$DUPLEX\"" >> $CONFIGFILE
echo "IDREC=\"$IDREC\"" >> $CONFIGFILE
echo "TEXTTOCONVERT=\"$TEXTTOCONVERT\"" >> $CONFIGFILE


##############################################################
#           Start of file modification                       #
##############################################################
# first create a header file for template files  and save in /tmp
cat << _EOF > /tmp/tpl_info.txt
; THIS FILE WAS AUTOMATICALLY CONFIGURED BY NODE-CONFIG.SH
; EACH TIME THE SCRIPT IS RUN, THIS FILE WILL BE OVERWRITTEN.
; ===========================================================
_EOF

##############################################################
# rpt.conf
# NODE1;NODE2;STNCALL
# change number 1999 to <nodenumber>
# change WA3ZYZ to <stncall>

# Check allstar.env for possible different setup RPT template file
# WA3DSP 3/2019
if [ -z $RPT_TEMPLATE_FILE ]
    then
        RPT_TMP="rpt.conf_tpl"
    else
        RPT_TMP=$RPT_TEMPLATE_FILE
fi

# then convert the template using ConverFile and save in /tmp 
ConvertFile "$SRCDIR"/$RPT_TMP /tmp/rpt.conf_main

# cat the header file with the converted tpl file and save to 
# "$CONVDIR"/rpt.conf
cat /tmp/tpl_info.txt  /tmp/rpt.conf_main > "$CONVDIR"/rpt.conf

# setup report status

if [ "$REPORTSTAT" = "y" ] ; then
    sed 's/;statpost_/statpost_'/g "$CONVDIR"/rpt.conf > "$CONVDIR"/rpt.conf_1
    mv "$CONVDIR"/rpt.conf_1 "$CONVDIR"/rpt.conf
fi

# ID Change
#$SOFF
#$D --title "Updating Configuration" --msgbox  "rpt.conf completed..." 3 35

# ConvertFile "$SRCDIR"/extensions.conf_tpl "$CONVDIR"/extensions.conf

# Check allstar.env for possible different setup EXTENSIONS template file
# WA3DSP 3/2019
if [ -z $EXTENSIONS_TEMPLATE_FILE ]
    then
        EXTENSIONS_TMP="extensions.conf_tpl"
    else
        EXTENSIONS_TMP=$EXTENSIONS_TEMPLATE_FILE
fi

sed "s/_NODE1_/${NODE1}/g" "$SRCDIR"/$EXTENSIONS_TMP > /tmp/extensions.conf_main

# add the tpl info and conf file
cat /tmp/tpl_info.txt /tmp/extensions.conf_main > "$CONVDIR"/extensions.conf


#$SOFF
#$D --title "Updating Configuration" --msgbox  "extensions.conf completed..." 3 35



# Check allstar.env for possible different setup IAX template file
# WA3DSP 3/2019
if [ -z $IAX_TEMPLATE_FILE ]
    then
        IAX_TMP="iax.conf_tpl"
    else
        IAX_TMP=$IAX_TEMPLATE_FILE
fi

ConvertFile "$SRCDIR"/$IAX_TMP /tmp/iax.conf_main

cat /tmp/tpl_info.txt /tmp/iax.conf_main > "$CONVDIR"/iax.conf

#$SOFF
#$D --title "Updating Configuration" --msgbox  "iax.conf file created and setup" 3 35




##############################################################
# clean up tmp
rm -f /tmp/tpl_info.txt /tmp/extensions.conf_main /tmp/iax.conf_main /tmp/rpt.conf_main

##############################################################
# Setup the allstar.env file
#
# this replaces the export NODE1 line with the new line
sed -i  "s/^export NODE1=.*/export NODE1=${NODE1}/" /usr/local/etc/allstar.env




# Generate a random 10-character password with at least one number
generate_password() {
    local random_password
    random_password=$(head /dev/urandom | tr -dc 'A-Za-z0-9' | head -c 10)

    # Ensure the password contains at least one number
    while ! [[ $random_password =~ [0-9] ]]; do
        random_password=$(head /dev/urandom | tr -dc 'A-Za-z0-9' | head -c 10)
    done

    echo "$random_password"
}




# First file: /etc/asterisk/manager.conf
# Second file: /home/gmrs/poll_status.ini

update_poll_status_ini() {
    local random_password="$1"
    local node_number="$2"  # Accept node number as a parameter
    local file2="/home/gmrs/poll_status.ini"
    
    
    # Recreate the file with the correct format
    cat <<EOF > "$file2"
[$node_number]
host=127.0.0.1:5038
user=admin
passwd=$random_password

; Created by node-config.sh
;
; Beware Changing passwords in admin menus will update this file.
EOF

    local file1="/etc/asterisk/manager.conf"

    # Ensure the manager.conf file exists and the [admin] section is present
    if [[ -f "$file1" ]]; then
        if grep -q "^\[admin\]" "$file1"; then
            # Update the password for the [admin] section
            sed -i "/^\[admin\]/,/^$/s/^secret =.*/secret = $random_password/" "$file1"
        fi
    fi    
}






# Update dvswitch password
update_dvswitch_password() {
    local new_password
    new_password=$(cat /dev/urandom | tr -dc 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789' | head -c 6)

    local DVSWITCH_FILE="/etc/asterisk/iax.conf"
    local STANZA="[dvswitch]"

    if [[ -f "$DVSWITCH_FILE" ]]; then
        awk -v stanza="$STANZA" -v new_password="$new_password" '
            BEGIN { in_stanza = 0 }
            $0 ~ stanza { in_stanza = 1 }
            in_stanza && $0 ~ /^secret=/ { $0 = "secret=" new_password; in_stanza = 0 }
            { print }
        ' "$DVSWITCH_FILE" > "${DVSWITCH_FILE}.tmp" && mv "${DVSWITCH_FILE}.tmp" "$DVSWITCH_FILE"
    fi
}


# Check if PV_NODE is set to 1
if [ "$PV_NODE" -eq 1 ]; then
    IAX_CONF="/etc/asterisk/iax.conf"

    # Silently comment out the line starting with 'register =>', if not already commented
    sed -i '/^\s*register =>/ s/^/; /' "$IAX_CONF"

    # Show a popup warning the user
    dialog --title "Manual Action Required" --msgbox \
    "You need to manually stop the nodelist updater from running in cron, \
as well as disable the DNS download service. No support for stopping this \
on a private node is provided in this version. Contact LAGMRS.com for support.\
Otherwise the node will keep a up to date dns and nodelist." 10 60
fi





    # Generate a random password
    random_password=$(generate_password)

    # Update poll_status.ini
    update_poll_status_ini "$random_password" "$NODE1"

    # Update dvswitch password
    update_dvswitch_password
    
    
 
    
    
#$SOFF
#$D --title "Passwords" --msgbox  "Internal passwords have been randomised for Manager and Dvswitch.. " 10 45


#############################################################
# do a full reset to default on node manager
# Node manager needs to scan the config files to setup
php_file="/etc/asterisk/local/mm-software/firsttime.php"

# Run the PHP script and capture the output
php_output=$(php "$php_file" 2>&1)

# Display the output in a dialog message box
dialog --title "Setting Defaults" --msgbox "$php_output" 15 60

#status page and nodemanager should now be setup 

$SOFF
$D --colors --cr-wrap --backtitle "Louisiana GMRS Image $MM_SOFTWARE_VERSION " \
--title "Finished Main Install" \
--msgbox "The status page has been setup. 
The voice systems and high temp alarms have setup.
Anti bridging system installed and set on.
Error reporting system set on.
Time is on but off at night.

Weather and location set to default. You need to go to the setup in the status admin page and set your local location for the weather system to be correct.

Some of the voice options are turned off until you set your location.

After reboot wait and listen for the IP address and Welcome message from the AI.

Remember to tell your frinds..." 20 60



if [ "${SETUP_SIMPLEUSB,,}" != "disabled" ]; then

    if [ ! -f /tmp/rpt_config.tmp ] ; then
        $SOFF
        while true; do  # Start loop
            CHOICE=$(dialog --title "Simple USB Configuration" --menu \
            "You now will need to review and configure SimpleUSB.
In particular, the 'carrier from' and PTT invert need to be set to match
your radio's polarity. Make sure that COS and PTT are being detected properly.
Choose an option:" 15 75 3 \
        1 "Run Simple Tune Guided Setup Script" \
        2 "Run SimpleUSB-tune-menu (manual)" \
        3 "Leave Settings As Is" 3>&1 1>&2 2>&3)

            case $CHOICE in
                1)
                
                    /usr/local/sbin/simpleusb-config.sh
                    break  # Exit the loop and continue with the script 
                    ;;  # Return to the menu after completion
                2)
                    clear  # Clears the screen before running the setup
                    echo "Starting Simpleusb-tune-menu."
                    echo "Please follow the instructions carefully to configure your radio."
                    sleep 3  # Gives time for user to read the message
                    /sbin/simpleusb-tune-menu
                    break  # Exit the loop and continue with the script
                    ;;  # Return to the menu after completion
                3)
                
                    break  # Exit the loop and continue with the script
                    ;;
                *)
                    echo "Invalid selection, try again."
                    ;;
            esac
        done  # End loop

    fi

fi







$SOFF
# Notify the user about the restart
$D --title "Restart Asterisk" --msgbox \
"We are finished. 
AST needs to restart for changes in settings to be loaded." 10 60

# Restart Asterisk
/usr/local/sbin/astdn.sh >/dev/null 2>&1
sleep 3
/usr/local/sbin/astup.sh >/dev/null 2>&1

setterm --reset
exit #EOF







