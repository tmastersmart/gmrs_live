<?php
// (c)2024/25 by WRXB288 and LAgmrs.com  
// Footer
// 
print "<!-- footer  -->\n";
$dateTime = date("m-d-Y h:i A");
$year= date("Y");
$visitors_online = CountVisitors(); 
if (!isset($verGMRS)){$verGMRS="";}
print "<br><br>";
$louisiana="lo<font color=#FF0000>U</font>i<font color=#FF0000>S</font>i<font color=#FF0000>A</font>na";
print "<table  style=\"border-collapse: collapse\" class=\"footerGrid\" border=0 cellpadding=0 cellspacing=0  width=100%>";
if ($footerHTML){
print "<tr class=\"footer1\"><td>$footerHTML</font></td></tr>\n";}
print "<tr class=\"footer\" ><td><div id=\"timeLine\"><div id=\"cst-time\">$dateTime</div> Visitors Online $visitors_online.</div></td></tr>"; // <div id=\"user-time\"></div>
print "<tr class=\"footer1\"><td id=\"copy\">Status page software made in $louisiana (c)2024/$year LAGMRS.com all rights reserved</td></tr>";
print "</table>";
print "<!-- status page software made in Louisiana (c)2024/$year LAGMRS.com all rights reserved -->\n";
print "</body></html>";



// updated trying to stop error on first load
function CountVisitors() {
global  $visit_count,$visitorsdbfile,$newout;
 $newout=1;$VisitorExpire = 3600; // 60 minutes
//$visitorsdbfile = "/tmp/visitors.db"; // set in config
//$VisitorExpire = 1200; // 20 minutes
//$VisitorExpire = 1500; // 25 minutes
    $cur_ip = $_SERVER['REMOTE_ADDR'];
    $cur_time = time();
    $dbary_new = array();
 if (!file_exists($visitorsdbfile)) { file_put_contents($visitorsdbfile, serialize([])); chmod($visitorsdbfile, 0666); }
 if (is_readable($visitorsdbfile) && is_writable($visitorsdbfile)) {
        $dbary = unserialize(file_get_contents($visitorsdbfile));
        if (is_array($dbary)) {
            foreach ($dbary as $user_ip => $user_time) {
                // Retain entries that are still valid
                if (($user_ip != $cur_ip) && (($user_time + $VisitorExpire) > $cur_time)) {
                    $dbary_new[$user_ip] = $user_time;
                }
            }
        }
    $dbary_new[$cur_ip] = $cur_time;
    $fp = fopen($visitorsdbfile, "w");if ($fp) {fwrite($fp, serialize($dbary_new)); fclose($fp);}
    $newout = count($dbary_new); 
 }
else { file_put_contents($visitorsdbfile, serialize([])); chmod($visitorsdbfile, 0666);}
return $newout;
}

?>
