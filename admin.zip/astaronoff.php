<?php
// (c)2023 by WRXB288 and LAgmrs.com all rights reserved
//
// START STOP RESTART code 
//
// Junked orginal. Totaly new code for 2023.


$path         = "/etc/asterisk/local/mm-software";
include_once ("$path/supermon_input.php");

for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'button')          {  $button  = $fieldValues[$i]; }
}

// Sending on command
// test if on and if not send command
if ($button=="astaron"){
$file="/var/run/asterisk.ctl";
if(!file_exists($file)){Astart($button);}
else {print "<p>asterisk is already running</p>";}
}

// shutdown command
if ($button=="astaroff"){
$file="/var/run/asterisk.ctl";
if(file_exists($file)){Asstop($button);}
else {print "<p>asterisk not running</p>";}
}

// restart command
if ($button=="astreload"){
$file="/var/run/asterisk.ctl";
if(file_exists($file)){Asstop($button);}
Astart($button);
}


function Astop ($in){
exec("sudo /sbin/asterisk -rx 'stop now' ",$output,$return_var); print "<p>Sending Stop asterisk cmd</p>"; sleep(1);
exec("sudo /sbin/killall safe_asterisk",$output,$return_var);    print "<p>Sending Killall safe_asterisk</p>"; sleep(1);
exec("sudo /sbin/killall asterisk",$output,$return_var);         print "<p>Sending Killall asterisk</p>";sleep(1);
exec("sudo /bin/rm -f /var/run/asterisk.ctl /var/run/asterisk.pid",$output,$return_var);print "<p>Clearing run flags for safety</p>";
}

function Astart ($in){
print "<p>Sending Start asterisk cmd</p>";
exec("sudo /usr/sbin/safe_asterisk",$output,$return_var);
}




?>
