<?php
// (c)2015/2023 by The Master lagmrs.com  by pws.winnfreenet.com
// I license you to use this on your copy of this software only.
// File is protected in admin directory no need to check for logoins
//
// 
// v1.1 10/21/23  Extra field added 
// v1.2 11/01/23  

include_once("/srv/http/gmrs/global.php");
include_once("/srv/http/gmrs/common.php"); // BUG fix global and common were being loaded twice on each load slowing down supermon

$fileAllMon = "/srv/http/gmrs/admin/allmon.ini";       
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);// load the now secure file

include("/srv/http/gmrs/header.php"); 
include("/srv/http/gmrs/menu.php"); 





$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_start = $mtime;


include_once ("/srv/http/supermon/input-scan.php");
$log="";
for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'log') {  $log  = $fieldValues[$i]; }
if ($fieldNames[$i] == 'code'){  $code = $fieldValues[$i]; }
}


$fileC ="/var/log/asterisk/connectlog";
$fileE ="/var/log/asterisk/event_log";
$fileQ ="/var/log/asterisk/queue_log";
$fileD ="/var/log/asterisk/debug";
$fileM = $ASTERISK_LOG; ///var/log/asterisk/messages  Defined in common.inc for HUBS
$fileW = $WEB_ACCESS_LOG; // "/var/log/httpd/access_log";
$fileWE= $WEB_ERROR_LOG; // "/var/log/httpd/error_log";
$fileMM ="/etc/asterisk/local/mm-software/logs/log.txt";
$fileMM2 ="/etc/asterisk/local/mm-software/logs/log2.txt";
$fileMCP="/tmp/cpu_temp_log.txt";

if ($log=="connectlog"){$info="Connect Log"   ;  $file=$fileC;}
if ($log=="event_log"){ $info="Event Log"     ;  $file=$fileE;}
if ($log=="messages"){  $info="Messages Log"  ;  $file=$fileM;}
if ($log=="queue_log"){ $info="Queue Log"     ;  $file=$fileQ;}
if ($log=="debug"){     $info="Debug Log"     ;  $file=$fileD;}
if ($log=="web"){       $info="Web Access Log";  $file=$fileW;}
if ($log=="web_error"){ $info="Web Error Log";   $file=$fileWE;}
if ($log=="mmsoftware"){$info="Node Manager Log";$file=$fileMM;}
if ($log=="mmsoftware2"){$info="Node Manager Log Bak";$file=$fileMM2;}
if ($log=="temp"){      $info="CPU Temp Log" ;   $file=$fileMCP;}
if ($log=="jornal"){    $info="Journal" ;     ;}


print"<br>";
print"<html><head>
<title>Asterisk $info</title>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">
<link type=\"text/css\" rel=\"stylesheet\" href=\"/gmrs/supermon.css\">
</head>
<body>";


$codeOut= date('mdY'); 
$menu="<p>";
if(file_exists($fileC)){$menu="$menu [<a href=/gmrs/admin/log.php?log=connectlog&code=$codeOut>Connect</a>]";}
if(file_exists($fileE)){$menu="$menu [<a href=/gmrs/admin/log.php?log=event_log&code=$codeOut>Events</a>]";} 
if(file_exists($fileM)){$menu="$menu [<a href=/gmrs/admin/log.php?log=messages&code=$codeOut>Messages</a>]";} 
if(file_exists($fileQ)){$menu="$menu [<a href=/gmrs/admin/log.php?log=queue_log&code=$codeOut>Queue</a>]";}  
if(file_exists($fileD)){$menu="$menu [<a href=/gmrs/admin/log.php?log=debug&code=$codeOut>Debug</a>]";}
if(file_exists($fileW)){$menu="$menu [<a href=/gmrs/admin/log.php?log=web&code=$codeOut>Web</a>]";}  
if(file_exists($fileWE)){$menu="$menu [<a href=/gmrs/admin/log.php?log=web_error&code=$codeOut>Web Error</a>]";}
$menu="$menu [<a href=/gmrs/admin/log.php?log=jornal&code=$codeOut>Journal</a>]";
$menu="$menu [<a href=/gmrs/admin/log.php?log=mmsoftware&code=$codeOut>Manager</a>]";
$menu="$menu [<a href=/gmrs/admin/log.php?log=mmsoftware2&code=$codeOut>Manager Bak</a>]";
if(file_exists($fileMCP)){$menu="$menu [<a href=/gmrs/admin/log.php?log=temp&code=$codeOut>CPU Temp</a>]";}
$menu="$menu </p>";


//if ($code<>$codeOut){$file="";print"Expired session.";die;}
print "<table border=0 class=gridtable id=AutoNumber1 '> ";  
print "<tr class=\"gColor\"><td colspan=4  align=center><font size=small>$menu</font></td></tr>";
print "<tr class=\"gColor\"><td colspan=4  align=center><font size=small>$info</font></td></tr>";


if ($log=="jornal"){ 

$file="/tmp/journal.txt";
if (is_readable($file)) { unlink ($file);}
$cmd = "$SUDO $JOURNALCTL --no-pager --since \"1 day ago\" | $SED -e \"/sudo/ d\"";
exec("$cmd >$file");


}


if (is_readable($file)) { 
$fileIN= file($file); $i=0;$count=0;
$size=filesize($file);

//if ($size >=2){
foreach($fileIN as $line){ 
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
$i++;$count++;
if ($i == 1){$tr="<tr class=\"tColor\">";}
if ($i == 2){$tr="<tr class=\"wColor\">";$i=0;}
if ($file == $fileMM or $file= $fileMCP){
 $u = explode(",",$line);$d="-";$dd="-";
 if (!empty($u[1])){$d=$u[1];}// error trap
 if (!empty($u[2])){$dd=$u[2];}// error trap
 print "$tr<td>$count</td><td>$u[0]<td>$d</td><td>$dd</td></tr>\n";
 }
else{print "$tr<td>$count</td><td>$line</td><td></td></tr>\n";}
} 

$mtime = microtime();$mtime = explode(" ",$mtime);$mtime = $mtime[1] + $mtime[0];$script_end = $mtime;$script_time = ($script_end - $script_start);$script_time = round($script_time,2);
$datum   = date('m-d-Y H:i:s');

if ($size <=1){ print "<tr class=\"gColor\"><td colspan=4  align=center><font size=small>Sorry that file is empty. It likely cleared on reboot.</font></td></tr>";}

if ($file == $fileMM) {print "<tr class=\"gColor\"><td></td><td>$datum</td><td colspan=2>Total Time to process $script_time Sec</td></tr>\n";}
else{print"<tr class=\"gColor\"><td colspan=5 >Total Time to process $script_time Sec</td></tr>\n";}


print"</table>";       
//}


}
else{print"<br>ERROR: reading $info<br>";}


include("/srv/http/gmrs/footer.php"); 



?>
