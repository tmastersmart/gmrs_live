<?php
// ***************************************************
// (c)2015/2023 by The Master lagmrs.com  by pws.winnfreenet.com
// I license you to use this on your copy of this software only.
// File is protected in admin directory no need to check for logoins
//
// block list editor
// 100% PHP from scratch
// This edits the whitelist or blacklist
// v1 12/31/23  beta version

$verGMRS="v1.1";$releaseGMRS="1/7/2024";$betatest=true;

$in="";$out=""; $remotenode="";$cmd=""; $flag="";

$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
$path  = "/etc/asterisk/local/mm-software";
$datum = date('m-d-Y-H:i:s');
include_once("$rootDir/gmrs/global.php");
include_once("$rootDir/gmrs/common.php"); 

$ASTERISK =	"/usr/bin/asterisk";   
// /usr redirects to /usr/bin on node
$GREP =		"/bin/grep";

$fileAllMon = "$rootDir/gmrs/admin/allmon.ini";       
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);// load the now secure file

include_once ("$path/supermon_input.php");

include_once("$rootDir/gmrs/header.php"); 
include_once("$rootDir/gmrs/menu.php"); 
if(sizeof($fieldNames)>1) {
for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'remotenode'){$remotenode= $fieldValues[$i] ;print "<-- $remotenode -->\n";}
if ($fieldNames[$i] == 'whitelist') {$whitelist = $fieldValues[$i] ;print "<-- $whitelist -->\n";}
if ($fieldNames[$i] == 'blacklist') {$blacklist = $fieldValues[$i] ;print "<-- $blacklist -->\n";}
if ($fieldNames[$i] == 'comment')   {$comment   = $fieldValues[$i] ;print "<-- $comment -->\n";}
if ($fieldNames[$i] == 'cmd')       {$cmd       = $fieldValues[$i] ;print "<-- $cmd -->\n";}//put,del 
}
}
$black="";$white=""; $database="";$status=""; $listType="Restrict";

//$radio=`$GREP -oP '^\s*context\s*=\s*radio-secure' /etc/asterisk/iax.conf`;if ($radio){$listType="Radio Secure";$database="";}

$black=`$GREP -oP '^\s*context\s*=\s*blacklist' /etc/asterisk/iax.conf`; if ($black){$listType="Black List";$database="blacklist";}
$white=`$GREP -oP '^\s*context\s*=\s*whitelist' /etc/asterisk/iax.conf`; if ($white){$listType="White List";$database="whitelist";} //context = radio-secure

print"<!-- $GREP -oP '^\s*context\s*=\s*blacklist' /etc/asterisk/iax.conf | $black-->\n"; 
print"<!-- $GREP -oP '^\s*context\s*=\s*whitelist' /etc/asterisk/iax.conf | $white-->\n";



if($cmd=="put" and $remotenode){
print"<!-- sudo /bin/asterisk -rx \"database put $database $remotenode '$comment'-->\n"; 
$status= exec("sudo /bin/asterisk -rx \"database put $database $remotenode \"$comment\"\" ",$output,$return_var);
}

if($cmd=="del" and $remotenode){
print"<!-- sudo /bin/asterisk -rx \"database del $database $remotenode-->\n"; 
$status= exec("sudo /bin/asterisk -rx \"database put $database $remotenode\" ",$output,$return_var);
}


$list="";
if ($database){
print"<!-- sudo /bin/asterisk -rx \"database show $database -->\n"; 
$list= exec("sudo /bin/asterisk -rx \"database show $database\" ",$output,$return_var);
$flag  ="/tmp/$database.txt"; $fileOUT = fopen($flag,'w');fwrite ($fileOUT,"$list");fclose ($fileOUT);// Saves to a file for debuging
}

print"<image src=/gmrs/images/list.gif align=left><center><font color=GREEN size=6><h1>$listType Editor</h1></font></center></br>";



print"<br><br>";

if($flag){
 foreach($flag as $line){ 
 print "$line\n";
 }
}






if($database){
print"
<div id=\"connect_form\" >
<form method=\"POST\" action=\"/gmrs/admin/edit_list.php\">
<table border=\"0\" cellspacing=\"0\" id=\"AutoNumber1\" align=\"left\" >
<tr>
<td colspan=\"3\" bgcolor=\"#000080\">
<p align=\"center\"><b><font color=\"#FFFFFF\" size=\"4\">Enter Node to add/del</font></b></p>
</td>
</tr>
<tr>
<td colspan=\"2\"> 
<font size=\"2\">Node#</font><input type=\"text\" name=\"remotenode\" size=\"10\" id=\"remotenode\" style=\"margin-top: 10px;\">
<font size=\"2\">Comment#</font><input type=\"text\" name=\"comment\" size=\"10\" id=\"comment\" style=\"margin-top: 10px;\">
<select size=\"1\" name=\"type\">
 <option value=\"\" selected>select</option>
 <option value=\"put\">Add</option>
 <option value=\"del\">Delete</option>
 </select>
 </td>
<td>
<input type=\"submit\" class=\"submit\" value=\"Submit\" name=\"B1\">
</form>
</td>
</tr>
</table>
</div>";
}
else{ 
print"<center><font color=red>Disabled Protected</font> <br><br>
<font color=blue> White/Black list must be unlocked and activated using the<br> 
node manager 'Setup' program from the admin area. Before using this editor.</font></center>
 ";}



include ("$rootDir/gmrs/footer.php");

?>




