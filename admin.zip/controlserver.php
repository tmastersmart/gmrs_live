<?php
include('../amifunctions.inc');

#print_r($_GET);
$node = @trim(strip_tags($_GET['node']));
$cmd = @trim(strip_tags($_GET['cmd']));

// SECURITY FIX by WRXB288 
// Major security problem to have this in webserver root directory.
// With the password exposed.....
// BUG fix this was being loaded twice on each load slowing down supermon
// Load before header.inc so menu.inc will have it.  
$fileAllMon = "/srv/http/supermon/admin/allmon.ini";       
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);// load the now secure file




// Check if node exists in ini
if (!isset($config[$node])) {
    die("Node $node is not in allmon ini file.");
}

// Set up connection
$fp = AMIconnect($config[$node]['host']);
if (FALSE === $fp) {
    die("Could not connect to host.");
}

// Login 
if (FALSE === AMIlogin($fp, $config[$node]['user'], $config[$node]['passwd'])) {
    die("Could not login.");
}

// Substitute node number
$cmdString = preg_replace("/%node%/", $node, $cmd);

// AMI needs an ActionID so we can find our own response
$actionRand = mt_rand(); 
$actionID = 'cpAction_' . $actionRand;

if ((@fwrite($fp,"ACTION: COMMAND\r\nCOMMAND: $cmdString\r\nActionID: $actionID\r\n\r\n")) > 0 ) {
    $rptStatus = AMIget_response($fp, $actionID);
    print "<pre>\n===== $cmdString =====\n";
    print $rptStatus;
    #print "===== end =====\n</pre>\n";
} else {
    die("Get node $cmdString failed!");
}
?>
