<?php 
//
//  AllStarLink/ASL-Supermon is licensed under the GNU General Public License v3.0
//
// https://raw.githubusercontent.com/AllStarLink/ASL-Supermon/develop/LICENSE
// https://github.com/AllStarLink/ASL-Supermon/blob/develop/var/www/html/supermon/link.php
// https://www.gnu.org/licenses/gpl-3.0.en.html
// Modified in acordance with GPL
// include("/srv/http/gmrs/session.inc");

// version 2    release 10-23-23 
// v2.1 11/1/23
// v2.1 12/10/23
// v2.2 12/19/23 Better cach startup
// v2.3 12/27/23  Reformated screens inside table
// v2.7 1/14/24
// v2.9 1/24  Added breakout into box for connect button
// v3 1/26 cleanup link status box HTML fix

$versionL="v3.0";$releaseGMRS="1/26/2024"; $verGMRS=$versionL; $betatest=false;  $pageTitle="Admin Status Page";
$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
$path         = "/etc/asterisk/local/mm-software";  
include_once("$rootDir/gmrs/global.php"); // includes the local settings
include_once("$rootDir/gmrs/common.php"); // includes the main settings
$fileAllMon = "$rootDir/gmrs/admin/allmon.ini";
if (file_exists($fileAllMon)){$config = parse_ini_file($fileAllMon, true);}
else {print	"Couldn't load AllMon Login to admin and run Nodemanager Setup";}
include_once("$rootDir/gmrs/header.php"); 
include_once("$rootDir/gmrs/menu.php"); 
include_once ("$path/supermon_input.php");
$nodes=""; 
for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'nodes')   {  $nodes = $fieldValues[$i]; }
}
$passedNodes = explode(',', @trim($nodes));// for PHP code
$parms = @trim(strip_tags($nodes)); // for java code
if (count($passedNodes) == 0) {die ("Error no node number provided");}
$Displayed_Nodes="999"; $Display_Count=0; $Show_All="1";
// Remove nodes not in our allmon.ini file.
$nodes=array();
foreach ($passedNodes as $i => $node) {
 if (isset($config[$node])) {$nodes[] = $node;} 
 else {print "Warning: Node $node not found in our allmon ini file.";}
}
include("$rootDir/gmrs/link-java.php"); // moved to ext file for easier editing.
include("$path/supermon_display_cache.php");
print"<!-- $ipaddress -->\n";

// create a hub connect field
$nodelistHub = "$path/nodelist/hubs_online.csv";// Cleaned up nodelist
$action2= "<select name=\"T1\" >\n"; 
$randomS = mt_rand(1, 2);
if ($randomS==1){$hub="1195";}
//if ($randomS==2){$hub="2250";}
if ($randomS==2){$hub="700";}
if (file_exists($nodelistHub)) {
 $fileIN= file($nodelistHub); 
 foreach($fileIN as $line){
 $u = explode("|",$line);
 $string=$u[1];  
 if (strtoupper($string) == $string)  {$string=strtolower($string);}// ALL caps fix 
 $string = (strlen($string) > 30) ? substr($string,0,30).'...' : $string;
 if($u[0]==$hub){$action2="$action2 <option style=\"margin-top:10px;\" value=\"$u[0]\" selected>$u[0] $string</option>\n";}   
 else{$action2="$action2 <option style=\"margin-top:10px;\" value=\"$u[0]\">$u[0] $string</option>\n";}
 }
 $action2="$action2 </select>";  
 } 
else{
 print"\n<!--Requesting a nodelist rebuild -->\n";
 $flag  ="/tmp/nodelist_needs_update.txt"; $fileOUT = fopen($flag,'w');fwrite ($fileOUT,"$datum");fclose ($fileOUT);
 $action2="$action2 <option style=\"margin-top:10px;\" value=\"1195\" selected>RoadKill</option></select>\n"; 
}

// Build the local nodelist selection
$count=count($nodes); $action=""; $controlNodes="";
print"\n<!-- Connect form start count:$count-->\n";
if ($count>0) {
  $action= "<select name=\"localnode\" >\n";
        foreach ($nodes as $node) {
        if (isset($astdb[$node])){ $info = $astdb[$node][1] ." ". $astdb[$node][2] ; }
        else{ 
          $info = "Pending";
          if (file_exists($OurNodeCache)){unlink($OurNodeCache);}// Bad reset it.
          }
        $action="$action <option style=\"margin-top:10px;\" value=\"$node\">$node $info</option>\n";
        if (!$controlNodes){$controlNodes="$node";}
        else{$controlNodes="$controlNodes,$node";}
        }
  $action="$action </select>";
}

$count=count($nodes);
print"\n<!-- Connect form start count:$count-->\n";
 if ($count>0) {
 
print"<!-- New Submission form C,CP,D,DA,M,MP,ML,MLP-->
<div id=\"connect_form\" >
<form method=\"POST\" action=\"/gmrs/admin/connect.php\" target=\"_blank\">
<table border=0 cellspacing=2 id=AutoNumber1 align=left >
<tr>
<td> 
<font size=\"2\">Remote Node#</font><input style=\"margin-top:10px;\" type=\"text\" name=\"T1\" size=\"10\" id=\"node\">
  <select size=\"1\" name=\"type\">
  <option value=\"C\" selected>Connect</option>
  <option value=\"CP\">Connect Perm</option>
  <option value=\"M\">Monitor</option>
  <option value=\"MP\">Monitor Perm</option>
  <option value=\"ML\">Monitor Local</option>
  <option value=\"MLP\">Monitor Local Perm</option>
  <option value=\"D\">Disconnect</option>
  <option value=\"DA\">Disconnect ALL</option>
  </select>
</td>
<td>
  $action
</td>
<td>   
<input type=\"hidden\" name=\"nodes\" value=\"$parms\">
<input type=\"submit\" class=\"submit\" value=\"Submit\" name=\"B1\" >
</form></div>
</td>
</tr>
";



print"
<tr>
<td>
<div style=\"border-radius: 10px;\" id=\"connect_form\">
<form method=\"POST\" action=\"/gmrs/admin/connect.php\" target=\"_blank\">
$action2
  <select size=\"1\" name=\"type\">
  <option value=\"C\" selected>Connect</option>
  <option value=\"CP\">Connect Perm</option>
  <option value=\"M\">Monitor</option>
  <option value=\"MP\">Monitor Perm</option>
  <option value=\"D\">Disconnect</option>
  <option value=\"DA\">Disconnect ALL</option>
  </select>
  </td>
<td> 
  $action
  </td>
<td>  
<input type=\"hidden\" name=\"nodes\" value=\"$parms\">
<input type=\"submit\" class=\"submit\" value=\"Submit\" name=\"B2\" >
</form> 

</td></tr></div>


<tr><td colspan=3>
<input type=\"button\" class=\"submit\" Value=\"Control CMDS\" onclick=\"window.open('commands.php?nodes=$controlNodes','Send control','status=no,location=no,toolbar=yes,width=1200,height=550,left=100,top=100')\">  
<input type=\"button\" class=\"submit\" Value=\"Setup Editor\" onclick=\"window.open('setup-edit.php','Setup Editor','status=no,location=no,toolbar=yes,width=1200,height=550,left=100,top=100')\">
<input type=\"button\" class=\"submit\" Value=\"Block List Editor\" onclick=\"window.open('edit_list.php','Block List Editor','status=no,location=no,width=1200,toolbar=yes,height=550,left=100,top=100')\">   
<input type=\"button\" class=\"submit\" Value=\"Connect\" onclick=\"window.open('connect.php?nodes=$controlNodes','Connect','status=no,location=no,width=1200,toolbar=yes,height=550,left=100,top=100')\">   

</td></tr><tr><td colspan=3 align=center>
";






$phpzone = date_default_timezone_get();
//$astport = exec("$CAT /etc/asterisk/iax.conf |$EGREP 'bindport' |$SED 's/bindport=//g'");  // moved to seperate file
//$mgrport = exec("$CAT /etc/asterisk/manager.conf |$EGREP '^port =' |$SED 's/port = //g'"); // dont need to display
// $myssh   = exec("$CAT /etc/ssh/sshd_config |$EGREP '^Port' |$TAIL -1 |$CUT -d' ' -f2");
include_once ("$path/supermon_ip.php"); // Better php code 
//print"[SSh:$myssh]</small>\n";//  [$mgrport]
} #endif (count($nodes) > 0)

print "<br><small>";
$uptime = exec("$UPTIME");  // "/bin/uptime";
$u=explode(",",$uptime);
$myday = date('l jS \of F Y h:i:s A');
if (!isset($u[5])){$u[5]="";}// 0-1 users 2 3 4 5 cores sometimes 5 is not set
print "[TimeZone:$phpzone $myday] [$u[0] $u[1]]<br>[$u[2] $u[3] $u[4] $u[5]";   

include_once ("$path/supermon_temp.php"); // Better php code 
$Cores = `ls /var/lib/systemd/coredump |wc -w`;
if ($Cores == 1) {print "[Core dump: <span style=\"background-color: yellow; color: black;\">&nbsp;$Cores</span>]";}
if ($Cores >= 2) {print "[Core dumps: <span style=\"background-color: red; color: yellow; font-weight: bold;\">&nbsp;$Cores</span>]";}
print"</small>";

// End admin area......=--------------------------------------------------------

print "<!-- start weather ----->\n";include ("$path/supermon_weather.php");
print"</td></tr><tr><td colspan=3 align=center>";
foreach($nodes as $node) {
if (isset($astdb[$node])){ $info = $astdb[$node][1] . ' ' . $astdb[$node][2] . ' ' . $astdb[$node][3]; }
        else{ 
          $info = "Pending";
          if (file_exists($OurNodeCache)){unlink($OurNodeCache);}// Bad reset it.
          }
$nodeURL = "link.php?nodes=$node";$title = "&nbsp; Node:<a href=\"$nodeURL\" target=\"_blank\">$node</a> Info:$info &nbsp;";

if (isset($config[$node]['listenlive'])) {
  $ListenLiveLink = $config[$node]['listenlive'];
  $title .= "<a href=\"$ListenLiveLink\" target=\"_blank\" id=\"lsnodeschart\">Listen Live</a> &nbsp;";
}

//    rColor=darkblue cColor=red bColor=palegreen gColor=lightgray tColor=lemonchiffon lColor=powderblue  <tr class="gColor">    
   
// Dont edit table Java looks for this code (colors are set in java code)
print "\n<!-- Start Nodes table $node-->\n";
print"<table border=0 class=gridtable  id=table_$node>
<colgroup><col span=1> <col span=1><col span=1><col span=1><col span=1><col span=1><col span=1></colgroup>
<thead>
<tr class=\"lColor\"><td colspan=7 align=center>$title</td></tr>
</thead>
<tbody>
<tr><td colspan=\"7\"> &nbsp; Waiting for Client side refreash...</td></tr>
</tbody>
</table>
<br/>";
print "\n<!-- End Nodes table $node-->\n";
}

include ("$path/supermon_lnodes.php");

print"</td></tr></table>";

$verGMRS=$versionL;include("$rootDir/gmrs/footer.php");
 
function Show_help($in){
global $width,$height,$in;
print "<a href=\"#\" onclick=\"window.open('/gmrs/admin/help.php?help=$in', 'Help', 'width=$width,height=$height');\"><img src=\"/gmrs/images/help.gif\"></a>";
}

