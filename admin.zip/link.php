<?php 
//
//  AllStarLink/ASL-Supermon is licensed under the GNU General Public License v3.0
//
// https://raw.githubusercontent.com/AllStarLink/ASL-Supermon/develop/LICENSE
// https://github.com/AllStarLink/ASL-Supermon/blob/develop/var/www/html/supermon/link.php

// https://www.gnu.org/licenses/gpl-3.0.en.html

// Modified in acordance with GPL

// include("/srv/http/gmrs/session.inc");
include("/srv/http/gmrs/global.php");
include("/srv/http/gmrs/common.php"); // BUG fix global and common were being loaded twice on each load slowing down supermon

// SECURITY FIX by WRXB288 
// Major security problem to have this in webserver root directory.
// With the password exposed.....
// BUG fix this was being loaded twice on each load slowing down supermon
// Load before header.inc so menu.inc will have it.  
$fileAllMon = "/srv/http/gmrs/admin/allmon.ini";       
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);// load the now secure file

include("/srv/http/gmrs/header.php"); 
//include("/srv/http/supermon/menu.inc"); 
include("/srv/http/gmrs/menu.php"); 
//error_reporting(E_ALL);
// upgraded to a more modern anti hacker input
$path         = "/etc/asterisk/local/mm-software";
include_once ("$path/supermon_input.php");
//include_once ("input-scan.php");
$nodes="";
for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'nodes')   {  $nodes = $fieldValues[$i]; }
}


$passedNodes = explode(',', @trim($nodes));// for PHP code
$parms = @trim(strip_tags($nodes)); // for java code


if (count($passedNodes) == 0) {die ("Error no node number provided");}

$SUBMITTER = "submit2";


// Added WA3DSP

if (isset($_COOKIE['display-data'])) {
    foreach ($_COOKIE['display-data'] as $name => $value) {
        $name = htmlspecialchars($name);
        switch ($name) {
            case "number-displayed";
               $Displayed_Nodes = htmlspecialchars($value);
               break;
            case "show-number";
               $Display_Count = htmlspecialchars($value);
               break;
            case "show-all";
               $Show_All = htmlspecialchars($value);
               break;
        }
       // echo "$name : $value <br />\n";
    }
}

// Cookie block
if (! isset($Displayed_Nodes)) {$Displayed_Nodes="999";} // If not defined in cookie display all nodes
if ($Displayed_Nodes === "0") { $Displayed_Nodes="999";}
if (! isset($Display_Count)) { $Display_Count=0;} // If not define in cookie display all
if ( ! isset($Show_All)) { $Show_All="1";} // If not defined in cookie show all else omit "Never" Keyed 
// END WA3DSP


// Get GMRSLIVE database file
$db = $ASTDB_TXT;			// Defined in global.inc
$astdb = array();
if (file_exists($db)) {
    $fh = fopen($db, "r");
    if (flock($fh, LOCK_SH)){
        while(($line = fgets($fh)) !== FALSE) {
            $arr = preg_split("/\|/", trim($line));
            $astdb[$arr[0]] = $arr;
        }
    }
    flock($fh, LOCK_UN);
    fclose($fh);
    #print "<pre>"; print_r($astdb); print "</pre>";
}



#print "<pre>"; print_r($config); print "</pre>";
#print "<pre>"; print_r($config[$node]); print "</pre>";

// Remove nodes not in our allmon.ini file.
$nodes=array();
foreach ($passedNodes as $i => $node) {
	if (isset($config[$node])) {
		$nodes[] = $node;
	} else {
		print "Warning: Node $node not found in our allmon ini file.";
	}
}
// when DOM is ready

?>
<script type="text/javascript">

$(document).ready(function() {
  if(typeof(EventSource)!=="undefined") {
		
    // Start SSE 
    var source=new EventSource("/gmrs/server.php?nodes=<?php echo $parms; ?>");
        
    // Fires when node data come in. Updates the whole table
    source.addEventListener('nodes', function(event) {
    //console.log('nodes: ' + event.data);	        
    // server.php returns a json formated string

    var tabledata = JSON.parse(event.data);
    for (var localNode in tabledata) {
        var tablehtml = '';

        // Added WA3DSP
        var total_nodes = 0;
        var shown_nodes = 0;
        var ndisp = <?php echo (int) $Displayed_Nodes ?>;
	ndisp++;
        var sdisp = <?php echo $Display_Count ?>;
        var sall = <?php echo $Show_All ?>;
        // END

	// KB4FXC -- refactored telemetry state logic 10/21/2018

	var cos_keyed = 0;
	var tx_keyed = 0;

        for (row in tabledata[localNode].remote_nodes) {

               if (tabledata[localNode].remote_nodes[row].cos_keyed == 1)
			cos_keyed = 1;

		if (tabledata[localNode].remote_nodes[row].tx_keyed == 1)
			tx_keyed = 1;

	}
//    rColor=darkblue cColor=red bColor=palegreen gColor=lightgray tColor=lemonchiffon lColor=powderblue  <tr class="gColor">
//    p = pink new 
        if (cos_keyed == 0) { 
                if (tx_keyed == 0)
                        tablehtml += '<tr class="gColor"><td colspan="1" align="center">' + localNode + '</td><td colspan="5" align="center" >Idle Waiting for Net or Receiver</td><td align="center" ><div id=\"spinny\"></div></td></tr>';
                else
                        tablehtml += '<tr class="cColor"><td colspan="1" align="center">' + localNode + '</td><td colspan="5" align="center" >PTT-Keyed Transmitting</td><td align="center"><div id=\"spinny\"></div></td></tr>';
        }
        else {
                if (tx_keyed == 0)
                        tablehtml += '<tr class="lColor"><td colspan="1" align="center">' + localNode + '</td><td colspan="6" align="center">COS-Detected</td></tr>';
                else
                        tablehtml += '<tr class="cColor"><td colspan="1" align="center">' + localNode + '</td><td colspan="6" align="center">COS-Detected and PTT-Keyed (Full-Duplex)</td></tr>';
        }

	for (row in tabledata[localNode].remote_nodes) {

            if (tabledata[localNode].remote_nodes[row].info === "NO CONNECTION") {

               tablehtml += '<tr><td colspan="7"> &nbsp; &nbsp; No Connections.</td></tr>';

            } else {

	       nodeNum=tabledata[localNode].remote_nodes[row].node;	
	       if (nodeNum != 1) {

               // ADDED WA3DSP 
               // Increment total and display only requested
               total_nodes++;
               if (row<ndisp) {
                  if (sall == "1" || tabledata[localNode].remote_nodes[row].last_keyed != "Never" || total_nodes < 2) {
                     shown_nodes++;
               // END WA3DSP
        		
//    rColor=darkblue cColor=red bColor=palegreen gColor=lightgray tColor=lemonchiffon lColor=powderblue w=white  <tr class="gColor">
	             if (tabledata[localNode].remote_nodes[row].keyed == 'yes') {
		        tablehtml += '<tr class="rColor">';
	             } else if (tabledata[localNode].remote_nodes[row].mode == 'C') {
		        tablehtml += '<tr class="cColor">';
	             } else {
		        tablehtml += '<tr>';
	             }

	             var id = 't' + localNode + 'c0' + 'r' + row;
	             //console.log(id);
	             tablehtml += '<td id="' + id + '" align="center" class="nodeNum">' + tabledata[localNode].remote_nodes[row].node + '</td>';
            		
	             // Show info or IP if no info
	             if (tabledata[localNode].remote_nodes[row].info != "") {
		     	tablehtml += '<td>' + tabledata[localNode].remote_nodes[row].info + '</td>';
	             } else {
		    	tablehtml += '<td>' + tabledata[localNode].remote_nodes[row].ip + '</td>';
	             }
            	     tablehtml += '<td align="center" id="lkey' + row + '">' + tabledata[localNode].remote_nodes[row].last_keyed + '</td>';
 		     tablehtml += '<td align="center">' + tabledata[localNode].remote_nodes[row].link + '</td>';
	             tablehtml += '<td align="center">' + tabledata[localNode].remote_nodes[row].direction + '</td>';
	             tablehtml += '<td align="right" id="elap' + row +'">' + tabledata[localNode].remote_nodes[row].elapsed + '</td>';
            		
	             // Show mode in plain english
	             if (tabledata[localNode].remote_nodes[row].mode == 'R') {
		      	tablehtml += '<td align="center">Receive Only</td>';
	             } else if (tabledata[localNode].remote_nodes[row].mode == 'T') {
		     	tablehtml += '<td align="center">Transceive</td>';
		     } else if (tabledata[localNode].remote_nodes[row].mode == 'C') {
		    	tablehtml += '<td align="center">Connecting</td>';
	             } else {
		     	tablehtml += '<td align="center">' + tabledata[localNode].remote_nodes[row].mode + '</td>';
	             }
       		     tablehtml += '</tr>';
	          }
        	  //console.log('tablehtml: ' + tablehtml);

                 }  
               }
            }
         }    

      // ADDED WA3DSP
      // START Display node count at the botom 
      // WERXB288 fixed bug no <tr>
         if (sdisp === 1 && total_nodes >= shown_nodes && total_nodes > 0) {
            if (shown_nodes == total_nodes) {
               tablehtml += '<tr class="gColor"><td colspan="7"> &nbsp; &nbsp;' + total_nodes + ' node(s) connected.</td></tr>';
            } else {
               tablehtml += '<tr class="gColor"><td colspan="7"> &nbsp; &nbsp;' + shown_nodes + ' shown of ' + total_nodes + ' nodes connected.</td></tr>';
            }
         }

      // END 

      $('#table_' + localNode + ' tbody:first').html(tablehtml);
    }
});

        
        // Fires when new time data comes in. Updates only time columns
        source.addEventListener('nodetimes', function(event) {
			//console.log('nodetimes: ' + event.data);	        
			var tabledata = JSON.parse(event.data);
			for (localNode in tabledata) {
				tableID = 'table_' + localNode;
				for (row in tabledata[localNode].remote_nodes) {
					//console.log(tableID, row, tabledata[localNode].remote_nodes[row].elapsed, tabledata[localNode].remote_nodes[row].last_keyed);

					rowID='lkey' + row;
					$( '#' + tableID + ' #' + rowID).text( tabledata[localNode].remote_nodes[row].last_keyed );
					rowID='elap' + row;
		 			$( '#' + tableID + ' #' + rowID).text( tabledata[localNode].remote_nodes[row].elapsed );

				}
			}


	                if (spinny == "*") {
                                spinny = "|";
                        } else if (spinny == "|") {
                                spinny = "/";
                        } else if (spinny == "/") {
                                spinny = "-";
                        } else if (spinny == "-") {
                                spinny = "\\";
                        } else if (spinny == "\\") {
                                spinny = "|";
                        } else {
                                spinny = "*";
                        }
                        $('#spinny').html(spinny);
        });
        
        // Fires when connection message comes in.
        source.addEventListener('connection', function(event) {
			//console.log(statusdata.status);
			var statusdata = JSON.parse(event.data);
			tableID = 'table_' + statusdata.node;
			$('#' + tableID + ' tbody:first').html('<tr><td colspan="7">' + statusdata.status + '</td></tr>');
		});
		       
    } else {
        $("#list_link").html("Sorry, your browser does not support server-sent events...");
    }
});
</script>


<?php


// ---------------------------------------------------start admin
//if ($_SESSION['sm61loggedin'] === true) {

$count=count($nodes);
print"\n<!-- Connect form start count:$count-->\n";
 if ($count>0) {
 
    if ($count>1) {
        print "<select id=\"localnode\" class=\"submit\">";
        foreach ($nodes as $node) {
        print"\n<!-- node $node -->\n";
        if (isset($astdb[$node])) {$info = "$astdb[$node][1] $astdb[$node][2] $astdb[$node][3]";} // improper formating fixed
        else{$info = "Node not in database";}
        print"<!-- info: $info -->\n";
        print "<option value=\"$node\">$node => $info</option>";
        }
        print "</select>";
    } 
else { print " <input class=\"submit\" type=\"hidden\" id=\"localnode\" value=\"{$nodes[0]}\">"; }

print"\n<!-- Connect form end -->\n";

// This had to all be cleaned up it was a mismatch of patched code not in php
//    <input type=\"button\" class=\"submit\" value=\"Lookup\" id=\"astlookup\">   // removed in favor of my own


print"<div style=\"border-radius: 10px;\" id=\"connect_form\">  
<input style=\"margin-top:10px;\" type=\"text\" id=\"node\"> Permanent <input class=\"submit\" type=\"checkbox\">
<input type=\"button\" class=\"submit\" value=\"Connect\" id=\"connect\">
<input type=\"button\" class=\"submit\" value=\"Disconnect\" id=\"disconnect\">
<input type=\"button\" class=\"submit\" value=\"Monitor\" id=\"monitor\">
<input type=\"button\" class=\"submit\" value=\"Local Monitor\" id=\"localmonitor\">
<br>
<input type=\"button\" class=\"submit2\" value=\"DTMF\" id=\"dtmf\">

<input type=\"button\" class=\"submit2\" value=\"Control\" id=\"controlpanel\">
<input type=\"button\" class=\"submit\" value=\"Favorites\" id=\"favoritespanel\">

<input type=\"button\" class=\"submit\" Value=\"Configuration Editor\" onclick=\"window.open('edit/configeditor.php','ConfigEditor','status=no,location=no,toolbar=no,width=800,height=550,left=100,top=100')\">  
<input type=\"button\" class=\"submit\" Value=\"Display Configuration\" onclick=\"window.open('display-config.php','DisplayConfiguration','status=no,location=no,toolbar=no,width=600,height=550,left=100,top=100')\">
<input type=\"button\" class=\"submit\" value=\"CPU\" id=\"cpustats\">
<input type=\"button\" class=\"submit\" value=\"Status\" id=\"stats\">
<br>
<input type=\"button\" class=\"submit2\" value=\"Iax/Rpt/DP RELOAD\" id=\"astreload\">
<input type=\"button\" class=\"submit2\" value=\"AST START\" id=\"astaron\">
<input type=\"button\" class=\"submit2\" value=\"AST STOP\" id=\"astaroff\"> 
<input type=\"button\" class=\"submit2\" value=\"RESTART\" id=\"fastrestart\">
<input type=\"button\" class=\"submit2\" value=\"Server REBOOT\" id=\"reboot\">
<input type=\"button\" class=\"submit\" value=\"Restrict\" id=\"openbanallow\">
<br>



</div> 
";



$hostname = exec("$HOSTNAME |$AWK -F '.' '{print $1}'"); // "/bin/hostname";


// This is how you do it. Set php to correct time zone
$line =	exec('timedatectl | grep "Time zone"'); //       Time zone: America/Chicago (CDT, -0500)
$line = str_replace(" ", "", $line);
$pos1 = strpos($line, ':');$pos2 = strpos($line, '(');
if ($pos1){  $zone   = substr($line, $pos1+1, $pos2-$pos1-1); }
else {$zone="America/Chicago";}
define('TIMEZONE', $zone);
date_default_timezone_set(TIMEZONE);
$phpzone = date_default_timezone_get();

$astport = exec("$CAT /etc/asterisk/iax.conf |$EGREP 'bindport' |$SED 's/bindport=//g'");
$mgrport = exec("$CAT /etc/asterisk/manager.conf |$EGREP '^port =' |$SED 's/port = //g'");

$file="/tmp/external_ip.txt";  // Improved code for faster loading
if (!file_exists($file)) { 
$myip = file_get_contents("http://ipecho.net/plain"); // better code
//$myip = exec("$WGET -t 1 -T 3 -q -O- http://checkip.dyndns.org:8245 |$CUT -d':' -f2 |$CUT -d' ' -f2 |$CUT -d'<' -f1");
if($myip ){
$domain = gethostbyaddr($myip);
$fileOUT = fopen($file,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,"[IP:$myip = $domain]");flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
 }
}


$myssh = exec("$CAT /etc/ssh/sshd_config |$EGREP '^Port' |$TAIL -1 |$CUT -d' ' -f2");
$mylanip= $_SERVER['SERVER_ADDR'];

print "<small>[$hostname][LAN:$mylanip]";


if(file_exists($file)){
$fileIN= file($file);
foreach($fileIN as $line){
print $line; 
 }
}


if($astport<>4569) {print"[port:<span style=\"background-color: green; color: black;\">$astport</span>]";}
else{print"[port:$astport]";}

print"[SSh:$myssh]</small>\n";//  [$mgrport]

} #endif (count($nodes) > 0)


print "<br><small>";
$uptime = exec("$UPTIME");  // "/bin/uptime";
$u=explode(",",$uptime);
$myday = date('l jS \of F Y h:i:s A');
if (!isset($u[5])){$u[5]="";}// 0-1 users 2 3 4 5 cores sometimes 5 is not set
print "[TimeZone:$phpzone $myday] [$u[0] $u[1]]<br>[$u[2] $u[3] $u[4] $u[5]";   
include_once ("$path/supermon_temp.php"); // Better php code 
print"</small>";

// End admin area......=--------------------------------------------------------


print "<p style=\"margin-bottom:5px;margin-top:10px;\">";

if (isset($SHOW_COREDUMPS) && ($SHOW_COREDUMPS == 'yes')) {
    $Cores = `ls /var/lib/systemd/coredump |wc -w`;
    if (($Cores == 1) || ($Cores == 2)) {
       print " [ Core dump: <span style=\"background-color: yellow; color: black;\">&nbsp;$Cores</span>&nbsp;]";
    } elseif ($Cores > 2) {
       print " [ Core dumps: <span style=\"background-color: red; color: yellow; font-weight: bold;\">&nbsp;$Cores</span>&nbsp;]";
    }
}
if ((`cat /etc/asterisk/rpt.conf |egrep -c ^"outstreamcmd"` > 0) && (`cat /etc/asterisk/rpt.conf |egrep -c ^"archivedir"` > 0) && ($STREAMING_NODE == $ARCHIVING_NODE)) {
   print " [ Streaming & Archiving node(s): $STREAMING_NODE ]";
} else {
   if (`cat /etc/asterisk/rpt.conf |egrep -c ^"outstreamcmd"` > 0) {
      if (isset($STREAMING_NODE)) {
         print " [ Streaming node(s): $STREAMING_NODE ]";
      }
   }
   if (`cat /etc/asterisk/rpt.conf |egrep -c ^"archivedir"` > 0) {
      if (isset($ARCHIVING_NODE)) {
         print " [ Archiving node(s): $ARCHIVING_NODE ]";
      }
   }
}
// END KN2R
print "</p>\n";


// This installs my weather lines
print "<!-- start weather ----->\n";
include ("/etc/asterisk/local/mm-software/supermon_weather.php");
print "<!-- stop weather  ----->\n";
print "</p>";


print "<!-- Nodes table -->";
foreach($nodes as $node) {
if (isset($astdb[$node])){ $info = $astdb[$node][1] . ' ' . $astdb[$node][2] . ' ' . $astdb[$node][3]; }
else{ $info = "Node not in database";}

$nodeURL = "";$title = "&nbsp; Node:<a href=\"$nodeURL\" target=\"_blank\">$node</a> Info:$info &nbsp;";

if (isset($config[$node]['listenlive'])) {
  $ListenLiveLink = $config[$node]['listenlive'];
  $title .= "<a href=\"$ListenLiveLink\" target=\"_blank\" id=\"lsnodeschart\">Listen Live</a> &nbsp;";
}

//    rColor=darkblue cColor=red bColor=palegreen gColor=lightgray tColor=lemonchiffon lColor=powderblue  <tr class="gColor">    
    
print"<table border=0 class=gridtable id=table_$node>
	<colgroup><col span=1> <col span=1><col span=1><col span=1><col span=1><col span=1><col span=1></colgroup>
	
    <thead>
    <tr class=\"lColor\"><td colspan=7 align=center>$title</td></tr>
	<tr class=\"tColor\"><td>Node</td><td align=center>Node Information</td><td>Received</td><td align=center>Link</td><td>Direction</td><td>Connected</td><td>Mode</td></tr>
	</thead>
	<tbody>
	<tr><td colspan=\"7\"> &nbsp; Waiting for Client side refreash...</td></tr>
	</tbody>
	</table><br/>";
}

print "<!-- start lsnodes ----->\n";
include ("/etc/asterisk/local/mm-software/supermon_lnodes.php");
print "<!-- stop lsnodes  ----->\n";


include ("/srv/http/gmrs/footer.php");
 


