<?php
// (c)2015/2023 by The Master lagmrs.com
// I license you to use this on your copy of this software only.
//
// Universal help system for node manager

$verGMRS="v1";$releaseGMRS="1/21/2024";  
$path         = "/etc/asterisk/local/mm-software"; 
$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
include_once("$path/supermon_input.php"); $help="";
$log="";
for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'help') {  $help  = $fieldValues[$i]; }
}

$help = preg_replace('/[^0-9.]+/', '', $help);

if($help <1 or $help >50){$help=100;}

$pageTitle="Help Page $help";
print "
<!DOCTYPE html>
<html>
<head>
<title>$pageTitle GMRS Node Manager</title>\n";
print "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n";
print "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n";
print "<meta name=\"robots\" content=\"noindex, nofollow\">\n";   
print "<meta name=\"generator\" content=\"GMRS Node Manager (c)2024 lagmrs.com\">\n";
print "<meta name=\"license2\" content=\"All new code for GMRS is Copyrighted 2023/2024 all rights reserved\">\n";
print "<link rel=\"shortcut icon\" href=\"/gmrs/favicon.ico\" type=\"image/x-icon\">\n";
print "<link rel=\"icon\" href=\"/gmrs/favicon.ico\" type=\"image/x-icon\">\n";
print "<link type=\"text/css\" rel=\"stylesheet\" href=\"/gmrs/supermon.css\">";

print "<style>
body {
  background-color: #E6E6FA;
}
</style>";

print "</head><body>\n";

print "<table style=\"border-collapse: collapse\" border=0 cellpadding=0 cellspacing=0  width=100%>
<tr><td align=\"center\" bgcolor=\"#000080\"><font color=white>$pageTitle</font></td></tr></table><BR>";

if ($help=="100"){print"ERROR Help code not found<br>";}

if ($help=="1"){print"This is your node number for this node.";}
if ($help=="2"){print"MDC1200 is a 'digital signaling' technology widely used in analog, conventional two-way radio systems developed by Motorola.<br><br>Enter your call or the last numbers depending on what your radio supports. It will send the burst localy.";}
if ($help=="3"){
print"This sets the banner on your pages. Select from mine or you can add 2 custom ones of yours<br><br>
'/gmrs/images/back-custom.jpg'<br>
'/gmrs/images/back-custom2.jpg' <br>
 Place them in the images directory.<br><BR>
 If you have images you would like to submit please do. Im looking for city scapes sunsets and others.";}
if ($help=="4"){print"This is mostly used for debugging. It displays extra data on the console screen. The beta option map be used later";}
if ($help=="5"){print"
If you have a <a href=https://ambientweather.com target=_blank> Ambent Weather station.</a> That reports data to AmbientWeather.net you can load
weather from your station into the node. You need a API KEY code from your station. 
<a href=https://ambientweather.net/account target=_blank>Login here</a> and generate one.
<br><br>
This data comes from the Ambent server and is very reliable.
";}
  
if ($help=="6"){print"
Enter a National Weather Service,Airport,MADIS or APRS station<br>
<BR>
Load the MADIS MAP and select a station near you. Not all stations are reliable and some only report temp.
<br><a href=https://madis-data.ncep.noaa.gov/MadisSurface/ target=_blank>Load the MAP</a><BR><BR>
Get the station ID from the map and enter it here. Airports are the most reliable but you may find one closer to you.<BR><BR>
This data comes from the NWS server and may go down from time to time.
";}

if ($help=="7"){print"
Detail for the Time And temp lady<br>
<BR>
Temp,Cond,Dew,Wind,Hum,Rain,Forcast<BR><BR>
This is still under construction. And settings may change.
";}
if ($help=="8"){print"
Icon Block:<BR>
This displayes the NWS icon block under the weather. Subject to the NWS servers. If the servers go down a alternate image will be used.
<BR><BR><small>
";
include_once("$path/supermon_weather.php"); print"</small>";
}
if ($help=="9"){print"
Used for text to voice conversion:<BR><BR>
Sign up for the free service at <a href=https://voicerss.org/ target=_blank>Voicerss.org</a> and enter the TSS key they give you here
<BR><BR>
This is still under construction. And is not used at this time..
";}

if ($help=="10"){print"
The zip code is used Accuweather:<BR><BR><BR>
This is a backup for temp data and is used for currect conditions.
";}

if ($help=="11"){print"
Bridge Check<BR><BR>
Its intended for signle nodes. Prevents you from bridging systems. It only allows 1 connection. <BR><BR>
If your running a HUB or Repeater you will likely want to disable this. Set on by default to prevent bridging for new users.
";}

if ($help=="12"){print"
Bridge Monitor<BR><BR>
Watches for others bridging. <BR><BR>
Example: This notifies you that someone else bridged 700 to 1195 or 611. If you need other pairs added let me know.";}

if ($help=="13"){print"
Hide IP on boot<BR><BR>
If your node is in a private location you want it to report the IP. But if your node is on a repeater you want the IP hidden.
<BR><BR>
This is all part of the new power up routines that report status.";}

if ($help=="14"){print"
Start Up connect:<BR><BR>
This starts a Perm. Connection on startup to the node you enter.<BR><BR>
A delay is included to allow for registration to finish before connection starts.
<BR><BR>
This setting requires the config file be modified and AST needs to be restarted 
for the changes to take affect. <BR><BR><BR>
Notice because changes are merged at 13m int by cron its importaint that you not restart
the system until after the import has finished.<BR><BR> 
Recomend exiting setup after saving and then reloading it from admin to check on
 status before you restart AST. Or changes will be lost. <BR><BR>
 The system makes backups in an atempt to stop corruption of conf files but its safer to wait.";}
 
if ($help=="15"){print"
Register Fix:<BR><BR>
This should be set to OFF by default<BR><BR>
If you have problems getting your node to register try this<BR><BR>
It is only for users that have port blocks caused by your 
ISP,Router or WIFI. Even some phones will do this.<br><br>
It will show up every so often sometimes working for weeks then refusing to register.<BR>

This solves the problem by auto floating your Port number when it detects a block.<BR><BR>
Set the number of failures at which point the port will rotate. 4 works ok. 
<BR><BR>
The register status and port number are shown on the status page so you can monitor this.
<BR><BR>
This is not compatable with DV Switch. Or anything that requires a static port#<BR>
";} 

 if ($help=="16"){print"
Display All nodes under status:
<BR><BR>
This displays List Nodes under the status window on the status page. 
This full network scan finds all Hidden nodes connected down stream on other connected HUBS.
<BR><BR>
It can identify most DV Switch users if the user is in its database.
<BR><BR>
You can manualy load it from the pulldown menu.
";} 

if ($help=="17"){print"
Notify if Unlinked:
<BR><BR>
Notifies you if the node becomes unlinked.<BR><BR> 
This solves the problem of a node getting disconected and you not noticing it.<br>
If you dont connect your node all the time you will want this OFF
";} 

if ($help=="18"){print"
ID Type:
<BR>
Allows you to change the ID type from the webpage without editing anything.<BR>
Short Morse is the last digits of your call.
<BR> 
<BR><BR>
This setting requires the config file be modified and AST needs to be restarted 
for the changes to take affect. <BR><BR><BR>
Notice because changes are merged at 13m int by cron its importaint that you not restart
the system until after the import has finished.<BR><BR> 
Recomend exiting setup after saving and then reloading it from admin to check on
 status before you restart AST. Or changes will be lost. <BR><BR>
 The system makes backups in an atempt to stop corruption of conf files but its safer to wait.";} 

if ($help=="19"){print"
Courtesy Tones:
<BR>
Allows you to turn tones on and off.
<BR>
 
<BR><BR>
This setting requires the config file be modified and AST needs to be restarted 
for the changes to take affect. <BR><BR><BR>
Notice because changes are merged at 13m int by cron its importaint that you not restart
the system until after the import has finished.<BR><BR> 
Recomend exiting setup after saving and then reloading it from admin to check on
 status before you restart AST. Or changes will be lost. <BR><BR>
 The system makes backups in an atempt to stop corruption of conf files but its safer to wait.";} 

if ($help=="23"){print"
FEMA Alerts:
<BR><br>
Enter your state and Parish/County for FEMA alerts.

<BR><BR>
This is expermental since I have not received any FEMA alerts yet.
 It works when testimg but is a work in progress. <BR><BR> It will require a TTS key when finished.";} 

if ($help=="24"){print"
The Weather Service Alerts:
<BR><br>
Select which ones you want to be alerted to (Warring,Watch,Advisorys,Statements) 
Statements have strings of text connected with them that will be displayed but not read.
<BR><BR>
TTS may later be used on this if its not to anoying.";} 

if ($help=="30"){print"
GPS Location:
<BR><br>
The new National Weather Service CAP v1.2 system uses the GPS position to get alerts 
for your exact location and does not use the ZIP code or the NOAA Weather Radio FIPS codes.
<BR><BR>There are many places to get your GPS LAT and LON.  <BR>
<a href=https://gps-coordinates.org/ target=_blank>gps-coordinates.org</a> <BR>
<a href=https://www.latlong.net/ target=_blank>www.latlong.net</a> <BR>
<a href=https://www.gps-coordinates.net/ target=_blank>www.gps-coordinates.net</a> <BR>


<BR><i>NWS CAP v1.1 is being terminated. We use CAP v1.2</i>
";}

if ($help=="31"){print"
Mute during nets:
<BR><br>
There are 3 preset nets Wendesday,Sunday,Friday.<br>
Set if you want it to mute and the 24hr time the mute will start and stop.
";}

if ($help=="32"){print"
Mute at night:
<BR><br>
This is designed to stop reading time and messages at night which wakes me up and is anoying. 
Its a preset mute from 1am to 6am. 
";}

if ($help=="33"){print"
CPU Temp Reports:
<BR><br>
Reads the CPU temp and throttling status to you<br>
Hot Temp: is the warning temp 50 &#8451;<BR>
High Temp: is the danger alarm 60 &#8451;<BR>
Report Normal: is for testing reports the temp ever few mins.	
Speak Name: Is the name the node calls its self when it reports the temp. 
<BR><BR>
Fans are recomended on all moble nodes. <BR><BR>
<i>The CPU temperature of a Raspberry Pi must stay below 85 &#8451; at all times. It will start throttling
 (reducing performance) as it approaches this threshold in order to prevent overheating.<i><BR><BR>
 
";}

if ($help=="34"){print"
Doc Route:
<BR><br>
The root to your webserver. Should not be changed.<br>
Detected as :$rootDir
";}

if ($help=="35"){print"
Restrict Editor:<br><BR>
For now this is locked. Must be activated in command line setup.php<BR><BR>
Then you can add and remove nodes to blocklist or whitelist. <br>

";}

if ($help=="50"){print"
How does the import (merge) work:<br><BR>
Cron runs at about every 13 min and does a series of task<BR><BR>
Like alerts temp and other fuctions.<br><BR> 
If you save info here it will merge it into setup at that time. 
If you reboot before the import the changes will be lost.<BR><BR> 
Detection for a reboot during merge has been included and will atempt repair but please do not reboot during a merge.
";}





print "<br><BR>";

include ("$rootDir/gmrs/footer.php");
print"</body></html>";
