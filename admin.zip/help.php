<?php
// (c)2023/2025 by  lagmrs.com
// I license you to use this on your copy of this software only.
//
// Universal help system for node manager. 
// Will provide help pages for all node manager pages
// This version only provides admin help for security.
//  
// image version

$verGMRS="v2.0";$releaseGMRS="9/03/2025";  
$path         = "/etc/asterisk/local/mm-software"; 
$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
include_once("$rootDir/admin/input.php"); $help="";
$log="";
for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'help') {  $help  = $fieldValues[$i]; }
}

$help = preg_replace('/[^0-9.]+/', '', $help);



$pageTitle="Help Page $help";
print "
<!DOCTYPE html>
<html>
<head>
<title>$pageTitle GMRS Node Manager</title>\n";
print "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n";
print "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n";
print "<meta name=\"robots\" content=\"noindex, nofollow\">\n";   
print "<meta name=\"generator\" content=\"GMRS Node Manager HELP System $verGMRS $releaseGMRS\">\n";
print "<meta name=\"license2\" content=\"All new code for GMRS is Copyrighted 2023/2025 all rights reserved\">\n";
print "<link rel=\"shortcut icon\" href=\"/status/images/favicon.ico\" type=\"image/x-icon\">\n";
print "<link rel=\"icon\" href=\"/status/images/favicon.ico\" type=\"image/x-icon\">\n";
print "<link type=\"text/css\" rel=\"stylesheet\" href=\"/admin/supermon.css\">";

print "<style>
body {
  background-color: #E6E6FA;
}
</style>";

print "</head><body>\n";

print "<table style=\"border-collapse: collapse\" border=0 cellpadding=0 cellspacing=0  width=100%>
<tr><td align=\"center\" bgcolor=\"#000080\"><font color=white>$pageTitle</font></td></tr></table><BR>";


$rb="This setting requires the config file be modified and AST needs to be restarted 
for the changes to take affect.";


if ($help=="1"){print"This is your node number for this node. <br> It is autodetected at install. 
If its wrong you can change it but. If its wrong then something went wrong at install.<BR>
<br>
This must be correct or the voice system cant talk. And the node manager cant control the node.";}

if ($help=="2"){print"MDC1200 is a 'digital signaling' technology widely used in analog, conventional two-way
 radio systems developed by Motorola.<br><br>Enter your call or the last numbers depending on what your radio
  supports. It will send the burst localy.";}

if ($help=="3"){print"Select a banner or create your own custom one<br>
Save it in /header directory as a jpeg file and it will be auto detected. Then select it from the menu.";}

if ($help=="4"){print"debugging. It displays extra data on the console screen.";}
if ($help=="5"){print"
If you have a <a href=https://ambientweather.com target=_blank> Ambent Weather station.</a> That reports data to AmbientWeather.net you can load
weather from your station into the node. You need a API KEY code from your station. 
<a href=https://ambientweather.net/account target=_blank>Login here</a> and generate one.
<br><br>
If you own a station you should be a member of the 
<a href=https://www.weather.gov/cle/CWOP target=_blank>Citizen Weather Observer Program</a>
<BR><BR>
<a href=https://ambientcwop.com/ target=_blank>ambientcwop.com</a>
 Will submit data for you or I have php scripts that will submit data for you from a PI. 
Signup for a station ID at 
<a href=http://www.wxqa.com target=_blank> CWOP site wxqa.com</a>.
  Here is a <a href=https://www.kanonbra.com/maps/cwop/all_stations_in_map.html target=_blank>map</a>
   of all CWOP stations. 

";}
  
if ($help=="6"){print"
Enter a National Weather Service,Airport,MADIS or APRS station<br>
<BR>
This station will be used as your main station or as a backup to Ambient Weather.
<BR><BR>
Load the <a href=https://madis-data.ncep.noaa.gov/MadisSurface/ target=_blank>NOAA MADIS MAP </a>and select a station near you. 
Not all stations are reliable and some only report temp. Look for a box thats not gray and click on it to get the station ID.
<br><BR>
Stations will be Airports,Forrest service towers,Railroads, 
<a href=https://www.weather.gov/cle/CWOP>Citizen Weather Observer Program</a>
sites and HAM APRS stations. Select the one you 
wish to use.
<BR><BR>
This data comes from the NWS server and may go down from time to time.";}

if ($help=="7"){print"
Say the Time:<br>
<br>
Controls what detail is read in the weather report at the top of the hr. <BR>
Values will only be read if they exist like so you can turn on rain and only get a rain report when its raining. Or only get wind when its above 0.<BR><BR>
The new options allow you to turn off what you dont want.  Remember not all stations provide all data. 
";}
if ($help=="8"){print"
Icon Block:<BR>
This displayes the NWS icon block under the weather. Subject to the NWS servers. If the servers go down a alternate image will be used.
<BR><BR>Hold your mouse over for more detailed info.";
}
if ($help=="9"){print"
Used for text to voice conversion:<BR><BR>
Sign up for the free service at <a href=https://voicerss.org/ target=_blank>Voicerss.org</a> and enter the TSS key they give you here
<BR><BR>
If you already have this set you should see your key loaded.<br><br>
Future use.
";}

if ($help=="10"){print"
The zip code is used Accuweather:<BR><BR><BR>
This is a backup for temp data and is used for currect conditions.
";}

if ($help=="11"){print"
Bridge Check<BR><BR>
Prevents you from bridging.<br>
It only allows 1 connection. <BR><BR>
If you require more than one connection then dont use this option.";}

if ($help=="12"){print"Old GMRSLIVE option removed";}

if ($help=="13"){print"
Hide IP on boot<BR><BR>
If your node is in a private location you want it to report the IP. But if your node is on a repeater you want the IP hidden.
<BR><BR>
This is all part of the new power up routines that report status.";}

if ($help=="14"){print"
Start Up connect:<BR><BR>
This starts a Perm. Connection to the HUB entered.<BR>
The delay for this is set in rpt.conf file<BR>
<BR>
$rb
";}
 
if ($help=="15"){print"
Register Fix:<BR><BR>
This should be set to OFF by default<BR><BR>
If you have problems getting your node to register try this<BR><BR>
It is only for users that have port blocks caused by your 
ISP,Router or WIFI. Even some phones will do this.<br><br>
It will show up every so often sometimes working for weeks then refusing to register.<BR>

This solves the problem by auto floating your Port number when it detects a block.<BR><BR>
Set the number of failures at which point the port will rotate. 4 works ok. 
<BR><BR>
The register status and port number are shown on the status page so you can monitor this.
<BR><BR>
This is not compatable with DV Switch. Or anything that requires a static port#<BR>
";} 

 if ($help=="16"){print"
Display All nodes under status:
<BR><BR>
This displays List Nodes under the status window on the status page. 
This full network scan finds all Hidden nodes connected down stream on other connected HUBS.
<BR><BR>
It can identify most DV Switch users if the user is in its database.
<BR><BR>
You can manualy load it from the pulldown menu.
";} 

if ($help=="17"){print"
    <h3>Notify if Unlinked:</h3>
    <p>Receive a notification if the node becomes unlinked.</p>
    <p>This feature helps you avoid missing when a node gets disconnected.</p>
    <p>If you don't always keep your node connected, you may want to turn this option off.</p>

";} 

if ($help=="18"){print"
ID Type:
<BR>
Allows you to change the ID type from the webpage without editing anything.<BR>
Short Morse is the last digits of your call.
<BR> 
<BR><BR>
$rb <BR><BR><BR>
Notice because changes are merged at 13m int by cron its importaint that you not restart
the system until after the import has finished.<BR><BR> 
Recomend exiting setup after saving and then reloading it from admin to check on
 status before you restart AST. Or changes will be lost. <BR><BR>
 The system makes backups in an atempt to stop corruption of conf files but its safer to wait.";} 

if ($help=="19"){print"
Courtesy Tones:
<BR>
Allows you to turn tones on and off.
<BR>
 
<BR><BR>
$rb <BR><BR><BR>
Notice because changes are merged at 13m int by cron its importaint that you not restart
the system until after the import has finished.<BR><BR> 
Recomend exiting setup after saving and then reloading it from admin to check on
 status before you restart AST. Or changes will be lost. <BR><BR>
 The system makes backups in an atempt to stop corruption of conf files but its safer to wait.";} 

if ($help=="23"){print"
State:
<BR><br>
Not in use at this time. Was for FEMA alert system. May be used later 
";} 

if ($help=="24"){print"
The Weather Service Alerts:
<BR><br>
Select which ones you want to be alerted to (Warring,Watch,Advisorys,Statements) 
Statements have strings of text connected with them that will be displayed but not read.
<BR><BR>
TTS may later be used on this if its not to anoying.";} 

if ($help=="30"){print"
GPS Location:
<BR><br>
The new National Weather Service CAP v1.2 system uses the GPS position to get alerts 
for your exact location and does not use the ZIP code or the NOAA Weather Radio FIPS codes.
<BR><BR>There are many places to get your GPS LAT and LON.  <BR>
<a href=https://gps-coordinates.org/ target=_blank>gps-coordinates.org</a> <BR>
<a href=https://www.latlong.net/ target=_blank>www.latlong.net</a> <BR>
<a href=https://www.gps-coordinates.net/ target=_blank>www.gps-coordinates.net</a> <BR>


<BR><i>NWS CAP v1.1 is being terminated. We use CAP v1.2</i>
";}

if ($help=="31"){print"
Mute during nets:
<BR><br>
There are 3 preset nets Wendesday,Sunday,Friday.<br>
<BR>
Set the time you want the mute to start and stop.
";}

if ($help=="32"){print"
Mute at night:
<BR><br>
This is designed to stop reading time and messages at night which wakes me up and is anoying. 
Its a preset mute from 1am to 6am. 
";}

if ($help=="33"){print"
CPU Temp Reports:
<BR><br>
Reads the CPU temp and throttling status to you<br>
Hot Temp: is the warning temp 50 &#8451;<BR>
High Temp: is the danger alarm 60 &#8451;<BR>
Report Normal: is for testing reports the temp ever few mins.	
Speak Name: Is the name the node calls its self when it reports the temp. 
<BR><BR>
Fans are recomended on all moble nodes. <BR><BR>
<i>The CPU temperature of a Raspberry Pi must stay below 85 &#8451; at all times. It will start throttling
 (reducing performance) as it approaches this threshold in order to prevent overheating.<i><BR><BR>
 
";}

if ($help=="34"){print"
Doc Route:
<BR><br>
The root to your webserver. Should not be changed.<br>
Detected as :$rootDir
";}

if ($help=="35"){print"
Restrict Editor:<br><BR>
For now this is locked. Must be activated in command line setup.php<BR><BR>
Then you can add and remove nodes to blocklist or whitelist. <br>

";}


if ($help=="36"){print"
AST connection:<br><BR>
If the status page fails to connect please check your password and IP address.<BR><BR>
";}

if ($help=="37"){print"
Time Out Timer:<br><BR>
This is the Max time the node can key up your transmiter. And the max time you can transmit into the network. 
Its also recomended that you set a TOT timer in your radio or Repeater. Some may even have a rest timmer you can set.<br>
This is an importiant setting to protect repeaters from lockups and quick keying..<BR><BR>
$rb
";}

if ($help=="38"){print"
Play Jingle:<br><BR>
On the bottom of the hr play a Jingle.<BR>
<br>
It will cycle from custom_bv to the option you select.
You will need a TTS Key set and check (rase old custom).
You can select a ch and it will play that and custom_bv randomly.

";}

if ($help=="39"){print"
Port Number:<br><BR>
This is the port # AST runs on. You may change this without contacting GMRSHUB because the system tells the server this number
when it registers. If you have more than one server you may have to change the ports.
<br>
In some cases your ISP or hotspot may block the port preventing you from registering with the server. 
You can reboot your hotspot router or phone when the node cant register. <br><br>
In such a case I recomend using the auto port rotation system. 
<br>
";}

if ($help=="40"){print"Old GMRSLive roadkill option removed";}


if ($help=="50"){print"
How does the import (merge) work:<br><BR>
Cron runs at about every 13 min and does a series of task<BR><BR>
Like alerts temp and other fuctions.<br><BR> 
If you save info here it will merge it into setup at that time. 
If you reboot before the import the changes will be lost.<BR><BR> 
Detection for a reboot during merge has been included and will atempt repair but please do not reboot during a merge.
";}

if ($help=="51"){print"Commands:<br>
<BR>
&nbsp;*70 system status</br>
&nbsp;*76 Disconnect All Nodes</br>
&nbsp;*81 Time</br>
*910 Reboot the system</br>
*911 Halt the system</br> 
*912 local IP</br> 
*913 Public IP</br>
*914 Registration Status</br>
*916 Restart Asterisk</br>
*971 SIMPLEX Repeater ON</br>
*970 SIMPLEX Repeater Off</br>
*973 SIMPLEX Repeater Flush</br>
</br>
Simplex repeater mode simulates a repeater by repeating everything you say on the RX channel to the TX channel. 
It does not repeat over the net globaly. 
This is needed if more than one persion uses the node or if your not connected to a hub and just want a repeater.
";}

if ($help=="101"){print"
    <p><strong>What is the EPROM Setting?</strong><br>
    The **EPROM** setting is used to enable or disable the storage of certain configuration parameters in the **EPROM memory**. If your system uses a radio or interface that includes an EPROM chip, this setting will store configuration data such as node IDs, frequencies, and other parameters to ensure they persist after power cycles or reboots. However, **soundcard-based systems** do not use EPROM, and the configuration will instead be stored in files that are loaded upon system start.</p>

    <h2>EPROM Options:</h2>
    <p>The **EPROM** setting can be configured with the following options:</p>

    <ul>
        <li><strong>no:</strong> Disables the use of **EPROM** memory. This option is typically used for **sound card-based systems** where there is no need for an EPROM, and all configuration data is stored in system files. For sound card systems, this is the default setting.</li>
        <li><strong>yes:</strong> Enables the use of **EPROM** memory to store certain configuration parameters. This option is useful when your system uses hardware with an **EPROM chip** (e.g., USB radio adapters or radios with internal EPROM) to store important settings that need to persist across reboots. This is **not applicable for soundcard-based nodes**.</li>
    </ul>

    <h2>How to Configure the EPROM Setting</h2>
    <p>In systems where **EPROM** is used (e.g., USB radios or certain modems with EPROM), you can configure the **EPROM** setting in the corresponding configuration file, such as **`simpleusb.conf`**, **`usbradio.conf`**, or **`radio.conf`**.</p>

    <h3>Example Configuration in `simpleusb.conf`:</h3>
    <pre>
    eprom = yes   # Use 'yes' if your radio has an EPROM for storing settings
    </pre>

    <h3>Example Configuration in `usbradio.conf`:</h3>
    <pre>
    eprom = yes   # Use 'yes' if your radio or interface supports EPROM storage
    </pre>

    <h2>Understanding the EPROM Options:</h2>

    <h3>1. no - Disable EPROM Storage</h3>
    <p>If **no** is selected, the system will not store configuration settings in **EPROM memory**. This is appropriate for systems that use sound cards or do not have hardware with an EPROM chip. Configuration parameters will instead be stored in software files, and changes will be lost if the system reboots unless manually saved in configuration files.</p>

    <h3>2. yes - Enable EPROM Storage</h3>
    <p>If **yes** is selected, the system will store critical settings in **EPROM memory** (if supported by the hardware). This ensures that settings like node IDs and frequency information persist even after power cycles or system reboots. Use this option only if your system includes a radio interface with EPROM support (such as some USB radio interfaces or radio modems).</p>

    <h2>Considerations When Configuring EPROM:</h2>
    <p>Before configuring the **EPROM** setting, consider the following:</p>
    <ul>
        <li>**yes** is used if your system supports **EPROM storage** (e.g., USB radio interfaces with built-in EPROM). Sound card-based systems should use **no**.</li>
        <li>In **sound card-based systems**, where there is no EPROM, configuration parameters will be stored in **system files**, not EPROM memory.</li>
        <li>If your hardware doesn't support EPROM, enabling **EPROM = yes** will have no effect.</li>
        <li>Ensure that any hardware that claims to support EPROM has been properly configured to use it.</li>
    </ul>

";}

if ($help=="103"){print"  <p><strong>What is COS (Carrier Operated Switch)?</strong><br>
    **COS** (Carrier Operated Switch) is a feature used in radio systems that detects the presence of a carrier signal. This carrier signal is typically generated when a radio begins transmitting. The **COS** setting controls how the system detects this carrier signal in order to trigger events, such as opening the squelch or enabling transmission. In AllStarLink and HamVoIP systems, the **COS** setting determines how the system handles carrier detection for managing communication.</p>

    <p><strong>What is the COS Setting?</strong><br>
    The **COS** setting tells the system how to detect the carrier signal from your radio or interface. This is crucial for managing the squelch and ensuring that the system only activates the receiver when a valid carrier signal is present. Depending on your hardware configuration, you can choose from different sources for carrier detection, such as using **USB adapters** or disabling carrier detection entirely. The available options allow for flexibility in different setups.</p>

    <h2>COS Options:</h2>
    <p>The **COS** setting can be set to one of the following values:</p>

    <ul>
        <li><strong>no:</strong> Disables carrier detection completely. This means that the system will not detect any carrier signal, and it will rely on other methods for managing squelch and triggering transmission. Typically, this option is used if you don’t need carrier detection or if another mechanism (like PTT or CTCSS) will be used for controlling the audio path.</li>
        <li><strong>usb:</strong> Enables carrier detection via a **USB radio adapter** connected to your system. The system will use the **COR** (Carrier Operated Relay) connection from the USB adapter to detect when a radio begins transmitting. This allows the system to detect the presence of a carrier and control the audio path accordingly.</li>
        <li><strong>usbinvert:</strong> Similar to **usb**, but with an **inverted polarity**. This means the system will interpret the signal from the USB radio adapter with the opposite polarity (i.e., a low voltage will be treated as high, and a high voltage will be treated as low). This option is used when the COR signal from the USB adapter is inverted, which can be common with certain hardware interfaces.</li>
    </ul>

    <h2>How to Configure the COS Setting</h2>
    <pThe **COS** setting is typically configured in your system's configuration files, such as **`simpleusb.conf`**, **`usbradio.conf`**, or **`radio.conf`**. Below are examples of how you can configure the **COS** setting in your system:</p>

    <h3>Example Configuration in `simpleusb.conf`:</h3>
    <pre>
    cos = usb   # Use 'no', 'usb', or 'usbinvert' based on your setup
    </pre>

    <h3>Example Configuration in `usbradio.conf`:</h3>
    <pre>
    cos = usb   # Use 'no', 'usb', or 'usbinvert' based on your setup
    </pre>

    <h2>Understanding Each COS Option:</h2>

    <h3>1. no - No Carrier Detection</h3>
    <p>When **no** is selected, carrier detection is disabled. The system will not look for a carrier signal (such as from the radio) and will rely on other methods like **PTT** (Push-To-Talk) or **CTCSS** for triggering transmission. This option is useful if your setup doesn't require carrier detection or if you want to manually control the audio path through other means.</p>

    <h3>2. usb - Carrier Detection via USB Adapter</h3>
    <p>When **usb** is selected, the system will use a **USB radio adapter** to detect the carrier signal through the **COR (Carrier Operated Relay)** pin. This method allows the system to automatically detect when the radio begins transmitting and will open the squelch or allow audio through accordingly. The USB adapter typically handles the detection and provides a clean signal for the system to use.</p>

    <h3>3. usbinvert - Carrier Detection via USB Adapter with Inverted Polarity</h3>
    <p>When **usbinvert** is selected, the system will use a **USB radio adapter** to detect the carrier signal, but the polarity of the signal will be inverted. In other words, a low voltage will be treated as a high signal and a high voltage as low. This option is useful if your USB adapter provides an inverted COR signal, which is common with certain USB interface hardware.</p>

    <h2>Considerations When Configuring COS:</h2>
    <p>Before selecting a COS option, it's important to understand your hardware setup and how it interacts with the system. Here are some considerations:</p>
    <ul>
        <li>**no** is typically used when you do not need carrier detection and prefer to manage squelch or transmission through other means like PTT or CTCSS.</li>
        <li>If you're using a **USB adapter** that can provide COR information, the **usb** option is the most straightforward choice.</li>
        <li>If your USB adapter provides an inverted COR signal, then **usbinvert** may be the correct option to ensure proper detection and operation.</li>
        <li>Ensure that your USB adapter is correctly connected and configured to provide COR detection if you're using **usb** or **usbinvert**.</li>
    </ul>
";}			
if ($help=="104"){print"CTCSS from<BR>
 <p><strong>What is CTCSS?</strong><br>
    **CTCSS** (Continuous Tone-Coded Squelch System) is a sub-audible tone used in radio communications to control squelch and allow for selective communication. It is commonly used in repeaters and radio networks to filter out unwanted transmissions by requiring a specific tone to be present before allowing audio through. In AllStarLink and HamVoIP systems, the **CTCSS Decoder Source** setting determines where the system will receive the CTCSS signal for decoding and squelch purposes.</p>

    <p><strong>What is the CTCSS Decoder Source?</strong><br>
    The **CTCSS Decoder Source** setting tells the system where to look for the CTCSS tone signal in order to properly decode it and control the audio transmission. This setting is important for controlling when the system should activate the transmit or receive function based on the presence of a valid CTCSS tone. The available options allow you to configure the source of the CTCSS signal, either from a regular carrier squelch or from a USB adapter (with or without polarity inversion).</p>

    <h2>CTCSS Decoder Source Options:</h2>
    <p>The **CTCSS Decoder Source** can be set to the following values:</p>

    <ul>
        <li><strong>no:</strong> Disables CTCSS decoding. The system will only rely on traditional **carrier squelch** (detecting the presence of any signal) to determine when to open the audio path. No tone decoding will be applied, so any signal that is present will trigger the receiver, regardless of the CTCSS tone.</li>
        <li><strong>usb:</strong> Enables CTCSS decoding using input from a **USB adapter** that is connected to the system. This adapter decodes the CTCSS tone directly from the radios audio output and provides this information to the system for squelch control. When the correct tone is detected, the system will allow audio to pass through.</li>
        <li><strong>usbinvert:</strong> Same as the **usb** option, but with an **inverted polarity**. This means the system will interpret the signal from the USB adapter with the opposite polarity (e.g., a low signal will be interpreted as a high signal and vice versa). This can be useful if the connected USB device outputs an inverted CTCSS signal.</li>
    </ul>

    <h2>How to Configure the CTCSS Decoder Source</h2>
    <p>The **CTCSS Decoder Source** setting is typically configured in the system's configuration files, such as **`simpleusb.conf`**, **`usbradio.conf`**, or **`radio.conf`**. Here’s how you can configure it:</p>

    <h3>Example Configuration in `simpleusb.conf`:</h3>
    <pre>
    ctcssdecodersource = usb   # Use 'no', 'usb', or 'usbinvert' based on your setup
    </pre>

    <h3>Example Configuration in `usbradio.conf`:</h3>
    <pre>
    ctcssdecodersource = usb   # Use 'no', 'usb', or 'usbinvert' based on your setup
    </pre>

    <h2>Understanding Each Option:</h2>

    <h3>1. no - No CTCSS Decoding (Carrier Squelch)</h3>
    <p>When **no** is selected, the system will not decode CTCSS tones. It will operate on a **carrier squelch** basis, which means that any received signal, regardless of the presence of a CTCSS tone, will trigger the audio path to open. This is useful if you don’t require tone filtering or are operating in an environment where CTCSS is not needed.</p>

    <h3>2. usb - CTCSS Decoding via USB Adapter</h3>
    <p>When **usb** is selected, the system will decode the CTCSS tone from a USB adapter connected to the node. The adapter will read the CTCSS tone from the radio’s audio output. This method ensures that only transmissions with the correct CTCSS tone will be allowed to pass through. If the tone does not match, the audio will be squelched. This option is useful when you have a USB interface or adapter that can handle CTCSS tone detection.</p>

    <h3>3. usbinvert - CTCSS Decoding with Inverted Polarity</h3>
    <p>When **usbinvert** is selected, the system will decode the CTCSS tone in the same way as **usb**, but with **inverted polarity**. Inverted polarity means the system will treat a low voltage as a high voltage and vice versa. This is useful if the USB adapter is outputting an inverted signal, and the system needs to interpret this correctly for tone detection.</p>

    <h2>Considerations When Configuring CTCSS Decoder Source:</h2>
    <p>Here are some important things to consider when configuring the **CTCSS Decoder Source**:</p>
    <ul>
        <li>Ensure that your hardware setup (radio and interface) supports CTCSS decoding through the selected method (USB adapter, traditional carrier squelch, etc.).</li>
        <li>If you use a USB adapter, make sure it is properly configured and connected to the node. Also, check if the device needs to be configured for inverted polarity.</li>
        <li>If you’re unsure whether you need an inverted signal, try the **usb** option first. If it doesn’t work as expected, try **usbinvert**.</li>
    </ul>
";}			

if ($help=="105"){print"
    <p><strong>What is Invert PTT?</strong><br>
    The **Invert PTT** setting in AllStarLink and HamVoIP allows you to reverse the behavior of the Push-To-Talk (PTT) signal for your radio system. When enabled, this setting inverts the normal logic of the PTT control. Typically, when you press the PTT button on your radio, it sends a signal to the node or repeater to enable transmission. With **Invert PTT**, this behavior is reversed, so pressing the PTT button will disable transmission and releasing it will enable transmission. This can be useful if your system's wiring or logic requires this inverted behavior.</p>

    <p><strong>How Does Invert PTT Work?</strong><br>
    In standard operation, the PTT signal is used to enable transmission, and it is active when the PTT button is pressed (the signal is typically low when inactive and high when active). The **Invert PTT** setting reverses this logic, meaning that when the PTT button is pressed, the system will treat it as if the PTT is inactive, and when the button is released, the system will treat it as if the PTT is active. This is often used in systems where the PTT signal behaves in reverse due to specific hardware wiring or other reasons.</p>

    <p><strong>Why Use Invert PTT?</strong><br>
    The **Invert PTT** setting is useful when your radio or interface system expects a reversed PTT signal. Some radios or repeater controllers might have a logic inversion in their PTT line, and enabling this setting allows the AllStarLink or HamVoIP system to properly interpret the PTT state and correctly enable or disable transmission. It also allows flexibility when integrating with different hardware systems that may have different PTT signal logic.</p>

    <h2>How to Enable Invert PTT in AllStarLink/HamVoIP</h2>
    <p>The **Invert PTT** setting can be configured in the system's configuration files, such as **`simpleusb.conf`**, **`usbradio.conf`**, or **`radio.conf`**. Below are examples of how to enable the **Invert PTT** setting:</p>

    <h3>Example Configuration in `simpleusb.conf`:</h3>
    <pre>
    invertppt = yes  # Set to 'yes' to enable Invert PTT, 'no' to disable
    </pre>

    <h3>Example Configuration in `usbradio.conf`:</h3>
    <pre>
    invertppt = yes  # Set to 'yes' to enable Invert PTT, 'no' to disable
    </pre>

    <p>The **invertppt** parameter can be set to:</p>
    <ul>
        <li>**yes**: Inverts the PTT signal logic (pressing PTT disables transmission, releasing PTT enables transmission).</li>
        <li>**no**: The default behavior where pressing PTT enables transmission, and releasing PTT disables transmission.</li>
    </ul>

    <p>After adjusting the **Inv";}


if ($help=="106"){print"
    <p><strong>Incoming Audio with PL Tone:</strong><br>
    When a radio transmits audio with a PL tone (CTCSS tone), the AllStarLink system can be configured to listen for that specific tone. The system detects the tone embedded in the signal and can respond accordingly.</p>

    <p><strong>PL Filter in Action:</strong><br>
    The system filters incoming signals and only allows the audio to be passed through if it matches the configured PL tone. If the tone does not match, the signal is ignored or squelched, preventing any unwanted transmissions.</p>

    <p><strong>Preventing Unwanted Access:</strong><br>
    This filtering mechanism prevents unauthorized or unintended transmissions on a node, ensuring that only users with the correct access tone can transmit and communicate over the system.</p>
";}

if ($help=="110"){print"
    <p><strong>Incoming Audio with DCS Code:</strong><br>
    When a radio transmits audio with a DCS code, the AllStarLink system can be configured to listen for that specific DCS code. The system detects the digital coded squelch (DCS) embedded in the signal and responds based on that code.</p>

    <p><strong>DCS Filter in Action:</strong><br>
    The system filters incoming signals and only allows the audio to be passed through if it matches the configured DCS code. If the code does not match, the signal is ignored or squelched, preventing unwanted transmissions.</p>

    <p><strong>Preventing Unwanted Access:</strong><br>
    This filtering mechanism helps prevent unauthorized or unintended transmissions on a node, ensuring that only users with the correct DCS code can transmit and communicate over the system.</p>
";}


if ($help=="107"){print"
    <p><strong>What is De-Emphasis?</strong><br>
    De-emphasis is a signal processing technique used to reduce high-frequency noise that may be introduced during the modulation and transmission process. In radio systems, it is used to flatten the frequency response and ensure the audio signal is more natural and clear when received.</p>

    <p><strong>De-Emphasis in Action:</strong><br>
    When audio is transmitted over a radio link, it may undergo **pre-emphasis** (boosting high frequencies) during transmission to improve signal clarity. De-emphasis is applied during reception to restore the audio signal to its natural balance by reducing these high frequencies, making the sound clearer and more intelligible.</p>

    <p><strong>De-Emphasis and Signal Quality:</strong><br>
    This process helps improve the quality of received audio, particularly in cases where the transmitted signal has been processed to emphasize higher frequencies. By applying de-emphasis, unwanted high-frequency noise is reduced, resulting in a smoother and clearer audio signal.</p>
";}

if ($help=="108"){print"
    <p><strong>What is Pre-Emphasis?</strong><br>
    Pre-emphasis is a signal processing technique used during the transmission of audio to boost high-frequency components of the signal. The purpose of pre-emphasis is to improve the signal-to-noise ratio by emphasizing higher frequencies, which helps to maintain audio clarity and intelligibility over a noisy or degraded radio link.</p>

    <p><strong>Pre-Emphasis in Action:</strong><br>
    During transmission, the audio signal undergoes **pre-emphasis**, where higher frequencies are boosted. This compensates for the fact that high frequencies tend to degrade more quickly over long distances and in noisy environments. Pre-emphasis ensures that important high-frequency details in the audio, such as speech clarity, are preserved when transmitted over radio systems.</p>

    <p><strong>Pre-Emphasis and Signal Quality:</strong><br>
    The process of pre-emphasis helps to enhance the transmitted signal by increasing the level of high frequencies. This is important for ensuring the clarity of speech or other high-frequency sounds during transmission. Once received, **de-emphasis** is typically applied to reduce these boosted frequencies, restoring the natural balance of the audio signal.</p>
";}


if ($help=="109"){print"
   <p><strong>What is RX Audio Delay?</strong><br>
    RX (Receive) Audio Delay refers to a setting that introduces a small time delay in the audio signal as it is received by the radio system. This delay can be used to help synchronize audio streams, compensate for audio processing, or to resolve issues like **echo** or **feedback** that might occur in certain radio configurations.</p>

    <p><strong>RX Audio Delay in Action:</strong><br>
    When RX audio delay is configured, it causes a brief delay between when the audio is received by the radio hardware and when it is played through the system. This delay can be beneficial in situations where you want to account for the time it takes for audio processing, or to prevent **echo** or **feedback loops** in a repeater or node setup.</p>

    <p><strong>Why Use RX Audio Delay?</strong><br>
    RX Audio Delay is commonly used to adjust the timing of audio to prevent audio artifacts like **echoing** or **feedback** that can occur when the receive audio is being processed or played back in real-time. By adding a slight delay, you can prevent the audio from feeding back into the system and causing undesirable sound issues.</p>

    <p><strong>Adjusting RX Audio Delay:</strong><br>
    The RX audio delay can be configured in the radio or software settings (such as in **`simpleusb.conf`**, **`usbradio.conf`**, or similar configuration files) based on your system's needs. It is often set in milliseconds, and the value can be fine-tuned to optimize the audio experience, especially for systems with echo or feedback problems.</p>
";}


if ($help=="111"){print"
    <p><strong>What is RX On Delay?</strong><br>
    RX On Delay refers to the amount of time (in milliseconds) that the system will wait after detecting a signal before it starts processing or playing the incoming audio. This delay can be useful in various scenarios, such as compensating for issues like **audio clipping**, **overdriven audio**, or other artifacts that occur if the system begins processing the audio too soon after the signal is detected.</p>

    <p><strong>RX On Delay in Action:</strong><br>
    When an RX On Delay is configured, the system introduces a brief waiting period after detecting the incoming signal before it processes or outputs the audio. This delay can prevent audio clipping or distortion that could occur if the audio signal is immediately routed into the system without allowing the system to stabilize first. It can also be useful in preventing issues caused by initial noise or static at the start of a transmission.</p>

    <p><strong>Why Use RX On Delay?</strong><br>
    RX On Delay is typically used in systems where the beginning of an audio signal might contain distortion or unwanted noise. By adding a slight delay before the system processes the signal, you can avoid audio artifacts like **clipping** or **popping sounds** that can be unpleasant to hear. This is especially useful in repeater or node systems, where the audio quality needs to be consistently clear.</p>

    <p><strong>Adjusting RX On Delay:</strong><br>
    The RX On Delay is usually configured in the radio software or configuration files (such as **`simpleusb.conf`**, **`usbradio.conf`**, or other related files). The delay is typically set in **milliseconds (ms)**, and it can be fine-tuned based on the specific needs of the system. Increasing the delay can help resolve distortion problems, while too much delay can affect the responsiveness of the system.</p>
";}

if ($help=="112"){print"
    <p><strong>What is Queue Size?</strong><br>
    Queue Size refers to the number of audio packets or data entries that can be stored temporarily in the system’s buffer before being processed. In radio systems, particularly in AllStarLink, the queue size setting controls how much incoming audio data the system can hold while waiting for processing, transmission, or further handling. It helps ensure smooth audio flow and prevents buffer underruns or overflows that could cause issues like audio dropouts or delays.</p>

    <p><strong>Queue Size in Action:</strong><br>
    The Queue Size setting determines the buffer capacity for incoming audio. If the queue is too small, the system may experience **buffer underrun**, which leads to audio dropouts or cuts. If the queue is too large, it could result in unnecessary delays in audio processing. Finding the optimal queue size is crucial for balancing smooth audio flow and system responsiveness, ensuring there are no noticeable gaps or interruptions in the transmission or reception of audio.</p>

    <p><strong>Why Adjust Queue Size?</strong><br>
    Adjusting the Queue Size is essential for fine-tuning the system's performance. If the audio processing system is unable to handle incoming audio quickly enough, it may need a larger queue to store the data temporarily. Conversely, if the system is processing the audio too slowly, the queue might need to be reduced to avoid adding unnecessary delay. An optimal queue size ensures the system can handle bursts of audio traffic efficiently while avoiding loss of data or audio artifacts.</p>

    <p><strong>Adjusting Queue Size:</strong><br>
    Queue Size can typically be adjusted in the **configuration files** (such as **`simpleusb.conf`**, **`usbradio.conf`**, or similar) for your AllStarLink system. The size is generally specified in terms of the number of audio packets or the time duration the system will buffer before processing the data. A typical setting might be a few hundred milliseconds or a few audio frames, depending on your system’s needs.</p>
";}
if ($help=="113"){print"
      <p>
        <code>tx_audio_level_method</code> determines how the transmission (TX) audio level is managed when sending audio to the connected radio. This parameter directly impacts the modulation quality and audio deviation during transmission.
    </p>

    <h2>Setting: <code>tx_audio_level_method = 0</code></h2>
    <ul>
        <li><strong>Mode:</strong> <em>Automatic Adjustment</em></li>
        <li><strong>Behavior:</strong>
            <ul>
                <li>The system dynamically adjusts the TX audio level based on internal algorithms.</li>
                <li>Ensures consistent audio output without requiring manual intervention.</li>
                <li>Ideal for most users and hardware setups where automatic level control provides satisfactory results.</li>
            </ul>
        </li>
    </ul>

    <h2>TX DSP Level (<code>txdsplvl</code>)</h2>
    <p>
        When using <code>tx_audio_level_method = 0</code>, the TX DSP Level is automatically managed by the system. However, if you need to provide a fallback value or for testing purposes, a recommended default for <code>txdsplvl</code> is:
    </p>
    <pre>txdsplvl = 500</pre>
    <p>This value may vary depending on your hardware. Always test to ensure proper modulation and clarity.</p>

    <h2>Use Case</h2>
    <p>
        Best suited for users who prefer the system to handle TX audio level adjustments without requiring manual configuration. Works well with standard hardware setups or when precision manual adjustments are not needed.
    </p>

    <h2>Advantages</h2>
    <ul>
        <li>Simplifies configuration by automatically setting optimal audio levels.</li>
        <li>Reduces the risk of improper deviation caused by manual errors.</li>
        <li>Ideal for quick setups and general use.</li>
    </ul>

    <h2>Disadvantages</h2>
    <ul>
        <li>Limited control over specific audio level adjustments.</li>
        <li>May not perform optimally with certain radios or custom hardware setups requiring precise manual tuning.</li>
    </ul>

    <h2>How to Enable</h2>
    <ol>
        <li>Open the configuration file (<code>simpleusb.conf</code> or <code>usbradio.conf</code>):
            <pre>sudo nano /etc/asterisk/simpleusb.conf</pre>
        </li>
        <li>Locate or add the following line:
            <pre>tx_audio_level_method = 0</pre>
        </li>
        <li>Save the file and restart the Asterisk service:
            <pre>sudo systemctl restart asterisk</pre>
        </li>
    </ol>

    <div class=\"note\">
        <strong>Note:</strong> For users requiring manual adjustment, set <code>tx_audio_level_method = 1</code> and configure <code>txdsplvl</code> or other related parameters. Always test the transmitted audio to ensure proper modulation and clarity.
    </div>
";}


if ($help=="114"){print"
    <p><strong>What is RX Boost?</strong><br>
    RX on a node is the Receiving signal from your portable. Its the volume going into the net.
    
    **RX Boost** (Receiver Boost) is a setting in AllStarLink and HamVoIP systems that amplifies the incoming audio signal at the receiver side. It is used to increase the volume of the received audio to ensure that weak or low-level signals are still intelligible. By applying a boost to the audio, **RX Boost** helps make quiet transmissions more audible and clear, especially in noisy or weak signal conditions.</p>

    <p><strong>RX Boost in Action:</strong><br>
    When RX Boost is enabled, the system applies an increase in gain to the incoming audio signal. This is particularly helpful when receiving signals that are faint, weak, or distorted. **RX Boost** can be especially useful in repeater systems or node configurations where the incoming signal might be coming from a distant or low-powered transmitter. The boost makes the received audio more audible, reducing the chances of missed or unintelligible transmissions.</p>

    <p><strong>Why Use RX Boost?</strong><br>
    **RX Boost** is most useful in situations where the received audio signal is too quiet or difficult to understand. For example, weak signals due to long-distance communication, poor antenna setups, or low-powered transmitters may result in audio that is not loud enough to hear clearly. By enabling RX Boost, you can make these signals more audible, improving the overall communication quality.</p>

    <p><strong>Considerations When Using RX Boost:</strong><br>
    While RX Boost can help with weak or distant signals, it may also introduce unwanted noise or distortion if the incoming signal is already strong and clear. Applying RX Boost in such cases can amplify background noise or static, making the signal harder to listen to. It’s important to test RX Boost and use it selectively, only when necessary to enhance weak signals without degrading the audio quality.</p>

    <h2>How to Adjust RX Boost in AllStarLink/HamVoIP</h2>
    <p>To enable or adjust RX Boost, you typically modify the configuration file used for your radio setup. Common configuration files for AllStarLink and HamVoIP systems include **`simpleusb.conf`**, **`usbradio.conf`**, or **`radio.conf`**. Below are examples of how to configure RX Boost in these files:</p>


    <p>The value for **rxboost** can typically be set to either **yes** or **no**. To enable the boost, set it to **yes**. To disable it, set it to **no**. After making changes, you may need to restart the system or reload the configuration for the changes to take effect.</p>

";}


if ($help=="115"){print"
       <p><strong>What is RX Level?</strong><br>
    The **RX Level** setting in HamVoIP controls the gain of the incoming audio signal (Receiver or **RX**). This setting adjusts the audio level at which your node receives signals from your radios. And then transmits into the net.
    The **RX Level** is a numerical value that typically ranges from **0** to **999**, where **0** represents the lowest possible gain (essentially no amplification) and **999** represents the highest possible gain (maximum amplification).</p>

    <p><strong>RX Level in Action:</strong><br>
    Adjusting the **RX Level** affects the volume of the audio signals that are received by the node. A lower value means quieter reception, while a higher value amplifies the signal. This is useful for adjusting the volume of weak or distant transmissions. If the RX Level is set too low, you may not hear faint signals clearly. If set too high, the signal could become distorted or clipped. The optimal **RX Level** ensures that received audio is clear and intelligible without distortion.</p>

    <p><strong>Why Adjust RX Level?</strong><br>
    Adjusting the **RX Level** allows you to customize the volume of incoming audio based on the strength of the received signal. If your node is receiving transmissions that are too quiet, you can increase the **RX Level** to boost the audio. Conversely, if the signal is too loud and causing distortion, you can reduce the **RX Level** to lower the volume. The correct setting ensures clear communication and helps avoid issues with missed or distorted audio.</p>

    <p><strong>Considerations When Adjusting RX Level:</strong><br>
    The **RX Level** should be adjusted carefully to avoid distortion. Setting it too high could cause the signal to clip, meaning that the audio will become garbled or hard to understand. Setting it too low can make distant or faint signals hard to hear. The goal is to find a balance where the audio is loud enough to be clear, but not so loud that it causes distortion. Also, remember that different transmitters and users may require different **RX Level** adjustments, depending on their distance or power level.</p>

    <h2>How to Adjust RX Level in AllStarLink/HamVoIP</h2>
    <p>The **RX Level** setting is typically configured in the system's configuration files, such as **`simpleusb.conf`**, **`usbradio.conf`**, or **`radio.conf`**. Below are examples of how to configure the **RX Level** in these files:</p>

    <h3>Example Configuration in `simpleusb.conf`:</h3>
    <pre>
    rxlevel = 500   # Set the RX level between 0 and 999
    </pre>

    <h3>Example Configuration in `usbradio.conf`:</h3>
    <pre>
    rxlevel = 500   # Set the RX level between 0 and 999
    </pre>

    <p>The **rxlevel** parameter can typically be set between **0** and **999**, where:</p>
    <ul>
        <li>**0**: No amplification (silent or very quiet reception).</li>
        <li>**999**: Maximum amplification (may introduce distortion if too high).</li>
        <li>Values in between allow for fine-tuned adjustments, depending on signal strength.</li>
    </ul>

    <p>After adjusting the **RX Level**, you should save the configuration file and restart the system or reload the configuration to apply the changes.</p>

    <h2>Conclusion</h2>
    <p>The **RX Level** setting in AllStarLink and HamVoIP allows you to adjust the incoming audio gain for received signals. By modifying the **RX Level**, you can optimize the volume of the received audio, ensuring clear communication and minimizing distortion. It’s important to adjust this setting carefully, as incorrect levels can lead to either faint audio or distorted, unintelligible signals.</p>

    <p><strong>Key Points to Remember:</strong></p>
    <ul>
        <li>**RX Level** controls the incoming audio signal's gain, ranging from **0** (silent) to **999** (maximum gain).</li>
        <li>A higher **RX Level** increases the volume of weak signals, but too high can cause distortion.</li>
        <li>A lower **RX Level** may result in weak or difficult-to-hear audio.</li>
        <li>Adjust **RX Level** in configuration files like **`simpleusb.conf`** or **`usbradio.conf`**.</li>
    </ul>
";}

if ($help=="116" or $help=="117"){print"
    <p><strong>What are TX Level A and TX Level B?</strong><br>
    The **TX Level A** and **TX Level B** settings in AllStarLink and HamVoIP control the audio gain for outgoing signals—i.e., the audio that your node transmits to other radios or nodes. This is the signal received from the net. 
    We have A & B because the sound card has Left And Right outputs.
    These settings adjust the volume of the audio sent from your node to the connected radio system or repeater. **TX Level A** and **TX Level B** may control different channels or audio paths, allowing for more granular control over the transmission levels in specific scenarios (for example, separate transmit levels for different transmit paths or users).</p>

    <p><strong>TX Level A in Action:</strong><br>
    **TX Level A** adjusts the transmission audio gain for one specific path (often the primary or default transmit path). When this level is adjusted, it changes the loudness of the signal that is transmitted to other stations or nodes. If **TX Level A** is set too high, you may cause overmodulation, leading to distortion in the transmitted signal. If it is too low, your signal might be inaudible or too weak to be clearly received by other stations. The goal is to set the correct level to ensure clear, undistorted transmission.</p>

    <p><strong>TX Level B in Action:</strong><br>
    **TX Level B** works similarly to **TX Level A** but is often used for another path or set of transmissions. Some nodes may have multiple transmit paths (for example, multiple radios connected to different systems or users). **TX Level B** allows you to independently control the transmission audio level for this second path, ensuring that the outgoing signal is optimized for both primary and secondary transmissions.</p>

    <p><strong>Why Adjust TX Level A and B?</strong><br>
    Adjusting **TX Level A** and **TX Level B** ensures that the transmitted audio is clear, intelligible, and not overly distorted. Since both **TX Level A** and **TX Level B** control outgoing audio, it is important to balance them to avoid overmodulation or weak signals. Setting the correct levels for both channels ensures that your transmissions are heard at the correct volume and with minimal distortion. This is particularly important in repeater systems, where clear and undistorted transmission is crucial for effective communication.</p>

    <p><strong>Considerations When Adjusting TX Level A and B:</strong><br>
    Both **TX Level A** and **TX Level B** should be adjusted carefully to prevent overmodulation or under-modulation. If the level is too high, it can cause distortion, making your audio difficult to understand. If the level is too low, your signal may be too weak, resulting in unclear or inaudible transmission. It's best to adjust these levels based on your system's needs and test for clarity at different settings.</p>

    <h2>How to Adjust TX Level A and B in AllStarLink/HamVoIP</h2>
    <pThe **TX Level A** and **TX Level B** settings are typically configured in the system's configuration files, such as **`simpleusb.conf`**, **`usbradio.conf`**, or **`radio.conf`**. Below are examples of how to configure both **TX Level A** and **TX Level B** in these files:</p>

    <h3>Example Configuration in `simpleusb.conf`:</h3>
    <pre>
    txlevel_a = 500   # Set TX Level A between 0 and 999 (0 = no output, 999 = maximum output)
    txlevel_b = 500   # Set TX Level B between 0 and 999 (0 = no output, 999 = maximum output)
    </pre>

    <h3>Example Configuration in `usbradio.conf`:</h3>
    <pre>
    txlevel_a = 500   # Set TX Level A between 0 and 999 (0 = no output, 999 = maximum output)
    txlevel_b = 500   # Set TX Level B between 0 and 999 (0 = no output, 999 = maximum output)
    </pre>

    <p>The **txlevel_a** and **txlevel_b** parameters can typically be set between **0** and **999**, where:</p>
    <ul>
        <li>**0**: No transmission (silent output).</li>
        <li>**999**: Maximum output (may introduce distortion if set too high).</li>
        <li>Values between **0** and **999** allow for fine adjustments to the transmission levels.</li>
    </ul>

    <p>After adjusting the **TX Level A** and **TX Level B** settings, be sure to save the configuration file and restart the system or reload the configuration for the changes to take effect.</p>

    <h2>Conclusion</h2>
    <p>The **TX Level A** and **TX Level B** settings allow you to control the volume of outgoing audio signals in AllStarLink and HamVoIP. Properly adjusting these levels ensures clear, intelligible transmission while avoiding overmodulation or distortion. The ability to independently control **TX Level A** and **TX Level B** is useful in multi-path or multi-radio setups, where different audio paths require different levels of adjustment. Careful tuning of these levels helps ensure that your system performs optimally in all transmission conditions.</p>

    <p><strong>Key Points to Remember:</strong></p>
    <ul>
        <li>**TX Level A** and **TX Level B** control the audio gain for outgoing transmission (TX) signals.</li>
        <li>Both settings range from **0** to **999**, where **0** is no transmission and **999** is maximum output.</li>
        <li>Adjust both levels carefully to avoid distortion or weak signals.</li>
        <li>Configure **TX Level A** and **TX Level B** in files like **`simpleusb.conf`** or **`usbradio.conf`**.</li>
    </ul>


";}

if ($help=="118"){print"

  <p><strong>What is TX DSP Level?</strong><br>
    The **TX DSP Level** setting in AllStarLink and HamVoIP controls the gain applied to the **digital signal processing (DSP)** for the transmitted audio. DSP is used to modify the transmitted signal’s audio before it leaves the node. The **TX DSP Level** setting adjusts the amount of processing (gain) applied to the audio, which can help optimize the sound quality of your transmitted signal. This is particularly useful for ensuring that your transmitted signal is neither too quiet nor overly distorted.</p>

    <p><strong>TX DSP Level in Action:</strong><br>
    The **TX DSP Level** setting allows you to control the amount of gain applied during the digital signal processing (DSP) phase. When this level is increased, the DSP applies more gain to the audio signal, making it louder. However, if this level is set too high, it could lead to distortion or clipping. Conversely, if the level is set too low, the transmitted audio may sound too weak or muffled. Adjusting the **TX DSP Level** allows you to fine-tune your audio transmission for the best clarity and loudness without overdriving the signal.</p>

    <p><strong>Why Adjust TX DSP Level?</strong><br>
    Adjusting the **TX DSP Level** helps optimize the outgoing audio for clearer communication. This setting is particularly useful if your transmitted signal is too weak or if it sounds distorted due to over-modulation. For example, if your audio signal is faint or difficult to hear, increasing the **TX DSP Level** will provide more gain to the transmitted audio, making it louder and clearer. On the other hand, if the signal is too loud and distorting, lowering the **TX DSP Level** can reduce overmodulation and prevent clipping.</p>

    <p><strong>Considerations When Adjusting TX DSP Level:</strong><br>
    While adjusting the **TX DSP Level** can improve audio quality, it should be done carefully. If the level is too high, it can result in **clipping**, where the transmitted signal is distorted and hard to understand. If set too low, your transmitted audio might be too weak to be heard clearly by others. It’s important to balance the **TX DSP Level** with the **TX Level** to avoid both distortion and weak transmission. Fine-tuning this setting is essential for maintaining clear and intelligible communications.</p>

    <h2>How to Adjust TX DSP Level in AllStarLink/HamVoIP</h2>
    <p>The **TX DSP Level** setting is typically configured in the system's configuration files, such as **`simpleusb.conf`**, **`usbradio.conf`**, or **`radio.conf`**. Below are examples of how to configure the **TX DSP Level** in these files:</p>

    <h3>Example Configuration in `simpleusb.conf`:</h3>
    <pre>
    txdsplevel = 500  # Set TX DSP Level between 0 and 999 (0 = no gain, 999 = maximum gain)
    </pre>

    <h3>Example Configuration in `usbradio.conf`:</h3>
    <pre>
    txdsplevel = 500  # Set TX DSP Level between 0 and 999 (0 = no gain, 999 = maximum gain)
    </pre>

    <p>The **txdsplevel** parameter can typically be set between **0** and **999**, where:</p>
    <ul>
        <li>**0**: No gain (no digital signal processing applied).</li>
        <li>**999**: Maximum gain (may introduce distortion if set too high).</li>
        <li>Values between **0** and **999** allow you to fine-tune the audio processing for optimal sound quality.</li>
    </ul>

    <p>After adjusting the **TX DSP Level**, you should save the configuration file and restart the system or reload the configuration for the changes to take effect.</p>

";}




//  the * commands help screen

if ($help=="200"){
print"<h2>Basic Node Control Commands</h2>
    <table>
        <thead><tr><th>Command</th><th>Description</th><th>Example</th></tr></thead>
        <tbody>
            <tr>
                <td>*1<node></td>
                <td>Disconnect link.</td>
                <td><strong>*1281000</strong> (Disconnect node 281000)</td>
            </tr>
            <tr>
                <td>*2<node></td>
                <td>Monitor link.</td>
                <td><strong>*2281000</strong> (Monitor node 281000)</td>
            </tr>
            <tr>
                <td>*3<node></td>
                <td>Connect link transceive.</td>
                <td><strong>*3281000</strong> (Connect to node 281000)</td>
            </tr>


        </tbody>
    </table>

    <h2>Advanced Commands</h2>
    <table>
        <thead><tr><th>Command</th><th>Description</th><th>Example</th></tr></thead>
        <tbody>
            <tr>
                <td>*70</td>
                <td>System status.</td>
            </tr>
            <tr>
                <td>*71<node></td>
                <td>Disconnect permanently</td>
                <td><strong>*71281000</strong> (Disconnect node 281000)</td>
            </tr>
            <tr>
                <td>*72<node></td>
                <td>Connect permanent monitor.</td>
                <td><strong>*72281000</strong> (Perminate Monitor node 281000)</td>
            </tr>
            <tr>
                <td>*73<node></td>
                <td>Connect link permanent transceive.</td>
                <td><strong>*73281000</strong> (Perminate Connect node 281000)</td>
            </tr>
            <tr>
                <td>*75</td>
                <td>Play full system status.</td>
            </tr>
            <tr>
                <td>*76</td>
                <td>Disconnect all links.</td>
                <td>Best way to disconnect everything</td>
            </tr>
            <tr>
                <td>*77</td>
                <td>Reconnect previously disconnected links.</td>
            </tr>
            <tr>
                <td>*78</td>
                <td>Permanently monitor link (local monitor only).</td>
            </tr>

        </tbody>
    </table>

    <h2>Utility Commands</h2>
    <table>
        <thead>
            <tr>
                <th>Command</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
                    <tr>
                <td>*80</td>
                <td>Gives local ID</td>
            </tr>
            <tr>
                <td>*81</td>
                <td>Time Temp Weather information.</td>
            </tr>
            <tr>
                <td>*82</td>
                <td>Say the time (24-hour format).</td>
            </tr>
            <tr>
                <td>*83</td>
                <td>Say the time (12-hour format).</td>
            </tr>
            <tr>
                <td>*910</td>
                <td>Reboot the system.</td>
            </tr>
            <tr>
                <td>*911</td>
                <td>Halt the system (total shutdown).</td>
            </tr>
            <tr>
                <td>*912</td>
                <td>Say local IP address.</td>
            </tr>
            <tr>
                <td>*913</td>
                <td>Say public IP address.</td>
            </tr>
            <tr>
                <td>*914</td>
                <td>Say registration status.</td>
            </tr>
            <tr>
                <td>*916</td>
                <td>Restart Asterisk.</td>
            </tr>
        </tbody>
    </table>

    <h2>Parrot Mode Commands</h2>
    <table>
        <thead>
            <tr>
                <th>Command</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>*970</td>
                <td>Disable Parrot Mode.</td>
            </tr>
            <tr>
                <td>*971</td>
                <td>Enable Parrot Mode.</td>
            </tr>
            <tr>
                <td>*972</td>
                <td>Parrot once (if disabled).</td>
            </tr>
            <tr>
                <td>*973</td>
                <td>Parrot cleanup/flush.</td>
            </tr>
        </tbody>
    </table>

    <h2>Troubleshooting</h2>
    <p>If you experience issues with commands not responding:</p>
    <ul>
        <li>Ensure your radio levels are set right. The most common problem is to high a level. This distorts the tones. The node mutes your tones if they are correct, if they are not correct people will be able to hear the improper tones. If someone tells you they hear tones your level is likely to high.</li>
        <li>Try diffrent radios. Remember tones must be correct and at the proper level for this to work.</li>
        <li>Its also importiant to remember when you key up everyone can hear you. </l1>
    </ul>
    Louisiana Custom image not for other use.
  
";}


if($help <1 or $help >200){print"ERROR Help code not found<br>";}

print "
<br>
<br>
<div align=\"center\">
<table style=\"border-collapse: collapse\" border=0 cellpadding=0 cellspacing=0  width=100%>
<tr>
<td align=\"center\" bgcolor=\"#000080\"><img src = \"/status/images/node-manager.png\">&emsp;<img src = \"/status/images/php.gif\"></td>
</tr>
</table></div>
";

function Show_help($in){
global $width,$height,$in;
print "<a href=\"#\" onclick=\"window.open('/admin/help.php?help=$in', 'Help', 'width=$width,height=$height');\"><img src=\"/status/images/help.gif\"></a>";
}


print"</body></html>";
