<?php
//  System controler for node manager
//  Total rewrite.
//
//  v1.0 11/27/23
//





include_once("/srv/http/gmrs/global.php"); // includes the local settings
include_once("/srv/http/gmrs/common.php"); // includes the main settings

$fileAllMon = "/srv/http/gmrs/admin/allmon.ini";       
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);// load the now secure file

//$file = "/srv/http/gmrs/admin/allmon.ini";$favorites="";       
//if (file_exists($file)){ $favorites = parse_ini_file($file, true);}


include("/srv/http/gmrs/header.php"); 
include("/srv/http/gmrs/menu.php"); 


//error_reporting(E_ALL);
// upgraded to a more modern anti hacker input
$path         = "/etc/asterisk/local/mm-software";
include_once ("$path/supermon_input.php");

include('/srv/http/gmrs/admin/ami-functions.php');

$remotenode = "";$connectType= "";$localnode = "";$dtmf="";

for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'remotenode')    {$remotenode  = $fieldValues[$i]; }
if ($fieldNames[$i] == 'dtmf'){                 $dtmf = $fieldValues[$i]; }
if ($fieldNames[$i] == 'type')          {$connectType = $fieldValues[$i]; } // types C,CP,D,DP,DA,M,ML
if ($fieldNames[$i] == 'localnode'){       $localnode = $fieldValues[$i]; }
}


// all unneeded since its already validated buit just to be safe.
$remotenode = @trim($remotenode);
$connectType= @trim($connectType);
$localnode = @trim($localnode);


include_once ("$path/load.php");
if (!$localnode){ $localnode = $node;}
print"<b> Node Manager Command Page</b>";

if($connectType){

// Open a socket to Asterisk Manager


$fp = AMIconnect($config[$localnode]['host']);
if (FALSE === $fp) { die("Could not connect.\n\n");}
if (FALSE === AMIlogin($fp, $config[$localnode]['user'], $config[$localnode]['passwd'])) {	die("Login failed.");}

if ($connectType=="DTMF"){
 if ($dtmf){ do_dtmf_cmd($fp, $localnode, $dtmf); }
 else {print"<p>EMPTY DTMF</p>";}
}

if ($connectType=="AON"){
 if(!file_exists("/var/run/asterisk.ctl")){Astart($button);}
 else {print "<p>asterisk is already running</p>";}
}

if ($connectType=="AOFF"){
if(file_exists("/var/run/asterisk.ctl")){Asstop($button);}
else {print "<p>asterisk not running</p>";}
}

if ($connectType=="AR"){
if(file_exists("/var/run/asterisk.ctl")){
 Asstop($button);
 Astart($button);
 }
}

if ($connectType=="R"){
   $out = array();
   print "<b> Rebooting Server! </b>";
   exec("sudo /bin/killall watchdog; sync; sync; sync; sudo /bin/reboot");
}


if ($connectType=="ASTR"){
   $out = array();
      print "<b>Executing: asterisk -rx \"Iax2, Rpt, & Dialplan Reloads\" ... </b> ";
      exec('export TERM=vt100 && sudo /bin/asterisk -rx "rpt reload"', $out);
      sleep(1);
      exec('export TERM=vt100 && sudo /bin/asterisk -rx "iax2 reload"', $out);
      sleep(1);
      exec('export TERM=vt100 && sudo /bin/asterisk -rx "dialplan reload"', $out);
}

}

print"<b>Enter Your command</b>
<div style=\"border-radius: 10px;\" id=\"connect_form\"      >
<form method=\"POST\" action=\"/gmrs/admin/commands.php\"  >

  <select size=\"1\" name=\"type\">
  <option value=\"AON\" selected>Asterisk ON</option>
  <option value=\"AOFF\">Asterisk OFF</option>
  <option value=\"AR\">Asterisk Restart</option>
  <option value=\"ASTR\">Iax/Rpt/DP RELOAD</option>
  <option value=\"R\">Full Reboot of PI</option> 

  </select>
<input style=\"margin-top:10px;\" type=\"text\" name=\"T1\" size=\"10\" id=\"localnode\" value=\"$localnode\"> 

<input type=\"submit\" class=\"submit\" value=\"Submit\" name=\"B1\" >
</form> </div>
\n";

print"<br>
<b>Enter a DTMF command</b>
<div style=\"border-radius: 10px;\" id=\"connect_form\">
<form method=\"POST\" action=\"/gmrs/admin/commands.php\"  >
<input style=\"margin-top:10px;\" type=\"text\" name=\"DTMF\" size=\"10\" id=\"node\">
  <select size=\"1\" name=\"type\">
  <option value=\"DTMF\" selected>DTMF</option>
  </select>
<input style=\"margin-top:10px;\" type=\"text\" name=\"T1\" size=\"10\" id=\"localnode\" value=\"$localnode\"> 

<input type=\"submit\" class=\"submit\" value=\"Submit\" name=\"B1\" >
</form> </div>
<img src='/gmrs/images/dtmf.jpg'>
\n";



include ("/srv/http/gmrs/footer.php");
// end of line



function do_dtmf_cmd($fp, $localnode, $dtmf){
    $AMI1 = AMIcommand ($fp, "rpt fun $localnode $dtmf");
    print "<b>Executing DTMF command '$dtmf' on node $localnode</b>";
}


function Astop ($in){
exec("sudo /sbin/asterisk -rx 'stop now' ",$output,$return_var); print "<p>Sending Stop asterisk cmd</p>"; sleep(1);
exec("sudo /sbin/killall safe_asterisk",$output,$return_var);    print "<p>Sending Killall safe_asterisk</p>"; sleep(1);
exec("sudo /sbin/killall asterisk",$output,$return_var);         print "<p>Sending Killall asterisk</p>";sleep(1);
exec("sudo /bin/rm -f /var/run/asterisk.ctl /var/run/asterisk.pid",$output,$return_var);print "<p>Clearing run flags for safety</p>";
}

function Astart ($in){
print "<p>Sending Start asterisk cmd</p>";
exec("sudo /usr/sbin/safe_asterisk",$output,$return_var);
}



