<?php
//  System controler for node manager
//  Total rewrite.
//
//  v1.0 11/27/23
//
// v1.2 1/4/24  fixed bug in remote node controls.
// v1.3 1/5/24  Now working for all nodes
// 1.4 1/7/24   support for webserver with diffrent path. Some items still not 100% so marking as beta 

$verGMRS="v1.4";$releaseGMRS="1/7/2024";$betatest=true;

$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else

include_once("$rootDir/gmrs/global.php"); // includes the local settings
include_once("$rootDir/gmrs/common.php"); // includes the main settings

$fileAllMon = "$rootDir/gmrs/admin/allmon.ini";       
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);// load the now secure file

//$file = "/srv/http/gmrs/admin/allmon.ini";$favorites="";       
//if (file_exists($file)){ $favorites = parse_ini_file($file, true);}


include("$rootDir/gmrs/header.php"); 
include("$rootDir/gmrs/menu.php"); 


//error_reporting(E_ALL);
// upgraded to a more modern anti hacker input
$path         = "/etc/asterisk/local/mm-software";
include_once ("$path/supermon_input.php");

include("$rootDir/gmrs/admin/ami-functions.php");

$remotenode = "";$connectType= "";$localnode = "";$dtmf="";$in="";

for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'remotenode')    {$remotenode  = $fieldValues[$i]; }
if ($fieldNames[$i] == 'DTMF'){                 $dtmf = $fieldValues[$i]; }
if ($fieldNames[$i] == 'type')          {$connectType = $fieldValues[$i]; } // types C,CP,D,DP,DA,M,ML
if ($fieldNames[$i] == 'localnode'){       $localnode = $fieldValues[$i]; }
if ($fieldNames[$i] == 'nodes')   {            $nodes = $fieldValues[$i]; }
}

$NodesStore = @trim($nodes);

// all unneeded since its already validated buit just to be safe.
$remotenode = @trim($remotenode);
$connectType= @trim($connectType);
$localnode = @trim($localnode);

include_once ("$path/supermon_load_setup.php");
//include_once ("$path/load.php");
if (!$localnode){ $localnode = $node;}
print"<b> Node Manager Command Page</b></br>";


if($connectType){

// Open a socket to Asterisk Manager


$fp = AMIconnect($config[$localnode]['host']);
if (FALSE === $fp) { print "Could not connect.\n\n";}
if (FALSE === AMIlogin($fp, $config[$localnode]['user'], $config[$localnode]['passwd'])) {	print "Login failed.";}

if ($connectType=="DTMF"){
 if ($dtmf){ do_dtmf_cmd($fp, $localnode, $dtmf); }
 else {print"<p>EMPTY DTMF</p>";}
}

if ($connectType=="AON"){
 print "<b> AON </b>";
 if(!file_exists("/var/run/asterisk.ctl")){Astart($in);}
 else {print "<p>asterisk is already running</p>";}
}

if ($connectType=="AOFF"){
 print "<b> OFF </b>";
if(file_exists("/var/run/asterisk.ctl")){Asstop($in);}
else {print "<p>asterisk not running</p>";}
}

if ($connectType=="AR"){
 print "<b> Restart AST </b>";
if(file_exists("/var/run/asterisk.ctl")){
  print "<b> Stop </b>"; Asstop($in);
  print "<b> Start </b>";Astart($in);
 }
}

if ($connectType=="R"){
   $out = array();
   print "<b> Rebooting Server! </b>";
   exec("sudo /bin/killall watchdog; sync; sync; sync; sudo /bin/reboot");
}


if ($connectType=="ASTR"){
   $out = array();
      print "<b>Executing: asterisk -rx \"Iax2, Rpt, & Dialplan Reloads\" ... </b> ";
      exec('export TERM=vt100 && sudo /bin/asterisk -rx "rpt reload"', $out);
      sleep(1);
      exec('export TERM=vt100 && sudo /bin/asterisk -rx "iax2 reload"', $out);
      sleep(1);
      exec('export TERM=vt100 && sudo /bin/asterisk -rx "dialplan reload"', $out);
}

}

$passedNodes = explode(',', @trim($nodes));// for PHP code
// Remove nodes not in our allmon.ini file.
$nodes=array();
foreach ($passedNodes as $i => $nodeZ) {
 if (isset($config[$nodeZ])) {$nodes[] = $nodeZ;} 
 else {$nodes[0]=$node;}  // Default to our node for directloading
}

include("/etc/asterisk/local/mm-software/supermon_display_cache.php");
// Build the local nodelist selection
$count=count($nodes); $action=""; $controlNodes="";
print"\n<!-- Connect form start count:$count-->\n";
if ($count>0) {
  $action= "<select name=\"localnode\" >\n";
        foreach ($nodes as $nodex) {
        print"\n<!-- $nodex-->\n";
        if (isset($astdb[$nodex])){ $info = $astdb[$nodex][1] ." ". $astdb[$nodex][2] ; }
        else{ 
          $info = "Pending";
          if (file_exists($OurNodeCache)){unlink($OurNodeCache);}// Bad reset it.
          }
        $action="$action <option style=\"margin-top:10px;\" value=\"$nodex\">$nodex $info</option>\n";
        if (!$controlNodes){$controlNodes="$nodex";}
        else{$controlNodes="$controlNodes,$nodex";}
        }
  $action="$action </select>";
}





print"<b>Enter Your command</b>
<div style=\"border-radius: 10px;\" id=\"connect_form\"      >
<form method=\"POST\" action=\"/gmrs/admin/commands.php\"  >

  <select size=\"1\" name=\"type\">
  <option value=\"\" selected>Select CMD</option>
  <option value=\"AON\">Asterisk ON</option>
  <option value=\"AOFF\">Asterisk OFF</option>
  <option value=\"AR\">Asterisk Restart</option>
  <option value=\"ASTR\">Iax/Rpt/DP RELOAD</option>
  <option value=\"R\">Full Reboot of PI</option> 

  </select>";
//<input style=\"margin-top:10px;\" type=\"text\" name=\"localnode\" size=\"10\" id=\"localnode\" value=\"$localnode\"> 
print"$action
<input type=\"hidden\" value=\"$NodesStore\" name=\"nodes\" > 
<input type=\"submit\" class=\"submit\" value=\"Submit\" name=\"B1\" >  
</form> </div>
\n";

print"<br>
<b>Enter a DTMF command</b>
<div style=\"border-radius: 10px;\" id=\"connect_form\">
<form method=\"POST\" action=\"/gmrs/admin/commands.php\"  >
<input style=\"margin-top:10px;\" type=\"text\" name=\"DTMF\" size=\"10\" id=\"node\">
  <select size=\"1\" name=\"type\">
  <option value=\"DTMF\" selected>DTMF</option>
  </select>";

//<input style=\"margin-top:10px;\" type=\"text\" name=\"localnode\" size=\"10\" id=\"localnode\" value=\"$localnode\"> 
print"$action
<input type=\"hidden\" value=\"$NodesStore\" name=\"nodes\" > 
<input type=\"submit\" class=\"submit\" value=\"Submit\" name=\"B1\" >
</form> </div>

\n";


// image map will be here. On hold more to work on elsewhere
?>
<table><tr><td>
<img src="/gmrs/images/dtmf.jpg" usemap="#image-map">
<map name="image-map">
    <area target="" alt="1" title="1" href="1" coords="22,26,22,12" shape="rect">
    <area target="" alt="2" title="2" href="2" coords="63,29,63,14" shape="rect">
    <area target="" alt="3" title="3" href="3" coords="102,26,100,10" shape="rect">
    <area target="" alt="4" title="4" href="4" coords="22,65,27,50" shape="rect">
    <area target="" alt="5" title="5" href="5" coords="65,67,60,51" shape="rect">
    <area target="" alt="6" title="6" href="6" coords="103,67,101,49" shape="rect">
    <area target="" alt="7" title="7" href="7" coords="25,108,22,90" shape="rect">
    <area target="" alt="8" title="8" href="8" coords="65,105,62,89" shape="rect">
    <area target="" alt="9" title="9" href="9" coords="103,105,103,91" shape="rect">
    <area target="" alt="0" title="0" href="0" coords="64,144,63,129" shape="rect">
    <area target="" alt="#" title="#" href="#" coords="103,144,105,130" shape="rect">
    <area target="" alt="*" title="*" href="*" coords="25,145,25,129" shape="rect">
</map>
</td>
<td>
<table>
<tr><td>*70 system status. </td></tr>
<tr><td>*75 Play full system status</td></tr>
<tr><td>*76 Disconnect from ALL links</td></tr>
<tr><td>*80 ID</td></tr>
<tr><td>*81 Time</td></tr>
<tr><td>*911 Halt the system</td></tr>
<tr><td>*914 Registration status</td></tr>
<tr><td>*971 SIMPLEX Mode On</td></tr>
<tr><td>*970 SIMPLEX Mode Off</td></tr>
<tr><td>*973 SIMPLEX cleanup/flush</td></tr>

</table>

</td></tr></table>



<?php

include ("/srv/http/gmrs/footer.php");
// end of line



function do_dtmf_cmd($fp, $localnode, $dtmf){
    $AMI1 = AMIcommand ($fp, "rpt fun $localnode $dtmf");
    print "<b>Executing DTMF command '$dtmf' on node $localnode</b>";
}


function Astop ($in){
print "<p>Sending Stop asterisk cmd</p>";
exec("sudo /sbin/asterisk -rx 'stop now' ",$output,$return_var);  sleep(1); 
print "<p>Sending Killall safe_asterisk</p>";
exec("sudo /sbin/killall safe_asterisk",$output,$return_var);     sleep(1); 
print "<p>Sending Killall asterisk</p>";sleep(1);
exec("sudo /sbin/killall asterisk",$output,$return_var); 
print "<p>Clearing run flags for safety</p>";
exec("sudo /bin/rm -f /var/run/asterisk.ctl /var/run/asterisk.pid",$output,$return_var);
}

function Astart ($in){
print "<p>Sending Start asterisk cmd</p>";
exec("sudo /usr/sbin/safe_asterisk",$output,$return_var);
}



