<?php
//  System controler for node manager
//  Total rewrite.
//
//  v1.0 11/27/23
//
// v1.2 1/4/24  fixed bug in remote node controls.
// v1.3 1/5/24  Now working for all nodes
// 1.4 1/7/24   support for webserver with diffrent path. Some items still not 100% so marking as beta 

$verGMRS="v1.5";$releaseGMRS="1/11/2024";$betatest=false;  $pageTitle="Node Command";


$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else

include_once("$rootDir/gmrs/global.php"); // includes the local settings
include_once("$rootDir/gmrs/common.php"); // includes the main settings

$fileAllMon = "$rootDir/gmrs/admin/allmon.ini";       
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);// load the now secure file

include("$rootDir/gmrs/header.php"); 
include("$rootDir/gmrs/menu.php"); 


//error_reporting(E_ALL);
// upgraded to a more modern anti hacker input
$path         = "/etc/asterisk/local/mm-software";
include_once ("$path/supermon_input.php");

include("$rootDir/gmrs/admin/ami-functions.php");

$remotenode = "";$connectType= "";$localnode = "";$dtmf="";$in="";  

for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'remotenode')    {$remotenode  = $fieldValues[$i]; }
if ($fieldNames[$i] == 'DTMF'){                 $dtmf = $fieldValues[$i]; }
if ($fieldNames[$i] == 'type')          {$connectType = $fieldValues[$i]; } // types C,CP,D,DP,DA,M,ML
if ($fieldNames[$i] == 'localnode'){       $localnode = $fieldValues[$i]; }
if ($fieldNames[$i] == 'nodes')   {            $nodes = $fieldValues[$i]; }
}

$NodesStore = @trim($nodes);

// all unneeded since its already validated buit just to be safe.
$remotenode = @trim($remotenode);
$connectType= @trim($connectType);
$localnode = @trim($localnode);

include_once ("$path/supermon_load_setup.php");
//include_once ("$path/load.php");
if (!$localnode){ $localnode = $node;}

print"<div align=center><font color=GREEN size=6><h1>$pageTitle Page</h1></font></div>";


if ($connectType=="DTMF"){
$fp = AMIconnect($config[$localnode]['host']);
if (FALSE === $fp) { print "Could not connect.\n\n";}
if (FALSE === AMIlogin($fp, $config[$localnode]['user'], $config[$localnode]['passwd'])) {	print "Login failed.";}
 if ($dtmf){ do_dtmf_cmd($fp, $localnode, $dtmf); }
 else {print"<p>EMPTY DTMF</p>";}
}




$passedNodes = explode(',', @trim($nodes));// for PHP code
// Remove nodes not in our allmon.ini file.
$nodes=array();
foreach ($passedNodes as $i => $nodeZ) {
 if (isset($config[$nodeZ])) {$nodes[] = $nodeZ;} 
 else {$nodes[0]=$node;}  // Default to our node for directloading
}

include("$path/supermon_display_cache.php");
// Build the local nodelist selection
$count=count($nodes); $action=""; $controlNodes="";
print"\n<!-- Connect form start count:$count-->\n";
if ($count>0) {
  $action= "<select name=\"localnode\" >\n";
        foreach ($nodes as $nodex) {
        print"\n<!-- $nodex-->\n";
        if (isset($astdb[$nodex])){ $info = $astdb[$nodex][1] ." ". $astdb[$nodex][2] ; }
        else{ 
          $info = "Pending";
          if (file_exists($OurNodeCache)){unlink($OurNodeCache);}// Bad reset it.
          }
        $action="$action <option style=\"margin-top:10px;\" value=\"$nodex\">$nodex $info</option>\n";
        if (!$controlNodes){$controlNodes="$nodex";}
        else{$controlNodes="$controlNodes,$nodex";}
        }
  $action="$action </select>";
}


$piVersion = file_get_contents ("/proc/device-tree/model");
print"<!-- (c)2023/2024 by lagmrs.com all rights reserverd-->\n";
$image="/gmrs/images/GMRSLiveicon.jpg";
$pos = strpos("-$piVersion", "Pi 3 Model A"); if ($pos){$image="/gmrs/images/pi-3a.jpg";}
$pos = strpos("-$piVersion", "Pi 3 Model B"); if ($pos){$image="/gmrs/images/pi3b.jpg";}
$pos = strpos("-$piVersion", "Pi 4");         if ($pos){$image="/gmrs/images/pi4.jpg";}
print "<image src=$image align=right>";


//  <option value=\"*75\">Play full system status</option>

print"<br>
<b>Select Preformated DTMF command</b>
<div style=\"border-radius: 10px;\" id=\"connect_form\">
<form method=\"POST\" action=\"/gmrs/admin/commands.php\"  >
  <select size=\"1\" name=\"DTMF\">
  <option value=\"\" selected>Select CMD</option>
  <option value=\"*70\">system status</option>

  <option value=\"*76\">Disconnect All Nodes</option>
  <option value=\"*81\">Time</option>
  <option value=\"*910\">Reboot the system</option> 
  <option value=\"*911\">Halt the system</option> 
  <option value=\"*912\">local IP</option> 
  <option value=\"*913\">Public IP</option> 
  <option value=\"*914\">Registration Status</option>
  <option value=\"*916\">Restart Asterisk</option>
  <option value=\"*971\">SIMPLEX repeat ON</option> 
  <option value=\"*970\">SIMPLEX repeat Off</option> 
  <option value=\"*973\">SIMPLEX flush</option>        
  </select>


  
  $action
<input type=\"hidden\" value=\"DTMF\" name=\"type\" >  
<input type=\"hidden\" value=\"$NodesStore\" name=\"nodes\" > 
<input type=\"submit\" class=\"submit\" value=\"Submit\" name=\"B1\" >
</form></div>\n";

// ---------------------------------------------------------------------------

print"<br>
<b>Enter a DTMF command</b>
<div style=\"border-radius: 10px;\" id=\"connect_form\">
<form method=\"POST\" action=\"/gmrs/admin/commands.php\"  >
<input style=\"margin-top:10px;\" type=\"text\" name=\"DTMF\" size=\"5\" id=\"dtmf\">



$action
<input type=\"hidden\" value=\"DTMF\" name=\"type\" >
<input type=\"hidden\" value=\"$NodesStore\" name=\"nodes\" > 
<input type=\"submit\" class=\"submit\" value=\"Submit\" name=\"B1\" >
</form></div>\n";





?>



<script type="text/javascript">

function input(e) {
    var tbInput = document.getElementById("dtmf");
    tbInput.value = tbInput.value + e.value;
}

function del() {
    var tbInput = document.getElementById("dtmf");
    tbInput.value = tbInput.value.substr(0, tbInput.value.length - 1);
}

</script>

<?php

$butAct="onclick=\"input(this);\" style=\"background: black; color: white; font-size: 20px;\" /></td>";


print "
    <table>
    <tr>
    <td><input id=\"btn1\" type=\"button\" value=\"1\" $butAct
    <td><input id=\"btn2\" type=\"button\" value=\"2\" $butAct
    <td><input id=\"btn3\" type=\"button\" value=\"3\" $butAct
    </tr><tr>
    <td><input id=\"btn4\" type=\"button\" value=\"4\" $butAct
    <td><input id=\"btn5\" type=\"button\" value=\"5\" $butAct
    <td><input id=\"btn6\" type=\"button\" value=\"6\" $butAct
    </tr><tr>
    <td><input id=\"btn7\" type=\"button\" value=\"7\" $butAct
    <td><input id=\"btn8\" type=\"button\" value=\"8\" $butAct
    <td><input id=\"btn9\" type=\"button\" value=\"9\" $butAct
    </tr><tr>
    <td><input id=\"btn11\" type=\"button\" value=\"*\" $butAct
    <td><input id=\"btn0\"  type=\"button\" value=\"0\" $butAct
    <td><input id=\"btn12\" type=\"button\" value=\"#\" $butAct
    </tr><tr>
    <td colspan=3><input id=\"btnDel\" type=\"button\" value=\"Backspace\" onclick=\"del();\" /></td>
    </tr>
    </table>
    
";


include ("/srv/http/gmrs/footer.php");
// end of line



function do_dtmf_cmd($fp, $localnode, $dtmf){
    $AMI1 = AMIcommand ($fp, "rpt fun $localnode $dtmf");
    print "<b><font color=blue>Sending DTMF command [$dtmf] to node $localnode</font></b><br><br>";
}


function Astop ($in){
print "<p>Sending Stop asterisk cmd</p>";
exec("sudo /sbin/asterisk -rx 'stop now' ",$output,$return_var);
print "$output</br>";
sleep(1); 
print "<p>Sending Killall safe_asterisk</p>";
exec("sudo /sbin/killall safe_asterisk",$output,$return_var);
print "$output</br>";
sleep(1); 
print "<p>Sending Killall asterisk</p>";
exec("sudo /sbin/killall asterisk",$output,$return_var);
print "$output</br>";
sleep(1); 
print "<p>Clearing run flags for safety</p>";
exec("sudo /bin/rm -f /var/run/asterisk.ctl /var/run/asterisk.pid",$output,$return_var);
print "$output</br>";
}

function Astart ($in){
print "<p>Sending Start asterisk cmd</p>";
exec("sudo /usr/sbin/safe_asterisk",$output,$return_var);
print "$output</br>";
}



?>
