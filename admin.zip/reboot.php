<?php
//
//  AllStarLink/ASL-Supermon is licensed under the GNU General Public License v3.0
//
// https://raw.githubusercontent.com/AllStarLink/ASL-Supermon/develop/LICENSE
// https://github.com/AllStarLink/ASL-Supermon/blob/develop/var/www/html/supermon/edit/reboot.php
// https://www.gnu.org/licenses/gpl-3.0.en.html

// Modified in acordance with GPL

   $out = array();
   print "<b> Rebooting Server! </b>";

  $statcmd = "sudo /bin/killall watchdog; sync; sync; sync; sudo /bin/reboot";
  exec($statcmd);

?>
