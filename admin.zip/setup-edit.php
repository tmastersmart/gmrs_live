 <?php
// ***************************************************
// (c)2023/2024 by The Master lagmrs.com WRXB288 winnfreenet.com
//  all rights reserved

// File is protected in admin directory no need to check for logoins
//
// This is the web editor for Node Manager
// Some items will be in the AST editor because this file only hold flags for the cmd line setup prg
//
// Files saved here will be loaded from cron on a schedule . Save is not live
// v1.6 1/1/24 working release
// v1.7 1/3/24 Fix for banner setting being blank in older versions
// v1.8 1/5/24  Bug fix 
// v1.9 1/7/23  New setting brokenBridge
// v2   1/14/24 Mods to remove TX suport
// v2.1 1/16/24 Dewpoint level added
// v2.2 1/21 bug fix in level and docroute added. Flag for safe to restart added
// v2.3 1/25 new var for global $levelForcast,$levelDew,$levelRain,$levelPress,$levelUvi;

$verGMRS="v2.3";  $save=false; $in="";$out=""; $betatest=false;  $pageTitle="Node Controler Setup";

$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else

$path  = "/etc/asterisk/local/mm-software";
$datum = date('m-d-Y-H:i:s');
include_once("$rootDir/gmrs/global.php");
include_once("$rootDir/gmrs/common.php"); 

$fileAllMon = "$rootDir/gmrs/admin/allmon.ini";       
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);// load the now secure file

include_once ("/etc/asterisk/local/mm-software/supermon_input.php");
include_once("$rootDir/gmrs/header.php"); 
include_once("$rootDir/gmrs/menu.php"); 

$fileWEB="/tmp/setup.txt";  // We have write permission
$fileSET="/etc/asterisk/local/mm-software/setup.txt"; // We have read only permissions

$astport = exec("$CAT /etc/asterisk/iax.conf |$EGREP 'bindport' |$SED 's/bindport=//g'");
if($astport<>4569) {$portd="[port:$astport Floating]";}
else{$portd="[port:$astport]";}

if(sizeof($fieldNames)>1) {
for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'B1'){                    $save=true;}

if ($fieldNames[$i] == 'node')        {$node         = $fieldValues[$i] ;} 
if ($fieldNames[$i] == 'NodePassword'){$NodePassword = $fieldValues[$i] ;}// Password is not used at this time 


if ($fieldNames[$i] == 'ambientApiKey'){$ambientApiKey= $fieldValues[$i];}
if ($fieldNames[$i] == 'parishCounty') {$parishCounty = $fieldValues[$i];}
if ($fieldNames[$i] == 'fema')      {   $fema         = $fieldValues[$i];}
if ($fieldNames[$i] == 'startUp')   {   $startUp      = $fieldValues[$i];}
if ($fieldNames[$i] == 'startUpNode') { $startUpNode  = $fieldValues[$i];}
if ($fieldNames[$i] == 'coreVersion')  {$coreVersion  = $fieldValues[$i];}
if ($fieldNames[$i] == 'burst')    {    $burst        = $fieldValues[$i];}
if ($fieldNames[$i] == 'DisplayNodes') {$DisplayNodes = $fieldValues[$i];}

if ($fieldNames[$i] == 'Net1Start'){$Net1Start= $fieldValues[$i];}
if ($fieldNames[$i] == 'Net1Stop') {$Net1Stop = $fieldValues[$i];}
if ($fieldNames[$i] == 'MuteNet1') {$MuteNet1 = $fieldValues[$i];}

if ($fieldNames[$i] == 'Net2Start'){$Net2Start= $fieldValues[$i];}
if ($fieldNames[$i] == 'Net2Stop') {$Net2Stop = $fieldValues[$i];}
if ($fieldNames[$i] == 'MuteNet2') {$MuteNet2 = $fieldValues[$i];}

if ($fieldNames[$i] == 'Net3Start'){$Net3Start= $fieldValues[$i];}
if ($fieldNames[$i] == 'Net3Stop') {$Net3Stop = $fieldValues[$i];}
if ($fieldNames[$i] == 'MuteNet3') {$MuteNet3 = $fieldValues[$i];}

if ($fieldNames[$i] == 'tts')      {$tts= $fieldValues[$i];}
if ($fieldNames[$i] == 'sleep')    {$sleep   = $fieldValues[$i];}

if ($fieldNames[$i] == 'IconBlock'){$IconBlock = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'debug')    {$debug     = $fieldValues[$i] ;}

if ($fieldNames[$i] == 'station')  {$station   = $fieldValues[$i] ;}

if ($fieldNames[$i] == 'zipcode')  {$zipcode   = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'lat')      {$lat       = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'lon')      {$lon       = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'sayWarn')  {$sayWarn   = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'sayWatch') {$sayWatch  = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'sayAdvisory'){$sayAdvisory  = $fieldValues[$i];}
if ($fieldNames[$i] == 'sayStatement'){$sayStatement= $fieldValues[$i];}

if ($fieldNames[$i] == 'sleep')    {$sleep = $fieldValues[$i];}
if ($fieldNames[$i] == 'high')     {$high  = $fieldValues[$i];}
if ($fieldNames[$i] == 'hot')      {$hot   = $fieldValues[$i];}

if ($fieldNames[$i] == 'reportAll'){$reportAll = $fieldValues[$i];}
if ($fieldNames[$i] == 'LinkCheck'){$LinkCheck = $fieldValues[$i];} 


if ($fieldNames[$i] == 'bridgeCheck'){  $bridgeCheck  = $fieldValues[$i];}
if ($fieldNames[$i] == 'bridgeMonitor'){$bridgeMonitor= $fieldValues[$i];}
if ($fieldNames[$i] == 'brokenBridge'){ $brokenBridge = $fieldValues[$i];}


if ($fieldNames[$i] == 'outToneL'){$outToneL= $fieldValues[$i];}
if ($fieldNames[$i] == 'outToneU'){$outToneU= $fieldValues[$i];}
if ($fieldNames[$i] == 'inTone')  {$inTone  = $fieldValues[$i];}
if ($fieldNames[$i] == 'idType')  {$idType  = $fieldValues[$i];}  
if ($fieldNames[$i] == 'hideIP')  {$hideIP  = $fieldValues[$i];}

if ($fieldNames[$i] == 'debug')   {$debug   = $fieldValues[$i];}  
if ($fieldNames[$i] == 'beta')    {$beta    = $fieldValues[$i];}

if ($fieldNames[$i] == 'watchdog'){$watchdog= $fieldValues[$i];}
if ($fieldNames[$i] == 'nodeName'){$nodeName= $fieldValues[$i];}
if ($fieldNames[$i] == 'banner'){  $banner  = $fieldValues[$i];}

if ($fieldNames[$i] == 'docRouteP'){$docRouteP = $fieldValues[$i];}

if ($fieldNames[$i] == 'level')       {$level       = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'levelForcast'){$levelForcast= $fieldValues[$i] ;}
if ($fieldNames[$i] == 'levelDew')    {$levelDew    = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'levelPress')  {$levelPress  = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'levelUvi')    {$levelUvi    = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'levelTemp')   {$levelTemp   = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'levelCond')   {$levelCond   = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'levelHum')    {$levelHum    = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'levelRain')   {$levelRain   = $fieldValues[$i] ;}

}

if($save){
 // save config task  30 data points with spares for expansion
$datum = date('m-d-Y-H:i:s');
$fileOUT = fopen($fileWEB, "w");
fwrite ($fileOUT, "MMSOFTWARE,$node,$station,$level,$zipcode,$IconBlock,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$sleep,$high,$hot,$nodeName,$reportAll,$datum,$LinkCheck,$beta,$watchdog,$debug,$tts,$bridgeCheck,$MuteNet1,$MuteNet2,$MuteNet3,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$DisplayNodes,$burst,$startUp,$startUpNode,$parishCounty,$fema,$ambientApiKey,$hideIP,$idType,$inTone,$outToneL,$outToneU,$bridgeMonitor,$banner,$brokenBridge,$NodePassword,$docRouteP,$levelForcast,$levelDew,$levelRain,$levelPress,$levelUvi,$levelTemp,$levelCond,$levelHum,$levelWind,,,,,,,,");
fclose ($fileOUT);
print"<!-- New save created. Data is loaded from submission -->\n";
}
}
else{include_once ("$path/supermon_load_setup.php");}

$piVersion = file_get_contents ("/proc/device-tree/model");

if(!$banner){$banner="back-default";}// fix a upgrade problem

print"<!-- setup is (c)2023/2024 by lagmrs.com all rights reserverd-->\n";

$image="/gmrs/images/pi3b.jpg";
$pos = strpos("-$piVersion", "Pi 3 Model A"); if ($pos){$image="/gmrs/images/pi-3a.jpg";}
$pos = strpos("-$piVersion", "Pi 3 Model B"); if ($pos){$image="/gmrs/images/pi3b.jpg";}
$pos = strpos("-$piVersion", "Pi 4");         if ($pos){$image="/gmrs/images/pi4.jpg";}

print "<table style=width: 100%><tr><td><image src=$image align=left></td><td align=right>
<div align=center><font color=GREEN size=6><h1>$pageTitle Page</h1></font><center>";  
print "$piVersion</br>";

if($save){
$safe="<font color=red>Importing dont restart</font>";
print"<p><b>Setup was Saved.<br>Waiting for import into live setup.$safe</b></p>";}
else{     print"<p><b>$status $safe</b></p>";}


print"</td></tr></table> 
<form method=\"GET\" name=\"config\" action=\"/gmrs/admin/setup-edit.php\">
<table align=center border=\"1\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse: collapse\" bordercolor=\"#111111\" id=\"AutoNumber1\">";


$background="#808080"; $fontcolor="white";$basecolor="#FFFFCC"; //$NodePassword

// future use
print"<input type='hidden' name='NodePassword' size='5' value='$NodePassword'>";
//print"<input type='hidden' name='level' size='5' value='$level'>";

print "<tr>
   <td bgcolor=$background><b><font color=$fontcolor>Node</font></b></td>
   <td bgcolor=$basecolor><input type='text' name='node' size='5' value='$node'>";
$width=500;$height=200;$in=1;Show_help($in);
print"</td>    

   <td bgcolor=$background><b><font color=$fontcolor>MDC1200 Burst</font></b></td>
   <td bgcolor=$basecolor><input type='text' name='burst' size='8' value='$burst'><br>$CALL";
$width=500;$height=200;$in=2;Show_help($in);
print"</td>    
  
   <td bgcolor=$background><b><font color=$fontcolor>Banner</font></b></td>
   <td bgcolor=$basecolor>
   <select size=1 name=banner>
    <option selected value='$banner'>$banner.jpg</option>
    <option value='back-default'>default</option>
    <option value='back-beach'>beach</option>
    <option value='back-dark'>dark</option>
    <option value='back-green'>green</option>
    <option value='back-swamp-green'>swamp-green</option>
    <option value='back-orange'>orange</option>
    <option value='back-rail'>rail</option>
    <option value='back-gmrs'>live</option>
    <option value='back-custom'>custom 'back-custom.jpg'</option>
    <option value='back-custom2'>custom2 'back-custom2.jpg'</option>
    </select>";
$width=600;$height=400;$in=3;Show_help($in);
print"</td>     
    <td bgcolor=$background><b><font color=$fontcolor>Debug<br>Beta Features</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=debug>";
    if ($debug){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select></br>
    <select size=1 name=beta>";
    if ($beta){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>";
$width=500;$height=200;$in=4;Show_help($in);
print"</td>     
</tr>";



print"<tr>
    <td bgcolor=$background><b><font color=$fontcolor>Ambient Key:<BR>NWS Station:</font></b></td>
    <td bgcolor=$basecolor><input type='text' name='ambientApiKey' size='10' value='$ambientApiKey'>";
$width=500;$height=200;$in=5;Show_help($in);
print"<br>
<input type='text' name='station' size='4' value='$station'>";
$width=600;$height=300;$in=6;Show_help($in);
if ($station){print"<a href=https://weather.gladstonefamily.net/site/$station target=_blank>$station Info</a>";}
print"</td>     
    <td bgcolor=$background><b><font color=$fontcolor>
    Mute All:<br>
    Temp:<br>
    DewPoint:<br>
    Rain:<br>
    Conditions:
    </font></b></td>
    <td bgcolor=$basecolor>
    <select size=1 name=level>";
    if ($level<=0){print"<option value='1'>TALK</option>        <option selected value='0'>MUTE</option>";}
    if ($level==1){print"<option selected value='1'>TALK</option><option value='0'>MUTE</option>";}
    if ($level>=2){print"<option selected value='$level'>$level</option><option value='1'>TALK</option><option value='0'>MUTE</option>";}    
    print"</select>
    <br>
    <select size=1 name=levelTemp>";
    if ($levelTemp){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else   {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>
    <br>
    <select size=1 name=levelDew>";
    if ($levelDew){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else   {       print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>
    <br>  
    <select size=1 name=levelRain>";
    if ($levelRain){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else   {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>  
    <br>
    <select size=1 name=levelCond>";
    if ($levelCond){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else   {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>";
    $width=500;$height=300;$in=7;Show_help($in);
print"   
</td>     

    <td bgcolor=$background>
    <b><font color=$fontcolor>Humidity:
    <br>Pressure:
    <br>Ultraviolet Index:
    <br>Rain:
    <br>Forcast:
    </font></b>
    </td>
    <td bgcolor=$basecolor>
  
    "; 
    print"    
    <select size=1 name=levelHum>";
    if ($levelHum){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else   {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>       
    <br><select size=1 name=levelPress>";
    if ($levelPress){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else   {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>    
    <br><select size=1 name=levelUvi>";
    if ($levelUvi){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else   {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>
    <br><select size=1 name=levelRain>";
    if ($levelRain){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else   {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>
    <br><select size=1 name=levelForcast>";
    if ($levelForcast){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else   {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>    

    
    
    "; 
    
     
    
    
$width=500;$height=300;$in=7;Show_help($in);
print"</td>     
    <td bgcolor=$background><b><font color=$fontcolor>Icons Block</font></b></td>
    <td bgcolor=$basecolor>
    <select size=1 name=IconBlock>";
    if ($IconBlock){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>
    
    
    
    
    ";
$width=900;$height=300;$in=8;Show_help($in);
print"</td>     
   
    </tr>";
  
print"<tr>
    <td bgcolor=$background><b><font color=$fontcolor>TTS Key</font></b></td>
    <td bgcolor=$basecolor><input type='text' name='tts' size='10' value='$tts'>";
$width=300;$height=200;$in=9;Show_help($in);
print"</td>     
    <td bgcolor=$background><b><font color=$fontcolor>Zipcode</font></b></td>
    <td bgcolor=$basecolor><input type='text' name='zipcode' size='8' value='$zipcode'>";
$width=300;$height=200;$in=10;Show_help($in);
print"</td>     

    <td bgcolor=$background><b><font color=$fontcolor>Bridge Check<br>Bridge Monitor</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=bridgeCheck>";
    if ($bridgeCheck){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>Stop you from bridging";
$width=300;$height=200;$in=11;Show_help($in);
print"
    <br>
    <select size=1 name=bridgeMonitor>";
    if ($bridgeMonitor){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>Detect others Bridging";
$width=300;$height=200;$in=12;Show_help($in);

    
//    print"<select size=1 name=brokenBridge>";
//    if ($brokenBridge){print"<option selected value='1'>True</option><option value='0'>False</option>";}
//    else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
//    print"</select>Detect broken bridge";
    
    print"<input type='hidden' name='brokenBridge' size='5' value='0'>"; // Force disabled since the tx to la link is no more
    
    print"</td> 
                                      
    
    <td bgcolor=$background><b><font color=$fontcolor>Hide IP on boot</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=hideIP>";
    if ($hideIP){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>";
    $width=300;$height=200;$in=13;Show_help($in);
print"</td> 
 
    </tr>";  
    
print"<tr>    
    
    <td bgcolor=$background><b><font color=$fontcolor>Startup Connect*</font></b></td>  
    <td bgcolor=$basecolor><select size=1 name=startUp>";
    if ($startUp){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select><br><input type='text' name='startUpNode' size='8' value='$startUpNode'><br>Node to connect to.";
  $width=600;$height=400;$in=14;Show_help($in);
print"</td> ";    
    
    if($watchdog==99){$dwatchdog="off";}
    else{$dwatchdog="$watchdog falures";}
    
    print"<td bgcolor=$background><b><font color=$fontcolor>Register Fix</font></b></td>  
    <td bgcolor=$basecolor><select size=1 name=watchdog>
    <option selected value='$watchdog'>$dwatchdog</option>
    <option value='2'>2</option>
    <option value='3'>3</option>
    <option value='4'>4</option>
    <option value='6'>6</option>
    <option value='10'>10</option>
    <option value='99'>OFF</option>
    </select>$portd<br> Rotates port on x falures"; 
 $width=600;$height=400;$in=15;Show_help($in);
print"</td> 

    <td bgcolor=$background><b><font color=$fontcolor>Display Nodes</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=DisplayNodes>";
    if ($DisplayNodes){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>";
$width=500;$height=200;$in=16;Show_help($in);
print"</td>                
                                      
    <td bgcolor=$background><b><font color=$fontcolor>Link Check<br>Schedule</font></b></td>  
    <td bgcolor=$basecolor><select size=1 name=LinkCheck>";
    if ($LinkCheck==0){ print"<option selected value='0'>OFF</option><option value='1'>15mins</option><option value='2'>30mins</option>";}
    if ($LinkCheck==1){ print"<option value='0'>OFF</option><option selected value='1'>15mins</option><option value='2'>30mins</option>";}
    if ($LinkCheck==2){ print"<option value='0'>OFF</option><option value='1'>15mins</option><option selected value='2'>30mins</option>";}
    print"</select>";
$width=400;$height=200;$in=17;Show_help($in);
print"</td>     
    </tr>";
    
      
// These need to be activated after import    

print"<tr>    
   <td bgcolor=$background><b><font color=$fontcolor>ID Type*</font></b></td>  
   <td bgcolor=$basecolor><select size=1 name=idType>";
    if ($idType==0){ print"<option selected value='0'>OFF</option><option value='1'>Voice/Morse</option><option value='6'>Voice/Short Morse</option><option value='2'>Morse</option><option value='3'>Morse/ Short Morse</option><option value='4'>Short Morse</option><option value='5'>Burst</option>";}
    if ($idType==1){ print"<option value='0'>OFF</option><option selected value='1'>Voice/Morse</option><option value='6'>Voice/Short Morse</option><option value='2'>Morse</option><option value='3'>Morse/ Short Morse</option><option value='4'>Short Morse</option><option value='5'>Burst</option>";}
    if ($idType==2){ print"<option value='0'>OFF</option><option value='1'>Voice/Morse</option><option value='6'>Voice/Short Morse</option><option selected value='2'>Morse</option><option value='3'>Morse/ Short Morse</option><option value='4'>Short Morse</option><option value='5'>Burst</option>";}
    if ($idType==3){ print"<option value='0'>OFF</option><option value='1'>Voice/Morse</option><option value='6'>Voice/Short Morse</option><option value='2'>Morse</option><option selected value='3'>Morse/ Short Morse</option><option value='4'>Short Morse</option><option value='5'>Burst</option>";}
    if ($idType==4){ print"<option value='0'>OFF</option><option value='1'>Voice/Morse</option><option value='6'>Voice/Short Morse</option><option value='2'>Morse</option><option value='3'>Morse/ Short Morse</option><option selected value='4'>Short Morse</option><option value='5'>Burst</option>";}
    if ($idType==5){ print"<option value='0'>OFF</option><option value='1'>Voice/Morse</option><option value='6'>Voice/Short Morse</option><option value='2'>Morse</option><option value='3'>Morse/ Short Morse</option><option value='4'>Short Morse</option><option selected value='5'>Burst</option>";}
    if ($idType==6){ print"<option value='0'>OFF</option><option value='1'>Voice/Morse</option><option selected value='6'>Voice/Short Morse</option><option value='2'>Morse</option><option value='3'>Morse/ Short Morse</option><option value='4'>Short Morse</option><option value='5'>Burst</option>";}

    print"</select>";
$width=400;$height=200;$in=18;Show_help($in);
print"</td>     
 
    <td bgcolor=$background><b><font color=$fontcolor>Incoming tone*</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=inTone>";
    if ($inTone){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>";
$width=300;$height=200;$in=19;Show_help($in);
print"</td>     

    <td bgcolor=$background><b><font color=$fontcolor>Outgoing tone Linked*</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=outToneL>";
    if ($outToneL){print"<option selected value='1'>True</option><option value='0'>False</option>";}
   else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
   print"</select>";
$width=300;$height=200;$in=19;Show_help($in);
print"</td>    

   <td bgcolor=$background><b><font color=$fontcolor>Outgoing tone Unlinked*</font></b></td>
   <td bgcolor=$basecolor><select size=1 name=outToneU>";
   if ($outToneU){print"<option selected value='1'>True</option><option value='0'>False</option>";}
   else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
   print"</select>";
$width=300;$height=200;$in=19;Show_help($in);
print"</td>    
   </tr>";      


$Statedata= file("$path/states.csv");
$action="";$femaD=$fema;
foreach($Statedata as $line){ 
$line  = str_replace(" ", "", $line );
$uu = explode(",",$line);
//$line = strtoupper($line);
if ($fema==$uu[1]){$femaD=$uu[0];}  
$action="$action <option value='$uu[1]'>$uu[0]</option>\n";
}
 
print "<tr>
    <td bgcolor=$background><b><font color=$fontcolor>Fema State<br>Parish/County</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=fema>
    <option selected value=''>OFF Disabled</option>
    <option selected value='$fema'>$femaD</option>
    $action
    </select><br><input type='text' name='parishCounty' size='10' value='$parishCounty'>";                                                                                                    
$width=300;$height=300;$in=23;Show_help($in);
print"</td> 
    <td bgcolor=$background><b><font color=$fontcolor>Say Warn<br>Say Watch</font></b></td>
    <td bgcolor=$basecolor>
    <select size=1 name=sayWarn>";
    if ($sayWarn){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select><br>
    <select size=1 name=sayWatch>";
    if ($sayWatch){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>";
$width=300;$height=200;$in=24;Show_help($in);
print"</td>     
    
    <td bgcolor=$background><b><font color=$fontcolor>Say Advisory<br>Statements</font></b></td>
    <td bgcolor=$basecolor>
    <select size=1 name=sayAdvisory>";
    if ($sayAdvisory){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select><br>
    <select size=1 name=sayStatement>";
    if ($sayStatement){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select>";
$width=300;$height=200;$in=24;Show_help($in);
print"</td>     


   <td bgcolor=$background><b><font color=$fontcolor>Latitude<br>Longitude</font></b></td>
   <td bgcolor=$basecolor><input type='text' name='lat' size='10' value='$lat'><br>
   <input type='text' name='lon' size='10' value='$lon'>";
$width=300;$height=200;$in=30;Show_help($in);
print"</td>    

    </tr>";    
    

   
print"<tr>
    <td bgcolor=$background><b><font color=$fontcolor>Mute Wen Net1<br>Start Time<br>Stop Time</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=MuteNet1>";
    if ($MuteNet1){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select><br>
    <input type='text' name='Net1Start' size='3' value='$Net1Start'>24hr<br>
    <input type='text' name='Net1Stop' size='3' value='$Net1Stop'>";
$width=300;$height=200;$in=31;Show_help($in);
print"</td>     

    <td bgcolor=$background><b><font color=$fontcolor>Mute Sun Net2<br>Start Time<br>Stop Time</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=MuteNet2>";
    if ($MuteNet2){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select><br>
    <input type='text' name='Net2Start' size='3' value='$Net2Start'>24hr<br>
    <input type='text' name='Net2Stop' size='3' value='$Net2Stop'>";
$width=300;$height=200;$in=31;Show_help($in);
print"</td>     
 
    <td bgcolor=$background><b><font color=$fontcolor>Mute Fri Net3<br>Start Time<br>Stop Time</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=MuteNet3>";
    if ($MuteNet3){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select><br>
    <input type='text' name='Net3Start' size='3' value='$Net3Start'>24hr<br>
    <input type='text' name='Net3Stop' size='3' value='$Net3Stop'>";
$width=300;$height=200;$in=31;Show_help($in);
print"</td>    
    
    <td bgcolor=$background><b><font color=$fontcolor>Mute at Nite</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=sleep>";
    if ($sleep){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
print"</select>";
$width=300;$height=200;$in=32;Show_help($in);
print"</td></tr>";    




print"<tr>
    <td bgcolor=$background>
    <b><font color=$fontcolor>Speak Name</font></b></br>
    <b><font color=$fontcolor>Hot Temp</font></b></br>
    <b><font color=$fontcolor>High Temp</font></b></br>
    <b><font color=$fontcolor>Report Normal</font></b>
    </td>
    <td bgcolor=$basecolor><select size=1 name=nodeName>";
if ($nodeName=="server"){     print"<option selected value='server'>Server</option><option value='repeator'>Repeator</option>         <option value='node'>Node</option>         <option value='tower'>Tower</option>         <option value='temperature'>Temperature</option>";}
if ($nodeName=="repeator"){   print"<option  value='server'>Server</option>        <option selected value='repeator'>Repeator</option><option value='node'>Node</option>         <option value='tower'>Tower</option>         <option value='temperature'>Temperature</option>";}
if ($nodeName=="node"){       print"<option  value='server'>Server</option>        <option value='repeator'>Repeator</option>         <option selected value='node'>Node</option><option value='tower'>Tower</option>         <option value='temperature'>Temperature</option>";}
if ($nodeName=="tower"){      print"<option  value='server'>Server</option>        <option value='repeator'>Repeator</option>         <option value='node'>Node</option>         <option selected value='tower'>Tower</option><option value='temperature'>Temperature</option>";}
if ($nodeName=="temperature"){print"<option  value='server'>Server</option>        <option value='repeator'>Repeator</option>         <option value='node'>Node</option>         <option value='tower'>Tower</option>         <option selected value='temperature'>Temperature</option>";}
if ($nodeName==""){           print"<option selected value='server'>Server</option><option value='repeator'>Repeator</option>         <option value='node'>Node</option>         <option value='tower'>Tower</option>         <option value='temperature'>Temperature</option>";}
print"</select></br>
<input type='text' name='hot'  size='3' value='$hot'>50&#8451;</br>
<input type='text' name='high' size='3' value='$high'>60&#8451;</br>
<select size=1 name=reportAll>";
if ($reportAll){print"<option selected value='1'>True</option><option value='0'>False</option>";}
else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
print"</select>";
$width=400;$height=200;$in=33;Show_help($in);
print"</td>";



if (!file_exists("$docRouteP/gmrs/admin/setup-edit.php")){$docRouteP=$rootDir; }

//$docRouteP = "/srv/http";// PI default       
print"
<td bgcolor=$background><b><font color=$fontcolor>Doc Route</font></b></td>
<td bgcolor=$basecolor><input type='text' name='docRouteP' size='8' value='$docRouteP'><br> Actual:[$rootDir] ";
$width=400;$height=200;$in=34;Show_help($in);
print"
</td>
<td bgcolor=$background></td>
<td bgcolor=$basecolor></td>
<td bgcolor=$background></td>
<td bgcolor=$basecolor></td>
</tr>";
print"</table></div>";

print "<center><small>*= requires a ast restart (no not restart untill settings say live.)<a href=setup-edit.php> - Reload Page to Check - </a> $safe"; $width=400;$height=300;$in=50;Show_help($in);
print"</center></small></td>"; 

print "<br><center><input type=\"submit\" value=\"Submit\" name=\"B1\"></form></center>";
print"<!-- setup is (c)2023/2024 by lagmrs.com all rights reserverd-->\n";
include ("$rootDir/gmrs/footer.php");

function Show_help($in){
global $width,$height,$in;
print "<a href=\"#\" onclick=\"window.open('/gmrs/admin/help.php?help=$in', 'Help', 'width=$width,height=$height');\"><img src=\"/gmrs/images/help.gif\"></a>";
}
?>
