 <?php
// ***************************************************
// (c)2015/2023 by The Master lagmrs.com  by pws.winnfreenet.com
// I license you to use this on your copy of this software only.
// File is protected in admin directory no need to check for logoins
//
// This is the web editor for Node Manager
// Some items will be in the AST editor because this file only hold flags for the cmd line setup prg
//
// Files saved here will be loaded from cron on a schedule . Save is not live

$verGMRS="v1.1";  $save=false; $in="";$out="";
$path  = "/etc/asterisk/local/mm-software";
$datum = date('m-d-Y-H:i:s');
include_once("/srv/http/gmrs/global.php");
include_once("/srv/http/gmrs/common.php"); 

$fileAllMon = "/srv/http/gmrs/admin/allmon.ini";       
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);// load the now secure file

include_once ("/etc/asterisk/local/mm-software/supermon_input.php");

include_once("/srv/http/gmrs/header.php"); 
include_once("/srv/http/gmrs/menu.php"); 


$fileWEB="/tmp/setup.txt";  // We have write permission
$fileSET="/etc/asterisk/local/mm-software/setup.txt"; // We have read only permissions

$astport = exec("$CAT /etc/asterisk/iax.conf |$EGREP 'bindport' |$SED 's/bindport=//g'");
if($astport<>4569) {$portd="[port:$astport Floating]";}
else{$portd="[port:$astport]";}



if(sizeof($fieldNames)>1) {
for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'B1'){       $save=true;}
if ($fieldNames[$i] == 'ambientApiKey'){$ambientApiKey = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'parishCounty') {$parishCounty  = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'fema')      {$fema = $fieldValues[$i] ;} // ol
if ($fieldNames[$i] == 'startUp')   {$startUp   = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'startUpNode') {$startUpNode = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'coreVersion')   {$coreVersion  = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'burst')    {$burst = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'DisplayNodes')  {$DisplayNodes = $fieldValues[$i] ;}

if ($fieldNames[$i] == 'Net1Start'){$Net1Start  = $fieldValues[$i];}
if ($fieldNames[$i] == 'Net1Stop') {$Net1Stop  = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'MuteNet1') {$MuteNet1  = $fieldValues[$i] ;}

if ($fieldNames[$i] == 'Net2Start'){$Net2Start  = $fieldValues[$i];}
if ($fieldNames[$i] == 'Net2Stop') {$Net2Stop  = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'MuteNet2') {$MuteNet2  = $fieldValues[$i] ;}

if ($fieldNames[$i] == 'Net3Start'){$Net3Start  = $fieldValues[$i];}
if ($fieldNames[$i] == 'Net3Stop') {$Net3Stop  = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'MuteNet3') {$MuteNet3  = $fieldValues[$i] ;}

if ($fieldNames[$i] == 'tts')      {$tts= $fieldValues[$i];}
if ($fieldNames[$i] == 'sleep')    {$sleep   = $fieldValues[$i];}

if ($fieldNames[$i] == 'IconBlock'){$IconBlock         = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'debug')    {$debug  = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'node')     {$node = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'station')  {$station  = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'level')    {$level = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'zipcode')  {$zipcode = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'lat')      {$lat  = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'lon')      {$lon  = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'sayWarn')  {$sayWarn= $fieldValues[$i] ;}
if ($fieldNames[$i] == 'sayWatch') {$sayWatch  = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'sayAdvisory'){$sayAdvisory  = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'sayStatement'){$sayStatement = $fieldValues[$i] ;}

if ($fieldNames[$i] == 'sleep')    {$sleep  = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'high')     {$high  = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'hot')      {$hot  = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'nodeName') {$nodeName = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'reportAll'){$reportAll  = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'LinkCheck'){$LinkCheck  = $fieldValues[$i] ;}


if ($fieldNames[$i] == 'bridgeCheck'){$bridgeCheck = $fieldValues[$i] ;}

if ($fieldNames[$i] == 'outToneL'){$outToneL = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'outToneU'){$outToneU = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'inTone')  {$inTone = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'idType')  {$idType = $fieldValues[$i] ;}  
if ($fieldNames[$i] == 'hideIP')  {$hideIP = $fieldValues[$i] ;}

if ($fieldNames[$i] == 'debug')   {$debug = $fieldValues[$i] ;}  
if ($fieldNames[$i] == 'beta')    {$beta = $fieldValues[$i] ;}

if ($fieldNames[$i] == 'watchdog'){$watchdog = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'nodeName'){$nodeName = $fieldValues[$i] ;}
if ($fieldNames[$i] == 'saveDate'){$saveDate = $fieldValues[$i] ;}

}

if($save){
 // save config task  30 data points with spares for expansion
$datum = date('m-d-Y-H:i:s');
$fileOUT = fopen($fileWEB, "w");
fwrite ($fileOUT, "$path,$node,$station,$level,$zipcode,$IconBlock,$lat,$lon,$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,$sleep,$high,$hot,$nodeName,$reportAll,$datum,$LinkCheck,$beta,$watchdog,$debug,$tts,$bridgeCheck,$MuteNet1,$MuteNet2,$MuteNet3,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,$DisplayNodes,$burst,$startUp,$startUpNode,$parishCounty,$fema,$ambientApiKey,$hideIP,$idType,$inTone,$outToneL,$outToneU,,,,,,,,,,,,");
fclose ($fileOUT);
print"<!-- New save created. Data is loaded from submission -->\n";
}
}
else{include_once ("/etc/asterisk/local/mm-software/supermon_load_setup.php");}

?>
<div align="center">
<font color="GREEN" size="6"><h1>Node Manager</h1></font>
<center>
<?php
if($save){print"<p><b>Setup was Saved.<br>Waiting for import into live setup.</b></p>";}
else{     print"<p><b>$status</b></p>";}

?>
</center><form method="GET" name="config" action="/gmrs/admin/setup-edit.php">
<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" id="AutoNumber1">
<?php

print "

<input type='hidden' name='saveDate' value='$datum'>
<input type='hidden' name='idType' value='$idType'>
<input type='hidden' name='inTone' value='$inTone'>
<input type='hidden' name='outToneL' value='$outToneL'>
<input type='hidden' name='outToneU' value='$outToneU'>
";


//"$path,$node,$station,$level,$zipcode,$IconBlock,$lat,$lon,
//$sayWarn,$sayWatch,$sayAdvisory,$sayStatement,
//$sleep,$high,$hot,$nodeName,$reportAll,$datum,
//$LinkCheck,$beta,$watchdog,$debug,$tts,$,
//$MuteNet1,$MuteNet2,$MuteNet3,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop,
//$DisplayNodes,$burst,
//$startUp,$startUpNode,  // start up 
//$parishCounty,$fema,$ambientApiKey,
//$hideIP,$idType,$inTone,$outToneL,$outToneU,$bridgeMonitor bridgeCheck



$background="#808080"; $fontcolor="white";$basecolor="#FFFFCC";

print "<tr>
   <td bgcolor=$background><b><font color=$fontcolor>Node</font></b></td>
   <td bgcolor=$basecolor><input type='text' name='node' size='20' value='$node'></td>
   <td bgcolor=$background><b><font color=$fontcolor>MDC1200 Burst</font></b></td>
   <td bgcolor=$basecolor><input type='text' name='burst' size='8' value='$burst'></td>
   <td bgcolor=$background><b><font color=$fontcolor>Latitude</font></b></td>
   <td bgcolor=$basecolor><input type='text' name='lat' size='10' value='$lat'> <a href=https://gps-coordinates.org/ targer=_blank>Lat/Lon Lookup</a></td>
   <td bgcolor=$background><b><font color=$fontcolor>Longitude</font></b></td>
   <td bgcolor=$basecolor><input type='text' name='lon' size='10' value='$lon'></td>
</tr>";



print"<tr>
    <td bgcolor=$background><b><font color=$fontcolor>Ambient Weather</font></b></td>
    <td bgcolor=$basecolor><input type='text' name='ambientApiKey' size='20' value='$ambientApiKey'><br>Your API Station Key</td>
    <td bgcolor=$background><b><font color=$fontcolor>NWS Station</font></b></td>
    <td bgcolor=$basecolor><input type='text' name='station' size='8' value='$station'><br>Airport or MADIS station <a href=https://madis-data.ncep.noaa.gov/MadisSurface/ target=_blank>Map</a></td>
    <td bgcolor=$background><b><font color=$fontcolor>Level</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=level>";
    
    if ($level== 0){print"<option selected value='0'>OFF</option>";}
    else {print"<option value='0'>OFF</option>";}
    if ($level== 1){print"<option selected value='1'>Temp</option>";}
    else {print"<option value='1'>Temp</option>";}
    if ($level== 2){print"<option selected value='2'>Temp,Cond</option>";}
    else {print"<option value='2'>Temp,Cond</option>";}
    if ($level== 3){print"<option selected value='3'>Temp,Cond,Wind Hum Rain</option>";}
    else {print"<option value='3'>Temp,Cond,Wind Hum Rain</option>";}
    if ($level== 4){print"<option selected value='4'>Temp,Cond,Wind Hum Rain,Forcast</option>";}
    else {print"<option value='4'>Temp,Cond,Wind Hum Rain,Forcast</option>";}

    print "</select>
    
    <td bgcolor=$background><b><font color=$fontcolor>Icons Block</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=IconBlock>";
    if ($IconBlock){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select></td>    
    </tr>";
  
print"<tr>
    <td bgcolor=$background><b><font color=$fontcolor>TTS Key</font></b></td>
    <td bgcolor=$basecolor><input type='text' name='tts' size='20' value='$tts'><br>Your TTS Key <a href=https://voicerss.org/ target=_blank>Voicerss</a></td>
    <td bgcolor=$background><b><font color=$fontcolor>Zipcode</font></b></td>
    <td bgcolor=$basecolor><input type='text' name='zipcode' size='8' value='$zipcode'></td>     


    <td bgcolor=$background><b><font color=$fontcolor>Bridge Check</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=bridgeCheck>";
    if ($bridgeCheck){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select><br>Stop you from bridging</td> 
                                      
    
    <td bgcolor=$background><b><font color=$fontcolor>Bridge Monitor</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=bridgeMonitor>";
    if ($bridgeMonitor){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select><br>Detect others Bridging</td>    
    </tr>";  
    
print"<tr>    
    
    <td bgcolor=$background><b><font color=$fontcolor>Startup Connect</font></b></td>  
    <td bgcolor=$basecolor><select size=1 name=startUp>";
    if ($startUp){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select><br><input type='text' name='startUpNode' size='8' value='$startUpNode'><br>Node to connect to</td>";     
    
    if($watchdog==99){$dwatchdog="off";}
    else{$dwatchdog="$watchdog falures";}
    
    print"<td bgcolor=$background><b><font color=$fontcolor>Register Fix</font></b></td>  
    <td bgcolor=$basecolor><select size=1 name=watchdog>
    <option selected value='$watchdog'>$dwatchdog</option>
    <option value='2'>2</option>
    <option value='3'>3</option>
    <option value='4'>4</option>
    <option value='6'>6</option>
    <option value='10'>10</option>
    <option value='99'>OFF</option>
    </select>$portd<br> Rotates port on x falures</td>  


    <td bgcolor=$background><b><font color=$fontcolor>Display Nodes</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=DisplayNodes>";
    if ($DisplayNodes){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select><br>Display All nodes under status</td> 
                                      
    <td bgcolor=$background><b><font color=$fontcolor>Link Check</font></b></td>  
    <td bgcolor=$basecolor><select size=1 name=LinkCheck>";
    if ($LinkCheck==0){ print"<option selected value='0'>OFF</option><option value='1'>15mins</option><option value='2'>30mins</option>";}
    if ($LinkCheck==1){ print"<option value='0'>OFF</option><option selected value='1'>15mins</option><option value='2'>30mins</option>";}
    if ($LinkCheck==2){ print"<option value='0'>OFF</option><option value='1'>15mins</option><option selected value='2'>30mins</option>";}
    print"</select><br>Schedule</td>  
    </tr>";
    
      
    

// these are just flags used by the setup program. 
// To be moved into ast setup page. These varables reserved for something else.
// This display will show the settings but changing wont do anything.

if($debug){
print"<tr>    
   <td bgcolor=$background><b><font color=$fontcolor>ID Type</font></b></td>  
   <td bgcolor=$basecolor><select size=1 name=idType>";
    if ($idType==0){ print"<option selected value='0'>OFF</option><option value='1'>Voice</option><option value='2'>Voice/Morse</option><option value='3'>Morse/ Short Morse</option><option value='4'>Short Morse</option><option value='5'>Burst</option>";}
    if ($idType==1){ print"<option value='0'>OFF</option><option selected value='1'>Voice</option><option value='2'>Voice/Morse</option><option value='3'>Morse/ Short Morse</option><option value='4'>Short Morse</option><option value='5'>Burst</option>";}
    if ($idType==2){ print"<option value='0'>OFF</option><option value='1'>Voice</option><option selected value='2'>Voice/Morse</option><option value='3'>Morse/ Short Morse</option><option value='4'>Short Morse</option><option value='5'>Burst</option>";}
    if ($idType==3){ print"<option value='0'>OFF</option><option value='1'>Voice</option><option value='2'>Voice/Morse</option><option selected value='3'>Morse/ Short Morse</option><option value='4'>Short Morse</option><option value='5'>Burst</option>";}
    if ($idType==4){ print"<option value='0'>OFF</option><option value='1'>Voice</option><option value='2'>Voice/Morse</option><option value='3'>Morse/ Short Morse</option><option selected value='4'>Short Morse</option><option value='5'>Burst</option>";}
    if ($idType==5){ print"<option value='0'>OFF</option><option value='1'>Voice</option><option value='2'>Voice/Morse</option><option value='3'>Morse/ Short Morse</option><option value='4'>Short Morse</option><option selected value='5'>Burst</option>";}
    print"</select></td>     
    <td bgcolor=$background><b><font color=$fontcolor>Incoming tone</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=inTone>";
    if ($inTone){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select></td> 
    <td bgcolor=$background><b><font color=$fontcolor>Outgoing tone Linked</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=outToneL>";
    if ($outToneL){print"<option selected value='1'>True</option><option value='0'>False</option>";}
   else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
   print"</select></td> 
   <td bgcolor=$background><b><font color=$fontcolor>Outgoing tone Unlinked</font></b></td>
   <td bgcolor=$basecolor><select size=1 name=outToneU>";
   if ($outToneU){print"<option selected value='1'>True</option><option value='0'>False</option>";}
   else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
   print"</select></td> 
   </tr>";      
}

 
print "<tr>
    <td bgcolor=$background><b><font color=$fontcolor>Fema State</font></b></td>
    <td bgcolor=$basecolor><input type='text' name='fema' size='10' value='$fema'></td>



   <td bgcolor=$background><b><font color=$fontcolor>Parish/County</font></b></td>
   <td bgcolor=$basecolor><input type='text' name='parishCounty' size='10' value='$parishCounty'></td>
   

    <td bgcolor=$background><b><font color=$fontcolor>Hide IP on boot</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=hideIP>";
    if ($hideIP){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {         print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select></td> 
   
   <td bgcolor=$background><b><font color=$fontcolor>Node Name</font></b></td>
      <td bgcolor=$basecolor><input type='text' name='nodeName' size='10' value='$nodeName'></td>
</tr>";    
    

print"<tr>
    <td bgcolor=$background><b><font color=$fontcolor>Say Warn</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=sayWarn>";
    if ($sayWarn){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select></td>";
    
print"<td bgcolor=$background><b><font color=$fontcolor>Say Watch</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=sayWatch>";
    if ($sayWatch){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select></td>";
    
print"<td bgcolor=$background><b><font color=$fontcolor>Advisory</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=sayAdvisory>";
    if ($sayAdvisory){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select></td>";
    
print"<td bgcolor=$background><b><font color=$fontcolor>Statement</font></b></td>
     <td bgcolor=$basecolor><select size=1 name=sayStatement>";
    if ($sayStatement){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select></td>
   </tr>";

//  $MuteNet1,$MuteNet2,$MuteNet3,$Net1Start,$Net1Stop,$Net2Start,$Net2Stop,$Net3Start,$Net3Stop  
   
print"<tr>
    <td bgcolor=$background><b><font color=$fontcolor>Mute WEN Net1</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=MuteNet1>";
    if ($MuteNet1){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select></td>";
    
print"<td bgcolor=$background><b><font color=$fontcolor>Start Time</font></b></td>
    <td bgcolor=$basecolor><input type='text' name='Net1Start' size='3' value='$Net1Start'></td>
    <td bgcolor=$background><b><font color=$fontcolor>Start Time</font></b></td>
    <td bgcolor=$basecolor><input type='text' name='Net1Stop' size='3' value='$Net1Stop'></td>

    <td bgcolor=$background><b><font color=$fontcolor>Debug</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=debug>";
    if ($debug){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select></td>";   

    
print"<tr>
    <td bgcolor=$background><b><font color=$fontcolor>Mute SUN Net2</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=MuteNet2>";
    if ($MuteNet2){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select></td>";    
    
    
print"<td bgcolor=$background><b><font color=$fontcolor>Start Time</font></b></td>
    <td bgcolor=$basecolor><input type='text' name='Net2Start' size='3' value='$Net2Start'></td>
    <td bgcolor=$background><b><font color=$fontcolor>Start Time</font></b></td>
    <td bgcolor=$basecolor><input type='text' name='Net2Stop' size='3' value='$Net2Stop'></td>
    

     <td bgcolor=$background><b><font color=$fontcolor>Beta Features</font></b></td>
     <td bgcolor=$basecolor><select size=1 name=beta>";
    if ($beta){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select></td>
   </tr>";
    
print"<tr>
    <td bgcolor=$background><b><font color=$fontcolor>Mute FRI Net3</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=MuteNet3>";
    if ($MuteNet3){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select></td>";    
    
    
print"<td bgcolor=$background><b><font color=$fontcolor>Start Time</font></b></td>
    <td bgcolor=$basecolor><input type='text' name='Net3Start' size='3' value='$Net3Start'></td>
    <td bgcolor=$background><b><font color=$fontcolor>Start Time</font></b></td>
    <td bgcolor=$basecolor><input type='text' name='Net3Stop' size='3' value='$Net3Stop'></td>
    <td bgcolor=$background><b><font color=$fontcolor>Nite Mute</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=sleep>";
    if ($sleep){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select></td>";    
              
   
print"</tr>";


print"<tr><td bgcolor=$background><b><font color=$fontcolor>Hot Temp</font></b></td>
    <td bgcolor=$basecolor><input type='text' name='hot' size='3' value='$hot'></td>

    <td bgcolor=$background><b><font color=$fontcolor>High Temp</font></b></td>
    <td bgcolor=$basecolor><input type='text' name='high' size='3' value='$high'></td>

    <td bgcolor=$background><b><font color=$fontcolor>Report Normal</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=reportAll>";
    if ($reportAll){print"<option selected value='1'>True</option><option value='0'>False</option>";}
    else {        print"<option value='1'>True</option><option selected value='0'>False</option>";}
    print"</select></td>   
       
    <td bgcolor=$background><b><font color=$fontcolor>Server Name</font></b></td>
    <td bgcolor=$basecolor><select size=1 name=server>";
    if ($server=="server"){ print"<option selected value='server'>Server</option><option value='repeator'>Repeator</option><option value='node'>Node</option><option value='tower'>Tower</option><option value='temperature'>Temperature</option>";}
    if ($server=="repeator"){ print"<option  value='server'>Server</option><option selected value='repeator'>Repeator</option><option value='node'>Node</option><option value='tower'>Tower</option><option value='temperature'>Temperature</option>";}
    if ($server=="node"){ print"<option  value='server'>Server</option><option value='repeator'>Repeator</option><option selected value='node'>Node</option><option value='tower'>Tower</option><option value='temperature'>Temperature</option>";}
    if ($server=="tower"){ print"<option  value='server'>Server</option><option value='repeator'>Repeator</option><option value='node'>Node</option><option selected value='tower'>Tower</option><option value='temperature'>Temperature</option>";}
    if ($server=="temperature"){ print"<option  value='server'>Server</option><option value='repeator'>Repeator</option><option value='node'>Node</option><option value='tower'>Tower</option><option selected value='temperature'>Temperature</option>";}
    if ($server==""){ print"<option selected value='server'>Server</option><option value='repeator'>Repeator</option><option value='node'>Node</option><option value='tower'>Tower</option><option value='temperature'>Temperature</option>";}
    print"</select></td></tr>";
    

      
              
   
print"</table></div>";

print "<br><center><input type=\"submit\" value=\"Submit\" name=\"B1\"></form></center>


";
include ("/srv/http/gmrs/footer.php");
?>
