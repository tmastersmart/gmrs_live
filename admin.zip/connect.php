<?php
//
//  GMRS supermon v1 11/24/23
// v1.1 12/27/23  Bug in manual connect fields
// v1.3 12/27/23  extra Error traps
// v1.5 multi node support . direct link support
// v1.7 1/14/24

$verGMRS="v1.7";$releaseGMRS="1/14/2024";  $pageTitle="Connection Control";
 
$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
$path         = "/etc/asterisk/local/mm-software";  

include_once("$rootDir/gmrs/global.php"); // includes the local settings
include_once("$rootDir/gmrs/common.php"); // includes the main settings

$fileAllMon = "$rootDir/gmrs/admin/allmon.ini";
if (file_exists($fileAllMon)){$config = parse_ini_file($fileAllMon, true);}


include_once("$rootDir/gmrs/header.php"); 
include_once("$rootDir/gmrs/menu.php"); 
include_once("$path/supermon_input.php");
include_once("$rootDir/gmrs/admin/ami-functions.php");



for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'remotenode'){ $remotenode  = $fieldValues[$i];}
if ($fieldNames[$i] == 'T1')        { $remotenode = $fieldValues[$i]; } // TBR
if ($fieldNames[$i] == 'type')      { $connectType = $fieldValues[$i];} // types C,CP,D,DP,DA,M,ML
if ($fieldNames[$i] == 'localnode') { $localnode = $fieldValues[$i];  }
if ($fieldNames[$i] == 'nodes')   {            $nodes = $fieldValues[$i]; }
}


// all unneeded since its already validated buit just to be safe.
$remotenode = @trim($remotenode);
$connectType= @trim($connectType);
$localnode = @trim($localnode);


include_once ("$path/supermon_load_setup.php");  
if (!$localnode){ $localnode = $node;}

print"<div align=center><font color=GREEN size=6><h1>$pageTitle Page</h1></font></div>";

if($connectType){
$ilink="";


if($remotenode){
 if ($connectType == "C" or $connectType =="CP") {
  if ($connectType =="CP") {$ilink = 13;print "<b>Permanently Connecting $localnode to $remotenode<br>";} 
  else {$ilink = 3; print "<b>Connecting $localnode to $remotenode<br>";}
 } 

if ($connectType == "M" or $connectType == "MP") {  
  if ($connectType == "MP") { $ilink = 12; print "<b>Permanently Monitoring $remotenode from $localnode<br>";}
  else { $ilink = 2; print "<b>Monitoring $remotenode from $localnode<br>";}
} 

if ($connectType == "ML" or $connectType == "MLP") {
  if ($connectType == "MLP") {$ilink = 18; print "<b>Permanently Local Monitoring $remotenode from $localnode<br>";}
  else {$ilink = 8; print "<b>Local Monitoring $remotenode from $localnode<br>";}
} 

if ($connectType == "D" or $connectType =="DP") {  $ilink = 11; print "<b>Permanently Disconnect $remotenode from $localnode<br>";}
print"</b><b><br> Sent command [$localnode ilink $ilink $remotenode] </b>";
}

if ($connectType == "DA" ) {
$ilink = 6; $remotenode="";
print "<b>Disconnect ALL LINKS from $localnode<br>";
print"</b><b><br> Sent command [$localnode ilink $ilink] </b>"; // remotenode not needed or used
}

// Error checking if no ilink set above
if($ilink){
$fp = AMIconnect($config[$localnode]['host']); // Open a socket to Asterisk Manager
if (FALSE === $fp) { print"Could not connect.<br>";}
if (FALSE === AMIlogin($fp, $config[$localnode]['user'], $config[$localnode]['passwd'])) {	print"Login failed.<br>";}

$AMI1 = AMIcommand ($fp, "rpt cmd $localnode ilink $ilink $remotenode");
print "<p>Status: $AMI1</p>";
 }
else {print"Received Command [$connectType] with a missing Node #<br>";} 
}
//else {print"No valid commands received <br>";}


// create a hub connect field
$nodelistHub = "$path/nodelist/hubs_online.csv";// Cleaned up nodelist
$action2= "<select name=\"T1\" >\n"; 
$randomS = mt_rand(1, 2);
if ($randomS==1){$hub="1195";}
//if ($randomS==2){$hub="2250";}
if ($randomS==2){$hub="700";}
if (file_exists($nodelistHub)) {
 $fileIN= file($nodelistHub); 
 foreach($fileIN as $line){
 $u = explode("|",$line);
 $string=$u[1];  
 if (strtoupper($string) == $string)  {$string=strtolower($string);}// ALL caps fix 
 $string = (strlen($string) > 30) ? substr($string,0,30).'...' : $string;
 if($u[0]==$hub){$action2="$action2 <option style=\"margin-top:10px;\" value=\"$u[0]\" selected>$u[0] $string</option>\n";}   
 else{$action2="$action2 <option style=\"margin-top:10px;\" value=\"$u[0]\">$u[0] $string</option>\n";}
 }
 $action2="$action2 </select>";  
 } 
else{
 print"\n<!--Requesting a nodelist rebuild -->\n";
 $flag  ="/tmp/nodelist_needs_update.txt"; $fileOUT = fopen($flag,'w');fwrite ($fileOUT,"$datum");fclose ($fileOUT);
 $action2="$action2 <option style=\"margin-top:10px;\" value=\"1195\" selected>RoadKill</option></select>\n"; 
}


$passedNodes = explode(',', @trim($nodes));// for PHP code
// Remove nodes not in our allmon.ini file.
$nodes=array();
foreach ($passedNodes as $i => $nodeZ) {
 if (isset($config[$nodeZ])) {$nodes[] = $nodeZ;} 
 else {$nodes[0]=$node;}  // Default to our node for directloading
}

include("$path/supermon_display_cache.php");
// Build the local nodelist selection
$count=count($nodes); $action=""; $controlNodes="";
print"\n<!-- Connect form start count:$count-->\n";
if ($count>0) {
  $action= "<select name=\"localnode\" >\n";
        foreach ($nodes as $nodex) {
        print"\n<!-- $nodex-->\n";
        if (isset($astdb[$nodex])){ $info = $astdb[$nodex][1] ." ". $astdb[$nodex][2] ; }
        else{ 
          $info = "Pending";
          if (file_exists($OurNodeCache)){unlink($OurNodeCache);}// Bad reset it.
          }
        $action="$action <option style=\"margin-top:10px;\" value=\"$nodex\">$nodex $info</option>\n";
        if (!$controlNodes){$controlNodes="$nodex";}
        else{$controlNodes="$controlNodes,$nodex";}
        }
  $action="$action </select>";
}
$piVersion = file_get_contents ("/proc/device-tree/model");
print"<!-- (c)2023/2024 by lagmrs.com all rights reserverd-->\n";
$image="/gmrs/images/GMRSLiveicon.jpg";
$pos = strpos("-$piVersion", "Pi 3 Model A"); if ($pos){$image="/gmrs/images/pi-3a.jpg";}
$pos = strpos("-$piVersion", "Pi 3 Model B"); if ($pos){$image="/gmrs/images/pi3b.jpg";}
$pos = strpos("-$piVersion", "Pi 4");         if ($pos){$image="/gmrs/images/pi4.jpg";}
print "<image src=$image align=right>";

print"
<div id=\"connect_form\" >

<form method=\"POST\" action=\"/gmrs/admin/connect.php\">
<table border=\"0\" cellspacing=\"0\" id=\"AutoNumber1\" align=\"left\" >
<tr>
<td colspan=\"3\" bgcolor=\"#000080\">
<p align=\"center\"><b><font color=\"#FFFFFF\" size=\"4\">Enter connection commands</font></b></p>
</td>
</tr>

<tr>
<td colspan=\"2\"> 
<font size=\"2\">Remote Node#</font><input type=\"text\" name=\"remotenode\" size=\"10\" id=\"remotenode\" style=\"margin-top: 10px;\">

<select size=\"1\" name=\"type\">
 <option value=\"C\" selected>Connect</option>
 <option value=\"CP\">Connect Perm</option>
 <option value=\"D\">Disconnect</option>
 <option value=\"DA\">Disconnect ALL</option>
 <option value=\"M\">Monitor</option>
 <option value=\"MP\">Monitor Perm</option>
 <option value=\"ML\">Monitor Local</option>
 <option value=\"MLP\">Monitor Local Perm</option>
 </select>
 </td>
<td>
<font size=\"2\">Local node#</font>
  $action

<input type=\"submit\" class=\"submit\" value=\"Submit\" name=\"B1\">
</form>
</td>
</tr>
<tr>
<td colspan=\"2\">
<div style=\"border-radius: 10px;\" id=\"connect_form\"      >
<form method=\"POST\" action=\"/gmrs/admin/connect.php\" >
$action2
  <select size=\"1\" name=\"type\">
  <option value=\"C\" selected>Connect</option>
  <option value=\"CP\">Connect Perm</option>
  </select>
</td>  
<td>
<font size=\"2\">Local node#</font>
  $action

<input type=\"submit\" class=\"submit\" value=\"Submit\" name=\"B2\" >
</form> 
</td>
</tr>

</table>
</div>





<br><br><br>


<br><br><br>




";



include ("$rootDir/gmrs/footer.php");

?>
