<?php
//
//  GMRS supermon v1 11/24/23

$verGMRS="v1.0";$releaseGMRS="11/24/2023";  


include_once("/srv/http/gmrs/global.php"); // includes the local settings
include_once("/srv/http/gmrs/common.php"); // includes the main settings

$fileAllMon = "/srv/http/gmrs/admin/allmon.ini";       
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);// load the now secure file

//$file = "/srv/http/gmrs/admin/allmon.ini";$favorites="";       
//if (file_exists($file)){ $favorites = parse_ini_file($file, true);}


include("/srv/http/gmrs/header.php"); 
include("/srv/http/gmrs/menu.php"); 


//error_reporting(E_ALL);
// upgraded to a more modern anti hacker input
$path         = "/etc/asterisk/local/mm-software";
include_once ("$path/supermon_input.php");

include('/srv/http/gmrs/admin/ami-functions.php');



for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'remotenode')    {  $remotenode  = $fieldValues[$i]; }
if ($fieldNames[$i] == 'T1')            { $remotenode = $fieldValues[$i]; }
if ($fieldNames[$i] == 'type')          {$connectType = $fieldValues[$i]; } // types C,CP,D,DP,DA,M,ML
if ($fieldNames[$i] == 'localnode'){       $localnode = $fieldValues[$i]; }
}


// all unneeded since its already validated buit just to be safe.
$remotenode = @trim($remotenode);
$connectType= @trim($connectType);
$localnode = @trim($localnode);


include_once ("$path/load.php");
if (!$localnode){ $localnode = $node;}
print"<b> Node Manager Connect/Disconnect Page </b>";

if($connectType){

// Open a socket to Asterisk Manager
$fp = AMIconnect($config[$localnode]['host']);
if (FALSE === $fp) { die("Could not connect.\n\n");}
if (FALSE === AMIlogin($fp, $config[$localnode]['user'], $config[$localnode]['passwd'])) {	die("Login failed.");}

if ($connectType == "C" or $connectType =="CP") {
  if ($connectType =="CP") {$ilink = 13;print "<b>Permanently Connecting $localnode to $remotenode";} 
  else {$ilink = 3; print "<b>Connecting $localnode to $remotenode";}
} 

if ($connectType == "M" or $connectType == "MP") {  
  if ($connectType == "MP") { $ilink = 12; print "<b>Permanently Monitoring $remotenode from $localnode";}
  else { $ilink = 2; print "<b>Monitoring $remotenode from $localnode";}
} 

if ($connectType == "ML" or $connectType == "MLP") {
  if ($connectType == "MLP") {$ilink = 18; print "<b>Permanently Local Monitoring $remotenode from $localnode";}
  else {$ilink = 8; print "<b>Local Monitoring $remotenode from $localnode";}
} 

if ($connectType == "D" or $connectType =="DP") {
  $ilink = 11; print "<b>Permanently Disconnect $remotenode from $localnode";// same code for both 
}

if ($connectType == "DA" ) {
  $ilink = 6; print "<b>Disconnect ALL LINKS from $localnode"; 
   }


print" Sending command [$localnode ilink $ilink $remotenode]</b>";

$AMI1 = AMIcommand ($fp, "rpt cmd $localnode ilink $ilink $remotenode");

print "<p>$AMI1</p>";
}


print"<b>Please Enter Remote Node and then Local node</b>
<div style=\"border-radius: 10px;\" id=\"connect_form\"      >
<form method=\"POST\" action=\"/gmrs/admin/connect.php\" target=\"_blank\" >
<input style=\"margin-top:10px;\" type=\"text\" name=\"T1\" size=\"10\" id=\"node\">
  <select size=\"1\" name=\"type\">
  <option value=\"C\" selected>Connect</option>
  <option value=\"CP\">Connect Perm</option>
  <option value=\"D\">Disconnect</option>
  <option value=\"DA\">Disconnect ALL</option>
  <option value=\"M\">Monitor</option>
  <option value=\"MP\">Monitor Perm</option>
  <option value=\"ML\">Monitor Local</option>
  <option value=\"MLP\">Monitor Local Perm</option>
  </select>
<input style=\"margin-top:10px;\" type=\"text\" name=\"T1\" size=\"10\" id=\"localnode\" value=\"$localnode\"> 

<input type=\"submit\" class=\"submit\" value=\"Submit\" name=\"B1\" >
</form> </div>
\n";


include ("/srv/http/gmrs/footer.php");

?>
