<?php
//
//  GMRS supermon v1 11/24/23
// v1.1 12/27/23  Bug in manual connect fields
// v1.3 12/27/23  extra Error traps

$verGMRS="v1.3";$releaseGMRS="12/28/2023";


include_once("/srv/http/gmrs/global.php"); // includes the local settings
include_once("/srv/http/gmrs/common.php"); // includes the main settings

$fileAllMon = "/srv/http/gmrs/admin/allmon.ini";       
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);// load the now secure file

//$file = "/srv/http/gmrs/admin/allmon.ini";$favorites="";       
//if (file_exists($file)){ $favorites = parse_ini_file($file, true);}


include("/srv/http/gmrs/header.php"); 
include("/srv/http/gmrs/menu.php"); 


//error_reporting(E_ALL);
// upgraded to a more modern anti hacker input
$path         = "/etc/asterisk/local/mm-software";
include_once ("$path/supermon_input.php");

include('/srv/http/gmrs/admin/ami-functions.php');



for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'remotenode'){ $remotenode  = $fieldValues[$i];}
if ($fieldNames[$i] == 'T1')        { $remotenode = $fieldValues[$i]; } // TBR
if ($fieldNames[$i] == 'type')      { $connectType = $fieldValues[$i];} // types C,CP,D,DP,DA,M,ML
if ($fieldNames[$i] == 'localnode') { $localnode = $fieldValues[$i];  }
}


// all unneeded since its already validated buit just to be safe.
$remotenode = @trim($remotenode);
$connectType= @trim($connectType);
$localnode = @trim($localnode);


include_once ("$path/load.php");
if (!$localnode){ $localnode = $node;}

print"<div align=center>
<font color=GREEN size=6><h1>
Connection Control Page</h1></font>
</div>";

if($connectType){
$ilink="";

// Open a socket to Asterisk Manager
$fp = AMIconnect($config[$localnode]['host']);
if (FALSE === $fp) { die("Could not connect.\n\n");}
if (FALSE === AMIlogin($fp, $config[$localnode]['user'], $config[$localnode]['passwd'])) {	die("Login failed.");}

if($remotenode){
 if ($connectType == "C" or $connectType =="CP") {
  if ($connectType =="CP") {$ilink = 13;print "<b>Permanently Connecting $localnode to $remotenode<br>";} 
  else {$ilink = 3; print "<b>Connecting $localnode to $remotenode<br>";}
 } 

if ($connectType == "M" or $connectType == "MP") {  
  if ($connectType == "MP") { $ilink = 12; print "<b>Permanently Monitoring $remotenode from $localnode<br>";}
  else { $ilink = 2; print "<b>Monitoring $remotenode from $localnode<br>";}
} 

if ($connectType == "ML" or $connectType == "MLP") {
  if ($connectType == "MLP") {$ilink = 18; print "<b>Permanently Local Monitoring $remotenode from $localnode<br>";}
  else {$ilink = 8; print "<b>Local Monitoring $remotenode from $localnode<br>";}
} 

if ($connectType == "D" or $connectType =="DP") {  $ilink = 11; print "<b>Permanently Disconnect $remotenode from $localnode<br>";}
print"</b><b><br> Sent command [$localnode ilink $ilink $remotenode] </b>";
}

if ($connectType == "DA" ) {
$ilink = 6; $remotenode="";
print "<b>Disconnect ALL LINKS from $localnode<br>";
print"</b><b><br> Sent command [$localnode ilink $ilink] </b>"; // remotenode not needed or used
}

// Error checking if no ilink set above
if($ilink){
$AMI1 = AMIcommand ($fp, "rpt cmd $localnode ilink $ilink $remotenode");
print "<p>Status: $AMI1</p>";
}
}
else {print"No commands received <br>";}

// create a hub connect field
$nodelistHub = "/etc/asterisk/local/mm-software/nodelist/hubs_online.csv";// Cleaned up nodelist
$action2= "<select name=\"T1\" >\n"; 
$randomS = mt_rand(1, 3);
if ($randomS==1){$hub="1195";}
if ($randomS==2){$hub="2250";}
if ($randomS==3){$hub="700";}
if (file_exists($nodelistHub)) {
 $fileIN= file($nodelistHub); 
 foreach($fileIN as $line){
 $u = explode("|",$line);
 $string=$u[1];  
 if (strtoupper($string) == $string)  {$string=strtolower($string);}// ALL caps fix 
 $string = (strlen($string) > 30) ? substr($string,0,30).'...' : $string;
 if($u[0]==$hub){$action2="$action2 <option style=\"margin-top:10px;\" value=\"$u[0]\" selected>$u[0] $string</option>\n";}   
 else{$action2="$action2 <option style=\"margin-top:10px;\" value=\"$u[0]\">$u[0] $string</option>\n";}
 }
 $action2="$action2 </select>";  
 } 
else{
 print"\n<!--Requesting a nodelist rebuild -->\n";
 $flag  ="/tmp/nodelist_needs_update.txt"; $fileOUT = fopen($flag,'w');fwrite ($fileOUT,"$datum");fclose ($fileOUT);
 $action2="$action2 <option style=\"margin-top:10px;\" value=\"1195\" selected>RoadKill</option></select>\n"; 
}





print"
<div id=\"connect_form\" >

<form method=\"POST\" action=\"/gmrs/admin/connect.php\">
<table border=\"0\" cellspacing=\"0\" id=\"AutoNumber1\" align=\"left\" >
<tr>
<td colspan=\"3\" bgcolor=\"#000080\">
<p align=\"center\"><b><font color=\"#FFFFFF\" size=\"4\">Enter connection commands</font></b></p>
</td>
</tr>

<tr>
<td colspan=\"2\"> 
<font size=\"2\">Remote Node#</font><input type=\"text\" name=\"remotenode\" size=\"10\" id=\"remotenode\" style=\"margin-top: 10px;\">

<select size=\"1\" name=\"type\">
 <option value=\"C\" selected>Connect</option>
 <option value=\"CP\">Connect Perm</option>
 <option value=\"D\">Disconnect</option>
 <option value=\"DA\">Disconnect ALL</option>
 <option value=\"M\">Monitor</option>
 <option value=\"MP\">Monitor Perm</option>
 <option value=\"ML\">Monitor Local</option>
 <option value=\"MLP\">Monitor Local Perm</option>
 </select>
 </td>
<td>
<font size=\"2\">Local node#</font>
<input type=\"text\" name=\"localnode\" size=\"10\" id=\"localnode\" value=\"$localnode\" style=\"margin-top: 10px;\">

<input type=\"submit\" class=\"submit\" value=\"Submit\" name=\"B1\">
</form>
</td>
</tr>
<tr>
<td colspan=\"2\">
<div style=\"border-radius: 10px;\" id=\"connect_form\"      >
<form method=\"POST\" action=\"/gmrs/admin/connect.php\" >
$action2
  <select size=\"1\" name=\"type\">
  <option value=\"C\" selected>Connect</option>
  <option value=\"CP\">Connect Perm</option>
  </select>
</td>  
<td>
<font size=\"2\">Local node#</font>
<input type=\"text\" name=\"localnode\" size=\"10\" id=\"localnode\" value=\"$localnode\" style=\"margin-top: 10px;\">

<input type=\"submit\" class=\"submit\" value=\"Submit\" name=\"B2\" >
</form> 
</td>
</tr>

</table>
</div>





<br><br><br>


<br><br><br>




";



include ("/srv/http/gmrs/footer.php");

?>
