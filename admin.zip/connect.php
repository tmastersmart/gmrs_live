<?php
//
//  AllStarLink/ASL-Supermon is licensed under the GNU General Public License v3.0
//
// https://raw.githubusercontent.com/AllStarLink/ASL-Supermon/develop/LICENSE
// https://github.com/AllStarLink/ASL-Supermon/blob/develop/var/www/html/supermon/link.php

// https://www.gnu.org/licenses/gpl-3.0.en.html

// Modified in acordance with GPL



include('/srv/http/gmrs/admin/ami-functions.php');

$path         = "/etc/asterisk/local/mm-software";
include_once ("$path/supermon_input.php");

for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'remotenode')    {  $remotenode  = $fieldValues[$i]; }
if ($fieldNames[$i] == 'perm')          {  $perm        = $fieldValues[$i]; }
if ($fieldNames[$i] == 'button')        {  $button      = $fieldValues[$i]; }
if ($fieldNames[$i] == 'localnode')     {  $localnode   = $fieldValues[$i]; }
}

// all unneeded since its already validated buit just to be safe.
$remotenode = @trim($remotenode);
$perm = @trim($perm);
$button = @trim($button);
$localnode = @trim($localnode);

// fix no need to stop just load the local node.
if (!$localnode){
include_once ("$path/load.php");
$localnode = $node;
}


// SECURITY FIX by WRXB288 
// Major security problem to have this in webserver root directory.
// With the password exposed.....
// new secure protected location        
$fileAllMon = "/srv/http/gmrs/admin/allmon.ini";       
if (!file_exists($fileAllMon)){	die("Couldn't load $fileAllMon.\n");}
$config = parse_ini_file($fileAllMon, true);// load the now secure file

#print "<pre>"; print_r($config); print "</pre>";

// Open a socket to Asterisk Manager
$fp = AMIconnect($config[$localnode]['host']);
if (FALSE === $fp) {
	die("Could not connect.\n\n");
}
if (FALSE === AMIlogin($fp, $config[$localnode]['user'], $config[$localnode]['passwd'])) {
	die("Login failed.");
}

// Which ilink command?
if ($button == 'connect') {
    if ($perm == 'on') {
        $ilink = 13;
        print "<b>Permanently Connecting $localnode to $remotenode</b>";
    } else {
        $ilink = 3;
        print "<b>Connecting $localnode to $remotenode</b>";
    }
} elseif ($button == 'monitor') {
    if ($perm == 'on') {
        $ilink = 12;
        print "<b>Permanently Monitoring $remotenode from $localnode</b>";
    } else {
        $ilink = 2;
        print "<b>Monitoring $remotenode from $localnode</b>";
    }
} elseif ($button == 'localmonitor') {
    if ($perm == 'on') {
        $ilink = 18;
        print "<b>Permanently Local Monitoring $remotenode from $localnode</b>";
    } else {
        $ilink = 8;
        print "<b>Local Monitoring $remotenode from $localnode</b>";
    }
} elseif ($button == 'disconnect') {
    if ($perm == 'on') {
        $ilink = 11;
        print "<b>Permanently Disconnect $remotenode from $localnode</b>";
    } else {
        $ilink = 11;
        print "<b>Still Permanently Disconnect $remotenode from $localnode</b>";
    }
}

#exit;

 $AMI1 = AMIcommand ($fp, "rpt cmd $localnode ilink $ilink $remotenode");




?>
