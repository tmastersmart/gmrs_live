<?php
//
//  AllStarLink/ASL-Supermon is licensed under the GNU General Public License v3.0
//
// https://raw.githubusercontent.com/AllStarLink/ASL-Supermon/develop/LICENSE
// https://github.com/AllStarLink/ASL-Supermon/blob/develop/var/www/html/supermon/edit/save.php
// https://www.gnu.org/licenses/gpl-3.0.en.html

// Modified in acordance with GPL

 $path         = "/etc/asterisk/local/mm-software";
include_once ("$path/supermon_input.php");

// Security mods
for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'edit')    {  $edit  = $fieldValues[$i]; }
if ($fieldNames[$i] == 'filename'){  $filename = $fieldValues[$i]; }
}


$edit = str_replace ("\r","",$edit);
print "<form name=REFRESH method=POST action='configeditor.php'>\n";
print "<link type='text/css' rel='stylesheet' href='/supermon/supermon.css'>";
print "<input name=return tabindex=50 TYPE=SUBMIT class=\"submit\" Value=\"Return to Index\"></form></h1>\n";

if (is_writable($filename)) {
   if (copy($filename, "$filename.bak")) { print "<strong>Success, backup file created <em>($filename.bak)</em></strong><br>"; }
   
   if (!$handle = fopen($filename, 'w')) {
        print "<strong>Cannot open file <em>($filename)</em></strong>";
        exit;
   }
   if (fwrite($handle, $edit) === FALSE) {
       print "<strong>Cannot write to file <em>($filename)</em></strong>";
       exit;
   }
   fclose($handle);
   $edit = nl2br ($edit);
   print "<strong>Success, wrote edits to file <em>($filename)</em>:</strong><br><br>$edit<br>";
   }
   
 else { print "<strong>The file <em>($filename)</em> is not writable</strong>";}

?>

