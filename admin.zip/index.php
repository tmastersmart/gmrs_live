<?php

$path         = "/etc/asterisk/local/mm-software";
include_once ("$path/load.php");


header("Location: /gmrs/link.php?nodes=$node");

?>
