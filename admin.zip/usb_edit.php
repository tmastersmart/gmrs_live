<?php
// ***************************************************
// (c)2025 by The Master lagmrs.com WRXB288 
//  all rights reserved
//
//  100% new GMRS code
//**************************************************** 
// v1   beta
// v2.0 Realled defective
// v2.1 Major rewrite needed bug fixes in many sections
//      not reading and not writing 

$verGMRS="v2.1";  $save=false; $in="";$out=""; $betatest=false;  $pageTitle="Simple USB edit config";
$gpl=false;$iframe=false;$save=false;
$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
include_once("$rootDir/admin/config.php"); // includes the main settings
$path  = "/etc/asterisk/local/mm-software";
$datum = date('m-d-Y-H:i:s');
if (file_exists($fileAllMon)){$config = parse_ini_file($fileAllMon, true);}
else {print	"Couldn't load AllMon ";}
include_once("$rootDir/admin/header.php"); 
include_once("$rootDir/admin/input.php");
include_once("$rootDir/admin/menu.php"); 

// the live files
$fileUSB = "/etc/asterisk/simpleusb_tune_usb.conf";
$fileUSB2  = "/etc/asterisk/simpleusb.conf";

// saved files
$fileUSBtmp= "/tmp/simpleusb_tune_usb.conf";
$fileUSB2tmp= "/tmp/simpleusb.conf";

load_live($in);
load_simple_usb($in);
load_simple_tune_usb($in);


//simple tune menu saves like this
//Saved updated simpleusb.conf node stanza to: /tmp/simpleusb_usb.conf
//Merged changed in: /tmp/simpleusb_usb.conf with: /etc/asterisk/simpleusb.conf
//Saved radio tuning settings to simpleusb_tune_usb.conf



if(sizeof($fieldNames)>1) {
for ($i=0; $i < sizeof($fieldNames); $i++) {
if ($fieldNames[$i] == 'B1'){                    $save=true;}
// $eeprom,$carrierfrom,$ctcssfrom,$invertptt,$plfilter,$deemphasis,$preemphasis,$dcsfilter,$queuesize;
// $rxboost,$rxondelay,$rxaudiodelay,$tx_audio_level_method,
if ($fieldNames[$i] == 'eeprom')     {$eeprom      = $fieldValues[$i];}
if ($fieldNames[$i] == 'carrierfrom'){$carrierfrom = $fieldValues[$i];}  
if ($fieldNames[$i] == 'ctcssfrom')  {$ctcssfrom   = $fieldValues[$i];}
if ($fieldNames[$i] == 'invertptt')  {$invertptt   = $fieldValues[$i];}
if ($fieldNames[$i] == 'plfilter')   {$plfilter    = $fieldValues[$i];}
if ($fieldNames[$i] == 'deemphasis') {$deemphasis  = $fieldValues[$i];}
if ($fieldNames[$i] == 'preemphasis'){$preemphasis = $fieldValues[$i];}
if ($fieldNames[$i] == 'dcsfilter')  {$dcsfilter   = $fieldValues[$i];}
if ($fieldNames[$i] == 'queuesize')  {$queuesize   = $fieldValues[$i];}
if ($fieldNames[$i] == 'rxboost')    {$rxboost     = $fieldValues[$i];}
if ($fieldNames[$i] == 'rxondelay')  {$rxondelay   = $fieldValues[$i];}
if ($fieldNames[$i] == 'rxaudiodelay'){$rxaudiodelay= $fieldValues[$i];}
if ($fieldNames[$i] == 'tx_audio_level_method') {$tx_audio_level_method = $fieldValues[$i];}
//$rxmixerset=300;$txmixaset=225;$txmixbset=225;$txdsplvl=300;$ok=false;
if ($fieldNames[$i] == 'rxmixerset') {$rxmixerset = $fieldValues[$i];}
if ($fieldNames[$i] == 'txmixaset'){$txmixaset= $fieldValues[$i];}
if ($fieldNames[$i] == 'txmixbset') {$txmixbset = $fieldValues[$i];}
if ($fieldNames[$i] == 'txdsplvl') {$txdsplvl = $fieldValues[$i];}
}
}

SyncUSB($in); 

if($save){
 save_usb($in);
 save_usb2($in);
 SyncUSB($in);
 }



$piSystem=false;if (is_readable("/proc/device-tree/model")) {$piVersion = file_get_contents ("/proc/device-tree/model");$piSystem=true;}
else {$piVersion =	exec('uname -m -p');}


print"<!-- $piVersion -->\n";   // Raspberry Pi 3 Model B Plus Rev 1.4

$image="/status/images/cpu.jpg";
$pos = strpos("-$piVersion", "Pi 3 Model A"); if ($pos){$image="/status/images/pi-3a.jpg";}
$pos = strpos("-$piVersion", "Pi 3 Model B"); if ($pos){$image="/status/images/pi3b.jpg";}
$pos = strpos("-$piVersion", "Pi 4");         if ($pos){$image="/status/images/pi4.jpg";}
$pos = strpos("-$piVersion", "x86_64");       if ($pos){$image="/status/images/x86_64.jpg";}



print "
<image src=$image align=left>
<div align=center><font color=GREEN size=6><h1>$pageTitle</h1></font><center>";  
print "$piVersion</br>";


if ($live and $live2){print "<font color=green>Loaded Live Config files</font>";}
else{print"<font color=RED size=6>Waiting for import into live setup</font>";}

if($save){ print "<font color=red>Importing dont restart</font>";}

print"
<form method=\"GET\" name=\"config\" action=\"/admin/usb_edit.php\">
<table align=center border=\"1\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse: collapse\" bordercolor=\"#111111\" id=\"AutoNumber1\">";


$background="#808080"; $fontcolor="white";$basecolor="#FFFFCC"; 



print "<tr>";
//eeprom=0
//			; 1 = Indicates that an EEPROM internal to the radio
//			;     adapter and cable is expected. 
//			; 0 = no warning message if no EEPROM found.
print"<td bgcolor=$background><b><font color=$fontcolor>eeprom</font></b></td>
      <td bgcolor=$basecolor>";// no or yes
print"<select size=1 name=eeprom>";
    if ($eeprom == "0"){print"<option selected value='0'>No</option><option value='1'>Yes</option>";}
    if ($eeprom == "1"){print"<option value='0'>No</option><option selected value='1'>Yes</option>";}
    print"</select>";
$width=500;$height=200;$in=101;Show_help($in);
print"</td>";

// 2 
//carrierfrom=no
//			; Options - no,usb,usbinvert 
//			; no - no carrier detection at all
//			; usb - via USB radio adapter COR connection
//			; usbinvert - same as above but inverted polarity.
print"<td bgcolor=$background><b><font color=$fontcolor>carrierfrom</font></b></td>
      <td bgcolor=$basecolor>";// no or yes
print"<select size=1 name=carrierfrom>";
    if ($carrierfrom == "no"){ print"<option selected value='no'>No</option><option value='usb'>USB</option><option value='usbinvert'>USB Invert</option>";}
    if ($carrierfrom == "usb"){print"<option value='no'>No</option><option selected value='usb'>USB</option><option value='usbinvert'>USB Invert</option>";}
    if ($carrierfrom == "usbinvert"){print"<option value='no'>No</option><option value='usb'>USB</option><option selected value='usbinvert'>USB Invert</option>";}
    print"</select>";
$width=500;$height=200;$in=103;Show_help($in);
print"</td>";


//ctcssfrom=no
//			; CTCSS Decoder Source
//			; Options = no,usb,dsp
//			; no - CTCSS decoding, system will be carrier squelch
//			; usb - CTCSS decoding using input from USB adapter 
//			; usbinvert - same as above but inverted polarity.
print"<td bgcolor=$background><b><font color=$fontcolor>ctcssfrom</font></b></td>
      <td bgcolor=$basecolor>";// no or yes
print"<select size=1 name=ctcssfrom>";
    if ($ctcssfrom == "no"){ print"<option selected value='no'>No</option><option value='usb'>USB</option><option value='usbinvert'>USB Invert</option>";}
    if ($ctcssfrom == "usb"){print"<option value='no'>No</option><option selected value='usb'>USB</option><option value='usbinvert'>USB Invert</option>";}
    if ($ctcssfrom == "usbinvert"){print"<option value='no'>No</option><option value='usb'>USB</option><option selected value='usbinvert'>USB Invert</option>";}
    print"</select>";
$width=500;$height=200;$in=104;Show_help($in);
print"</td>";

print "</tr><tr>";

//invertptt=1
//			; Invert PTT 0 = ground to transmit, 1 = open to
//          ; transmit
//          ; This is the collector lead of the 2n4401 on the 
//          ; modified usb sound fob.



print"<td bgcolor=$background><b><font color=$fontcolor>PTT Invert</font></b></td>
      <td bgcolor=$basecolor>";// no or yes
print"<select size=1 name=invertptt>";
    if ($invertptt == "0"){ print"<option selected value='0'>No</option><option value='1'>Yes</option>";}
    if ($invertptt == "1"){print"<option value='0'>No</option><option selected value='1'>Yes</option>";}

print"</select>";
$width=500;$height=200;$in=105;Show_help($in);
print"</td>";

//plfilter=no
//			; enable PL filter
//			; yes, enabled
//			; no, disabled

print"<td bgcolor=$background><b><font color=$fontcolor>PL Filter</font></b></td>
      <td bgcolor=$basecolor>";// no or yes
print"<select size=1 name=plfilter>";
    if ($plfilter == "no"){ print"<option selected value='no'>No</option><option value='yes'>Yes</option>";}
    if ($plfilter == "yes"){print"<option value='no'>No</option><option selected value='yes'>Yes</option>";}

print"</select>$Lplfilter";
$width=500;$height=200;$in=106;Show_help($in);
print"</td>";

// queuesize

print"<td bgcolor=$background><b><font color=$fontcolor>queuesize</font></b></td>
     <td bgcolor=$basecolor><input type='text' name='queuesize' size='5' value='$queuesize'>";$width=500;$height=200;$in=112;Show_help($in);
print"</td>";



print"</tr><tr>";

//deemphasis=no
//			; enable de-emphasis (input from discriminator)
//			; yes, enabled
//			; no, disabled

print"<td bgcolor=$background><b><font color=$fontcolor>Deemphasis</font></b></td>
      <td bgcolor=$basecolor>";// no or yes
print"<select size=1 name=deemphasis>";
    if ($deemphasis == "no"){ print"<option selected value='no'>No</option><option value='yes'>Yes</option>";}
    if ($deemphasis == "yes"){print"<option value='no'>No</option><option selected value='yes'>Yes</option>";}

print"</select>$Ldeemphasis";
$width=500;$height=200;$in=107;Show_help($in);
print"</td>";



//preemphasis=no
//			; enable pre-emphasis (output to Tx)
//			; yes, enabled
//			; no, disabled

print"<td bgcolor=$background><b><font color=$fontcolor>Preemphasis</font></b></td>
      <td bgcolor=$basecolor>";// no or yes
print"<select size=1 name=preemphasis>";
    if ($preemphasis == "no"){ print"<option selected value='no'>No</option><option value='yes'>Yes</option>";}
    if ($preemphasis == "yes"){print"<option value='no'>No</option><option selected value='yes'>Yes</option>";}

print"</select>$Lpreemphasis";
$width=500;$height=200;$in=108;Show_help($in);
print"</td>";


//
//dcsfilter


print"<td bgcolor=$background><b><font color=$fontcolor>DCS Filter</font></b></td>
      <td bgcolor=$basecolor>";// no or yes
print"<select size=1 name=dcsfilter>";
    if ($dcsfilter == "no"){ print"<option selected value='no'>No</option><option value='yes'>Yes</option>";}
    if ($dcsfilter == "yes"){print"<option value='no'>No</option><option selected value='yes'>Yes</option>";}

print"</select>$Ldcsfilter";
$width=500;$height=200;$in=110;Show_help($in);
print"</td>";

print"</tr><tr>";

//rxboost=0
//			; Rx Audio Boost
//			; 0 = 20db attenuator inserted 
//			; 1 = 20db attenuator removed
//			; Set to 1 for additonal gain if using a low-level
//			; receiver output.

print"<td bgcolor=$background><b><font color=$fontcolor>RX Boost 20db</font></b></td>
      <td bgcolor=$basecolor>";
print"<select size=1 name=rxboost>";
    if ($rxboost == "0"){ print"<option value='1'>Yes</option><option selected value='0'>No</option>";}
    if ($rxboost == "1"){print"<option selected value='1'>Yes</option><option value='0'>No</option>";}
print"</select>$Lrxboost";
$width=500;$height=200;$in=114;Show_help($in);
print"</td>";

//rxaudiodelay
//rxaudiodelay=0
//			; default value is 0
//			; rx audio delay for squelch tail elimination.
//			; Squelch tail delay in 20ms frames. Values range
//			; from  0 (no delay) to 24 (480ms delay)
//			; Typical values would range from 5-10 (100-200ms)
print"<td bgcolor=$background><b><font color=$fontcolor>RX Audio Delay</font></b></td>
     <td bgcolor=$basecolor><input type='text' name='rxaudiodelay' size='5' value='$rxaudiodelay'>$rxaudiodelay";
$width=500;$height=200;$in=109;Show_help($in);
print"</td>";

//  rxmixerset
print"<td bgcolor=$background><b><font color=$fontcolor>RX Mixer Set</font></b></td>
     <td bgcolor=$basecolor><input type='text' name='rxmixerset' size='5' value='$rxmixerset'>$Lrxmixerset";
$width=500;$height=200;$in=115;Show_help($in);
print"</td>";
print"</tr><tr>";

//txmixaset
print"<td bgcolor=$background><b><font color=$fontcolor>TX Mixer A Set</font></b></td>";
print"<td bgcolor=$basecolor><input type='text' name='txmixaset' size='5' value='$txmixaset'>$Ltxmixaset";
$width=500;$height=200;$in=116;Show_help($in);
print"</td>";

//txmixaset
print"<td bgcolor=$background><b><font color=$fontcolor>TX Mixer B Set</font></b></td>";
print"<td bgcolor=$basecolor><input type='text' name='txmixbset' size='5' value='$txmixbset'>$Ltxmixbset";
$width=500;$height=200;$in=117;Show_help($in);
print"</td>";


//txdsplvl
print"<td bgcolor=$background><b><font color=$fontcolor>TX DSP</font></b></td>";
print"<td bgcolor=$basecolor><input type='text' name='txdsplvl' size='5' value='$txdsplvl'>$Ltxdsplvl";
$width=500;$height=200;$in=118;Show_help($in);
print"</td>";

print"</tr><tr>";
//tx_audio_level_method

print"<td bgcolor=$background><b><font color=$fontcolor>TX Level Method</font></b></td>
      <td bgcolor=$basecolor>";// no or yes
print"<select size=1 name=tx_audio_level_method>";
    if ($tx_audio_level_method == "0"){ print"<option selected value='0'>Auto</option><option value='1'>Manual</option>";}
    if ($tx_audio_level_method == "1"){print"<option value='0'>Auto</option><option selected value='1'>Manual</option>";}
print"</select>";
$width=500;$height=200;$in=113;Show_help($in);
print"</td>";


//$Lptt
print"<td bgcolor=$background><b><font color=$fontcolor>PTT</font></b></td>
      <td bgcolor=$basecolor>$Lptt</td>";

print"<td bgcolor=$background><b><font color=$fontcolor>PTT Status</font></b></td>
      <td bgcolor=$basecolor>$Lptts</td>";

print"</tr><tr>";
//CTCSS (input):   Ignored
//COS (input):     Ignored
//COS (test):      Un-Keyed
//COS (composite): Keyed

print"<td bgcolor=$background><b><font color=$fontcolor>COS test</font></b></td>
      <td bgcolor=$basecolor>$LCOSt</td>";

print"<td bgcolor=$background><b><font color=$fontcolor>COS</font></b></td>
      <td bgcolor=$basecolor>$LCOSc</td>";

print"<td bgcolor=$background><b><font color=$fontcolor>COS (input)</font></b></td>
      <td bgcolor=$basecolor>$LCOSi</td>";


print"</tr><tr>";


print"<td bgcolor=$background><b><font color=$fontcolor>CTCSS (input)</font></b></td>
      <td bgcolor=$basecolor>$Lctssi</td>";

print"<td bgcolor=$background><b><font color=$fontcolor>Name</font></b></td>
      <td bgcolor=$basecolor>$Lusb</td>";

print"<td bgcolor=$background><b><font color=$fontcolor>Card</font></b></td>
      <td bgcolor=$basecolor>$Lcard</td>";

print"</tr></table></div>";

print "<center><small>*= requires a ast restart (no not restart untill settings say live.)<a href=usb_edit.php> - Reload Page to Check - </a> "; $width=400;$height=300;$in=50;Show_help($in);
print"</center></small></td>"; 

print "<br><center><input type=\"submit\" value=\"Submit\" name=\"B1\"></form></center>";
print"<!-- setup is (c)2024 by lagmrs.com all rights reserverd-->\n";
include ("$rootDir/admin/footer.php");







//$fileUSB  = "/etc/asterisk/simpleusb_tune_usb.conf";$fileUSBtmp= "/tmp/simpleusb_tune_usb.conf";
//$fileUSB2 = "/etc/asterisk/simpleusb.conf";         $fileUSB2tmp= "/tmp/simpleusb.conf";





// load into fileIN
function load_simple_usb($in){
global $fileUSB,$fileUSBtmp,$fileUSB2,$fileUSB2tmp,$fileIN;
global $rxmixerset,$txmixaset,$txmixbset,$txdsplvl,$live2;
global $eeprom,$carrierfrom,$ctcssfrom,$invertptt,$plfilter,$deemphasis,$preemphasis,$dcsfilter,$queuesize;
global $rxboost,$rxondelay,$rxaudiodelay,$tx_audio_level_method,$live;

$rxmixerset=300;$txmixaset=225;$txmixbset=225;$txdsplvl=300;$ok=false;$live=false;

if(file_exists($fileUSBtmp)){$fileIN= file($fileUSBtmp);$live=false;$ok=true;print "<!-- Loading $fileUSBtmp -->\n";}
else{$fileIN= file($fileUSB);$live=true;$ok=true;print "<!-- Loading $fileUSB -->\n";}

if($ok){
 foreach($fileIN as $line){ 
 $line = str_replace("\r", "", $line); 
 $line = str_replace("\n", "", $line);
 print "<!-- tune:$line -->\n";
 $pos = strpos("-$line", ";");if($pos){continue;}// skip all comments
 $pos = strpos("-$line", "rxmixerset");if($pos){$u= explode("=",$line);$rxmixerset=trim($u[1]);}
 $pos = strpos("-$line", "txmixaset"); if($pos){$u= explode("=",$line); $txmixaset=trim($u[1]);}
 $pos = strpos("-$line", "txmixbset"); if($pos){$u= explode("=",$line); $txmixbset=trim($u[1]);}
 $pos = strpos("-$line", "txdsplvl");  if($pos){$u= explode("=",$line);  $txdsplvl=trim($u[1]);}
  }// end loop
 }// end ok
}




// load into fileIN2
function load_simple_tune_usb($in){
global $fileUSB,$fileUSBtmp,$fileUSB2,$fileUSB2tmp,$fileIN;
global $rxmixerset,$txmixaset,$txmixbset,$txdsplvl,$live2;
global $eeprom,$carrierfrom,$ctcssfrom,$invertptt,$plfilter,$deemphasis,$preemphasis,$dcsfilter,$queuesize;
global $rxboost,$rxondelay,$rxaudiodelay,$tx_audio_level_method,$live;



// varables needed default them 
$eeprom=0;$invertptt=0;$queuesize = 18;$ok=false;$live2=false;
$carrierfrom="no";$ctcssfrom="no";$plfilter="no";$deemphasis="no";$preemphasis="no";$dcsfilter = "no";
$rxboost=0;$rxondelay = 5;$rxaudiodelay=0;$tx_audio_level_method = 0;


if(file_exists($fileUSB2tmp)){$fileIN2= file($fileUSB2tmp);$live2=false;$ok=true;print "<!-- Loading $fileUSB2tmp -->\n";}
else{$fileIN2= file($fileUSB2);$live2=true;$ok=true;print "<!-- Loadimg $fileUSB2 -->\n";}



if($ok){
 foreach($fileIN2 as $line){ 
 $line = str_replace("\r", "", $line);
 $line = str_replace("\n", "", $line);
  print "<!-- usb:$line -->\n";
  



 $pos = strpos("-$line", ";");if($pos){continue;}// skip all comments
 $pos = strpos("-$line", "eeprom");     if($pos){$u= explode("=",$line);     $eeprom=trim($u[1]);}
 $pos = strpos("-$line", "carrierfrom");if($pos){$u= explode("=",$line);$carrierfrom=trim($u[1]);}
 $pos = strpos("-$line", "ctcssfrom");  if($pos){$u= explode("=",$line);  $ctcssfrom=trim($u[1]);} 
 $pos = strpos("-$line", "invertptt");  if($pos){$u= explode("=",$line);  $invertptt=trim($u[1]);}
 $pos = strpos("-$line", "plfilter");   if($pos){$u= explode("=",$line);   $plfilter=trim($u[1]);} 
 $pos = strpos("-$line", "deemphasis"); if($pos){$u= explode("=",$line); $deemphasis=trim($u[1]);}
 $pos = strpos("-$line", "preemphasis");if($pos){$u= explode("=",$line);$preemphasis=trim($u[1]);} 
 $pos = strpos("-$line", "dcsfilter");  if($pos){$u= explode("=",$line);  $dcsfilter=trim($u[1]);} 
 $pos = strpos("-$line", "queuesize");  if($pos){$u= explode("=",$line);  $queuesize=trim($u[1]);}
 $pos = strpos("-$line", "rxboost");    if($pos){$u= explode("=",$line);    $rxboost=trim($u[1]);} 
 $pos = strpos("-$line", "rxondelay");  if($pos){$u= explode("=",$line);  $rxondelay=trim($u[1]);}
 $pos = strpos("-$line", "rxaudiodelay");if($pos){$u= explode("=",$line);$rxaudiodelay=trim($u[1]);}
 $pos = strpos("-$line", "tx_audio_level_method");if($pos){$u= explode("=",$line);  $tx_audio_level_method=trim($u[1]);}

  }// end loop
 }// end ok
}



function load_live($in){

global $Ldeemphasis,$Lpreemphasis,$Lplfilter, $Lrxboost,  $Lrxmixerset, $Ldcsfilter;
global $Ltxtestkeyed,$Linvertptt,  $Lrxcdtype, $Ltxdsplvl,$fileIN2,   $Lrxsdyype;
global $Lechomode,   $Lrxmisetset,$Lrxondelay,  $Lrxaudiodelay,$Ltxmixaset;
global $Ltxmixbset,  $Ltxsplevl,  $Lpttstatus,  $Lcoscomposite,$Ltx_audio_level_method;
global $Lptt,$Lptts,$Lctssi,$LCOSi,$LCOSt,$LCOSc,$Lusb,$Lcard,$fileUSB2tmp,$fileUSBtmp;

$Ldeemphasis="";$Lpreemphasis="";$Lplfilter="";$Lrxboost="";$Lrxmixerset="";$Ldcsfilter="";$Ltxtestkeyed="";
$Linvertptt="";$Lrxcdtype="";$Ltxdsplvl="";$Lrxsdyype="";$Lechomode="";$Lrxmisetset="";$Lrxondelay="";$Lrxaudiodelay="";
$Ltxmixaset="";$Ltxmixbset="";$Ltxsplevl="";$Lpttstatus="";$Lcoscomposite="";$Ltx_audio_level_method="";$Lptt="";
$Lptts="";$Lctssi="";$LCOSi="";$LCOSt="";$LCOSc="";$Lusb="";$Lcard="";



print "<!-- Read live -->\n";
$status= exec("sudo /bin/asterisk -rx \"susb tune menu-support 2\" ",$output,$return_var);
// susb tune menu-support 2



 print "<!-- Dump live settings susb tune menu-support 2 -->\n";
 foreach($output as $line){ 
 $line = str_replace("\r", "", $line); 
 $line = str_replace("\n", "", $line);
// $line = str_replace(" ", "", $line);
 
 print "<!-- live:$line -->\n";
 $pos = strpos("-$line", "invertptt");  if($pos){$u= explode(":",$line);  $Linvertptt=trim($u[1]);} // its not reporting this 
 $pos = strpos("-$line", "plfilter");   if($pos){$u= explode(":",$line);   $Lplfilter=trim($u[1]);} 
 $pos = strpos("-$line", "deemphasis"); if($pos){$u= explode(":",$line); $Ldeemphasis=trim($u[1]);}
 $pos = strpos("-$line", "preemphasis");if($pos){$u= explode(":",$line);$Lpreemphasis=trim($u[1]);} 
 $pos = strpos("-$line", "dcsfilter");  if($pos){$u= explode(":",$line);  $Ldcsfilter=trim($u[1]);} 
 $pos = strpos("-$line", "rxboost"); if($pos){$u= explode(":",$line);    $Lrxboost=trim($u[1]);} 
 $pos = strpos("-$line", "Rx ondelay");  if($pos){$u= explode(":",$line);  $Lrxondelay=trim($u[1]);}
 $pos = strpos("-$line", "Rx audio-delay");if($pos){$u= explode(":",$line);$Lrxaudiodelay=trim($u[1]);}
 
 
 $pos = strpos("-$line", "Rx Level");if($pos){$u= explode(":",$line);$Lrxmixerset=trim($u[1]);}
 $pos = strpos("-$line", "Tx A Level"); if($pos){$u= explode(":",$line); $Ltxmixaset=trim($u[1]);}
 $pos = strpos("-$line", "Tx B Level"); if($pos){$u= explode(":",$line); $Ltxmixbset=trim($u[1]);}
 $pos = strpos("-$line", "Tx DSP Level");  if($pos){$u= explode(":",$line);$Ltxdsplvl=trim($u[1]);}
 $pos = strpos("-$line", "Name is");  if($pos){$u= explode(":",$line);$Lusb=trim($u[1]);} 
 $pos = strpos("-$line", "Card is");  if($pos){$u= explode(":",$line);$Lcard=trim($u[1]);} 
 
//Card is:         0
//Name is:         usb
//Rx Level:        300
//Rx ondelay:      0
//Rx audio-delay:  0
//Tx A Level:      225
//Tx B Level:      225
//Tx DSP Level:    300
//preemphasis:     no
//deemphasis:      no
//plfilter:        no
//dcsfilter:       no
//rxboost:         yes

//PTT:             Active HIGH
//PTT status:      Un-Keyed

//CTCSS (input):   Ignored
//COS (input):     Ignored
//COS (test):      Un-Keyed
//COS (composite): Keyed

 $pos = strpos("-$line", "PTT");            if($pos and !$Lptt){$u= explode(":",$line);$Lptt=trim($u[1]);}
 $pos = strpos("-$line", "PTT status");     if($pos){$u= explode(":",$line);$Lptts=trim($u[1]);}
 $pos = strpos("-$line", "CTCSS (input)");  if($pos){$u= explode(":",$line);$Lctssi=trim($u[1]);}
 $pos = strpos("-$line", "COS (input)");    if($pos){$u= explode(":",$line);$LCOSi=trim($u[1]);}
 $pos = strpos("-$line", "COS (test)");     if($pos){$u= explode(":",$line);$LCOSt=trim($u[1]);}
 $pos = strpos("-$line", "COS (composite)");if($pos){$u= explode(":",$line);$LCOSc=trim($u[1]);}

 

 
 

 
}
}
//$fileUSB  = "/etc/asterisk/simpleusb_tune_usb.conf";$fileUSBtmp= "/tmp/simpleusb_tune_usb.conf";
//$fileUSB2 = "/etc/asterisk/simpleusb.conf";         $fileUSB2tmp= "/tmp/simpleusb.conf";

function save_usb($in){
// save 2 files into tmp directory
global $fileUSB,$fileUSBtmp,$fileIN;
global $fileUSB2,$fileUSB2tmp,$fileIN2;
global $eeprom,$carrierfrom,$ctcssfrom,$invertptt,$plfilter,$deemphasis,$preemphasis,$dcsfilter,$queuesize;
global $rxboost,$rxondelay,$rxaudiodelay,$tx_audio_level_method,$live;

global $rxmixerset,$txmixaset,$txmixbset,$txdsplvl,$live2;
$line="";//safety keep this out the next file

// the live files
$fileUSB  = "/etc/asterisk/simpleusb.conf";
$fileUSBtmp= "/tmp/simpleusb.conf";


$st1=false; $st2=false; $st3=false; $st4=false; $st5=false; $st6=false; $st7=false; $st8=false;$st9=false;$st10=false; $st11=false; $st12=false; $st13=false;
$fileIN= file($fileUSB);
$fileOUT = fopen($fileUSBtmp, "w") ;print "<!-- saving $fileUSBtmp-->\n";
foreach($fileIN as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
 $pos = strpos("-$line", "second USB node");if ($pos){print "<!--END $line -->\n";break;}
 $pos = strpos("-$line", ";");if($pos){fwrite ($fileOUT, "$line\n");print "<!--copy $line -->\n";continue;}// skip all comments

 print "<!-- Read $line -->\n";
 $pos = strpos("-$line", "eeprom");      if($pos and !$st1){$line = "eeprom=$eeprom";              $st1=true;}
 $pos = strpos("-$line", "carrierfrom"); if($pos and !$st2){$line = "carrierfrom=$carrierfrom";    $st2=true;}
 $pos = strpos("-$line", "ctcssfrom");   if($pos and !$st3){$line = "ctcssfrom=$ctcssfrom";        $st3=true;}
 $pos = strpos("-$line", "invertptt");   if($pos and !$st4){$line = "invertptt=$invertptt";        $st4=true;}
 $pos = strpos("-$line", "plfilter");    if($pos and !$st5){$line = "plfilter=$plfilter";          $st5=true;}
 $pos = strpos("-$line", "deemphasis");  if($pos and !$st6){$line = "deemphasis=$deemphasis";      $st6=true;}
 $pos = strpos("-$line", "preemphasis"); if($pos and !$st7){$line = "preemphasis=$preemphasis";    $st7=true;}
 $pos = strpos("-$line", "dcsfilter");   if($pos and !$st8){$line = "dcsfilter=$dcsfilter";        $st8=true;}
 $pos = strpos("-$line", "queuesize");   if($pos and !$st9){$line = "queuesize=$queuesize";        $st9=true;}
 $pos = strpos("-$line", "rxboost");     if($pos and !$st10){$line = "rxboost=$rxboost";          $st10=true;}          
 $pos = strpos("-$line", "rxondelay");   if($pos and !$st11){$line = "rxondelay=$rxondelay";      $st11=true;}
 $pos = strpos("-$line", "rxaudiodelay");if($pos and !$st12){$line = "rxaudiodelay=$rxaudiodelay";$st12=true;}
 $pos = strpos("-$line", "tx_audio_level_method");if($pos and !$st13){$line = "tx_audio_level_method=$tx_audio_level_method";$st13=true;}
 $pos = strpos("-$line", "second USB node");if ($pos){break;}
 
 fwrite ($fileOUT, "$line\n"); print "<!--write $line -->\n";
 }// end loop
 
 // fix missing lines
 if(!$st1){$line = "eeprom=$eeprom";              $st1=true;fwrite ($fileOUT, "$line\n"); print "<!--write $line -->\n";}
 if(!$st2){$line = "carrierfrom=$carrierfrom";    $st2=true;fwrite ($fileOUT, "$line\n"); print "<!--write $line -->\n";}
 if(!$st3){$line = "ctcssfrom=$ctcssfrom";        $st3=true;fwrite ($fileOUT, "$line\n"); print "<!--write $line -->\n";}
 if(!$st4){$line = "invertptt=$invertptt";        $st4=true;fwrite ($fileOUT, "$line\n"); print "<!--write $line -->\n";}
 if(!$st5){$line = "plfilter=$plfilter";          $st5=true;fwrite ($fileOUT, "$line\n"); print "<!--write $line -->\n";}
 if(!$st6){$line = "deemphasis=$deemphasis";      $st6=true;fwrite ($fileOUT, "$line\n"); print "<!--write $line -->\n";}
 if(!$st7){$line = "preemphasis=$preemphasis";    $st7=true;fwrite ($fileOUT, "$line\n"); print "<!--write $line -->\n";}
 if(!$st8){$line = "dcsfilter=$dcsfilter";        $st8=true;fwrite ($fileOUT, "$line\n"); print "<!--write $line -->\n";}
 if(!$st9){$line = "queuesize=$queuesize";        $st9=true;fwrite ($fileOUT, "$line\n"); print "<!--write $line -->\n";}
 if(!$st10){$line = "rxboost=$rxboost";          $st10=true;fwrite ($fileOUT, "$line\n"); print "<!--write $line -->\n";}          
 if(!$st11){$line = "rxondelay=$rxondelay";      $st11=true;fwrite ($fileOUT, "$line\n"); print "<!--write $line -->\n";}
 if(!$st12){$line = "rxaudiodelay=$rxaudiodelay";$st12=true;fwrite ($fileOUT, "$line\n"); print "<!--write $line -->\n";}
 if(!$st13){$line = "tx_audio_level_method=$tx_audio_level_method";$st13=true;fwrite ($fileOUT, "$line\n"); print "<!--write $line -->\n";}
 
$datum = date('m-d-Y-H:i:s');
fwrite ($fileOUT, "; end of USB file [usb_edit.php edited this on $datum  ] Only 1 usb allowed\n"); print "<!--write EOF $datum ->\n"; 
fclose ($fileOUT);





//SyncUSB($in);
}


function save_usb2($in){
// save 2 files into tmp directory
global $fileUSB,$fileUSBtmp,$fileIN;
global $fileUSB2,$fileUSB2tmp,$fileIN2;
global $eeprom,$carrierfrom,$ctcssfrom,$invertptt,$plfilter,$deemphasis,$preemphasis,$dcsfilter,$queuesize;
global $rxboost,$rxondelay,$rxaudiodelay,$tx_audio_level_method,$live;
global $rxmixerset,$txmixaset,$txmixbset,$txdsplvl,$live2;
$line="";//safety keep this out the next file
// save the tune file [usb]
//; name=usb
//; devicenum=0
//devstr=1-1.1.3:1.0
//rxmixerset=290
//txmixaset=700
//txmixbset=700
//txdsplvl=999
// the live files
$fileUSB2 = "/etc/asterisk/simpleusb_tune_usb.conf";
$fileUSB2tmp= "/tmp/simpleusb_tune_usb.conf";

$st1=false; $st2=false; $st3=false; $st4=false;
$fileIN2= file($fileUSB2); // we have to load this again because it was getting lost in memory???? 
$fileOUT = fopen($fileUSB2tmp, "w") ;print "<!-- saving $fileUSB2tmp -->\n";
$line="";
foreach($fileIN2 as $line){
$line = str_replace("\r", "", $line);
$line = str_replace("\n", "", $line);
 print "<!--read $line -->\n";
 $pos = strpos("-$line", ";");if($pos){fwrite ($fileOUT, "$line\n");print "<!--copy $line -->\n";continue;}// skip all comments

 $pos = strpos("-$line", "tx_audio_level_method");if($pos){$line = ";error [$line]";}  // this should not be here WHY?
 $pos = strpos("-$line", "rxmixerset");if($pos){$line === "rxmixerset=$rxmixerset";$st1=true;}
 $pos = strpos("-$line", "txmixaset"); if($pos){$line === "txmixaset=$txmixaset";  $st2=true;}
 $pos = strpos("-$line", "txmixbset"); if($pos){$line === "txmixbset=$txmixbset";  $st3=true;}
 $pos = strpos("-$line", "txdsplvl");  if($pos){$line === "txdsplvl=$txdsplvl";    $st4=true;}

 fwrite ($fileOUT, "$line\n");print "<!--write $line -->\n";
  }// end loop
  
// fix if missing  
if(!$st1) {fwrite ($fileOUT, "rxmixerset=$rxmixerset\n");} 
if(!$st2) {fwrite ($fileOUT, "txmixaset=$txmixaset\n");} 
if(!$st3) {fwrite ($fileOUT, "txmixbset=$txmixbset\n");} 
if(!$st4) {fwrite ($fileOUT, "txdsplvl=$txdsplvl\n");} 
  
fclose ($fileOUT);

//SyncUSB($in);
}

//Usage: susb tune <function>
//       rx [newsetting]
//       rxdisplay
//       txa [newsetting]
//       txb [newsetting]
//       save (settings to tuning file)
//       load (tuning settings from EEPROM)
//
//       All [newsetting]'s are values 0-999

function SyncUSB($in){
global $rxmixerset,$txmixaset,$txmixbset,$Ltxmixaset,$Ltxmixbset,$Lrxmixerset,$invertptt,$Linvertptt;
global $fileUSB,$fileUSBtmp,$fileIN;
global $fileUSB2,$fileUSB2tmp,$fileIN2;

if ($rxmixerset<>$Lrxmixerset){$status= exec("sudo /bin/asterisk -rx \"susb tune rs $rxmixerset\" ",$output,$return_var);print"<!-- rs set to $rxmixerset -->";$Lrxmixerset=$rxmixerset;}
if ($txmixaset<>$Ltxmixaset)  {$status= exec("sudo /bin/asterisk -rx \"susb tune txa $txmixaset\" ",$output,$return_var);print"<!-- txa set to $txmixaset -->";$Ltxmixaset=$txmixaset;}
if ($txmixbset<>$Ltxmixbset)  {$status= exec("sudo /bin/asterisk -rx \"susb tune txb $txmixbset\" ",$output,$return_var);print"<!-- txb set to $txmixbset -->";$Ltxmixbset=$txmixbset;}



}



function Show_help($in){
global $width,$height,$in;
print "<a href=\"#\" onclick=\"window.open('/admin/help.php?help=$in', 'Help', 'width=$width,height=$height');\"><img src=\"/status/images/help.gif\"></a>";
}

?>
