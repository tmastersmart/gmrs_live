<?php
//
//   v1.1  New node manager expandable menu system
//   v1.2  Modified links to open a new window but stay in that window
//         as you navigate weather pages. and not open more than one.
//   v1.3  uses the names from the nodelist for the status pages
//   v1.4  conversion to menu with no node numbers. all nodes controled by ini setup
//   v1.5  7/6/24 minor tweeks
//   v1.6  
//   v1.7  2/25 no live status page updates  ( mods to make a adjustable menu)
// Start node manager custom auto upgrade menu system
$var1 = explode('/', $_SERVER['REQUEST_URI']);
$var2 = array_pop($var1);
$current_url = urldecode($var2);
$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]); // /srv/http/ or something else
$Dir = getcwd() ;
// print"<!-- $rootDir | $Dir | $var1 | $var2 | $current_url -->";
// Build the new menu

$menu1="";$menu2="";$menu3="";$menu4="";$menu5="";$menu6="";$name="";
$menu1Name="Node Manager";
$menu2Name="Weather";
$menu3Name="Bookmarks";
$menu4Name="GMRS Hub";
$menu5Name="FCC";
$menu6Name="Contact";

if (file_exists($NewMenu)) {
 $fileIN= file($NewMenu); 
 natsort($fileIN);
//$fileIN = a[a[:, 1].argsort()];

 foreach($fileIN as $line){
 $line = str_replace("\r", "", $line);
 $line = str_replace("\n", "", $line);
 $u = explode("|",$line);
 if($u[0]==$menu1Name){ $menu1 .= "<a target=_new href=\"$u[2]\" >$u[1]</a>\n";}
 if($u[0]==$menu2Name){ $menu2 .= "<a target=_new href=\"$u[2]\" >$u[1]</a>\n";}
 if($u[0]==$menu3Name){ $menu3 .= "<a target=_new href=\"$u[2]\" >$u[1]</a>\n";}
 if($u[0]==$menu4Name){ $menu4 .= "<a target=_new href=\"$u[2]\" >$u[1]</a>\n";}
 if($u[0]==$menu5Name){ $menu5 .= "<a target=_new href=\"$u[2]\" >$u[1]</a>\n";}
 if($u[0]==$menu6Name){ $menu6 .= "<a target=_new href=\"$u[2]\" >$u[1]</a>\n";}
 
 //Status Pages|Gmrs Live|http://gmrslive.com/status/link.php?nodes=700,611,900|700|
 
}

 
 
} 
 print "<!-- Start GMRS menu -->\n"; 
 print "<div id=\"menu\"><ul>\n";
 print "<li class=\"dropdown\"><div class=\"dropdown-content\">\n";
 print "</div></li>\n";

 if($menu1){
 print "<li class=\"dropdown\"><a href=\"#\" class=\"dropbtn\">$menu1Name</a><div class=\"dropdown-content\">\n";
 print $menu1;
 print "</div></li>\n";
 }
 if($menu2){ 
 print "<li class=\"dropdown\">&nbsp;<a href=\"#\" class=\"dropbtn\">$menu2Name</a><div class=\"dropdown-content\">\n";
 print $menu2;
 print "</div></li>\n";
 }
 
if($menu3){  
 print "<li class=\"dropdown\">&nbsp;<a href=\"#\" class=\"dropbtn\">$menu3Name</a><div class=\"dropdown-content\">\n";
 print $menu3;
 print "</div></li>\n";
 }
if($menu4){  
 print "<li class=\"dropdown\"><a href=\"#\" class=\"dropbtn\">$menu4Name</a><div class=\"dropdown-content\">\n";
 print $menu4;
 print "</div></li>\n";
 }
 

 if($menu5){  
 print "<li class=\"dropdown\"><a href=\"#\" class=\"dropbtn\">$menu5Name</a><div class=\"dropdown-content\">\n";
 print $menu5;
 print "</div></li>\n";
 }
 
 if($menu6){  
 print "<li class=\"dropdown\"><a href=\"#\" class=\"dropbtn\">$menu6Name</a><div class=\"dropdown-content\">\n";
 print $menu6;
 print "</div></li>\n";
 }
 
 print "</ul></div>\n";  
print "<!-- end GMRS menu -->\n";

?>

