<?php

print"
<html>
<head>
<title>Node search for all Nodes in the LINK</title>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">
<link type=\"text/css\" rel=\"stylesheet\" href=\"supermon.css\">
</head>
<body>
";
// <body style=\"background-color:powderblue;\">

$path="/etc/asterisk/local/mm-software";
include_once ("$path/load.php");

$DisplayNodes=true;
$popup=true;

include ("/etc/asterisk/local/mm-software/supermon_lnodes.php");
print"</body></html>";
?>
